// ============================================================================
//  ArchBB 1.83 — scoring.h · FASE 3 (porting scoring on-device)
//  Cesare Pagura · Padova/Noale IT · 11 luglio 2026
// ----------------------------------------------------------------------------
//  Macchina a stati dello scoring on-device, portata dalla 1.69 (v2.11.3) e
//  adattata alla 1.83. In Fase 3 NON ci sono ancora IMU e BLE: portiamo solo la
//  UI (le 3 schermate) e la logica. L'output e' una struct ScoreResult
//  autosufficiente: quando arriveranno IMU/BLE bastera' leggerla per popolare
//  lo ScorePacket, senza toccare la UI.
//
//  DIFFERENZE CHIAVE dalla 1.69 (perche' non e' un copia-incolla):
//   - Touch: usa il nostro modulo touch.h/.cpp gia' validato (config chip
//     corretta), NON il driver embedded in scoring_ui.cpp della 1.69.
//   - Pannello 240x284 (non 280): soglie zona ricalcolate in terzi puliti.
//   - Nessuno stato globale di firmware: lo scoring e' una sotto-macchina
//     autonoma che il main avvia e interroga.
// ----------------------------------------------------------------------------
#pragma once
#include <Arduino.h>
#include "touch.h"

// ----------------------------------------------------------------------------
//  Stati della sotto-macchina scoring.
// ----------------------------------------------------------------------------
enum class ScoringState : uint8_t {
  IDLE,        // inattiva (fuori dallo scoring)
  ESITO,       // schermata 1: colpito il bersaglio? (verde/rosso)
  ZONA,        // schermata 2: zona 3x3 (SPOT al centro se colpito)
  DISTANZA,    // schermata 3: DISTANZA + ELEVAZIONE (due slider, v2.16)
  DONE         // completata: ScoreResult pronto
};

// ----------------------------------------------------------------------------
//  Zona 3x3. Indice = colonna + 3*riga (come la 1.69).
// ----------------------------------------------------------------------------
//    0 = alto-sx    1 = alto     2 = alto-dx
//    3 = sx         4 = CENTRO   5 = dx
//    6 = basso-sx   7 = basso    8 = basso-dx
//  Semantica SPOT: se colpito E zona==4 (centro), l'etichetta e' "SPOT".
static constexpr uint8_t ZONA_CENTRO = 4;

// ----------------------------------------------------------------------------
//  ELEVAZIONE del bersaglio (v2.16 — portata dalla 1.69)
// ----------------------------------------------------------------------------
//  Il dato viene dal TELEMETRO (letto dall'arciere e digitato), NON dall'IMU.
//  Questa e' la differenza che governa tutto il design:
//
//    hold/release/cant/alzo nascono dai campioni grezzi -> se si perdono, si
//    RICALCOLANO. L'elevazione no: se non viene registrata al momento del tiro,
//    e' persa per sempre. Nessun calcolo la recupera.
//
//  Da qui la sentinella esplicita: ELEV_NOT_SET distingue "mai misurata" da
//  "misurata, tiro in piano". Lo ZERO NON puo' fare da sentinella perche' e' il
//  valore piu' FREQUENTE e legittimo (il tiro in piano). Confonderli
//  significherebbe non sapere piu', a posteriori, se un 0 nel CSV e' un dato o
//  un buco.
//
//    -128  = mai misurata (unico int8 fuori dal range +-127: non collide)
//       0  = misurata, tiro in piano
//   +-30   = range utile (un 3D oltre i 30 gradi non esiste in pratica)
static constexpr int8_t ELEV_MIN     = -30;
static constexpr int8_t ELEV_MAX     =  30;
static constexpr int8_t ELEV_NOT_SET = -128;

inline bool elevIsSet(int8_t e) { return e != ELEV_NOT_SET; }

// ----------------------------------------------------------------------------
//  Risultato dello scoring — la struct che il porting futuro leggera'.
// ----------------------------------------------------------------------------
//  Contiene TUTTO cio' che serve per costruire lo ScorePacket 1.69 (pkt_type
//  0x06) e la codifica ARCS, tranne gli angoli biomeccanici (cant/alzo) che
//  arriveranno con l'IMU. I campi angolo sono gia' previsti qui a 0 per non
//  cambiare la struct dopo.
struct ScoreResult {
  bool     valutato;    // true se lo scoring e' stato completato (non SKIP/timeout)
  bool     colpito;     // true = freccia sul bersaglio
  uint8_t  zona;        // 0..8 (valida solo se colpito); 4=centro
  uint8_t  distanza_m;  // metri: 0=ignota, altrimenti 5..60 (INCLINATA, line-of-sight)
  int16_t  arcs;        // codifica ARCS = ±(dist*10 + (zona+1)); 0 = non valutato
  // --- ANGOLI d'assetto (Fase 4c: popolati da shot_angles_compute) ---
  int16_t  cant_cdeg;   // centesimi di grado (+dx / -sx)
  int16_t  alzo_cdeg;   // centesimi di grado (+punta su / -giu)
  // --- v2.16: elevazione del bersaglio dal telemetro ---
  // Campo NUOVO in coda alla struct: stessa regola dei pacchetti BLE e delle
  // colonne CSV (i campi nuovi vanno SEMPRE in fondo, mai in mezzo).
  int8_t   elev_deg;    // gradi interi; ELEV_NOT_SET = mai misurata

  // ==========================================================================
  //  FASE 4c — METRICHE BIOMECCANICHE dal burst IMU
  // ==========================================================================
  //  Aggiunte IN CODA (mai in mezzo): quando arrivera' il ScorePacket BLE e il
  //  salvataggio su SD, questi campi si serializzano in fondo, senza rompere la
  //  compatibilita' dei formati gia' esistenti. Sono l'output diretto di
  //  ShotAngles, gia' pronti per il display e per la futura persistenza.
  //
  //  I *_valid distinguono \"non calcolato\" da \"calcolato = 0\": un hold_deg=0
  //  con hold_valid=false e' un buco (burst troncato), non una tenuta perfetta.
  //  Stessa filosofia della sentinella elev, applicata alle metriche.
  bool     angles_valid;   // finestra pre-scocco sufficiente -> cant/alzo validi
  bool     angles_stable;  // finestra STABILE (|g|~9.8, sd bassa) -> assetto affidabile
  //  cant/alzo sono gia' sopra in centesimi (cant_cdeg/alzo_cdeg).
  bool     hold_valid;     // post-scocco sufficiente -> hold calcolato
  int16_t  hold_cdeg;      // follow-through: variazione elevazione a +900ms [cdeg]
  uint8_t  hold_class;     // HoldClass (TENUTO/LIEVE/ABBASSATO/ALZATO/NA)
  bool     release_valid;  // finestra 40ms sufficiente -> jerk calcolato
  uint16_t release_jerk;   // pulizia rilascio: max |d(ay)/dt| nei 40ms [m/s^3]
  uint8_t  release_class;  // ReleaseClass (PULITO/MEDIO/STRAPPO/NA)
};

// ----------------------------------------------------------------------------
//  Codifica ARCS (identica alla 1.69, verificata su 1026 casi).
// ----------------------------------------------------------------------------
//  ARCS = ±(distanza*10 + (zona+1)). zona+1 in [1..9] cosi' le unita' non sono
//  mai 0 (distinguibile da "non valutato"=0). Segno: + se colpito, - se fuori.
int16_t encodeArcs(bool colpito, uint8_t zona, uint8_t distanza);

// Etichetta leggibile della zona: "SPOT" se colpito+centro, altrimenti
// direzionale (alto-sx, centro, dx, ...).
const char* zonaLabel(bool colpito, uint8_t zona);

// ----------------------------------------------------------------------------
//  API della sotto-macchina
// ----------------------------------------------------------------------------

// Avvia lo scoring: entra nello stato ESITO e disegna la prima schermata.
// shotId: identificativo del tiro (per il futuro ScorePacket; in Fase 3 e'
// solo un contatore mostrato a schermo).
void scoringStart(uint16_t shotId);

// Riapre lo scoring del tiro CORRENTE mantenendo le scelte gia' fatte (per il
// re-editing dal riepilogo tramite CORREGGI). Riparte dalla schermata ESITO ma
// colpito/zona/distanza restano quelli precedenti come punto di partenza.
void scoringResume();

// Da chiamare nel loop passando l'ultimo campione touch. Fa avanzare la
// macchina, ridisegna se serve, gestisce il timeout. Ritorna lo stato corrente.
// Quando ritorna DONE, il risultato e' pronto (scoringGetResult).
ScoringState scoringUpdate(const TouchData& td);

// True se la macchina e' attiva (non IDLE, non DONE).
bool scoringActive();

// Stato corrente.
ScoringState scoringGetState();

// Risultato finale (valido dopo DONE).
ScoreResult scoringGetResult();
