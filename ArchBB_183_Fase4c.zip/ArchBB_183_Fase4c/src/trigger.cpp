// ============================================================================
//  ArchBB 1.83 — trigger.cpp · FASE 4a (rilevazione tiro reale) · v1
//  Cesare Pagura · Padova/Noale IT · 13 luglio 2026
// ----------------------------------------------------------------------------
//  Macchina a stati portata dalla 1.69 v2.12.6. In Fase 4b il FIRED congela il
//  circular buffer (circular_buffer_freeze). Ancora niente semaforo verso un
//  task BLE (non c'e' BLE): il semaforo g_trigger_fired_sem va al task UI.
//    - "armato" non e' legato a g_recording_enabled (BLE) ma a un flag
//      controllato dal main: armato SOLO in ATTESA (vedi trigger.h).
//
//  Il resto della logica e' invariato perche' e' quella COLLAUDATA: gate sul
//  seq del campione (anti doppio-conteggio, perche' il task gira piu' veloce di
//  quanto arrivino i campioni), confirm_n consecutivi, rearm, trigger manuale
//  con fire immediato.
// ============================================================================
#include "trigger.h"
#include "imu.h"
#include "circular_buffer.h"

// ----------------------------------------------------------------------------
//  Variabili globali
// ----------------------------------------------------------------------------
SemaphoreHandle_t     g_trigger_fired_sem = nullptr;
volatile uint16_t     g_shot_id           = 0;
volatile float        g_trigger_az_peak   = 0.0f;
volatile TriggerPhase g_trigger_phase     = TRIG_IDLE;

// Config locale (dai default di config.h; in futuro modificabile via BLE).
static TriggerMode s_mode      = TRIG_DEFAULT_MODE;
static float       s_threshold = TRIG_DEFAULT_THRESHOLD;
static uint8_t     s_confirm_n = TRIG_DEFAULT_CONFIRM_N;
static uint16_t    s_rearm_ms  = TRIG_DEFAULT_REARM_MS;
static float       s_odr_hz    = 224.0f;

// Fase 4b: finestra del burst in campioni (calcolata dall'ODR reale in init).
static uint16_t    s_pre_samples  = 0;
static uint16_t    s_post_samples = 0;

// Stato interno.
static uint8_t       s_confirm_count  = 0;
static float         s_az_prev        = 0.0f;
static uint16_t      s_last_seq       = 0xFFFF;   // ultimo seq valutato
static volatile bool s_armed          = false;    // controllato dal main
static volatile bool s_manual_trigger = false;

// ----------------------------------------------------------------------------
void trigger_init() {
  g_trigger_fired_sem = xSemaphoreCreateBinary();
  if (!g_trigger_fired_sem) { DBG("ERRORE: trigger semaforo fallito"); }

  s_odr_hz = (float)odrToHz(ODR_250HZ);
  s_pre_samples  = calcPreSamples(ODR_250HZ);
  s_post_samples = calcPostSamples(ODR_250HZ);
  g_shot_id       = 0;
  g_trigger_phase = TRIG_IDLE;
  s_confirm_count = 0;
  s_az_prev       = 0.0f;
  s_last_seq      = 0xFFFF;
  s_armed         = false;
  s_manual_trigger = false;
  DBG("Trigger init OK — mode=%d soglia=%.1f confirm_n=%d rearm=%dms",
      (int)s_mode, s_threshold, s_confirm_n, s_rearm_ms);
}

void trigger_set_armed(bool armed) {
  s_armed = armed;
}

void trigger_manual() {
  s_manual_trigger = true;
}

// ----------------------------------------------------------------------------
//  trigger_task — Core 1.
// ----------------------------------------------------------------------------
void trigger_task(void* param) {
  DBG("trigger_task avviato su Core %d", xPortGetCoreID());

  while (!g_imu_ok) { vTaskDelay(pdMS_TO_TICKS(10)); }

  uint32_t rearm_start_ms = 0;

  for (;;) {
    // Legge il campione piu' recente sotto mutex.
    ImuSample sample;
    bool got = false;
    if (xSemaphoreTake(g_imu_sample_mutex, pdMS_TO_TICKS(2)) == pdTRUE) {
      sample = g_latest_sample;
      got = true;
      xSemaphoreGive(g_imu_sample_mutex);
    }
    if (!got) { vTaskDelay(pdMS_TO_TICKS(1)); continue; }

    // "Freschezza": la valutazione automatica avviene SOLO su campione nuovo
    // (seq diverso). Le transizioni interne (FIRED/REARM) avanzano comunque.
    bool fresh = (sample.seq != s_last_seq);

    switch (g_trigger_phase) {

      case TRIG_IDLE:
        // Disarmato: azzera lo stato e passa ad ARMED solo quando il main arma.
        s_confirm_count = 0;
        s_az_prev = sample.az;
        if (s_armed) {
          g_trigger_phase = TRIG_ARMED;
          DBG("Trigger ARMED (soglia=%.1f)", s_threshold);
        }
        break;

      case TRIG_ARMED:
      case TRIG_CONFIRMING:
        // Se il main disarma (scoring iniziato), torna IDLE.
        if (!s_armed) {
          g_trigger_phase = TRIG_IDLE;
          s_confirm_count = 0;
          break;
        }
        {
          // Trigger manuale: fire immediato, bypassa soglia e confirm_n.
          if (s_manual_trigger) {
            s_manual_trigger  = false;
            g_trigger_az_peak = sample.az;
            g_trigger_phase   = TRIG_FIRED;
            DBG("Trigger MANUALE -> FIRED");
            break;
          }

          // Valutazione automatica solo su campione nuovo.
          if (!fresh) break;
          s_last_seq = sample.seq;

          bool condition = false;
          if (s_mode == TRIG_AZ_THRESHOLD) {
            condition = (fabsf(sample.az) > s_threshold);
          } else {  // TRIG_JERK
            float dt   = 1.0f / s_odr_hz;
            float jerk = fabsf((fabsf(sample.az) - fabsf(s_az_prev)) / dt);
            condition  = (jerk > s_threshold);
          }

          if (condition) {
            s_confirm_count++;
            if (fabsf(sample.az) > fabsf(g_trigger_az_peak))
              g_trigger_az_peak = sample.az;
            g_trigger_phase = (s_confirm_count >= s_confirm_n)
                              ? TRIG_FIRED : TRIG_CONFIRMING;
          } else {
            s_confirm_count   = 0;
            g_trigger_az_peak = 0.0f;
            g_trigger_phase   = TRIG_ARMED;
          }
          s_az_prev = sample.az;
        }
        break;

      case TRIG_FIRED:
        g_shot_id++;
        DBG("TRIGGER! shot_id=%u az_peak=%.2f m/s^2", g_shot_id, g_trigger_az_peak);
        // Fase 4b: congela la finestra PRE+POST attorno allo scocco. Va fatto
        // PRIMA di postare il semaforo, cosi' quando la UI reagisce il buffer
        // sta gia' raccogliendo i POST campioni.
        circular_buffer_freeze(s_pre_samples, s_post_samples, g_shot_id);
        // Notifica il main: c'e' un tiro da valutare.
        xSemaphoreGive(g_trigger_fired_sem);
        rearm_start_ms  = millis();
        g_trigger_phase = TRIG_REARM;
        break;

      case TRIG_REARM:
        if ((millis() - rearm_start_ms) >= s_rearm_ms) {
          s_confirm_count   = 0;
          g_trigger_az_peak = 0.0f;
          s_manual_trigger  = false;   // scarta un manuale arrivato nel rearm
          // Dopo il rearm, torna ARMED solo se il main ci vuole ancora armati
          // (di norma NO: siamo entrati in scoring; il main riarmera' in ATTESA).
          g_trigger_phase = s_armed ? TRIG_ARMED : TRIG_IDLE;
          DBG("Trigger REARMED");
        }
        break;
    }

    // Periodo ~3ms: lascia margine rispetto al periodo campioni (~4.5ms @224Hz).
    vTaskDelay(pdMS_TO_TICKS(3));
  }
  vTaskDelete(nullptr);
}
