// ============================================================================
//  ArchBB 1.83 — scoring.cpp · FASE 3 (porting scoring on-device) · v3
//  Cesare Pagura · Padova/Noale IT · 11 luglio 2026
// ----------------------------------------------------------------------------
//  CORREZIONI v3 (feedback di campo):
//   1) Azione "nervosa" -> DEBOUNCE + COOLDOWN. Il rilascio deve essere stabile
//      per N campioni consecutivi prima di contare come tap (elimina i micro-
//      rimbalzi valido/non-valido del CST816 allo stacco del dito), e un
//      cooldown minimo tra due azioni impedisce il doppio-scatto. Reattivo ma
//      stabile (tecnica standard: debounce-out + throttle "primo evento").
//   2) BREADCRUMB in alto nelle schermate ZONA e DISTANZA: mostra le scelte
//      gia' fatte (esito, e nella distanza anche la zona), cosi' si ha sempre
//      contezza del percorso, non solo alla fine.
//   3) NIENTE "INDIETRO" nella schermata ESITO: e' il primo passo, non c'e' un
//      "prima". Li' resta solo SALTA. L'INDIETRO vive in ZONA e DISTANZA.
// ============================================================================
#include "scoring.h"
#include "display.h"
#include <TFT_eSPI.h>

static constexpr int THR_X_LC = 80, THR_X_CR = 160;
static constexpr int THR_Y_TM = 95, THR_Y_MB = 189;
static constexpr uint32_t SCORING_TIMEOUT_MS = 60000;

static constexpr int NAV_H = 40;
static constexpr int NAV_Y = ARCHBB_H - NAV_H;

// ============================================================================
//  LAYOUT DIST + ELEV (portato dalla 1.69 v2.16.10)
// ============================================================================
//  LA LEZIONE PIU' COSTOSA DELLA 1.69, APPLICATA QUI DALL'INIZIO:
//
//    "Se un fatto e' scritto in due posti, prima o poi divergono."
//
//  Sulla 1.69 il disegno usava le costanti (KEY_Y=191, BTN_TOP=235) e l'handler
//  aveva i NUMERI SCRITTI A MANO della versione precedente (190, 150..180).
//  Risultato: toccavi "+" e partiva OK. Otto versioni spese a calibrare un touch
//  che era gia' a posto, mentre il bug era un letterale in una riga.
//
//  Percio' QUI: disegno e handler leggono le STESSE costanti. Nessun letterale
//  di posizione negli handler. Se un tasto si sposta, si sposta in un punto solo.
//
//  GEOMETRIA — perche' si rimappa da sola da 280 (1.69) a 284 (1.83):
//  BTN_TOP e KEY_Y sono DERIVATE da ARCHBB_H, non assolute. I 4px in piu' della
//  1.83 diventano automaticamente respiro fra lo slider ELEV e i tasti (43 ->
//  47px), senza toccare nulla. Gli slider restano a quote assolute perche' sono
//  ancorati alla parte alta.
// ----------------------------------------------------------------------------
static constexpr uint8_t DIST_MIN = 5;
static constexpr uint8_t DIST_MAX = 60;

// --- binario condiviso dai due slider ---
static constexpr int16_t SLD_X0 = 24;                  // inizio barra
static constexpr int16_t SLD_X1 = ARCHBB_W - 24;       // fine barra (216)
static constexpr int16_t SLD_W  = SLD_X1 - SLD_X0;     // larghezza utile (192)
static constexpr int16_t SLD_HIT = 16;                 // semi-altezza fascia tattile

// --- quote verticali ---
//  [1] i due slider ben staccati (79px fra gli assi): sulla 1.69 avvicinarli
//      causava tocchi che finivano sullo slider sbagliato.
//  [2] BTN_GUARD: zona morta sopra i pulsanti. Il tap che "scivola" giu' dal
//      tasto "+" non deve cementare un OK.
static constexpr int16_t SLD_Y_DIST = 69;
static constexpr int16_t SLD_Y_ELEV = 148;
static constexpr int16_t DIVIDER_Y  = 96;              // riga fra i due slider

static constexpr int16_t BTN_H     = 45;                     // INDIETRO/OK
static constexpr int16_t BTN_TOP   = ARCHBB_H - BTN_H;       // 239 su 1.83
static constexpr int16_t BTN_GUARD = 12;                     // zona morta
static constexpr int16_t KEY_H     = 32;                     // tasti -/?/+
static constexpr int16_t KEY_Y     = BTN_TOP - BTN_GUARD - KEY_H;   // 195 su 1.83

// --- tasti -/?/+ (X) --------------------------------------------------------
//  DUE geometrie DISTINTE e VOLUTE (attenzione a non confonderle: e' proprio la
//  situazione della lezione §4.1, qui gestita esplicitamente coi nomi):
//
//   _HIT  = zona TATTILE. I tasti - e + arrivano fino al BORDO dello schermo.
//           Cosi' un tocco verso il bordo NON PUO' cadere "fuori": si elimina
//           una classe intera di errori invece di curarla con la calibrazione.
//           E' l'idea di Cesare, ed e' quella giusta: niente margine = niente
//           "appena fuori".
//   _DRAW = rettangolo DISEGNATO. Resta rientrato dai bordi, per estetica (un
//           tasto incollato al vetro sta male). Il disegno e' piu' piccolo della
//           zona attiva: la zona sensibile "sborda" oltre il rettangolo, verso
//           il bordo, ed e' esattamente cio' che vogliamo.
//
//  Regola per non ricascare nel bug: il DISEGNO usa _DRAW, l'HANDLER usa _HIT.
//  Sono due intenzioni diverse, non due copie che possono divergere.
static constexpr int16_t KEY_MINUS_HIT_X0 = 0;              // fino al bordo sx
static constexpr int16_t KEY_MINUS_HIT_X1 = 76;
static constexpr int16_t KEY_IGN_HIT_X0   = 84;
static constexpr int16_t KEY_IGN_HIT_X1   = 156;
static constexpr int16_t KEY_PLUS_HIT_X0  = 164;
static constexpr int16_t KEY_PLUS_HIT_X1  = ARCHBB_W;       // fino al bordo dx

static constexpr int16_t KEY_MINUS_DRAW_X0 = 16;
static constexpr int16_t KEY_MINUS_DRAW_X1 = 64;
static constexpr int16_t KEY_IGN_DRAW_X0   = ARCHBB_W/2 - 28;
static constexpr int16_t KEY_IGN_DRAW_X1   = ARCHBB_W/2 + 28;
static constexpr int16_t KEY_PLUS_DRAW_X0  = ARCHBB_W - 64;
static constexpr int16_t KEY_PLUS_DRAW_X1  = ARCHBB_W - 16;

// Lo ZERO dell'elevazione sta al centro esatto della barra.
static constexpr int16_t ELEV_X_ZERO = SLD_X0 + SLD_W / 2;   // 120

// --- FOCUS: su quale slider agiscono i tasti +/- ---------------------------
// I due slider condividono una sola coppia di tasti fini. Il focus dice su chi
// agiscono, e il COLORE del bordo lo comunica (ciano=distanza, ambra=elevazione)
// senza bisogno di un'etichetta in piu'.
enum SliderFocus : uint8_t { FOCUS_DIST = 0, FOCUS_ELEV = 1 };
static SliderFocus s_focus = FOCUS_DIST;

// --- mappa distanza <-> x --------------------------------------------------
// Arrotondamento al PIU' VICINO (il +meta'-divisore prima della divisione): con
// il troncamento il round-trip x->valore->x perdeva un'unita' e certe tacche non
// erano raggiungibili toccando la propria posizione.
static int16_t distToX(uint8_t d) {
  if (d < DIST_MIN) d = DIST_MIN;
  if (d > DIST_MAX) d = DIST_MAX;
  return SLD_X0 + (int16_t)(((int32_t)(d - DIST_MIN) * SLD_W
                             + (DIST_MAX - DIST_MIN) / 2) / (DIST_MAX - DIST_MIN));
}
static uint8_t xToDist(int16_t x) {
  if (x < SLD_X0) x = SLD_X0;
  if (x > SLD_X1) x = SLD_X1;
  int v = DIST_MIN + (int)(((int32_t)(x - SLD_X0) * (DIST_MAX - DIST_MIN)
                            + SLD_W / 2) / SLD_W);
  if (v < DIST_MIN) v = DIST_MIN;
  if (v > DIST_MAX) v = DIST_MAX;
  return (uint8_t)v;
}

// --- mappa elevazione <-> x ------------------------------------------------
static int16_t elevToX(int8_t e) {
  if (!elevIsSet(e)) e = 0;
  if (e < ELEV_MIN) e = ELEV_MIN;
  if (e > ELEV_MAX) e = ELEV_MAX;
  return SLD_X0 + (int16_t)(((int32_t)(e - ELEV_MIN) * SLD_W
                             + (ELEV_MAX - ELEV_MIN) / 2) / (ELEV_MAX - ELEV_MIN));
}
static int8_t xToElev(int16_t x) {
  if (x < SLD_X0) x = SLD_X0;
  if (x > SLD_X1) x = SLD_X1;
  int v = ELEV_MIN + (int)(((int32_t)(x - SLD_X0) * (ELEV_MAX - ELEV_MIN)
                            + SLD_W / 2) / SLD_W);
  if (v < ELEV_MIN) v = ELEV_MIN;
  if (v > ELEV_MAX) v = ELEV_MAX;
  // SNAP A ZERO (+-2 gradi): il tiro in piano e' il caso piu' frequente e deve
  // essere raggiungibile senza mirare col dito. Senza snap un tap impreciso
  // produce +1/-1 spuri: rumore che nel gesto reale non esiste ma che nel CSV
  // sarebbe indistinguibile da una misura vera.
  if (v >= -2 && v <= 2) v = 0;
  return (int8_t)v;
}

// --- Parametri debounce/cooldown -------------------------------------------
// Il loop gira ~ogni 20ms (delay(20) nel main). 2 campioni stabili = ~40ms di
// rilascio confermato. Cooldown 180ms: abbastanza per evitare il doppio-tap,
// ma piu' reattivo per tocchi intenzionali consecutivi (es. tacca -> CONFERMA,
// che con 250ms risultava "pigra").
static constexpr uint8_t  RELEASE_STABLE_N   = 2;
static constexpr uint32_t ACTION_COOLDOWN_MS = 180;

// ----------------------------------------------------------------------------
static ScoringState s_state   = ScoringState::IDLE;
static ScoreResult  s_result;
static uint16_t     s_shotId  = 0;
static uint32_t     s_lastTouchMs  = 0;
static uint32_t     s_lastActionMs = 0;
static bool         s_needRedraw   = true;
static uint8_t      s_distSel      = 18;
// v2.16: elevazione del bersaglio. Parte SEMPRE dalla sentinella, mai da 0:
// "non l'ho ancora misurata" e "e' in piano" sono due fatti diversi, e solo il
// tocco dell'arciere trasforma il primo nel secondo.
static int8_t       s_elevSel      = ELEV_NOT_SET;

// Debounce state.
static bool     s_stableTouch = false;   // stato "tocco" debounced
static uint8_t  s_relCount    = 0;        // campioni consecutivi di non-tocco
static uint16_t s_pressX = 0, s_pressY = 0;

// ============================================================================
int16_t encodeArcs(bool colpito, uint8_t zona, uint8_t distanza) {
  int16_t mag = (int16_t)distanza * 10 + (zona + 1);
  return colpito ? mag : (int16_t)(-mag);
}

static const char* ZONA_NOME[9] = {
  "alto-sx","alto","alto-dx","sx","centro","dx","basso-sx","basso","basso-dx"
};
const char* zonaLabel(bool colpito, uint8_t zona) {
  if (colpito && zona == ZONA_CENTRO) return "SPOT";
  if (zona < 9) return ZONA_NOME[zona];
  return "";
}
static uint8_t coordToZona(uint16_t x, uint16_t y) {
  uint8_t col = (x < THR_X_LC) ? 0 : (x < THR_X_CR ? 1 : 2);
  uint8_t row = (y < THR_Y_TM) ? 0 : (y < THR_Y_MB ? 1 : 2);
  return col + 3 * row;
}
// NB: drawPlus()/drawMinus() sono stati RIMOSSI in v2.16: li usava solo la
// vecchia schermata distanza (tacche 18/30/50 + CONFERMA a barra), sostituita
// dal doppio slider. I glifi +/- ora si disegnano inline nei tasti, che hanno
// una geometria propria. Codice morto tolto invece che lasciato "per sicurezza":
// e' esattamente il tipo di residuo che poi qualcuno riusa per sbaglio.
static void kickTimeout() { s_lastTouchMs = millis(); }

// Breadcrumb: riga in alto con le scelte gia' fatte.
static void drawBreadcrumb(bool showZona) {
  tft.setTextDatum(TC_DATUM);
  char bc[40];
  const char* esito = s_result.colpito ? "COLPITO" : "MANCATO";
  if (showZona) {
    snprintf(bc, sizeof(bc), "%s  >  %s", esito,
             zonaLabel(s_result.colpito, s_result.zona));
  } else {
    snprintf(bc, sizeof(bc), "%s", esito);
  }
  uint16_t col = s_result.colpito ? ArchColor::GOOD : ArchColor::BAD;
  tft.setTextColor(col, ArchColor::BG);
  tft.drawString(bc, ARCHBB_W/2, 4, 2);
}

// Barra nav: INDIETRO (opzionale) a sx, azione (opzionale) a dx.
static void drawNavBar(bool showBack, const char* rightLabel, uint16_t rightColor) {
  if (showBack) {
    tft.fillRoundRect(6, NAV_Y + 3, 96, NAV_H - 6, 6, ArchColor::BG_CARD);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(ArchColor::TEXT2, ArchColor::BG_CARD);
    tft.drawString("< INDIETRO", 6 + 48, NAV_Y + NAV_H/2, 2);
  }
  if (rightLabel) {
    tft.fillRoundRect(ARCHBB_W - 6 - 96, NAV_Y + 3, 96, NAV_H - 6, 6, rightColor);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(ArchColor::TEXT, rightColor);
    tft.drawString(rightLabel, ARCHBB_W - 6 - 48, NAV_Y + NAV_H/2, 2);
  }
}
static uint8_t hitNavBar(uint16_t x, uint16_t y, bool hasBack, bool hasRight) {
  if (y < NAV_Y) return 0;
  if (hasBack  && x >= 6 && x < 6 + 96) return 1;
  if (hasRight && x >= ARCHBB_W - 6 - 96 && x < ARCHBB_W - 6) return 2;
  return 0;
}

// ============================================================================
//  Rendering
// ============================================================================
static void drawEsitoScreen() {
  tft.fillScreen(ArchColor::BG);
  tft.setTextDatum(TC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  char t[24]; snprintf(t, sizeof(t), "TIRO #%u", s_shotId);
  tft.drawString(t, ARCHBB_W/2, 8, 2);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString("Colpito il bersaglio?", ARCHBB_W/2, 30, 2);

  const int bx = 20, bw = ARCHBB_W - 40, bh = 72;
  const int y1 = 54, y2 = 54 + bh + 12;
  tft.fillRoundRect(bx, y1, bw, bh, 10, ArchColor::GOOD);
  tft.fillRoundRect(bx, y2, bw, bh, 10, ArchColor::BAD);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT, ArchColor::GOOD);
  tft.drawString("COLPITO", ARCHBB_W/2, y1 + bh/2, 4);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BAD);
  tft.drawString("MANCATO", ARCHBB_W/2, y2 + bh/2, 4);

  // Nav: NIENTE indietro (primo passo). Solo SALTA a destra.
  drawNavBar(false, "SALTA", ArchColor::BORDER);
}

static void drawZonaScreen() {
  tft.fillScreen(ArchColor::BG);
  drawBreadcrumb(false);   // mostra solo l'esito
  tft.setTextDatum(TC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString(s_result.colpito ? "Dove ha colpito?" : "Dove ha mancato?",
                 ARCHBB_W/2, 22, 2);

  const int gx = 10, gy = 44;
  const int gw = ARCHBB_W - 20, gh = ARCHBB_H - 44 - NAV_H - 4;
  const int cw = gw/3, ch = gh/3;

  for (int r = 0; r < 3; r++) {
    for (int c = 0; c < 3; c++) {
      int x = gx + c*cw, y = gy + r*ch;
      uint8_t z = c + 3*r;
      bool isCenter = (z == ZONA_CENTRO);
      bool disabled = isCenter && !s_result.colpito;

      uint16_t fill; const char* lbl; uint16_t tc;
      if (disabled)                        { fill = ArchColor::BG;      lbl = "--";   tc = ArchColor::BORDER; }
      else if (isCenter && s_result.colpito){ fill = ArchColor::AMBER;  lbl = "SPOT"; tc = ArchColor::BG; }
      else                                 { fill = ArchColor::BG_CARD; lbl = ZONA_NOME[z]; tc = ArchColor::TEXT2; }

      tft.fillRoundRect(x + 2, y + 2, cw - 4, ch - 4, 6, fill);
      tft.drawRoundRect(x + 2, y + 2, cw - 4, ch - 4, 6,
                        disabled ? ArchColor::BG_CARD : ArchColor::BORDER);
      tft.setTextDatum(MC_DATUM);
      tft.setTextColor(tc, fill);
      tft.drawString(lbl, x + cw/2, y + ch/2, 2);
    }
  }
  drawNavBar(true, nullptr, 0);   // solo INDIETRO
}

// --- Helper: binario slider con porzione attiva e tacca ---------------------
// Fattorizzato perche' i due slider differiscono SOLO per dove parte la porzione
// attiva: la distanza riempie da SINISTRA (grandezza monopolare: "quanto"),
// l'elevazione riempie DALLO ZERO CENTRALE (bipolare: "da che parte, e quanto").
// Rendere visibile questa differenza e' il punto: la barra comunica la natura
// del dato prima ancora che si legga il numero.
static void drawSliderTrack(int16_t yAxis, int16_t xFrom, int16_t xTo,
                            uint16_t col, bool showKnob) {
  tft.fillRoundRect(SLD_X0, yAxis - 3, SLD_W, 6, 3, ArchColor::BORDER);
  if (!showKnob) return;
  int16_t a = (xFrom < xTo) ? xFrom : xTo;
  int16_t b = (xFrom < xTo) ? xTo   : xFrom;
  if (b > a) tft.fillRoundRect(a, yAxis - 3, b - a, 6, 3, col);
  // tacca: cerchio pieno con foro -> anello spesso, ben visibile anche al sole
  tft.fillCircle(xTo, yAxis, 10, col);
  tft.fillCircle(xTo, yAxis, 5, ArchColor::BG);
}

// ============================================================================
//  Schermata 3: DISTANZA + ELEVAZIONE (v2.16, portata dalla 1.69)
// ============================================================================
//  PERCHE' I DUE DATI STANNO IN UNA SCHERMATA SOLA
//    Arrivano dallo STESSO gesto: il telemetro li mostra insieme, nella stessa
//    lettura. Separarli costringerebbe a memorizzare un numero mentre si naviga
//    — esattamente il carico cognitivo che lo scoring on-device esiste per
//    evitare. Sequenza tipica dopo una lettura (27 m, +12 gradi):
//      tap sullo slider distanza -> tap sullo slider elevazione -> OK.
//    Tre tocchi per due dati.
// ----------------------------------------------------------------------------
static void drawDistanzaScreen() {
  tft.fillScreen(ArchColor::BG);
  drawBreadcrumb(true);    // esito > zona

  const bool ignota   = (s_distSel == 0);
  const bool elev_set = elevIsSet(s_elevSel);
  // Se non impostata si DISEGNA 0 (default fisico sensato) ma il valore
  // TRASMESSO resta la sentinella: il colore grigio dice "non l'hai ancora
  // toccata", senza costringere a un tocco in piu' sul caso piu' frequente.
  const int8_t elev_shown = elev_set ? s_elevSel : 0;

  // ================= SLIDER 1: DISTANZA =================
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(s_focus == FOCUS_DIST ? ArchColor::ACCENT : ArchColor::TEXT3,
                   ArchColor::BG);
  tft.drawString("DISTANZA", 12, 30, 2);
  tft.setTextDatum(MC_DATUM);
  if (ignota) {
    tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
    tft.drawString("IGN", 170, 40, 4);
  } else {
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    char buf[8]; snprintf(buf, sizeof(buf), "%u", s_distSel);
    tft.drawString(buf, 165, 40, 6);          // font 6: solo cifre -> ok
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("m", 200, 46, 2);
  }
  drawSliderTrack(SLD_Y_DIST, SLD_X0, distToX(s_distSel), ArchColor::ACCENT, !ignota);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.setTextDatum(TL_DATUM);
  { char lo[4]; snprintf(lo, sizeof(lo), "%u", DIST_MIN);
    tft.drawString(lo, SLD_X0 - 4, SLD_Y_DIST + 10, 1); }
  tft.setTextDatum(TR_DATUM);
  { char hi[4]; snprintf(hi, sizeof(hi), "%u", DIST_MAX);
    tft.drawString(hi, SLD_X1 + 4, SLD_Y_DIST + 10, 1); }
  tft.setTextDatum(MC_DATUM);

  // divisore fra i due slider
  tft.drawFastHLine(12, DIVIDER_Y, ARCHBB_W - 24, ArchColor::BORDER);

  // ================= SLIDER 2: ELEVAZIONE =================
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(s_focus == FOCUS_ELEV ? ArchColor::AMBER : ArchColor::TEXT3,
                   ArchColor::BG);
  tft.drawString("ELEVAZIONE", 12, 108, 2);
  tft.setTextDatum(MC_DATUM);
  {
    // Il segno E' parte del dato, non un ornamento: "+12" e "-12" sono due tiri
    // opposti. FONT 4 e NON font 6: il font 6 di TFT_eSPI e' solo numerico e NON
    // ha il glifo '+' (lezione gia' pagata sulla 1.69).
    char buf[8]; snprintf(buf, sizeof(buf), "%+d", (int)elev_shown);
    tft.setTextColor(elev_set ? ArchColor::AMBER : ArchColor::TEXT3, ArchColor::BG);
    tft.drawString(buf, 168, 118, 4);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("o", 200, 112, 2);   // 'o' come simbolo di grado
  }
  drawSliderTrack(SLD_Y_ELEV, ELEV_X_ZERO, elevToX(elev_shown),
                  elev_set ? ArchColor::AMBER : ArchColor::BORDER, true);
  // tacca dello ZERO: marcata SEMPRE. Il tiro in piano e' il caso piu' frequente
  // e deve avere un riferimento visivo fisso.
  tft.drawFastVLine(ELEV_X_ZERO, SLD_Y_ELEV - 9, 18, ArchColor::TEXT3);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.setTextDatum(TL_DATUM);
  tft.drawString("-30", SLD_X0 - 6, SLD_Y_ELEV + 10, 1);
  tft.setTextDatum(TC_DATUM);
  tft.drawString("0", ELEV_X_ZERO, SLD_Y_ELEV + 10, 1);
  tft.setTextDatum(TR_DATUM);
  tft.drawString("+30", SLD_X1 + 6, SLD_Y_ELEV + 10, 1);
  tft.setTextDatum(MC_DATUM);

  // ================= TASTI  -  /  ?  /  + =================
  // CONTESTUALI: agiscono sullo slider col focus. Il colore del bordo dice su
  // cosa agiranno (ciano=distanza, ambra=elevazione): l'informazione sta nel
  // colore, non in un'etichetta che ruberebbe spazio.
  const uint16_t fcol = (s_focus == FOCUS_DIST) ? ArchColor::ACCENT : ArchColor::AMBER;
  const uint16_t fdim = ArchColor::BG_CARD;
  // "-"
  tft.fillRect(KEY_MINUS_DRAW_X0, KEY_Y, KEY_MINUS_DRAW_X1-KEY_MINUS_DRAW_X0, KEY_H, fdim);
  tft.drawRect(KEY_MINUS_DRAW_X0, KEY_Y, KEY_MINUS_DRAW_X1-KEY_MINUS_DRAW_X0, KEY_H, fcol);
  { int16_t cx = (KEY_MINUS_DRAW_X0+KEY_MINUS_DRAW_X1)/2, cy = KEY_Y + KEY_H/2;
    tft.fillRect(cx - 10, cy - 2, 20, 4, fcol); }
  // "+" (disegnato geometricamente: font 6 non ha il glifo)
  tft.fillRect(KEY_PLUS_DRAW_X0, KEY_Y, KEY_PLUS_DRAW_X1-KEY_PLUS_DRAW_X0, KEY_H, fdim);
  tft.drawRect(KEY_PLUS_DRAW_X0, KEY_Y, KEY_PLUS_DRAW_X1-KEY_PLUS_DRAW_X0, KEY_H, fcol);
  { int16_t cx = (KEY_PLUS_DRAW_X0+KEY_PLUS_DRAW_X1)/2, cy = KEY_Y + KEY_H/2;
    tft.fillRect(cx - 10, cy - 2, 20, 4, fcol);
    tft.fillRect(cx - 2, cy - 10, 4, 20, fcol); }
  // "?" IGNOTA — agisce SOLO sulla distanza: l'elevazione non ne ha bisogno
  // (il suo default "in piano" e' fisicamente sensato; "0 metri" non lo e').
  tft.fillRect(KEY_IGN_DRAW_X0, KEY_Y, KEY_IGN_DRAW_X1-KEY_IGN_DRAW_X0, KEY_H,
               ignota ? ArchColor::BG_CARD : ArchColor::BG);
  tft.drawRect(KEY_IGN_DRAW_X0, KEY_Y, KEY_IGN_DRAW_X1-KEY_IGN_DRAW_X0, KEY_H, ArchColor::AMBER);
  tft.setTextColor(ArchColor::AMBER, ignota ? ArchColor::BG_CARD : ArchColor::BG);
  tft.drawString("?", ARCHBB_W/2, KEY_Y + KEY_H/2, 4);

  // ================= INDIETRO (sx) / OK (dx) =================
  // Discriminati per LATO (X): e' cio' che li rende robusti, non l'altezza.
  // 45px sono ~6mm: comodi col guanto, e BTN_GUARD sopra protegge dal tap che
  // scivola giu' dal "+".
  const int16_t midX = ARCHBB_W/2, gap = 4;
  tft.fillRect(0, BTN_TOP, midX - gap, BTN_H, ArchColor::BG);
  tft.drawRect(0, BTN_TOP, midX - gap, BTN_H, ArchColor::BORDER);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  { int16_t ccx = 26, ccy = BTN_TOP + BTN_H/2;   // chevron '‹' geometrico
    tft.drawLine(ccx + 5, ccy - 8, ccx - 4, ccy, ArchColor::TEXT3);
    tft.drawLine(ccx - 4, ccy, ccx + 5, ccy + 8, ArchColor::TEXT3); }
  tft.drawString("INDIETRO", (midX - gap)/2 + 12, BTN_TOP + BTN_H/2, 2);
  tft.fillRect(midX + gap, BTN_TOP, ARCHBB_W - (midX + gap), BTN_H, ArchColor::GOOD);
  tft.setTextColor(ArchColor::BG, ArchColor::GOOD);
  tft.drawString("OK", midX + (ARCHBB_W - midX)/2, BTN_TOP + BTN_H/2, 4);
}

// ============================================================================
//  Gestione tap (chiamata UNA volta per tap, gia' debounced)
// ============================================================================
static void handleEsitoTap(uint16_t x, uint16_t y) {
  if (hitNavBar(x, y, false, true) == 2) {   // SALTA
    s_result.valutato = false;
    s_state = ScoringState::DONE; return;
  }
  const int bh = 72, y1 = 54, y2 = 54 + bh + 12;
  if (y >= y1 && y < y1 + bh) {
    s_result.colpito = true;  s_state = ScoringState::ZONA; s_needRedraw = true;
  } else if (y >= y2 && y < y2 + bh) {
    s_result.colpito = false; s_state = ScoringState::ZONA; s_needRedraw = true;
  }
}
static void handleZonaTap(uint16_t x, uint16_t y) {
  if (hitNavBar(x, y, true, false) == 1) {
    s_state = ScoringState::ESITO; s_needRedraw = true; return;
  }
  if (y >= NAV_Y) return;
  uint8_t z = coordToZona(x, y);
  if (!s_result.colpito && z == ZONA_CENTRO) return;   // centro off nel mancato
  s_result.zona = z;
  s_state = ScoringState::DISTANZA; s_needRedraw = true;
}
// ============================================================================
//  Tap sulla schermata DIST + ELEV
// ============================================================================
//  REGOLA FERREA (lezione 1.69 v2.16.10): qui NON compare un solo numero di
//  posizione scritto a mano. Ogni confronto usa le STESSE costanti del disegno
//  (BTN_TOP, KEY_Y, SLD_Y_*, KEY_*_X*). Sulla 1.69 la divergenza fra disegno e
//  handler ha prodotto il bug piu' costoso del progetto: toccavi "+" e partiva
//  OK. Con le costanti condivise quel bug e' strutturalmente impossibile.
// ----------------------------------------------------------------------------
static void handleDistanzaTap(uint16_t x, uint16_t y) {
  const int16_t tx = (int16_t)x, ty = (int16_t)y;
  uint8_t d = s_distSel;
  int8_t  e = s_elevSel;

  // --- INDIETRO (sx) / OK (dx): fascia bassa, il LATO decide l'azione ---
  if (ty >= BTN_TOP) {
    if (tx >= ARCHBB_W/2) {
      // OK -> chiude lo scoring. NB: NON forziamo elev a 0 se non impostata:
      // la sentinella deve arrivare fino al ScoreResult, cosi' a valle si sa
      // che il dato manca invece di credere a un "tiro in piano" mai misurato.
      s_result.distanza_m = s_distSel;
      s_result.elev_deg   = s_elevSel;
      s_result.valutato   = true;
      s_result.arcs = encodeArcs(s_result.colpito, s_result.zona, s_result.distanza_m);
      s_state = ScoringState::DONE;
    } else {
      s_state = ScoringState::ZONA;
      s_needRedraw = true;
    }
    return;
  }

  // --- Fascia tasti  -  /  ?  /  +  ---
  if (ty >= KEY_Y && ty <= KEY_Y + KEY_H) {
    if (tx >= KEY_MINUS_HIT_X0 && tx <= KEY_MINUS_HIT_X1) {
      // "-" CONTESTUALE: il focus decide su cosa agisce.
      if (s_focus == FOCUS_DIST) {
        if (d == 0) d = DIST_MIN; else if (d > DIST_MIN) d--;
      } else {
        // Il primo tocco sui +/- con elevazione non impostata la IMPOSTA
        // (partendo da 0): toccare i tasti E' la dichiarazione di aver misurato.
        if (!elevIsSet(e)) e = 0;
        else if (e > ELEV_MIN) e--;
      }
    } else if (tx >= KEY_PLUS_HIT_X0 && tx <= KEY_PLUS_HIT_X1) {
      if (s_focus == FOCUS_DIST) {
        if (d == 0) d = DIST_MIN; else if (d < DIST_MAX) d++;
      } else {
        if (!elevIsSet(e)) e = 0;
        else if (e < ELEV_MAX) e++;
      }
    } else if (tx >= KEY_IGN_HIT_X0 && tx <= KEY_IGN_HIT_X1) {
      // "?" IGNOTA: agisce SOLO sulla distanza, e porta li' il focus (se hai
      // appena detto "non so la distanza", il prossimo +/- serve quasi certo a
      // correggere la distanza).
      d = 0;
      s_focus = FOCUS_DIST;
    }
    s_distSel = d; s_elevSel = e; s_needRedraw = true;
    return;
  }

  // --- Tocco diretto sullo slider DISTANZA ---
  if (ty >= SLD_Y_DIST - SLD_HIT && ty <= SLD_Y_DIST + SLD_HIT &&
      tx >= SLD_X0 - 8 && tx <= SLD_X1 + 8) {
    s_distSel = xToDist(tx);
    s_focus   = FOCUS_DIST;      // toccare uno slider gli da' il focus
    s_needRedraw = true;
    return;
  }

  // --- Tocco diretto sullo slider ELEVAZIONE ---
  if (ty >= SLD_Y_ELEV - SLD_HIT && ty <= SLD_Y_ELEV + SLD_HIT &&
      tx >= SLD_X0 - 8 && tx <= SLD_X1 + 8) {
    // Toccare lo slider IMPOSTA l'elevazione, anche se il valore risultante e'
    // 0: il tocco E' la dichiarazione "l'ho misurata". E' qui che "in piano"
    // smette di essere "non lo so".
    s_elevSel = xToElev(tx);
    s_focus   = FOCUS_ELEV;
    s_needRedraw = true;
    return;
  }
  // Tocco fuori da ogni zona attiva: ignorato.
}

// ============================================================================
//  API
// ============================================================================
void scoringStart(uint16_t shotId) {
  s_shotId  = shotId;
  s_state   = ScoringState::ESITO;
  // ATTENZIONE al reset di elev_deg: NON puo' essere 0. L'initializer
  // posizionale della Fase 3 aveva 7 campi; ora la struct ne ha 8, e lasciare
  // che elev_deg cada a 0 per default significherebbe dichiarare "tiro in
  // piano" su OGNI tiro mai misurato — proprio il bug che la sentinella esiste
  // per prevenire. Uso quindi i nomi dei campi: se domani la struct cresce
  // ancora, il compilatore non silenzia l'errore.
  s_result = ScoreResult{};
  s_result.elev_deg = ELEV_NOT_SET;
  s_distSel = 18;
  s_elevSel = ELEV_NOT_SET;   // ogni tiro riparte da "non misurata"
  s_focus   = FOCUS_DIST;     // il focus riparte sempre dalla distanza
  s_needRedraw   = true;
  s_stableTouch  = false;
  s_relCount     = 0;
  s_lastActionMs = millis();
  kickTimeout();
}

void scoringResume() {
  // Re-editing: NON azzero s_result. Riparto da ESITO ma le scelte precedenti
  // restano il punto di partenza. Se il tiro era gia' valutato, riporto
  // s_distSel al valore scelto cosi' la schermata distanza lo ripropone.
  s_state = ScoringState::ESITO;
  if (s_result.distanza_m > 0) s_distSel = s_result.distanza_m;
  // v2.16: idem per l'elevazione. Qui la sentinella si propaga NATURALMENTE: se
  // il tiro era stato chiuso senza misurarla, s_result.elev_deg vale
  // ELEV_NOT_SET e ripartiamo da "non impostata" — che e' giusto, perche' il
  // CORREGGI e' proprio il momento in cui rimediare a quella dimenticanza.
  s_elevSel = s_result.elev_deg;
  s_focus   = FOCUS_DIST;
  s_result.valutato = false;   // torna "in editing" finche' non riconferma
  s_needRedraw   = true;
  s_stableTouch  = false;
  s_relCount     = 0;
  s_lastActionMs = millis();
  kickTimeout();
}
bool scoringActive() {
  return s_state != ScoringState::IDLE && s_state != ScoringState::DONE;
}
ScoringState scoringGetState() { return s_state; }
ScoreResult  scoringGetResult() { return s_result; }

ScoringState scoringUpdate(const TouchData& td) {
  if (!scoringActive()) return s_state;

  if (s_needRedraw) {
    switch (s_state) {
      case ScoringState::ESITO:    drawEsitoScreen();    break;
      case ScoringState::ZONA:     drawZonaScreen();     break;
      case ScoringState::DISTANZA: drawDistanzaScreen(); break;
      default: break;
    }
    s_needRedraw = false;
  }

  if (millis() - s_lastTouchMs > SCORING_TIMEOUT_MS) {
    s_result.valutato = false;
    s_state = ScoringState::DONE;
    return s_state;
  }

  // ---- DEBOUNCE ------------------------------------------------------------
  // Stato istantaneo del tocco.
  bool rawTouch = td.valid && (td.fingers > 0);
  if (rawTouch) {
    kickTimeout();
    s_pressX = td.x; s_pressY = td.y;   // memorizzo l'ultima posizione premuta
    s_relCount = 0;
    if (!s_stableTouch) s_stableTouch = true;   // press: immediato (reattivo)
  } else {
    // Rilascio: conta i campioni di non-tocco. Solo dopo N stabili confermo.
    if (s_stableTouch) {
      if (++s_relCount >= RELEASE_STABLE_N) {
        // Rilascio confermato: e' un tap. Applico SE fuori dal cooldown.
        s_stableTouch = false;
        s_relCount = 0;
        uint32_t now = millis();
        if (now - s_lastActionMs >= ACTION_COOLDOWN_MS) {
          s_lastActionMs = now;
          switch (s_state) {
            case ScoringState::ESITO:    handleEsitoTap(s_pressX, s_pressY);    break;
            case ScoringState::ZONA:     handleZonaTap(s_pressX, s_pressY);     break;
            case ScoringState::DISTANZA: handleDistanzaTap(s_pressX, s_pressY); break;
            default: break;
          }
        }
      }
    }
  }

  return s_state;
}
