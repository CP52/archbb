// ============================================================================
//  ArchBB 1.83 — main.cpp · FASE 4c (angoli cant/alzo dal burst) · v1
//  Cesare Pagura · Padova/Noale IT · 19 luglio 2026
// ----------------------------------------------------------------------------
//  COSA AGGIUNGE LA FASE 4c (rispetto alla 4a/4b)
//    La catena IMU era pronta fino al BUFFER CONGELATO: al FIRED il circular
//    buffer cattura la finestra PRE+POST attorno allo scocco e diventa READY.
//    Mancava l'ultimo anello: LEGGERE quel burst e calcolarne gli ANGOLI
//    biomeccanici. Ora, al DONE dello scoring:
//
//      circular_buffer_get_burst() -> shot_angles_compute() -> ScoreResult
//                                   -> riepilogo esteso (cant/alzo/hold/release)
//
//  IL PUNTO CRITICO: IL FRAME DI MONTAGGIO (perche' c'e' il DIAG ANGOLI)
//    shot_angles fu validato sul frame CANONICO della 1.69. La 1.83 e' un'altra
//    scheda: gli assi grezzi del suo QMI8658 potrebbero non essere canonici.
//    Percio' imu_task ora applica mount_apply() a monte (frame canonico a
//    valle), MA quale montaggio sia quello giusto NON si decide a tavolino: si
//    misura col DIAG ANGOLI (menu d'avvio), test statico ad angolo noto. Il
//    default e' MOUNT_DX_M90 (ipotesi \"come 1.69 a destra\"), da CONFERMARE.
//
//  ALLOCAZIONE DEL BURST: STATIC, MAI SULLO STACK
//    Il burst e' CIRCULAR_BUFFER_SIZE * sizeof(ImuSample) = 750*30 = ~22 KB.
//    Su stack (locale del loop) farebbe saltare la UI task. Lo teniamo STATIC:
//    vive una volta sola nel .bss, azzerato all'avvio, riusato a ogni tiro.
// ============================================================================
#include <Arduino.h>
#include "display.h"
#include "touch.h"
#include "scoring.h"
#include "config.h"
#include "imu.h"
#include "trigger.h"
#include "circular_buffer.h"
#include "touch_cal.h"
#include "mount.h"          // FASE 4c: frame di montaggio (g_mount_orientation)
#include "shot_angles.h"    // FASE 4c: shot_angles_compute, shot_angle_to_cdeg

// Flag di shutdown pulito (predisposto: i task lo controllano nella 1.69 e
// teniamo il pattern anche se in Fase 4 non lo attiviamo mai).
volatile bool g_shutdown = false;

enum class AppFlow : uint8_t { ATTESA, SCORING, RIEPILOGO };
static AppFlow     s_flow = AppFlow::ATTESA;
static ScoreResult s_lastResult;
static uint32_t    s_lastTempMs = 0;   // per rinfrescare la temperatura in attesa

// ----------------------------------------------------------------------------
//  BURST STATIC (Fase 4c) — ~22 KB, MAI sullo stack.
// ----------------------------------------------------------------------------
//  Buffer di lavoro dove copiamo il burst congelato per darlo a
//  shot_angles_compute. static -> vive nel .bss, allocato una volta, riusato a
//  ogni tiro. In PSRAM ci sarebbe stato bene, ma il .bss interno basta e avanza
//  (22 KB su ~320 KB di RAM interna) ed evita una dipendenza da ps_malloc qui.
static ImuSample s_burst[CIRCULAR_BUFFER_SIZE];

// ----------------------------------------------------------------------------
//  Debounce/cooldown per i tap di RIEPILOGO (identico alla Fase 4a).
// ----------------------------------------------------------------------------
static constexpr uint8_t  REL_STABLE_N = 2;
static constexpr uint32_t COOLDOWN_MS  = 300;
static bool     s_stable       = false;
static uint8_t  s_relCnt       = 0;
static uint32_t s_lastActionMs = 0;

static bool tapReleased(const TouchData& td) {
  bool raw = td.valid && (td.fingers > 0);
  if (raw) { s_relCnt = 0; s_stable = true; return false; }
  if (s_stable && ++s_relCnt >= REL_STABLE_N) {
    s_stable = false; s_relCnt = 0;
    uint32_t now = millis();
    if (now - s_lastActionMs >= COOLDOWN_MS) { s_lastActionMs = now; return true; }
  }
  return false;
}

// ----------------------------------------------------------------------------
//  computeShotAngles — legge il burst congelato e popola le metriche 4c.
// ----------------------------------------------------------------------------
//  Chiamata al DONE dello scoring, PRIMA di enterAttesa() (che resetta il
//  buffer). Se il buffer non e' READY (tiro manuale a banco senza IMU, o burst
//  non congelato) lascia i campi a \"non valido\": il riepilogo lo mostra come
//  n/d. cant/alzo e hold/release restano indipendenti fra loro (v. shot_angles).
// ----------------------------------------------------------------------------
static void computeShotAngles(ScoreResult& res) {
  // Default: tutto \"non calcolato\". Se qualcosa manca, il riepilogo dira' n/d.
  res.angles_valid = res.angles_stable = false;
  res.hold_valid   = res.release_valid = false;
  res.cant_cdeg = res.alzo_cdeg = 0;
  res.hold_cdeg = 0; res.release_jerk = 0;
  res.hold_class = HOLD_NA; res.release_class = RELEASE_NA;

  // Il burst ha senso solo se l'IMU e' viva e il buffer ha catturato la finestra.
  if (!g_imu_ok) return;
  if (circular_buffer_state() != BUFFER_READY) return;   // niente da leggere

  uint16_t trig_idx = 0;
  uint16_t n = circular_buffer_get_burst(s_burst, CIRCULAR_BUFFER_SIZE, &trig_idx);
  if (n == 0) return;

  // ODR_250HZ = 224 Hz reale: shot_angles lo usa solo per dimensionare le
  // finestre in campioni; l'integrazione usa i timestamp reali del burst.
  ShotAngles a = shot_angles_compute(s_burst, n, trig_idx, ODR_250HZ);

  if (a.valid) {
    res.angles_valid  = true;
    res.angles_stable = a.stable;
    res.cant_cdeg = shot_angle_to_cdeg(a.cant_deg);
    res.alzo_cdeg = shot_angle_to_cdeg(a.alzo_deg);
  }
  if (a.hold_valid) {
    res.hold_valid = true;
    res.hold_cdeg  = shot_angle_to_cdeg(a.hold_deg);
    res.hold_class = a.hold_class;
  }
  if (a.release_valid) {
    res.release_valid = true;
    // jerk e' un modulo >=0; lo saturiamo a 65535 per il campo uint16.
    float j = a.release_jerk;
    res.release_jerk  = (j > 65535.0f) ? 65535 : (uint16_t)(j + 0.5f);
    res.release_class = a.release_class;
  }
}

// ----------------------------------------------------------------------------
//  Entra in ATTESA: disegna la schermata IMU-armata e ARMA il trigger.
// ----------------------------------------------------------------------------
static void enterAttesa() {
  // Il tiro precedente e' concluso -> libera il buffer per il prossimo.
  // In 4c il burst e' gia' stato LETTO (computeShotAngles) al DONE: qui si
  // resetta soltanto, tornando in RUNNING per la finestra mobile del prossimo.
  circular_buffer_reset();
  float tC = g_imu_ok ? imu_read_temperature() : NAN;
  displayAttesaTiroIMU((uint16_t)(g_shot_id + 1), tC);
  s_lastTempMs = millis();
  // Svuota un eventuale semaforo residuo (un trigger arrivato mentre eravamo
  // ancora nel riepilogo non deve far partire subito il tiro dopo).
  if (g_trigger_fired_sem) xSemaphoreTake(g_trigger_fired_sem, 0);
  trigger_set_armed(true);
  s_flow = AppFlow::ATTESA;
}

// ----------------------------------------------------------------------------
//  Avvia lo scoring del tiro corrente: DISARMA il trigger e mostra il flash.
// ----------------------------------------------------------------------------
static void startScoringForShot(float azPeak) {
  trigger_set_armed(false);               // niente tiri fantasma durante lo score
  displayTriggerFlash(g_shot_id, azPeak); // feedback visivo istantaneo
  scoringStart(g_shot_id);
  // Reset debounce del main: il tap dato dentro lo scoring non deve trapelare.
  s_stable = false; s_relCnt = 0; s_lastActionMs = millis();
  s_flow = AppFlow::SCORING;
}

// ----------------------------------------------------------------------------
//  runAngleDiag — TEST STATICO dei segni di montaggio (Fase 4c).
// ----------------------------------------------------------------------------
//  Modalita' \"capolinea\" chiamata dal menu d'avvio: media in continuo gli assi
//  GREZZI del sensore (~1s a finestra scorrevole) e li passa a displayAngleDiag,
//  che mostra cant/alzo per tutti e 4 i montaggi. L'IMU deve essere gia'
//  inizializzata (imu_init in setup, PRIMA del menu) ma i task NON ancora
//  avviati (cosi' nessuno muove g_latest_sample: leggiamo noi, direttamente).
//  Si esce solo spegnendo: e' un banco di misura, non un passo del flusso.
// ----------------------------------------------------------------------------
static void runAngleDiag() {
  // Media mobile semplice su ~1s: a 224Hz sono ~224 campioni, ma leggiamo
  // \"quando pronto\" a intervalli di ~25ms per non intasare il refresh video.
  // Bastano ~40 letture/s per una media stabile e un display fluido.
  constexpr int WIN = 40;               // campioni nella finestra di media
  static float bx[WIN], by[WIN], bz[WIN];
  int head = 0, filled = 0;

  // --- Output seriale CSV (Fase 4c, dietro ARCHBB_DEBUG) --------------------
  //  Al tavolino col monitor aperto la seriale da' il DATO COPIABILE: gli assi
  //  grezzi mediati e i cant/alzo dei 4 montaggi in CSV, pronti da incollare in
  //  un foglio o in uno script. Il display resta il colpo d'occhio (8/s), la
  //  seriale va piu' rada (~1/s) cosi' ogni riga e' una media gia' stabile e il
  //  terminale non si allaga. Cautele HWCDC (memoria di progetto): stampa SOLO
  //  se il monitor e' pronto (availableForWrite>0), mai a raffica. Qui e' sicuro
  //  perche' i task IMU non sono ancora avviati: runAngleDiag gira nel menu.
#ifdef ARCHBB_DEBUG
  uint32_t s_lastCsvMs = 0;
  bool     s_hdrPrinted = false;
#endif

  for (;;) {
    float ax, ay, az, gx, gy, gz;
    if (imu_read_raw(ax, ay, az, gx, gy, gz)) {
      bx[head] = ax; by[head] = ay; bz[head] = az;
      head = (head + 1) % WIN;
      if (filled < WIN) filled++;
    }

    // Media e sd del modulo |a| sulla finestra corrente.
    float mx = 0, my = 0, mz = 0, gm = 0;
    for (int i = 0; i < filled; i++) {
      mx += bx[i]; my += by[i]; mz += bz[i];
      gm += sqrtf(bx[i]*bx[i] + by[i]*by[i] + bz[i]*bz[i]);
    }
    if (filled > 0) { mx/=filled; my/=filled; mz/=filled; gm/=filled; }
    float var = 0;
    for (int i = 0; i < filled; i++) {
      float m = sqrtf(bx[i]*bx[i] + by[i]*by[i] + bz[i]*bz[i]);
      var += (m - gm) * (m - gm);
    }
    float sd = (filled >= 2) ? sqrtf(var / (filled - 1)) : 0.0f;

    displayAngleDiag(mx, my, mz, gm, sd, (uint16_t)filled);

    // --- Riga CSV sulla seriale (~1/s), solo in debug e col monitor pronto ---
#ifdef ARCHBB_DEBUG
    if ((bool)Serial && Serial.availableForWrite() > 0) {
      if (!s_hdrPrinted) {
        Serial.println();
        Serial.println("ARCHBB_DIAG_ANGOLI_CSV");
        Serial.println("t_ms,ax,ay,az,gmean,gsd,n,"
                       "cant0,alzo0,cantDX,alzoDX,cantSX,alzoSX,cant180,alzo180,cantFZ,alzoFZ");
        s_hdrPrinted = true;
      }
      uint32_t now = millis();
      if (now - s_lastCsvMs >= 1000 && filled >= 2) {
        s_lastCsvMs = now;
        // Stessi grezzi mediati -> cant/alzo per TUTTI i montaggi, fianco a fianco.
        float c[MOUNT_COUNT], a[MOUNT_COUNT];
        for (uint8_t m = 0; m < MOUNT_COUNT; m++) {
          float px = mx, py = my, pz = mz, d0 = 0, d1 = 0, d2 = 0;
          mount_apply(m, px, py, pz, d0, d1, d2);
          c[m] = atan2f(py, px) * 180.0f / (float)M_PI;
          a[m] = atan2f(pz, px) * 180.0f / (float)M_PI;
        }
        // %.3f sugli assi (i segni richiedono precisione), %.1f sugli angoli.
        Serial.printf("%lu,%.3f,%.3f,%.3f,%.3f,%.3f,%d,"
                      "%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f\n",
                      (unsigned long)now, mx, my, mz, gm, sd, filled,
                      c[MOUNT_0],       a[MOUNT_0],
                      c[MOUNT_DX_M90],  a[MOUNT_DX_M90],
                      c[MOUNT_SX_P90],  a[MOUNT_SX_P90],
                      c[MOUNT_180],     a[MOUNT_180],
                      c[MOUNT_0_FLIPZ], a[MOUNT_0_FLIPZ]);
      }
    }
#endif

    delay(120);   // ~8 refresh/s: fluido e non affamato di CPU
  }
}

// ============================================================================
//  setup()
// ============================================================================
void setup() {
  Serial.begin(115200);
  Serial.setTxTimeoutMs(0);   // Serial.printf non blocca col monitor chiuso

  // --- Frame di montaggio: carica il default (Fase 4c) ---------------------
  // g_mount_orientation e' letto dall'imu_task nel suo hot-loop. Lo impostiamo
  // QUI, prima di avviare i task, dal default compilato. Quando arrivera' il
  // BLE/NVS potra' scriverlo a runtime senza toccare imu_task.
  g_mount_orientation = ARCHBB_MOUNT_DEFAULT;

  // --- Init hardware, nell'ordine giusto -----------------------------------
  displayInit();
  touchInit();     // avvia Wire (bus I2C condiviso) e configura il CST816

  // --- IMU inizializzata PRIMA del menu (serve al DIAG ANGOLI) --------------
  // In 4a l'IMU si inizializzava dopo il menu touch; in 4c la anticipiamo,
  // perche' il DIAG ANGOLI (test statico) deve poter leggere il sensore mentre
  // e' nel menu. I task NON partono ancora: g_latest_sample resta fermo, il
  // DIAG legge coi propri imu_read_raw() senza conflitti.
  bool imuOk = imu_init(ODR_250HZ, 8, 512);   // usa il bus GIA' attivo

  // --- MENU D'AVVIO (OPT-IN): CALIBRA / DIAG touch / DIAG ANGOLI ------------
  // Subito dopo il touch e prima di avviare i task. E' l'unico momento in cui
  // bloccare e' innocuo (nessun task, nessun tiro). Default = salta dopo 3s.
  {
    int scelta = touch_cal_offer(tft, 3000);
    if (scelta == 1) {
      TouchCalResult r = touch_cal_run(tft);
      (void)r;   // i coefficienti si ricopiano a mano in config.h (voluto)
    } else if (scelta == 2) {
      touch_cal_diag(tft);
    } else if (scelta == 3) {
      // DIAG ANGOLI: test statico dei segni di montaggio (Fase 4c).
      if (imuOk) runAngleDiag();   // non ritorna: si esce spegnendo
      // Se l'IMU non c'e', il menu non offre nemmeno la voce (v. touch_cal_offer).
    }
  }

  bool bufOk = circular_buffer_init();        // buffer in PSRAM (Fase 4b)
  trigger_init();

  // --- Task FreeRTOS su Core 1 ----------------------------------------------
  // Priorita': IMU la piu' alta (non deve perdere campioni), trigger appena
  // sotto, la UI (loop) gira alla priorita' di default di Arduino.
  if (imuOk) {
    xTaskCreatePinnedToCore(imu_task,     "imu",     4096, nullptr, 5, nullptr, 1);
    xTaskCreatePinnedToCore(trigger_task, "trigger", 4096, nullptr, 4, nullptr, 1);
  }

  // --- Schermata iniziale + arma il trigger ---------------------------------
  enterAttesa();

  if ((bool)Serial && Serial.availableForWrite() > 0) {
    Serial.printf("=== ArchBB 1.83 — Fase 4c (angoli) — IMU %s, buffer %s, mount %s ===\n",
                  imuOk ? "OK" : "ASSENTE", bufOk ? "OK" : "FALLITO",
                  mount_name(g_mount_orientation));
  }
}

// ============================================================================
//  loop()  =  TASK UI (touch + scoring + display)
// ============================================================================
void loop() {
  TouchData td = touchRead();

  switch (s_flow) {

    // ---------------------------------------------------------------------
    case AppFlow::ATTESA: {
      // 1) Tiro REALE: il trigger ha sparato?
      if (g_trigger_fired_sem &&
          xSemaphoreTake(g_trigger_fired_sem, 0) == pdTRUE) {
        startScoringForShot(g_trigger_az_peak);
        break;
      }
      // 2) Tiro MANUALE (fallback a banco): un tap avvia lo scoring.
      if (tapReleased(td)) {
        if (g_imu_ok) {
          trigger_manual();   // incrementa g_shot_id e posta il semaforo
        } else {
          g_shot_id++;
          startScoringForShot(0.0f);
        }
        break;
      }
      // 3) Rinfresca la temperatura IMU ogni 3s (feedback \"IMU viva\").
      if (g_imu_ok && millis() - s_lastTempMs > 3000) {
        s_lastTempMs = millis();
        displayAttesaTiroIMU((uint16_t)(g_shot_id + 1), imu_read_temperature());
      }
      break;
    }

    // ---------------------------------------------------------------------
    case AppFlow::SCORING: {
      ScoringState st = scoringUpdate(td);
      if (st == ScoringState::DONE) {
        s_lastResult = scoringGetResult();

        // --- FASE 4c: leggi il burst congelato e calcola gli angoli ---------
        // QUI, prima del riepilogo e prima di enterAttesa (che resetta il
        // buffer). Se il buffer non e' READY (tiro manuale senza IMU) le
        // metriche restano \"non valide\" -> il riepilogo mostra n/d.
        computeShotAngles(s_lastResult);

        s_stable = false; s_relCnt = 0; s_lastActionMs = millis();
        displayScoreRiepilogo(s_lastResult,
                              zonaLabel(s_lastResult.colpito, s_lastResult.zona));
        s_flow = AppFlow::RIEPILOGO;
      }
      break;
    }

    // ---------------------------------------------------------------------
    case AppFlow::RIEPILOGO: {
      static uint16_t rx = 0, ry = 0;
      if (td.valid && td.fingers > 0) { rx = td.x; ry = td.y; }
      if (tapReleased(td)) {
        uint8_t hit = hitRiepilogo(rx, ry);
        if (hit == 2) {                  // OK -> cementa e torna in attesa
          // [FUTURO] qui andra' la scrittura su microSD del burst + risultato.
          enterAttesa();                 // riarma il trigger per il prossimo tiro
        } else if (hit == 1) {           // CORREGGI -> riapre lo scoring corrente
          scoringResume();
          s_flow = AppFlow::SCORING;
        }
        // tocco fuori dai pulsanti: ignorato.
      }
      break;
    }
  }

  // Cede il Core 1 agli altri task. 15ms: UI fluida (~66 Hz touch), IMU/trigger
  // hanno CPU in abbondanza.
  delay(15);
}
