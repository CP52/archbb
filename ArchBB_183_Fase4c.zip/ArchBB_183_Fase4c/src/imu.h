// ============================================================================
//  ArchBB 1.83 — imu.h · FASE 4a (driver QMI8658C, polling puro)
//  Cesare Pagura · Padova/Noale IT · 13 luglio 2026
// ----------------------------------------------------------------------------
//  Interfaccia del modulo IMU. Portato dalla 1.69 v2.12.6 (logica MATURA e
//  validata sul campo), adattato alla 1.83 con due semplificazioni DELIBERATE
//  per la Fase 4a:
//
//   1) POLLING PURO senza pin INT. Sulla 1.69 l'IMU aveva INT su GPIO14, ma
//      sulla 1.83 il 14 e' SCL (bus condiviso col touch). SensorLib sa leggere
//      il registro STATUS via I2C con getDataReady(): non serve alcun GPIO
//      dedicato. Un pin in meno da sbagliare, comportamento identico.
//
//   2) NIENTE circular buffer (arrivera' in Fase 4b). In Fase 4a l'imu_task si
//      limita a mantenere g_latest_sample aggiornato (protetto da mutex): e'
//      tutto cio' che serve al trigger per osservare lo spike su az. Il buffer
//      per la finestra pre-scocco (angoli) e' un pezzo successivo.
//
//  BUS I2C CONDIVISO (trappola): imu_init() NON chiama Wire.begin(). Il bus e'
//  gia' vivo (touchInit() in Fase 2). Chiamare di nuovo begin() lo re-inizializza
//  e rompe il touch. imu_init() usa solo Wire.setClock() (idempotente) e passa
//  l'istanza Wire gia' attiva a SensorLib.
//
//  THREADING (FreeRTOS): imu_task gira su Core 1. Aggiorna g_latest_sample sotto
//  g_imu_sample_mutex. Il trigger_task (anch'esso Core 1) lo legge sotto lo
//  stesso mutex. g_imu_ok e' volatile: scritto da imu_init (setup/Core1), letto
//  dagli altri task per attendere che l'IMU sia pronta.
// ============================================================================
#pragma once
#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include "config.h"

// ----------------------------------------------------------------------------
//  Handle globali (definiti in imu.cpp)
// ----------------------------------------------------------------------------
extern SemaphoreHandle_t g_imu_sample_mutex;  // protegge g_latest_sample
extern ImuSample         g_latest_sample;     // ultimo campione (frame canonico)
extern volatile bool     g_imu_ok;            // true quando l'IMU e' inizializzata

// ----------------------------------------------------------------------------
//  API pubblica
// ----------------------------------------------------------------------------

// Inizializza il QMI8658C sul bus I2C GIA' ATTIVO (non chiama Wire.begin()).
// Ritorna true se il chip risponde e la config va a buon fine.
//   odr            : frequenza di campionamento (default 224 Hz reale)
//   accel_range_g  : fondo scala accelerometro in g (2/4/8/16; default 8)
//   gyro_range_dps : fondo scala giroscopio in deg/s (default 512)
bool imu_init(OdrSetting odr           = ODR_250HZ,
              uint8_t    accel_range_g = 8,
              uint16_t   gyro_range_dps = 512);

// Task FreeRTOS (Core 1). Polling di getDataReady(): quando c'e' un campione
// fresco lo legge, converte g->m/s^2, applica il frame canonico e aggiorna
// g_latest_sample sotto mutex. Non ritorna.
void imu_task(void* param);

// Temperatura on-chip [deg C] (diagnostica).
float imu_read_temperature();

// ----------------------------------------------------------------------------
//  FASE 4c — lettura GREZZA singola (pre-mount), per il DIAG ANGOLI.
// ----------------------------------------------------------------------------
//  Legge una volta accelerometro + giroscopio e restituisce i valori in frame
//  SENSORE (NON canonico: mount_apply NON viene applicato). Serve al DIAG
//  ANGOLI, che deve mostrare cosa produrrebbe OGNI montaggio a partire dagli
//  stessi grezzi: se leggesse dati gia' rimappati, applicherebbe il mount due
//  volte. Accel in m/s^2, gyro in deg/s. Ritorna false se non c'e' un campione
//  pronto (l'IMU va gia' inizializzata). Da usare PRIMA di avviare imu_task
//  (nel menu d'avvio), quando g_latest_sample non e' ancora in movimento.
bool imu_read_raw(float& ax, float& ay, float& az,
                  float& gx, float& gy, float& gz);
