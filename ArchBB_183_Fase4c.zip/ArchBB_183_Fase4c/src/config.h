// ============================================================================
//  ArchBB 1.83 — config.h · FASE 4a (IMU QMI8658 + trigger reale)
//  Cesare Pagura · Padova/Noale IT · 13 luglio 2026
// ----------------------------------------------------------------------------
//  Questo file NON e' il config.h monolitico della 1.69 (che porta con se' UUID
//  BLE, ScorePacket, buffer, ecc.). E' un config.h VOLUTAMENTE MINIMALE per la
//  1.83, che contiene SOLO cio' che la Fase 4a usa davvero:
//    - ImuSample     : il campione IMU (identico byte-per-byte alla 1.69, cosi'
//                      quando arrivera' il BLE il pacchetto sara' gia' compatibile)
//    - OdrSetting    : le tre frequenze di campionamento e odrToHz()
//    - i pin/indirizzi I2C dell'IMU
//    - i parametri di default del trigger
//
//  FILOSOFIA "un passo alla volta": aggiungiamo qui i pezzi delle fasi 4b/4c
//  (circular buffer, angoli) SOLO quando serviranno. Tenere il config leggero
//  evita di trascinare dipendenze morte e rende chiaro cosa e' realmente attivo.
//
//  TRAPPOLA HARDWARE 1.83 (bus I2C CONDIVISO):
//    L'IMU QMI8658 (0x6B) e il touch CST816 (0x15) stanno sullo STESSO bus I2C
//    SDA=15/SCL=14, gia' inizializzato da touchInit() in Fase 2. In imu_init()
//    NON richiamiamo Wire.begin() (romperebbe il touch): usiamo il bus attivo.
//    Sulla 1.69 il bus era 11/10 e l'IMU aveva un pin INT su GPIO14; QUI il 14 e'
//    gia' SCL, quindi NON esiste un IMU_INT_PIN. Scelta: POLLING PURO di
//    getDataReady() (SensorLib legge il registro STATUS via I2C, nessun GPIO
//    dedicato). Piu' semplice e piu' robusto: un pin in meno da sbagliare.
// ============================================================================
#pragma once
#include <Arduino.h>
#include <stdint.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

#define ARCHBB_FW_VERSION "1.83-Fase4c-angoli"

// ----------------------------------------------------------------------------
//  I2C dell'IMU (bus CONDIVISO col touch — vedi trappola sopra)
// ----------------------------------------------------------------------------
//  Questi valori coincidono con ARCHBB_I2C_SDA/SCL dei build_flags (Fase 2). Li
//  ridefiniamo qui come costanti C++ per chiarezza nel codice IMU, ma NON
//  reinizializziamo il bus: e' gia' vivo. L'indirizzo 0x6B e' il default della
//  SensorLib (QMI8658_L_SLAVE_ADDRESS) per il pin SA0 a massa, come sul modulo
//  Waveshare integrato.
static constexpr int     IMU_I2C_SDA  = 15;    // = ARCHBB_I2C_SDA (Fase 2)
static constexpr int     IMU_I2C_SCL  = 14;    // = ARCHBB_I2C_SCL (Fase 2)
static constexpr uint8_t IMU_I2C_ADDR = 0x6B;  // QMI8658_L_SLAVE_ADDRESS

// ----------------------------------------------------------------------------
//  ODR — Output Data Rate del QMI8658
// ----------------------------------------------------------------------------
//  Il QMI8658 NON ha ODR esatti 100/250/500 Hz per il giroscopio: i valori reali
//  piu' vicini sono 112.1 / 224.2 / 448.4 Hz. Manteniamo i nomi "logici" della
//  1.69 (ODR_100/250/500) ma odrToHz() ritorna i valori REALI, perche' tutti i
//  calcoli tempo->campioni (finestra pre-scocco, jerk) devono usare la frequenza
//  vera, non quella nominale. Default 224 Hz: buon compromesso banda/rumore per
//  cogliere l'impulso di rilascio (~40ms di finestra utile della freccia).
enum OdrSetting : uint8_t {
  ODR_100HZ = 0,   // ACC_ODR_125Hz / GYR_ODR_112_1Hz
  ODR_250HZ = 1,   // ACC_ODR_250Hz / GYR_ODR_224_2Hz  (DEFAULT)
  ODR_500HZ = 2,   // ACC_ODR_500Hz / GYR_ODR_448_4Hz
};

inline uint16_t odrToHz(OdrSetting odr) {
  switch (odr) {
    case ODR_100HZ: return 112;
    case ODR_250HZ: return 224;
    case ODR_500HZ: return 448;
    default:        return 224;
  }
}

// ----------------------------------------------------------------------------
//  ImuSample — IDENTICO alla 1.69 (30 byte, packed)
// ----------------------------------------------------------------------------
//  Lo teniamo bit-per-bit uguale alla 1.69 anche se in Fase 4a non lo
//  trasmettiamo via BLE: quando il BLE arrivera' sulla 1.83, il pacchetto burst
//  sara' gia' compatibile con l'app senza toccare nulla. I campi sono gia' nel
//  FRAME CANONICO (la trasformazione di montaggio e' applicata a monte
//  nell'imu_task, come sulla 1.69): ax=verticale/gravita', ay=laterale,
//  az=asse freccia/scocco.
struct __attribute__((packed)) ImuSample {
  uint16_t seq;           // numero sequenziale (per anti-doppio-conteggio nel trigger)
  uint32_t timestamp_us;  // microsecondi da boot (esp_timer_get_time())
  float    ax;            // [m/s^2] verticale / gravita'
  float    ay;            // [m/s^2] laterale (dx/sx)
  float    az;            // [m/s^2] asse freccia / scocco
  float    gx;            // [deg/s]
  float    gy;            // [deg/s]
  float    gz;            // [deg/s]
};
static_assert(sizeof(ImuSample) == 30, "ImuSample deve essere 30 byte (compat 1.69)");

// ----------------------------------------------------------------------------
//  Parametri di default del TRIGGER (dal campo, 1.69 v2.12.6)
// ----------------------------------------------------------------------------
//  Questi valori sono quelli COLLAUDATI sulla 1.69, non inventati. Il trigger
//  cerca lo spike dell'impulso di rilascio sull'asse freccia (az). Vedi
//  trigger.h per il razionale fisico completo.
enum TriggerMode : uint8_t {
  TRIG_AZ_THRESHOLD = 0,   // |az| oltre soglia per N campioni (default, robusto)
  TRIG_JERK         = 1,   // derivata di |az| oltre soglia (piu' selettivo)
};

static constexpr TriggerMode TRIG_DEFAULT_MODE      = TRIG_AZ_THRESHOLD;
static constexpr float       TRIG_DEFAULT_THRESHOLD = 20.0f;  // m/s^2 (attesi 30-80 su barebow)
static constexpr uint8_t     TRIG_DEFAULT_CONFIRM_N = 2;      // campioni consecutivi
static constexpr uint16_t    TRIG_DEFAULT_REARM_MS  = 2000;   // ~30 colpi/min max

// ----------------------------------------------------------------------------
//  FASE 4b — FINESTRA DEL BURST e CIRCULAR BUFFER
// ----------------------------------------------------------------------------
//  Il buffer circolare in PSRAM tiene sempre in memoria gli ultimi N campioni.
//  Sul trigger "congela" una finestra PRE (prima dello scocco) + POST (dopo),
//  che diventa il burst da cui la Fase 4c estrarra' gli angoli e che in futuro
//  finira' su microSD / BLE.
//
//  VALORI REALI DAL CAMPO (CSV BBarch_13JULf, ODR misurato 224.9 Hz):
//    pre  = 2000 ms  -> 448 campioni   (trigger_idx=448 in ogni tiro)
//    post = 1000 ms  -> 224 campioni
//    tot  = 672 campioni  (< CIRCULAR_BUFFER_SIZE=750, margine 78)
//
//  NOTA: i configDefaults() hard-coded nel sorgente 1.69 dicono 3000/350, ma
//  quei default sono SOVRASCRITTI: l'app HTML in fase di config scrive nella
//  Config (BLE->NVS) i valori reali 2000/1000, ed e' quello che il firmware usa.
//  Il CSV di un tiro vero e' l'arbitro: 448 pre / 224 post = 2000/1000 ms. Ho
//  corretto qui di conseguenza ("i dati comandano").
//
//  PERCHE' pre=2000 ms: la Fase 4c cerca una FINESTRA DI STABILITA' pre-scocco
//  (arco fermo in mira) facendola scorrere nell'intervallo pre-trigger. 2s
//  coprono ampiamente il tempo di mira di un barebow.
//
//  PERCHE' post=1000 ms (non 350!): le metriche post-scocco (follow-through,
//  recoil, vib_hz, drift) si calcolano sull'OSCILLAZIONE del riser DOPO il
//  rilascio. Con 350 ms si taglierebbe la coda smorzata; 1000 ms la cattura
//  tutta. Il post lungo NON e' spreco: e' il dato biomeccanico del rilascio.
//
//  NB: pre_ms + post_ms (in campioni all'ODR reale) NON devono superare
//  CIRCULAR_BUFFER_SIZE. A 224Hz: 672 < 750 (ok). A 448Hz sforerebbe (1344):
//  il clamp difensivo in circular_buffer_freeze() lo gestisce.
static constexpr uint16_t WINDOW_PRE_MS  = 2000;   // finestra pre-scocco [ms]
static constexpr uint16_t WINDOW_POST_MS = 1000;   // finestra post-scocco [ms]

static constexpr uint16_t CIRCULAR_BUFFER_SIZE = 750;  // campioni in PSRAM (~22KB)

// Conversione ms->campioni all'ODR REALE (non nominale): i calcoli tempo->indice
// devono usare la frequenza vera del QMI8658, altrimenti la finestra e' storta.
inline uint16_t calcPreSamples(OdrSetting odr)  {
  return (uint16_t)((float)WINDOW_PRE_MS  / 1000.0f * odrToHz(odr));
}
inline uint16_t calcPostSamples(OdrSetting odr) {
  return (uint16_t)((float)WINDOW_POST_MS / 1000.0f * odrToHz(odr));
}

// ----------------------------------------------------------------------------
//  MONTAGGIO DELL'IMU sul riser (FASE 4c)
// ----------------------------------------------------------------------------
//  La 1.83 e' una scheda FISICAMENTE diversa dalla 1.69: stesso QMI8658 ma
//  altro PCB, altro verso di saldatura, pannello gia' ruotato via software
//  (setRotation(0)+offset). Quindi NON e' garantito che gli assi elettronici
//  del sensore coincidano col frame canonico su cui shot_angles e' stato
//  validato (ax=gravita', ay=laterale, az=freccia).
//
//  mount_apply() (modulo mount.h, portato dalla 1.69) rimappa gli assi grezzi
//  del sensore nel frame canonico A MONTE (in imu_task, prima di trigger,
//  buffer e angoli): da li' in poi TUTTO il firmware vede il frame canonico e
//  shot_angles gira invariato. E' l'architettura della 1.69.
//
//  QUALE MONTAGGIO? — MISURATO col DIAG angoli il 19/07 (test statico, arco
//  fermo su supporto, |g|~9.98). Risultato:
//    - cant a destra -> ay POSITIVO  (gia' corretto in frame canonico)
//    - punta su      -> az NEGATIVO  (INVERTITO: dovrebbe essere positivo)
//  Il chip della 1.83 e' saldato SPECCHIATO sull'asse freccia rispetto alla
//  1.69. Non e' nessuna delle 4 rotazioni (sono a det=+1); serve una
//  RIFLESSIONE che nega solo az/gz -> MOUNT_0_FLIPZ (=4), aggiunto apposta a
//  mount.h. Verificato: con FLIPZ i tre gesti danno i segni giusti
//  (riposo~0, punta su alzo+, cant dx cant+).
//
//  NB: il test empirico "il trigger scatta frontale" aveva ristretto a {0,180}
//  guardando solo |az|; il DIAG, guardando i SEGNI, ha rivelato che serviva il
//  flip di z, che ne' 0 ne' 180 forniscono. Ecco perche' il DIAG e' l'arbitro
//  e la sola prova del trigger non bastava.
//
//  REGOLA (§4 handoff): i segni si validano SOLO su test statico ad angolo noto.
static constexpr uint8_t ARCHBB_MOUNT_DEFAULT = 4;  // 4 = MOUNT_0_FLIPZ (misurato 19/07)

// ----------------------------------------------------------------------------
//  GEOMETRIA DEL PANNELLO (fatto hardware)
// ----------------------------------------------------------------------------
//  Sta QUI e non in display.h perche' e' un fatto HARDWARE, come i pin e gli
//  indirizzi I2C: non e' proprieta' del driver di disegno. Anche il driver del
//  TOUCH deve conoscerlo (per il clamp delle coordinate corrette), e non ha
//  senso che per saperlo debba includere display.h — e con esso tutto TFT_eSPI.
//
//  display.h include config.h ed eredita queste costanti: un solo posto dove
//  sono scritte, come per KEY_Y/BTN_TOP nello scoring. Stessa lezione (§4.1):
//  se un fatto e' scritto in due posti, prima o poi divergono.
//
//  1.83 = 240x284 (la 1.69 era 240x280). L'offset Y=20 e' il rowstart del
//  ST7789V2 su questo pannello, applicato via CGRAM_OFFSET+setRotation().
static constexpr int16_t ARCHBB_W        = 240;   // larghezza visibile
static constexpr int16_t ARCHBB_H        = 284;   // altezza visibile (era 280 su 1.69)
static constexpr int16_t ARCHBB_OFFSET_Y = 20;    // ritaglio verticale (rowstart)
static constexpr int16_t ARCHBB_OFFSET_X = 0;     // nessun offset orizzontale

// ============================================================================
//  CALIBRAZIONE DEL TOUCH (1.83)
// ============================================================================
//  IL SINTOMO (osservato sul campo con lo scoring DIST+ELEV)
//    I tasti "-" e "+" (48px) rispondono male, e solo sul bordo verso il centro.
//    Gli slider (192px) funzionano benissimo. Il RIEPILOGO e la ZONA (bersagli
//    grandi) non hanno mai dato problemi.
//
//    Questo NON e' un bug della schermata nuova: e' una discrepanza fra le
//    coordinate del CST816 e quelle del display, presente da sempre e MASCHERATA
//    dai bersagli grandi. I tasti piccoli l'hanno solo resa visibile. E' la
//    stessa identica diagnosi della 1.69 (§4.5 del compendio), dove le celle
//    ZONA da 66px nascondevano cio' che i tasti da 32px rivelavano.
//
//  DOVE SI APPLICA LA CORREZIONE (la decisione importante)
//    Nel DRIVER, dentro touchRead(), UNA VOLTA SOLA. Da li' in poi TUTTO il
//    firmware vede coordinate-display e nient'altro.
//
//    L'alternativa — correggere in ogni handler — sarebbe un disastro: N punti
//    da tenere allineati a mano, e ogni schermata futura una nuova occasione di
//    dimenticarsene. Il bug e' latente proprio perche' le soglie sono empiriche
//    e sparse: la cura non puo' essere aggiungerne altre. Un solo punto di
//    verita', il piu' a monte possibile.
//    (NB: la 1.69 applica la correzione in scoring_ui.cpp, NON nel driver. La
//    sua stessa documentazione dice che il posto giusto e' il driver: qui
//    seguiamo la lezione, non l'implementazione.)
//
//  COME SI OTTENGONO QUESTI NUMERI — e come NON si ottengono
//    Con touch_cal.h: 5 crocette a coordinata NOTA, si misura DI QUANTO SBAGLIA
//    la catena completa, si fitta l'errore ai minimi quadrati.
//
//    NON si deducono a tavolino. Sulla 1.69 questo e' costato SEI versioni:
//    era stato dedotto "il sensore e' piu' stretto del 28%" dagli span rx
//    31..203 letti in diagnostica -> AX=1.38953. Ma quegli span non erano i
//    bordi del sensore: erano DOVE L'UTENTE AVEVA TOCCATO. Il coefficiente
//    inventato ha CAUSATO il disallineamento che poi si cercava di correggere.
//    Misurato per bene, l'asse X era gia' allineato (AX=1.006).
//
//    REGOLA: gli span misurano l'utente, non il chip. I bersagli a coordinata
//    nota misurano il chip. Si calibra solo cosi'.
//
//  VALORI INIZIALI = IDENTITA'
//    Partiamo con la trasformazione neutra (a=1, b=0): il firmware si comporta
//    esattamente come adesso. NON mettiamo i coefficienti della 1.69: sono di
//    un ALTRO pannello, con altri pin e altra meccanica. Copiarli sarebbe
//    ripetere l'errore di usare un numero non misurato su questo hardware.
//    Si esegue la calibrazione e si ricopiano qui i numeri che escono.
// COEFFICIENTI MISURATI da Cesare con la calibrazione a 5 punti (2 passate, stilo).
// Verificati: applicati ai centri dei tre tasti li riportano tutti in zona
// (- -> 40, ? -> 114, + -> 193). La X e' espansa ~1.34x (AX=0.746), la Y ~1.16x.
// Il "non ripetibile" che la calibrazione segnalava (spread 3.1%) era un FALSO
// ALLARME: soglia troppo severa (3%), ora alzata a 5% - per un tocco a mano
// libera con lo stilo un residuo del 3% e' del tutto normale.
static constexpr float TOUCH_CAL_AX = 0.74591f;
static constexpr float TOUCH_CAL_BX = 21.84f;
static constexpr float TOUCH_CAL_AY = 0.86208f;
static constexpr float TOUCH_CAL_BY = 21.68f;

//  Se un domani si volesse tornare all'identita' (touch grezzo, per ri-diagnosi):
//    static constexpr float TOUCH_CAL_AX = 1.0f;
//    static constexpr float TOUCH_CAL_BX = 0.0f;
//    static constexpr float TOUCH_CAL_AY = 1.0f;
//    static constexpr float TOUCH_CAL_BY = 0.0f;

// ----------------------------------------------------------------------------
//  DEBUG — coerente con la disciplina 1.83: mai Serial nel loop/hot-path.
// ----------------------------------------------------------------------------
//  Su ESP32-S3 con USB CDC nativo (HWCDC) il seriale col monitor chiuso puo'
//  bloccare i task (bug noto del core). Percio' i DBG sono attivi SOLO se
//  ARCHBB_DEBUG e' definito, e comunque best-effort (setTxTimeoutMs(0) nel main).
//  In produzione (ARCHBB_DEBUG assente) diventano no-op a costo zero.
#ifdef ARCHBB_DEBUG
  #define DBG(fmt, ...)  Serial.printf("[ARCHBB] " fmt "\n", ##__VA_ARGS__)
#else
  #define DBG(fmt, ...)
#endif
