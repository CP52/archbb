# ArchBB v1.24 — installare come APP sulla home (100% locale, telefono)

Obiettivo: icona sulla home, apertura a schermo pieno senza barra del browser,
tutto sul telefono, nessun sito esterno.

## Perche' serve un mini-server (e non basta aprire il file)
Chrome installa una PWA (con icona propria) SOLO da origine sicura:
`https://` oppure `http://localhost`. Da `file://` NON offre "Installa app".
Un mini-server locale serve i file da `http://localhost:PORTA` → origine sicura
→ Chrome mostra "Installa app". Resta tutto sul telefono.

## Cosa c'e' in questa cartella
- `index.html`            → l'app (v1.24)
- `manifest.webmanifest`  → nome, icona, schermo pieno
- `sw.js`                 → service worker (necessario per l'installabilita' + offline)
- `icon.svg`              → icona dell'app

Vanno tenuti TUTTI E QUATTRO nella STESSA cartella.

## Passi (Android)

### 1. Copia la cartella sul telefono
Copia l'intera cartella `archbb/` (con i 4 file) nella memoria del telefono,
p.es. in `Download/archbb/`.

### 2. Installa un mini-server locale
Serve un'app che serva una cartella su http://localhost. Opzioni comuni dal
Play Store (una qualsiasi, sono leggere):
- "Simple HTTP Server", "Http Server", "Web Server for Chrome"-like, oppure
- se hai Termux: `pkg install python` e poi (vedi sotto).

Con Termux (consigliato, nessuna app extra):
```
pkg install python
cd /sdcard/Download/archbb
python -m http.server 8080
```
Con un'app "HTTP Server": imposta come cartella radice `Download/archbb` e
avvia; leggi la porta che mostra (spesso 8080).

### 3. Apri in Chrome
Vai su:  `http://localhost:8080/`  (o la porta che usi).
Deve comparire ArchBB. Controlla che il titolo dica **v1.24**.

### 4. Installa sulla home
In Chrome: menu (⋮) → **"Installa app"** (o "Aggiungi a schermata Home" →
proporra' l'installazione PWA, non il semplice segnalibro).
Compare l'icona ArchBB sulla home. Aprendola parte a schermo pieno.

## Dopo l'installazione: serve ancora il server?
- **Se hai installato la PWA** e il service worker ha messo i file in cache
  (succede al primo avvio con successo), l'app parte OFFLINE dalla cache anche
  senza server attivo. Se non parte, riapri una volta col server acceso per
  ricaricare la cache.
- In pratica: tieni il metodo del server a portata per gli aggiornamenti; per
  l'uso quotidiano l'icona dovrebbe bastare.

## Bluetooth
Web Bluetooth funziona da `http://localhost` e dentro la PWA installata.
Nessuna differenza rispetto a come ti connetti ora.

## Aggiornare a una versione futura
Sostituisci `index.html` (e gli altri file se cambiano) nella cartella, poi:
apri con il server, e in Chrome fai un refresh; il service worker ha una
versione di cache (`archbb-v1_24` in sw.js): cambiando quel nome ad ogni
release, la cache vecchia viene ripulita da sola.

## Calibrazione
Gli offset (CALIBRA A LIVELLA) sono salvati per-origine. Se prima usavi l'app da
un altro indirizzo, in `http://localhost` riparti da zero: rifai la
calibrazione una volta.
