// Service worker ArchBB — v1.24
// Scopo: rendere l'app INSTALLABILE come PWA (serve un SW con fetch handler
// servito dalla stessa origine) e funzionante OFFLINE (cache dei file locali).
// Nota: NON tocca il Bluetooth ne' i dati; si limita a servire i file statici.

const CACHE = 'archbb-v1_25';
const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon.svg'
];

// Install: precarica i file dell'app in cache.
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

// Activate: pulisce le cache vecchie e prende il controllo subito.
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch: cache-first per i file dell'app (offline-ready). Le richieste non-GET
// (es. eventuali API) passano dritte alla rete senza intercettazione.
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then((hit) => hit || fetch(e.request).catch(() => hit))
  );
});
