# ArchBB — Crash Persistente v2.10: Diagnosi Core & Procedura

**Data:** 6 luglio 2026
**Sintomo:** al primo scocco, beep lunghissimo poi crash `rst:0xc`, a `chunk 10/42`
**Firmware:** v2.10.0 (confermato dal boot), montaggio −90, batt 86%

---

## 1. Il fix v2.10 NON ha risolto — e questo è un dato prezioso

| | Crash precedente (v2.9) | Crash ora (v2.10) |
|---|---|---|
| Punto | chunk 30/42 | **chunk 10/42** (prima!) |
| delay | fisso 20ms | adattivo, 8ms a chunk 10 |
| Saved PC | 0x4206258e | 0x42062626 (Δ 184 byte) |
| Extra | — | **beep lunghissimo** |

**Conclusione logica:** se la causa fosse il *timing* dei chunk, un delay più
prudente avrebbe aiutato. Invece il crash è ANTICIPATO. Questo **falsifica**
l'ipotesi congestione/timing su cui era costruito il fix v2.10. La causa è
altrove. (Il flow-control di v2.10 resta comunque utile e corretto, ma non
bastava perché curava il sintomo sbagliato.)

**Il beep lunghissimo** è la firma di un crash HARD: il buzzer si accende al
trigger e va spento dopo; se resta acceso, il task è morto di colpo, non con
un'uscita ordinata. Insieme al PC quasi identico (stessa funzione NimBLE), punta
a un problema nella chiamata `notify()` stessa, non nel ritmo con cui la chiami.

---

## 2. Ipotesi principale: ble_task sul core sbagliato

In `main.cpp` (righe 258-262):

```cpp
// Tutti i task su Core 1 — Core 0 riservato al NimBLE host
xTaskCreatePinnedToCore(imu_task,     "imu",     ..., 1);
xTaskCreatePinnedToCore(trigger_task, "trigger", ..., 1);
xTaskCreatePinnedToCore(ble_task,     "ble",     ..., 1);   // <-- Core 1!
xTaskCreatePinnedToCore(display_task, "display", ..., 1);
```

Il commento dichiara "Core 0 riservato al NimBLE host", ma `ble_task` — che è il
task che chiama `notify()` — è pinnato su **Core 1**, contraddicendo l'intento.

**Perché può causare il crash:** la convenzione ESP32 vuole lo stack Bluetooth su
Core 0 (Protocol Core) e l'applicazione su Core 1 (App Core). Il NimBLE host gira
su Core 0. Chiamare `notify()` ripetutamente da Core 1, mentre l'host manipola le
stesse strutture (mbuf) su Core 0, può innescare una race condition cross-core in
codice non progettato per accessi concorrenti — crash sempre nella stessa
funzione (coerente col Saved PC costante), intermittente (dipende dall'allineamento
dei due core), e insensibile al delay (rallentare non risolve una race).

**Nota storica:** il progetto ha GIÀ combattuto race NimBLE (ble_server.cpp v2.2:
delay 100ms post-CMD). Erano pezze locali; il core sbagliato è la possibile causa
di fondo mai affrontata.

### ⚠️ Onestà intellettuale (per non ripetere l'errore diagnostico)
Questa ipotesi è **plausibile ma non ancora dimostrata**. Sottigliezza: in
NimBLE-Arduino `notify()` accoda un'operazione eseguita poi dal task host — quindi
POTREBBE essere thread-safe anche da Core 1. Per questo il passo 3 (decode del PC)
serve a CONFERMARE prima di considerare chiuso il caso. Allineare il core resta
comunque la configurazione standard e la prima cosa ragionevole da provare.

---

## 3. CONFERMA DEFINITIVA — decodifica il Saved PC

Prima (o dopo) di applicare il fix, ottieni la prova di *quale* funzione crasha.
Con l'ambiente PlatformIO del progetto, esegui il monitor col decoder:

```
pio device monitor -b 115200 --filter esp32_exception_decoder
```

Poi riproduci il crash (un primo scocco). Il decoder tradurrà `Saved PC` e lo
stack in file:riga. Cosa aspettarsi:
- Se compaiono funzioni tipo `ble_gatts_notify`, `ble_hs_mbuf`, `os_mbuf_*`,
  `ble_hs_flow_*` → conferma che il crash è nel percorso notify dello stack.
- Se compare un assert `npl_freertos_mutex_*` → conferma race/concorrenza.

Incolla qui l'output decodificato: sceglieremo il fix definitivo con certezza.

---

## 4. Fix proposto (Strada A) — ble_task su Core 0

Modifica minima in `main.cpp`, riga 261: ultimo parametro da `1` a `0`.

```cpp
// PRIMA
xTaskCreatePinnedToCore(ble_task, "ble", BLE_TASK_STACK, nullptr, 3, &h_ble, 1);
// DOPO — allinea ble_task al core del NimBLE host (Core 0), come da intento
xTaskCreatePinnedToCore(ble_task, "ble", BLE_TASK_STACK, nullptr, 3, &h_ble, 0);
```

**Verifica dopo il fix:** al boot il log deve dire `ble_task avviato su Core 0`
(la DBG a ble_server.cpp:371 stampa `xPortGetCoreID()`).

**Rischio da controllare:** Core 0 gestisce anche lo stack di sistema. Con i
delay già presenti nel burst, ble_task cede spesso la CPU, quindi non dovrebbe
saturare Core 0. Se il display (Core 1) o l'IMU mostrassero rallentamenti,
valuteremo priorità/stack.

### Alternativa (Strada B) — mutex di serializzazione
Tenere ble_task su Core 1 ma proteggere ogni chiamata NimBLE con un mutex. Più
complessa e NimBLE-Arduino non espone bene il suo mutex interno. Da usare solo
se A non bastasse.

---

## 5. Criterio di successo

Dopo il fix, sessione al tavolino con serie lunga (15-20 scocchi ravvicinati):
- boot dichiara `ble_task avviato su Core 0`
- N beep = N bing = N tiri completi nel CSV
- **zero reset**, zero beep lunghi
- nell'app v1.19, zero toast "burst incompleto"

Se regge la serie lunga senza reset, il caso BLE è chiuso e possiamo tornare al
collaudo statistico del montaggio o allo scoring flow.
