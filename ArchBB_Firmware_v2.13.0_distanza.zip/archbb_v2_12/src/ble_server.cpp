// =============================================================================
// ble_server.cpp — ArchBB v2.2: NimBLE con delay post-write
// =============================================================================
//
// FIX CRASH rst:0xc:
//   Il crash avveniva perché ble_task chiamava notify() mentre NimBLE
//   stava ancora processando la transazione GATT write del CMD.
//   NimBLE non è rientrante: chiamare notify() durante un write in corso
//   causa un assert interno → abort() → rst:0xc.
//
//   SOLUZIONE: dopo aver letto il CMD dalla coda, ble_task aspetta 100ms
//   prima di fare qualsiasi chiamata NimBLE. Questo garantisce che la
//   transazione write sia completamente terminata prima della notify.
//
//   Il delay di 100ms è invisibile all'utente (il cambio stato sul display
//   e sull'app avviene dopo 100ms — impercettibile).
// =============================================================================

#include "ble_server.h"
#include "circular_buffer.h"
#include "trigger.h"
#include "battery.h"   // g_batt_pct: carica reale al posto del vecchio 100 fisso
#include "mount.h"     // v2.9: g_mount_orientation
#include "scoring.h"     // v2.11: PendingScore, ble_send_score()
#include "shot_angles.h" // v2.11: calcolo cant/alzo dal burst pre-scocco
#include <math.h>      // lroundf per BattDiagPacket
#include <esp_pm.h>    // v2.10.4: PM lock per impedire light-sleep durante il BLE
#include <freertos/semphr.h>  // v2.10.9: semaforo di sincronizzazione notify

extern volatile bool g_shutdown;

// =============================================================================
// VARIABILI GLOBALI
// =============================================================================
volatile DeviceState g_device_state    = STATE_IDLE;
volatile uint32_t    g_last_burst_end_ms = 0;   // v2.6: istante fine ultimo burst (gating batteria)
volatile bool        g_live_streaming  = false;
volatile bool        g_batt_diag_active   = false;   // diagnostica batteria via BLE attiva
volatile uint32_t    g_batt_diag_until_ms = 0;       // fino a quando (millis)

// v2.10.10 — connection interval REALE negoziato con il client (millisecondi).
// Aggiornato in onConnect() dal ble_gap_conn_desc. Il default 30.0f è un
// fallback prudente nel caso (mai osservato finora) in cui il device iniziasse
// un burst prima che la connessione fosse completamente stabilita.
volatile float g_ble_conn_interval_ms = 30.0f;

// v2.10.10 — flag di errore dall'ultima notify (impostato in BurstCharCallbacks
// quando onStatus riporta code!=0). Usato per un BACKOFF ADATTIVO: dopo un
// errore, il prossimo chunk aspetta più a lungo prima di ripartire.
volatile bool g_last_notify_error = false;
volatile bool        g_recording_enabled = false;

static NimBLEServer*         s_server      = nullptr;
static NimBLECharacteristic* s_char_cmd    = nullptr;
static NimBLECharacteristic* s_char_status = nullptr;
static NimBLECharacteristic* s_char_burst  = nullptr;

// v2.10.9 — SINCRONIZZAZIONE VERA sul completamento della notify.
// Finora il ritmo di invio era regolato da un delay "alla cieca" (bldChunkDelay,
// tarato per posizione nel burst): un tentativo ragionevole ma pur sempre una
// stima. I dati del 07/07 mostrano che un burst di 42 notify impiega ~2.2s
// REALI anche quando la somma dei nostri delay è solo ~800ms — il vero ritmo
// è governato da qualcosa che non controlliamo (radio/connection interval),
// non dal nostro timer software.
// NimBLE-Arduino invoca pero' un callback preciso, onStatus(), quando una
// notify ha DAVVERO finito di essere trasmessa (confermato nel nostro stesso
// log verboso: "onStatus: default" dopo ogni singola notify). Usarlo come
// segnale di via libera per il chunk successivo sostituisce la stima con la
// misura diretta: non inviamo mai il prossimo pacchetto prima che il
// precedente sia realmente uscito, qualunque sia il vero collo di bottiglia.
static SemaphoreHandle_t s_notify_done = nullptr;
static NimBLECharacteristic* s_char_config = nullptr;
static NimBLECharacteristic* s_char_live   = nullptr;
static Config* s_cfg = nullptr;

// Coda comandi
#define CMD_QUEUE_LEN    8
#define CMD_PAYLOAD_MAX  12
struct BleCmd {
    uint8_t cmd;
    uint8_t payload[CMD_PAYLOAD_MAX];
    uint8_t len;
};
static QueueHandle_t s_cmd_queue = nullptr;

// CRC8
static uint8_t crc8(const uint8_t* data, size_t len) {
    uint8_t crc = 0;
    for (size_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (int b = 0; b < 8; b++)
            crc = (crc & 0x80) ? (crc << 1) ^ 0x07 : (crc << 1);
    }
    return crc;
}

// =============================================================================
// CALLBACKS NimBLE
// =============================================================================
class ArchBBServerCallbacks : public NimBLEServerCallbacks {
    void onConnect(NimBLEServer* s, ble_gap_conn_desc* d) override {
        DBG("BLE client connesso: %s",
            NimBLEAddress(d->peer_ota_addr).toString().c_str());

        // -------------------------------------------------------------------
        // v2.10.8 — DIAGNOSI + FIX: connection interval BLE.
        //
        // IPOTESI (dai tempi misurati sul log 07/07): un burst di 42 notify
        // impiega ~2.2s REALI anche quando la somma dei nostri vTaskDelay è
        // solo ~800ms. La differenza (~1.4s) non è spiegata dal nostro
        // codice: è coerente con un connection interval BLE negoziato dal
        // telefono LUNGO (i notify possono uscire solo entro le finestre di
        // trasmissione concordate, non a piacere). Se l'interval è ampio,
        // i notify si accumulano nella coda del controller BLE (HCI/LL) più
        // in fretta di quanto la radio li smaltisca: un overflow lì è un
        // candidato concreto per l'abort()/PANIC osservato, e spiegherebbe
        // perché nessuna taratura del NOSTRO delay (6-30ms) abbia mai inciso
        // — erano ordini di grandezza sotto il vero collo di bottiglia.
        //
        // d->conn_itvl è in unità di 1.25ms (convenzione BLE / Mynewt).
        float itvl_ms = d->conn_itvl * 1.25f;
        g_ble_conn_interval_ms = itvl_ms;   // v2.10.10: usata per il pacing del burst
        DBG("*** BLE conn params: interval=%.2fms latency=%u timeout=%ums ***",
            itvl_ms, d->conn_latency, d->supervision_timeout * 10);

        // Richiediamo esplicitamente un interval CORTO (15-30ms) invece di
        // accettare quello che il telefono ha proposto (spesso conservativo
        // per il risparmio energetico in background, anche 50-100ms+).
        // updateConnParams(conn_handle, minItvl, maxItvl, latency, timeout)
        // — unità: min/max in multipli di 1.25ms, timeout in multipli di 10ms.
        // 12*1.25=15ms .. 24*1.25=30ms, latenza 0 (risponde ad ogni evento),
        // timeout 600ms (>> 10x l'interval, margine di sicurezza standard).
        s->updateConnParams(d->conn_handle, 12, 24, 0, 60);

        g_device_state = STATE_CONNECTED;
        NimBLEDevice::startAdvertising();
    }
    void onDisconnect(NimBLEServer* s) override {
        DBG("BLE disconnesso");
        g_device_state      = STATE_IDLE;
        g_recording_enabled = false;
        g_live_streaming    = false;
        NimBLEDevice::startAdvertising();
    }
};

// v2.10.9 — callback di completamento per la caratteristica BURST.
// onStatus() viene invocato da NimBLE quando l'invio di una notify (header,
// chunk dati o burst-end: sono tutti sulla STESSA caratteristica) è concluso,
// con successo o con errore. In ENTRAMBI i casi il canale è di nuovo libero
// per il prossimo pacchetto, quindi diamo comunque il semaforo.
//
// NOTA SULLA FIRMA: nelle versioni NimBLE-Arduino precedenti alla 2.x (la
// nostra, 1.4.1) onStatus riceve un parametro aggiuntivo `Status status`
// oltre al `code`. Non ne verifichiamo il valore simbolico (i nomi esatti
// dei valori dell'enum non sono documentati in modo affidabile per questa
// versione): usiamo invece `code`, che è documentato in modo esplicito dagli
// autori — 0 = successo, qualunque altro valore = errore.
//
// IMPORTANTE (lezione della v2.10.6): NON logghiamo ad ogni completamento —
// significherebbe una riga seriale per ognuno dei 42 notify del burst,
// esattamente l'overhead che in precedenza ha mascherato il crash rallentando
// tutto di 5-6x. Logghiamo SOLO gli errori (rari per definizione), che non
// alterano il ritmo normale del burst.
// ⚠️ UNICO PUNTO DI RISCHIO DI QUESTA MODIFICA: se il compilatore segnala un
// errore su questa riga (firma che non corrisponde alla classe base), la
// versione di NimBLE-Arduino effettivamente installata usa una firma diversa.
// Alternative da provare, in ordine di probabilità:
//   1) due soli parametri (stile 2.x):
//        void onStatus(NimBLECharacteristic* pCharacteristic, int code) override
//   2) NimBLEConnInfo al posto di Status:
//        void onStatus(NimBLECharacteristic* pCharacteristic,
//                       NimBLEConnInfo& connInfo, int code) override
// In tutti i casi la logica interna (dare il semaforo, loggare se code!=0)
// resta identica: basta sostituire la riga della firma.
class BurstCharCallbacks : public NimBLECharacteristicCallbacks {
    void onStatus(NimBLECharacteristic* pCharacteristic, Status status, int code) override {
        if (code != 0) {
            DBG("burst notify: errore code=%d", code);
            g_last_notify_error = true;   // v2.10.10: innesca backoff sul prossimo chunk
        }
        if (s_notify_done) xSemaphoreGive(s_notify_done);
    }
};

class CmdCallbacks : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic* pChar) override {
        if (!s_cmd_queue) return;
        // Accesso diretto senza std::string — evita allocazione heap
        const uint8_t* data = pChar->getValue().data();
        size_t len = pChar->getValue().size();
        if (len == 0 || !data) return;

        BleCmd cmd = {};
        cmd.cmd = data[0];
        cmd.len = (uint8_t)(len > CMD_PAYLOAD_MAX + 1 ? CMD_PAYLOAD_MAX : len - 1);
        if (cmd.len > 0) memcpy(cmd.payload, data + 1, cmd.len);
        xQueueSend(s_cmd_queue, &cmd, 0);
    }
};

class ConfigCallbacks : public NimBLECharacteristicCallbacks {
    void onWrite(NimBLECharacteristic* pChar) override {
        if (!s_cfg) return;
        const uint8_t* data = pChar->getValue().data();
        size_t len = pChar->getValue().size();
        if (len < sizeof(Config)) return;
        Config nc;
        memcpy(&nc, data, sizeof(Config));
        if (nc.checksum != config_calc_checksum(nc)) return;

        // v2.4: validazione range — una Config malformata (es. pre_trigger_ms
        // troppo alto) produrrebbe total_samples > buffer, con get_burst che
        // legge fuori range e trigger_idx oltre il totale → crash app/firmware.
        if (calcTotalSamples(nc) > 750) return;          // rifiuta: non sta nel buffer
        if (nc.trig_confirm_n < 1)  nc.trig_confirm_n = 1;
        if (nc.trig_confirm_n > 10) nc.trig_confirm_n = 10;
        if (nc.rearm_ms < 200)      nc.rearm_ms = 200;
        if (nc.trig_threshold_ms2 < 0.5f) nc.trig_threshold_ms2 = 0.5f;

        // v2.9: valida orientamento montaggio (NVS/app corrotta → frontale)
        if (!mount_is_valid(nc.mount_orientation)) nc.mount_orientation = MOUNT_0;

        *s_cfg = nc;
        trigger_update_config(*s_cfg);

        // v2.9: propaga l'orientamento all'imu_task. Scrittura atomica di un
        // uint8_t: l'imu_task (Core 1) legge sempre un valore coerente.
        g_mount_orientation = nc.mount_orientation;
    }
    void onRead(NimBLECharacteristic* pChar) override {
        if (s_cfg) {
            s_cfg->checksum = config_calc_checksum(*s_cfg);
            pChar->setValue((uint8_t*)s_cfg, sizeof(Config));
        }
    }
};

// =============================================================================
// ble_notify_status()
// =============================================================================
void ble_notify_status(DeviceState state, uint16_t shot_count, uint8_t batt_pct) {
    if (!s_char_status) return;
    if (!s_server || s_server->getConnectedCount() == 0) return;

    StatusPacket pkt = {};
    pkt.pkt_type     = 0x02;
    pkt.device_state = (uint8_t)state;
    pkt.shot_counter = shot_count;
    pkt.batt_pct     = batt_pct;
    pkt.uptime_s     = (float)(millis() / 1000UL);
    // La versione ora ha 6 caratteri ("2.12.0"); il campo e' char[6]. Copiamo
    // fino a sizeof-1 e forziamo il terminatore, cosi' la stringa non si tronca
    // ("2.11.3" con il vecchio limite 5 diventava "2.11.") ne' resta senza '\0'.
    strncpy(pkt.fw_version, FW_VERSION_STR, sizeof(pkt.fw_version) - 1);
    pkt.fw_version[sizeof(pkt.fw_version) - 1] = '\0';

    s_char_status->setValue((uint8_t*)&pkt, sizeof(StatusPacket));
    s_char_status->notify();
}

// =============================================================================
// v2.10 — CONTROLLO DI FLUSSO BLE (back-pressure adattivo)
// =============================================================================
// Parametri del delay adattivo tra chunk. Valori in millisecondi.
//   MIN: delay all'inizio del burst.
//   MAX: delay nella fascia "calda" del burst.
//
// STORIA DELLA DIAGNOSI (per non ripetere gli errori):
//   - v2.10   : ipotesi "congestione/timing" -> delay adattivo. FALSA: il primo
//               burst attraversava la zona calda e sopravviveva, il secondo
//               moriva a bassa pressione. Il carico non correlava col crash.
//   - v2.10.1 : ipotesi "race cross-core" -> ble_task su Core 0. Ha eliminato il
//               crash NimBLE originale (0x4206...) ma ne ha causato uno NUOVO
//               (0x4037...), sistematico al primo tiro. ERRORE: vedi sotto.
//   - v2.10.2 : ipotesi "Task WDT affamato" -> delay >= tick. FALSA: il TWDT non
//               era la causa, il fix non ha cambiato nulla.
//   - v2.10.3 : DECODE del Saved PC 0x40377ae4 = esp_restart_noos = meccanismo
//               di reset invocato da un WATCHDOG. Non è il Task WDT ma
//               l'INTERRUPT WDT: con ble_task su Core 0, la contesa sulle
//               sezioni critiche di NimBLE (spinlock che disabilitano gli
//               interrupt) teneva gli interrupt bloccati oltre il timeout IWDT.
//               FIX: ble_task torna su Core 1 + timeout IWDT alzato (sdkconfig).
//   - v2.10.6 : CORE_DEBUG_LEVEL=5 per catturare il backtrace del PANIC. Il
//               crash SPARISCE — ma è un artefatto: il log NimBLE interno
//               (attivato dallo stesso flag) aggiunge 5-6 righe seriali per
//               notify, rallentando il burst da <1s a ~4.6s. Mascherato, non
//               risolto (v2.10.7 lo conferma: senza debug, il crash torna).
//   - v2.10.8 : misura diretta — un burst di 42 notify impiega ~2.2s REALI
//               anche con soli ~800ms di delay software: il vero ritmo è
//               governato da qualcosa fuori dal nostro controllo (radio/
//               connection interval, 30ms misurato). Reso esplicito il
//               conn interval e stretto (12-24 * 1.25ms).
//   - v2.10.9 : sostituito il delay "stimato per posizione" con la SINCRO
//               VERA sul completamento reale via onStatus() (vedi
//               BurstCharCallbacks sopra). Non indoviniamo più il ritmo:
//               aspettiamo la conferma hardware che il pacchetto precedente
//               sia uscito prima di accodare il successivo.
//   - v2.10.10: LA CAUSA VERA, finalmente misurata (non più dedotta):
//               v2.10.9 ha prodotto il primo errore ESPLICITO mai catturato:
//               "burst notify: errore code=6" = BLE_HS_ENOMEM (buffer mbuf
//               esauriti). Cercando questo identico codice nel repository
//               ufficiale NimBLE-Arduino (issue #614), il mantenitore stesso
//               (h2zero) e un utente con lo STESSO connection interval
//               (30ms, identico al nostro misurato) documentano che un delay
//               INFERIORE al connection interval satura i buffer -> stesso
//               "status 4 rc 6" che vediamo noi. La ragione fisica: una
//               notify può uscire solo entro le finestre di trasmissione
//               concordate (ogni conn_interval ms); accodarne un'altra prima
//               che la precedente abbia avuto la sua finestra riempie i
//               buffer mbuf più in fretta di quanto si svuotino.
//               FIX: il delay minimo non è più una costante indovinata, ma è
//               ANCORATO al connection interval REALE negoziato (misurato in
//               g_ble_conn_interval_ms, aggiornato ad ogni connessione), con
//               un margine di sicurezza. bldFlowNotify() resta comunque
//               sincronizzata su onStatus() (v2.10.9): i due meccanismi sono
//               complementari, non alternativi — onStatus ci dice quando il
//               pacchetto PRECEDENTE è confermato accettato, il floor
//               temporale garantisce di non chiamare notify() più spesso di
//               quanto la radio possa fisicamente smaltire.
//
// Margine oltre il connection interval misurato. Il caso documentato in
// NimBLE-Arduino #614 mostrava fallimenti già con delay=10ms su interval=30ms
// (quindi < interval fallisce) e successo con delay=12ms in un contesto con
// interval diverso: la costante sicura è "interval + margine", non un valore
// assoluto. +5ms è un margine prudente (~17% extra sul nostro caso, 30->35ms).
static constexpr float BLD_INTERVAL_MARGIN_MS = 5.0f;

// Se l'ultima notify è fallita (g_last_notify_error), applichiamo un backoff
// PIÙ AMPIO prima del prossimo tentativo — i buffer hanno bisogno di più
// tempo per svuotarsi dopo una condizione di saturazione, non solo un
// margine lineare aggiuntivo.
static constexpr float BLD_BACKOFF_MULTIPLIER = 2.5f;

// bldFlowNotify() — invia una notify sul canale burst, sincronizzata sul
//   completamento REALE del pacchetto precedente (v2.10.9).
//
//   MECCANISMO: prima di inviare, ATTENDE che il semaforo s_notify_done sia
//   disponibile — cioè che la notify precedente abbia ricevuto onStatus().
//   Dopo aver chiamato notify(), il semaforo resta "preso": solo il prossimo
//   onStatus() lo rilascerà. Questo impedisce STRUTTURALMENTE di accodare un
//   pacchetto prima che il precedente sia davvero uscito — niente più stime.
//
//   TIMEOUT DI SICUREZZA: se onStatus() non arrivasse mai (bug dello stack,
//   client scomparso senza generare l'evento), un timeout largo (300ms, ben
//   oltre qualunque connection interval ragionevole) evita che il task resti
//   bloccato per sempre. Il pacchetto potrebbe essere perso in quel caso, ma
//   il burst prosegue e il CRC/conteggio lato app lo segnalerà.
//
//   LIMITE VERSIONE: in NimBLE-Arduino 1.4.1 notify() ritorna void (nessun
//   bool di successo immediato) — ma non ci serve: onStatus() è il segnale
//   di completamento asincrono corretto, indipendente dal valore di ritorno.
static constexpr uint32_t BLD_NOTIFY_TIMEOUT_MS = 300;

static void bldFlowNotify(NimBLECharacteristic* ch) {
    // Attende che il pacchetto precedente sia confermato uscito.
    if (s_notify_done) {
        if (xSemaphoreTake(s_notify_done, pdMS_TO_TICKS(BLD_NOTIFY_TIMEOUT_MS)) != pdTRUE) {
            DBG("bldFlowNotify: timeout attesa onStatus (>%ums) — procedo comunque",
                (unsigned)BLD_NOTIFY_TIMEOUT_MS);
            // Non ri-prendiamo il semaforo: lo lasciamo "libero" per non
            // incastrare il prossimo giro se il completamento arriva tardi.
        }
    }
    ch->notify();   // 1.4.1: void; il vero esito arriva via onStatus()
}

// bldChunkDelay() — delay da applicare DOPO l'invio di un chunk (v2.10.10).
//
//   Non è più una rampa per posizione nel burst (ipotesi v2.10, poi
//   falsificata): è un FLOOR ancorato al connection interval REALE misurato
//   (g_ble_conn_interval_ms), con margine di sicurezza. Se l'ultima notify è
//   fallita (ENOMEM o altro), applichiamo un backoff più ampio: i buffer
//   saturi hanno bisogno di più respiro per svuotarsi, non solo di un margine
//   lineare aggiuntivo.
//
//   `sent`/`total` non servono più al calcolo (nessuna rampa), ma restano nei
//   parametri per compatibilità con i punti di chiamata esistenti — inutile
//   rifattorizzare tutte le chiamate per questo.
static uint32_t bldChunkDelay(uint16_t /*sent*/, uint16_t /*total*/) {
    float floor_ms = g_ble_conn_interval_ms + BLD_INTERVAL_MARGIN_MS;
    if (g_last_notify_error) {
        floor_ms *= BLD_BACKOFF_MULTIPLIER;
        g_last_notify_error = false;   // consumato: il prossimo chunk parte pulito
    }
    return (uint32_t)floor_ms;
}

// =============================================================================
// ble_send_burst()
// =============================================================================
void ble_send_burst(const ImuSample* samples, uint16_t total,
                    uint16_t trigger_idx, uint8_t batt_pct) {
    if (!s_char_burst || !s_server || s_server->getConnectedCount() == 0) return;

    g_device_state = STATE_SENDING;

    BurstHeader hdr = {};
    hdr.pkt_type      = 0x01;
    hdr.shot_id       = g_shot_id;
    hdr.total_samples = total;
    hdr.pre_samples   = trigger_idx;
    hdr.trigger_sample= trigger_idx;
    hdr.trigger_src   = s_cfg ? (uint8_t)s_cfg->trig_mode : 0;
    hdr.accel_range   = s_cfg ? s_cfg->accel_range_g : 8;
    hdr.gyro_range    = s_cfg ? s_cfg->gyro_range_dps : 512;
    hdr.odr_hz_idx    = s_cfg ? (uint8_t)s_cfg->odr : 1;
    hdr.trigger_ts_us = g_trigger_ts_us;
    hdr.batt_pct      = batt_pct;
    hdr.pressure_hpa  = 0.0f;
    s_char_burst->setValue((uint8_t*)&hdr, sizeof(BurstHeader));
    bldFlowNotify(s_char_burst);           // v2.10: invio header (notify void)
    vTaskDelay(pdMS_TO_TICKS(20));

    DBG("burst_send: total=%u heap=%u", total, ESP.getFreeHeap());

    static uint8_t chunk_buf[6 + MAX_SAMPLES_PER_CHUNK * sizeof(ImuSample)];
    uint8_t crc_acc = 0, chunk_idx = 0;
    uint16_t sent = 0;

    // v2.10: DELAY ADATTIVO PER POSIZIONE NEL BURST.
    // Il vecchio delay fisso a 20ms/chunk aspettava alla cieca, uguale ovunque,
    // e su burst lunghi non bastava: NimBLE crashava (rst:0xc a chunk 30/42,
    // sessione 06JUL). Causa reale (doc Espressif ESP-IDF #9097): chiamare
    // notify() piu' in fretta di quanto lo stack smaltisca -> esaurimento buffer
    // mbuf -> BLE_HS_ENOMEM -> crash.
    //
    // In NimBLE-Arduino 1.4.1 notify() e' VOID: non possiamo sapere dal ritorno
    // se lo stack e' congestionato, quindi niente back-pressure con retry.
    // STRATEGIA ALTERNATIVA fondata sui DATI reali: il crash avveniva sempre
    // nella fascia centrale-alta del burst (chunk 25-32/42), dove i buffer si
    // accumulano. Applichiamo percio' un delay che CRESCE con l'avanzare del
    // burst (bldChunkDelay): rapido all'inizio (stack libero), piu' prudente
    // nella zona calda. Rampa basata sulla posizione, non sul ritorno di notify.

    while (sent < total) {
        // --- v2.10: verifica connessione viva PRIMA di ogni chunk ---
        // Nel crash del 06/07 il peer si era disconnesso a meta' burst e il
        // firmware continuava a chiamare notify() verso un peer assente — una
        // delle cause del rst:0xc. Se la connessione cade, interrompiamo con
        // grazia invece di spingere pacchetti nel vuoto.
        if (!s_server || s_server->getConnectedCount() == 0) {
            DBG("burst_send: peer disconnesso a chunk %u/%u — interrotto",
                chunk_idx, (total+MAX_SAMPLES_PER_CHUNK-1)/MAX_SAMPLES_PER_CHUNK);
            g_device_state = g_recording_enabled ? STATE_RECORDING : STATE_CONNECTED;
            return;
        }

        uint8_t count = (uint8_t)min((uint16_t)(total-sent), (uint16_t)MAX_SAMPLES_PER_CHUNK);
        DataChunkHeader ch = {0x03, chunk_idx, g_shot_id, (uint8_t)sent, count};
        memcpy(chunk_buf, &ch, sizeof(ch));
        const uint8_t* sb = (const uint8_t*)(samples + sent);
        size_t dl = count * sizeof(ImuSample);
        memcpy(chunk_buf + sizeof(ch), sb, dl);
        crc_acc ^= crc8(sb, dl);

        s_char_burst->setValue(chunk_buf, sizeof(ch) + dl);
        bldFlowNotify(s_char_burst);   // 1.4.1: notify() void, fire-and-forget

        sent += count; chunk_idx++;

        // --- yield esplicito dopo la notify ---
        // Cede lo scheduler così altri task possono girare tra un chunk e
        // l'altro.
        taskYIELD();

        // v2.10.10: floor ancorato al connection interval reale (+ backoff se
        // l'ultima notify è fallita). Non è più marginale: è ora il vincolo
        // primario, verificato empiricamente (issue NimBLE-Arduino #614: un
        // delay sotto il connection interval produce lo stesso identico
        // errore ENOMEM/code=6 che abbiamo osservato sul campo). Il semaforo
        // di bldFlowNotify (v2.10.9) resta come sincronizzazione complementare.
        uint32_t chunk_delay_ms = bldChunkDelay(sent, total);

        if (chunk_idx % 10 == 0) {
            DBG("  chunk %u/%u heap=%u delay=%ums", chunk_idx,
                (total+MAX_SAMPLES_PER_CHUNK-1)/MAX_SAMPLES_PER_CHUNK,
                ESP.getFreeHeap(), (unsigned)chunk_delay_ms);
        }

        vTaskDelay(pdMS_TO_TICKS(chunk_delay_ms));
    }

    BurstEnd end = {0x04, g_shot_id, sent, 0, crc_acc};
    s_char_burst->setValue((uint8_t*)&end, sizeof(end));
    bldFlowNotify(s_char_burst);           // v2.10: BurstEnd (notify void)

    if (s_cfg) s_cfg->shot_counter++;
    // v2.6: marca l'istante di fine burst. Il campionamento batteria lo usa per
    // NON misurare subito dopo una trasmissione (la tensione è ancora depressa
    // dall'IR drop e risalirà solo dopo un po' di riposo).
    g_last_burst_end_ms = millis();

    // --- v2.11: INNESTO SCORING ---------------------------------------------
    // Prima di rilasciare lo stato, calcoliamo gli angoli biomeccanici dal burst
    // (l'array 'samples' e' ancora valido QUI: dopo il return non lo sarebbe piu').
    // Depositiamo angoli + shot_id nel ponte g_pending_score, poi entriamo in
    // STATE_SCORING: sara' il display_task a raccogliere l'esito col touch e a
    // chiamare ble_send_score(). Il task BLE, invece, torna libero SUBITO — la
    // radio non resta bloccata durante la valutazione (che puo' durare secondi).
    ShotAngles ang = shot_angles_compute(samples, total, trigger_idx,
                                         s_cfg ? s_cfg->odr : ODR_250HZ);
    g_pending_score.shot_id      = g_shot_id;
    g_pending_score.cant_cdeg    = shot_angle_to_cdeg(ang.cant_deg);
    g_pending_score.alzo_cdeg    = shot_angle_to_cdeg(ang.alzo_deg);
    g_pending_score.disp_ms2     = ang.disp_ms2;
    g_pending_score.angles_valid = ang.valid;
    // reset dei campi di esito (verranno riempiti dal display_task)
    g_pending_score.valutato     = false;
    g_pending_score.colpito      = false;
    g_pending_score.zona         = 0;
    g_pending_score.distanza_m   = 0;
    g_pending_score.ready        = true;   // segnala al display_task: c'e' da valutare

    DBG("burst fine: angoli cant=%.2f alzo=%.2f disp=%.2f valid=%d stable=%d |g|=%.2f -> SCORING",
        ang.cant_deg, ang.alzo_deg, ang.disp_ms2, ang.valid, ang.stable, ang.g_mean);

    g_device_state = STATE_SCORING;
    // NB: l'uscita da SCORING (a CONNECTED/RECORDING) la gestisce il display_task
    // a valutazione conclusa, SKIP o timeout. Vedi display.cpp.
    // ------------------------------------------------------------------------
}

// =============================================================================
// SCORING (v2.11) — stato condiviso e trasmissione dello ScorePacket
// =============================================================================
// Istanza globale del ponte dati fra ble_server (angoli) e display_task (esito).
volatile PendingScore g_pending_score = {};

// Assembla e trasmette lo ScorePacket dai dati in g_pending_score.
// Chiamata dal display_task a scoring completato / SKIP / timeout.
// Usa la caratteristica BURST (stessa del tiro): l'app discrimina per pkt_type
// (0x06) e per lunghezza esatta (10 byte, unica). Nessun impatto sul flow
// control del burst: qui inviamo UNA sola notify, non uno stream.
bool ble_send_score() {
    if (!s_char_burst || !s_server || s_server->getConnectedCount() == 0) return false;

    ScorePacket sp = {};
    sp.pkt_type    = 0x06;
    sp.shot_id     = g_pending_score.shot_id;
    sp.score_flags = scoreFlagsPack(g_pending_score.valutato,
                                    g_pending_score.colpito,
                                    g_pending_score.zona);
    sp.distanza_m  = g_pending_score.distanza_m;
    // Gli angoli si trasmettono SEMPRE (anche se il tiro e' saltato): sono una
    // misura oggettiva del gesto, indipendente dalla valutazione soggettiva.
    sp.cant_cdeg   = g_pending_score.angles_valid ? g_pending_score.cant_cdeg : 0;
    sp.alzo_cdeg   = g_pending_score.angles_valid ? g_pending_score.alzo_cdeg : 0;
    sp.score_ver   = SCORE_FORMAT_VERSION;

    s_char_burst->setValue((uint8_t*)&sp, sizeof(sp));
    // In NimBLE-Arduino (questa versione) notify() restituisce void: la conferma
    // reale di trasmissione arriva dal callback onStatus(), non dal ritorno. Per
    // lo ScorePacket (una singola notify, non uno stream) e' sufficiente sapere
    // che siamo connessi — gia' verificato dalla guardia a inizio funzione.
    s_char_burst->notify();
    DBG("score inviato: shot=%u flags=0x%02X dist=%u cant=%d alzo=%d",
        sp.shot_id, sp.score_flags, sp.distanza_m, sp.cant_cdeg, sp.alzo_cdeg);
    return true;
}

// =============================================================================
// ble_server_init()
// =============================================================================
void ble_server_init(const char* advertising_name, Config* cfg_ptr) {
    s_cfg = cfg_ptr;
    s_cmd_queue = xQueueCreate(CMD_QUEUE_LEN, sizeof(BleCmd));

    DBG("BLE init NimBLE — %s", advertising_name);
    NimBLEDevice::init(advertising_name);
    NimBLEDevice::setMTU(BLE_MTU_SIZE);
    NimBLEDevice::setPower(ESP_PWR_LVL_P9);

    static ArchBBServerCallbacks server_cb;
    s_server = NimBLEDevice::createServer();
    s_server->setCallbacks(&server_cb);

    NimBLEService* svc = s_server->createService(ARCHBB_SERVICE_UUID);

    static CmdCallbacks cmd_cb;
    s_char_cmd = svc->createCharacteristic(ARCHBB_CHAR_CMD_UUID,
        NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
    s_char_cmd->setCallbacks(&cmd_cb);

    s_char_status = svc->createCharacteristic(ARCHBB_CHAR_STATUS_UUID,
        NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY);

    s_char_burst = svc->createCharacteristic(ARCHBB_CHAR_BURST_UUID,
        NIMBLE_PROPERTY::NOTIFY);
    static BurstCharCallbacks burst_cb;
    s_char_burst->setCallbacks(&burst_cb);

    // v2.10.9: semaforo binario per la sincronizzazione notify->onStatus.
    // Creato "dato" (non "vuoto"): il primissimo prendere non deve aspettare
    // un completamento che non è ancora mai avvenuto.
    if (!s_notify_done) {
        s_notify_done = xSemaphoreCreateBinary();
        xSemaphoreGive(s_notify_done);
    }

    static ConfigCallbacks cfg_cb;
    s_char_config = svc->createCharacteristic(ARCHBB_CHAR_CONFIG_UUID,
        NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
    s_char_config->setCallbacks(&cfg_cb);
    if (cfg_ptr) {
        cfg_ptr->checksum = config_calc_checksum(*cfg_ptr);
        s_char_config->setValue((uint8_t*)cfg_ptr, sizeof(Config));
    }

    s_char_live = svc->createCharacteristic(ARCHBB_CHAR_LIVE_UUID,
        NIMBLE_PROPERTY::NOTIFY);

    svc->start();

    NimBLEAdvertising* adv = NimBLEDevice::getAdvertising();
    adv->addServiceUUID(ARCHBB_SERVICE_UUID);
    adv->setScanResponse(true);
    NimBLEDevice::startAdvertising();

    DBG("BLE advertising avviato — device name: %s", advertising_name);
}

// =============================================================================
// ble_task() — con delay post-CMD per evitare race condition NimBLE
// =============================================================================
void ble_task(void* param) {
    DBG("ble_task avviato su Core %d", xPortGetCoreID());

    // -------------------------------------------------------------------------
    // v2.10.4 — FIX DEFINITIVO: PM lock contro il light-sleep durante il BLE.
    //
    // DIAGNOSI (finalmente certa, via decode del Saved PC):
    //   Core 1: 0x42062626 = esp_pm_impl_waiti  (il core dormiva in idle)
    //   Core 0: 0x40377ae4 = esp_restart_noos    (il reset in esecuzione)
    // Entrambi puntano al POWER MANAGEMENT, non a NimBLE. Il core arduino-esp32
    // ha CONFIG_PM_ENABLE attivo di default: tra un task e l'altro il sistema
    // entra in automatic light-sleep (tickless idle) e/o scala la frequenza CPU.
    // Durante burst_send, questo è LETALE: in light-sleep le periferiche sono
    // clock-gated e gli interrupt radio non vengono serviti in tempo -> lo stack
    // BLE si blocca -> watchdog -> reset (esp_restart_noos). La latenza aggiuntiva
    // degli interrupt introdotta dal PM (fino a 40us, doc Espressif) basta a far
    // saltare il timing serrato delle 42 notify del burst.
    //
    // PERCHÉ I FIX PRECEDENTI HANNO FALLITO: delay, core, watchdog... agivano
    // TUTTI sopra il PM, che restava la causa sottostante.
    //
    // SOLUZIONE: un PM lock ESP_PM_NO_LIGHT_SLEEP acquisito qui e mantenuto per
    // tutta la vita del task. Impedisce al sistema di entrare in light-sleep
    // mentre il BLE è attivo. Funziona A RUNTIME, quindi NON dipende da
    // sdkconfig (che con le librerie Arduino precompilate poteva non applicarsi).
    // Se il PM non fosse attivo, la creazione del lock è un no-op innocuo.
    //
    // COSTO: consumo leggermente maggiore (niente light-sleep). Accettabile: il
    // device è alimentato a LiPo e usato a sessioni, non in standby prolungato.
    // Se in futuro servisse risparmio, si può acquisire il lock SOLO attorno a
    // burst_send invece che per tutta la vita del task.
    static esp_pm_lock_handle_t s_pm_lock = nullptr;
    esp_err_t pm_rc = esp_pm_lock_create(ESP_PM_NO_LIGHT_SLEEP, 0,
                                         "archbb_ble", &s_pm_lock);
    if (pm_rc == ESP_OK && s_pm_lock) {
        esp_pm_lock_acquire(s_pm_lock);
        DBG("PM lock NO_LIGHT_SLEEP acquisito (anti-crash BLE)");
    } else {
        DBG("PM lock non creato (rc=%d) — PM forse non attivo, ok", (int)pm_rc);
    }

    ImuSample* burst_buf = (ImuSample*)malloc(750 * sizeof(ImuSample));
    uint32_t last_status_ms = 0;

    for (;;) {
        if (g_shutdown) { vTaskDelete(nullptr); }

        // Leggi CMD dalla coda
        BleCmd cmd;
        if (s_cmd_queue && xQueueReceive(s_cmd_queue, &cmd, 0) == pdTRUE) {
            DBG("CMD: 0x%02X heap:%u", cmd.cmd, ESP.getFreeHeap());

            // === DELAY CRITICO ===
            // Aspetta 100ms per garantire che la transazione GATT write
            // sia completamente terminata prima di qualsiasi chiamata NimBLE.
            // Senza questo delay, notify() durante un write causa rst:0xc.
            vTaskDelay(pdMS_TO_TICKS(100));

            switch ((CmdByte)cmd.cmd) {
                case CMD_START_REC:
                    if (g_device_state == STATE_CONNECTED ||
                        g_device_state == STATE_IDLE) {
                        circular_buffer_reset();
                        g_recording_enabled = true;
                        g_device_state      = STATE_RECORDING;
                        ble_notify_status(STATE_RECORDING,
                                         s_cfg ? s_cfg->shot_counter : 0, g_batt_pct);
                        DBG("START REC");
                    }
                    break;
                case CMD_STOP_REC:
                    g_recording_enabled = false;
                    g_live_streaming    = false;
                    g_device_state      = STATE_CONNECTED;
                    ble_notify_status(STATE_CONNECTED,
                                     s_cfg ? s_cfg->shot_counter : 0, g_batt_pct);
                    break;
                case CMD_MANUAL_TRIGGER:
                    if (g_device_state == STATE_RECORDING) trigger_manual();
                    break;
                case CMD_START_LIVE:
                    g_live_streaming = true;
                    g_device_state   = STATE_LIVE;
                    break;
                case CMD_STOP_LIVE:
                    g_live_streaming = false;
                    g_device_state   = STATE_CONNECTED;
                    break;
                case CMD_BATT_DIAG:
                    // Avvia la diagnostica batteria via BLE. Durata opzionale
                    // in secondi dai 2 byte di payload (default 240s = 4 min).
                    {
                        uint16_t dur_s = 240;
                        if (cmd.len >= 2)
                            dur_s = (uint16_t)(cmd.payload[0] | (cmd.payload[1] << 8));
                        g_batt_diag_until_ms = millis() + (uint32_t)dur_s * 1000UL;
                        g_batt_diag_active   = true;
                        DBG("BATT DIAG avviata per %us", dur_s);
                    }
                    break;
                case CMD_PING:
                    ble_notify_status(g_device_state,
                                     s_cfg ? s_cfg->shot_counter : 0, g_batt_pct);
                    break;
                default: break;
            }
        }

        // Burst trigger — v2.4: consuma il semaforo postato da trigger_task
        // invece di pollare BUFFER_READY. Prima il polling lasciava lo stato
        // READY per ~1s (durata invio) e, con le graffe mancanti, ble_send_burst
        // veniva chiamata di nuovo al giro successivo → doppio invio → crash.
        if (g_trigger_fired_sem &&
            xSemaphoreTake(g_trigger_fired_sem, 0) == pdTRUE) {

            // v2.11: INIBIZIONE TRIGGER DURANTE LO SCORING.
            // Se stiamo valutando un tiro (STATE_SCORING), un nuovo scuotimento
            // NON deve avviare un altro burst: un tiro si valuta prima del
            // successivo (coerente col design doc). Consumiamo il semaforo (gia'
            // fatto sopra) per non accumularlo, resettiamo il buffer per scartare
            // i campioni raccolti, e ignoriamo il trigger.
            if (g_device_state == STATE_SCORING) {
                circular_buffer_reset();
                DBG("trigger ignorato: scoring in corso");
            } else {
            // attende che il buffer abbia finito di accumulare i post-campioni
            uint32_t wait0 = millis();
            while (circular_buffer_state() != BUFFER_READY &&
                   (millis() - wait0) < 1000) {
                vTaskDelay(pdMS_TO_TICKS(5));
            }
            if (circular_buffer_state() == BUFFER_READY && burst_buf) {
                uint16_t trig_idx = 0;
                uint16_t n = circular_buffer_get_burst(burst_buf, 750, &trig_idx);
                if (n > 0 && s_server && s_server->getConnectedCount() > 0) {
                    DBG("Avvio burst: n=%u trig=%u heap=%u", n, trig_idx, ESP.getFreeHeap());
                    ble_send_burst(burst_buf, n, trig_idx, g_batt_pct);
                    DBG("Burst completato heap=%u", ESP.getFreeHeap());
                }
                circular_buffer_reset();   // sempre, anche se non inviato (no client)
            }
            }   // v2.11: chiude l'else dell'inibizione scoring
        }

        // Live streaming 50Hz — invia ImuSample sulla caratteristica LIVE
        if (g_live_streaming && s_char_live &&
            s_server && s_server->getConnectedCount() > 0) {
            static uint32_t last_live_ms = 0;
            if (millis() - last_live_ms >= 20) {
                last_live_ms = millis();
                ImuSample s = {};
                if (xSemaphoreTake(g_imu_sample_mutex, pdMS_TO_TICKS(2)) == pdTRUE) {
                    s = g_latest_sample;
                    xSemaphoreGive(g_imu_sample_mutex);
                }
                s_char_live->setValue((uint8_t*)&s, sizeof(ImuSample));
                s_char_live->notify();
            }
        }

        // Diagnostica batteria via BLE — invia BattDiagPacket a 1 Hz sulla
        // caratteristica LIVE (riuso: già cablata per notifiche frequenti).
        // Serve a osservare il transitorio di accensione della tensione SENZA
        // collegare l'USB (che ricaricherebbe la LiPo falsando la misura).
        if (g_batt_diag_active && s_char_live &&
            s_server && s_server->getConnectedCount() > 0) {
            static uint32_t last_diag_ms = 0;
            if (millis() - last_diag_ms >= 1000) {
                last_diag_ms = millis();
                if ((int32_t)(millis() - g_batt_diag_until_ms) >= 0) {
                    g_batt_diag_active = false;   // durata esaurita
                    DBG("BATT DIAG terminata");
                } else {
                    uint8_t rp = 0;
                    float v = battery_debug_read(&rp);
                    BattDiagPacket p = {};
                    p.pkt_type = 0x05;
                    p.ts_ms    = millis();
                    p.mv       = (uint16_t)lroundf(v * 1000.0f);
                    p.raw_pct  = rp;
                    p.filt_pct = g_batt_pct;
                    s_char_live->setValue((uint8_t*)&p, sizeof(BattDiagPacket));
                    s_char_live->notify();
                }
            }
        }

        // STATUS heartbeat ogni 5s
        if (millis() - last_status_ms > 5000) {
            if (s_server && s_server->getConnectedCount() > 0)
                ble_notify_status(g_device_state,
                                 s_cfg ? s_cfg->shot_counter : 0, g_batt_pct);
            last_status_ms = millis();
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
    vTaskDelete(nullptr);
}

bool ble_is_connected() {
    return s_server && s_server->getConnectedCount() > 0;
}
bool ble_is_burst_subscribed() { return ble_is_connected(); }
bool ble_is_live_subscribed()  { return ble_is_connected(); }

