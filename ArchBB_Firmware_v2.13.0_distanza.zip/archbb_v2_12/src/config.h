// =============================================================================
// config.h — ArchBB Black Box: costanti globali, UUID BLE, struct Config
// Versione v1.2 (firmware 2.11.0)
// =============================================================================
//
// CHANGELOG v1.2 (firmware 2.11.0 — Fase C scoring):
//   - Aggiunto STATE_SCORING = 0x06 all'enum DeviceState (valutazione post-burst,
//     gestita dal display_task per non bloccare il task BLE).
//   - Aggiunto ScorePacket (pkt_type 0x06, 10 byte): esito+zona+distanza+cant+alzo.
//     Lunghezza 10 scelta per UNICITA' (evita collisione coi 9 byte di BattDiag).
//   - Aggiunti helper scoreFlagsPack/scoreFlagValutato/Colpito/Zona,
//     SCORE_FORMAT_VERSION, SCORING_TIMEOUT_MS.
//   - Nient'altro modificato: Config, ImuSample e gli altri pacchetti INVARIATI.
//
// CHANGELOG v1.1:
//   - ImuSample: rimosso _pad, size = 30 byte (2+4+6×4=30). static_assert aggiornato.
//     Il protocollo BLE usa 30 byte per campione (MAX_SAMPLES_PER_CHUNK = 16).
//   - Tutti i pacchetti di protocollo aggiornati di conseguenza.
// =============================================================================

#pragma once

#include <Arduino.h>
#include <stdint.h>

#define FW_VERSION_STR   "2.13.0"
#define FW_BUILD_DATE    __DATE__

// Pin dal display offset
static constexpr int16_t DISPLAY_Y_OFFSET = 20;
static constexpr int16_t DISPLAY_W        = 240;
static constexpr int16_t DISPLAY_H        = 280;

// =============================================================================
// BLE UUID (lowercase — obbligatorio per Chrome Android Web Bluetooth)
// =============================================================================
#define ARCHBB_SERVICE_UUID        "bb4ac000-0001-0000-0000-000000000001"
#define ARCHBB_CHAR_CMD_UUID       "bb4ac000-0001-0000-0000-000000000010"
#define ARCHBB_CHAR_STATUS_UUID    "bb4ac000-0001-0000-0000-000000000020"
#define ARCHBB_CHAR_BURST_UUID     "bb4ac000-0001-0000-0000-000000000030"
#define ARCHBB_CHAR_CONFIG_UUID    "bb4ac000-0001-0000-0000-000000000040"
#define ARCHBB_CHAR_LIVE_UUID      "bb4ac000-0001-0000-0000-000000000050"
#define BLE_DEVICE_NAME_PREFIX     "ArchBB-"
#define BLE_MTU_SIZE               512

// =============================================================================
// ENUM COMANDI / STATI / ODR
// =============================================================================
enum CmdByte : uint8_t {
    CMD_START_REC        = 0x01,
    CMD_STOP_REC         = 0x02,
    CMD_MANUAL_TRIGGER   = 0x03,
    CMD_SET_TRIGGER_MODE = 0x04,  // [mode:u8][threshold:f32]
    CMD_SET_WINDOW       = 0x05,  // [pre_ms:u16][post_ms:u16]
    CMD_SET_ODR          = 0x06,  // [odr_idx:u8]
    CMD_START_LIVE       = 0x07,
    CMD_STOP_LIVE        = 0x08,
    CMD_BATT_DIAG        = 0x10,  // avvia diagnostica batteria via BLE [dur_s:u16]
    CMD_PING             = 0xFF,
};

enum TriggerMode : uint8_t {
    TRIG_AZ_THRESHOLD = 0,
    TRIG_JERK         = 1,
    TRIG_MANUAL       = 2,
};

enum DeviceState : uint8_t {
    STATE_IDLE        = 0x00,
    STATE_CONNECTED   = 0x01,
    STATE_RECORDING   = 0x02,
    STATE_TRIGGERED   = 0x03,
    STATE_SENDING     = 0x04,
    STATE_LIVE        = 0x05,
    STATE_SCORING     = 0x06,  // v2.11: valutazione del tiro post-burst
                               //  Ingresso: automatico a fine ble_send_burst.
                               //  Gestito dal display_task (touch + 3 schermate),
                               //  NON dal task BLE: cosi' la radio torna libera
                               //  subito e il flow control del burst resta intatto.
                               //  Uscita: completamento / SKIP / timeout -> CONNECTED.
};

enum OdrSetting : uint8_t {
    ODR_100HZ  = 0,   // QMI8658: ACC_ODR_125Hz / GYR_ODR_112_1Hz  (il più vicino)
    ODR_250HZ  = 1,   // QMI8658: ACC_ODR_250Hz / GYR_ODR_224_2Hz  (DEFAULT)
    ODR_500HZ  = 2,   // QMI8658: ACC_ODR_500Hz / GYR_ODR_448_4Hz
};

// Frequenza nominale in Hz per calcoli (valore approssimato)
inline uint16_t odrToHz(OdrSetting odr) {
    switch (odr) {
        case ODR_100HZ: return 112;   // GYR_ODR_112_1Hz reale
        case ODR_250HZ: return 224;   // GYR_ODR_224_2Hz reale
        case ODR_500HZ: return 448;   // GYR_ODR_448_4Hz reale
        default:        return 224;
    }
}

// =============================================================================
// STRUCT CONFIG (NVS-persistente, BLE-serializzata)
// =============================================================================
struct __attribute__((packed)) Config {
    TriggerMode trig_mode;
    float       trig_threshold_ms2;  // default 20.0 m/s²
    uint8_t     trig_confirm_n;      // default 2 campioni
    uint16_t    rearm_ms;            // default 2000 ms
    uint16_t    pre_trigger_ms;      // default 500 ms
    uint16_t    post_trigger_ms;     // default 250 ms
    OdrSetting  odr;
    uint8_t     accel_range_g;       // 2, 4, 8, 16
    uint16_t    gyro_range_dps;      // 16,32,64,128,256,512,1024
    uint16_t    shot_counter;
    uint16_t    session_id;
    uint8_t     config_version;      // usa _pad[0] — sizeof(Config) invariato
    uint8_t     mount_orientation;   // v2.9: era _pad — MountOrientation (0..3)
                                     //  0=frontale 1=DX(-90) 2=SX(+90) 3=180
                                     //  sizeof(Config) INVARIATO: nessuna
                                     //  corruzione NVS delle config esistenti.
    uint8_t     checksum;
};

inline Config configDefaults() {
    Config c;
    c.trig_mode          = TRIG_AZ_THRESHOLD;
    c.trig_threshold_ms2 = 20.0f;
    c.trig_confirm_n     = 2;
    c.rearm_ms           = 2000;
    c.pre_trigger_ms     = 3000;  // 3s @ 224Hz = 672 campioni
    c.post_trigger_ms    = 350;   // 350ms = 78 campioni → tot 750
    c.odr                = ODR_250HZ;
    c.accel_range_g      = 8;
    c.gyro_range_dps     = 512;
    c.shot_counter       = 0;
    c.session_id         = 0;
    c.config_version     = 3;     // v2.9: +mount_orientation (bump da 2)
    c.mount_orientation  = 0;     // MOUNT_0 = frontale (comportamento v2.8)
    c.checksum           = 0;
    return c;
}

inline uint8_t config_calc_checksum(const Config& c) {
    const uint8_t* b = reinterpret_cast<const uint8_t*>(&c);
    uint8_t x = 0;
    for (size_t i = 0; i < sizeof(Config) - 1; i++) x ^= b[i];
    return x;
}

// =============================================================================
// STRUTTURE PACCHETTI BLE
// =============================================================================

// --- ImuSample: 30 byte ---
// Layout: u16(2) + u32(4) + 6×f32(24) = 30 byte
// NESSUN padding: packed garantisce 30 byte esatti su ESP32 Xtensa.
// MAX_SAMPLES_PER_CHUNK = 16 → 16×30=480 + 6(header) = 486 < 509 (MTU-3)
struct __attribute__((packed)) ImuSample {
    uint16_t seq;           // numero sequenziale
    uint32_t timestamp_us;  // µs da boot (esp_timer_get_time())
    float    ax;            // [m/s²]
    float    ay;            // [m/s²]
    float    az;            // [m/s²]
    float    gx;            // [°/s]
    float    gy;            // [°/s]
    float    gz;            // [°/s]
};
static_assert(sizeof(ImuSample) == 30, "ImuSample deve essere 30 byte");

// MAX campioni per chunk (MTU 512, ATT header 3B, chunk header 6B)
// 512 - 3 - 6 = 503 / 30 = 16.7 → 16
static constexpr uint8_t MAX_SAMPLES_PER_CHUNK = 16;

// -----------------------------------------------------------------------------
// v2.10: CONTROLLO DI FLUSSO BLE (fix crash rst:0xc durante burst_send)
// -----------------------------------------------------------------------------
// Il crash avveniva a meta' invio burst (chunk ~30/42) per congestione dello
// stack NimBLE: notify() e' fire-and-forget e in NimBLE-Arduino 1.4.1 il suo
// valore di ritorno NON e' affidabile (changelog: "Notify/Indicate incorrectly
// returning success"). Non potendo interrogare la congestione, usiamo una
// strategia difensiva combinata:
//   - pausa tra chunk configurabile (adattiva: piu' lunga ogni N chunk per dare
//     respiro allo stack; breve altrimenti per non allungare troppo il burst);
//   - yield esplicito dopo ogni notify (cede a NimBLE su Core 0);
//   - verifica connessione viva ad ogni iterazione (se il peer si disconnette a
//     meta' burst, ci fermiamo con grazia invece di spingere notify nel vuoto).
static constexpr uint16_t BLE_CHUNK_DELAY_MS      = 12;  // pausa base tra chunk
static constexpr uint16_t BLE_CHUNK_DELAY_LONG_MS = 25;  // pausa "di respiro"
static constexpr uint8_t  BLE_CHUNK_BREATHE_EVERY = 8;   // ogni N chunk, pausa lunga

// --- BurstHeader (pkt_type=0x01) ---
struct __attribute__((packed)) BurstHeader {
    uint8_t  pkt_type;         // 0x01
    uint16_t shot_id;
    uint16_t total_samples;
    uint16_t pre_samples;
    uint16_t trigger_sample;
    uint8_t  trigger_src;      // TriggerMode
    uint8_t  accel_range;      // g
    uint16_t gyro_range;       // dps
    uint8_t  odr_hz_idx;       // OdrSetting
    uint32_t trigger_ts_us;
    uint8_t  batt_pct;
    float    pressure_hpa;     // 0.0 se BMP280 assente
    uint8_t  _pad;
};

// --- DataChunkHeader (pkt_type=0x03) ---
struct __attribute__((packed)) DataChunkHeader {
    uint8_t  pkt_type;       // 0x03
    uint8_t  chunk_idx;
    uint16_t shot_id;
    uint8_t  sample_start;
    uint8_t  sample_count;
};

// --- BurstEnd (pkt_type=0x04) ---
struct __attribute__((packed)) BurstEnd {
    uint8_t  pkt_type;       // 0x04
    uint16_t shot_id;
    uint16_t total_sent;
    uint16_t lost_samples;
    uint8_t  crc8;
};

// --- StatusPacket (pkt_type=0x02) ---
struct __attribute__((packed)) StatusPacket {
    uint8_t  pkt_type;        // 0x02
    uint8_t  device_state;
    uint16_t shot_counter;
    uint8_t  batt_pct;
    float    uptime_s;
    char     fw_version[6];   // "1.0.1\0"
};

// --- BattDiagPacket (pkt_type=0x05) --- DIAGNOSTICA BATTERIA ---
// Inviato sulla caratteristica LIVE a 1 Hz quando la diagnostica batteria è
// attiva (comando CMD_BATT_DIAG). Serve a osservare il transitorio di
// accensione della tensione SENZA collegare l'USB (che ricaricherebbe la LiPo
// falsando la misura). 8 byte.
struct __attribute__((packed)) BattDiagPacket {
    uint8_t  pkt_type;        // 0x05
    uint32_t ts_ms;           // millis() dal boot
    uint16_t mv;              // tensione batteria grezza (mV, ×3 già applicato)
    uint8_t  raw_pct;         // percentuale LUT diretta (non filtrata)
    uint8_t  filt_pct;        // percentuale filtrata (per confronto)
};

// --- ScorePacket (pkt_type = 0x06) --- VALUTAZIONE DEL TIRO --- 10 byte ---
// v2.11: trasmette all'app l'esito dello scoring on-device (colpito/mancato,
// zona d'impatto 3x3, distanza) PIU' due angoli biomeccanici (cant e alzo)
// calcolati dal burst nella finestra di stabilita' PRE-SCOCCO.
//
// QUANDO VIENE INVIATO
//   NON in coda al burst (come ipotizzato nel design doc originale), perche' con
//   l'architettura scelta lo scoring avviene DOPO che ble_send_burst e' gia'
//   terminato: l'utente tocca le 3 schermate con calma, secondi dopo il tiro.
//   Il display_task, completato lo scoring, chiama ble_send_score() che invia
//   questo pacchetto. Il legame col tiro e' garantito da shot_id, invariante.
//
// PERCHE' 10 BYTE (e non 9)
//   Un pacchetto da 9 byte COLLIDEREBBE con BattDiagPacket (anch'esso 9 byte):
//   l'app discrimina i pacchetti per LUNGHEZZA ESATTA (lezione appresa), quindi
//   due pacchetti di pari lunghezza sono ambigui. Il campo score_ver porta la
//   lunghezza a 10 (libera: le altre sono 6/8/9/15/24/30) E versiona il formato.
//
// ANGOLI: perche' PRE-SCOCCO e non "al rilascio"
//   All'istante dello scocco l'accelerometro e' dominato dallo spike dinamico
//   dello strappo (az ~+34 m/s^2), non dalla gravita': l'assetto calcolato li'
//   sarebbe falsato (un alzo reale di 12 deg verrebbe letto come ~73 deg). La
//   finestra di STABILITA' pre-trigger (arco fermo in mira) e' invece dominata
//   dalla gravita' -> assetto pulito. cant = atan2(ay,ax), alzo = atan2(az,ax),
//   su campioni gia' in frame CANONICO (la trasformazione di montaggio e' a
//   monte in imu.cpp, quindi il calcolo e' identico per tutti e 4 i montaggi).
//   Gli angoli sono una STIMA da validare incrociandoli con lo scoring reale:
//   se il cant correla con la dispersione laterale registrata, la misura e'
//   buona; altrimenti va rivista. I dati comandano.
struct __attribute__((packed)) ScorePacket {
    uint8_t  pkt_type;     // 0x06
    uint16_t shot_id;      // little-endian, lega al burst dello stesso tiro
    uint8_t  score_flags;  // bit0    : valutato (1) / saltato (0)
                           // bit1    : esito colpito (1) / mancato (0)
                           // bit2..5 : zona 0..8 (griglia 3x3; 0=alto-sx..8=basso-dx)
                           // bit6..7 : riservati
    uint8_t  distanza_m;   // 0 = ignota (SKIP schermata distanza); 5..60 = metri
    int16_t  cant_cdeg;    // cant  in centesimi di grado (×100); +dx / -sx
    int16_t  alzo_cdeg;    // alzo  in centesimi di grado (×100); +su / -giu
    uint8_t  score_ver;    // versione formato scoring (=1); porta il pkt a 10 byte
};
static_assert(sizeof(ScorePacket) == 10, "ScorePacket deve essere 10 byte (unicita' di lunghezza)");

// Versione corrente del formato scoring (campo score_ver dello ScorePacket)
static constexpr uint8_t SCORE_FORMAT_VERSION = 1;

// Timeout di sicurezza dello stato SCORING: se l'utente non tocca lo schermo
// per questo periodo, il tiro viene salvato NON valutato e la macchina prosegue.
// v2.11.3: si misura dall'ULTIMO TOCCO (si resetta a ogni interazione), non
// dall'ingresso: cosi' binocolo/telemetro tra un tocco e l'altro non fanno
// scadere lo scoring. 60s dall'ultimo tocco copre abbondantemente le pause.
static constexpr uint32_t SCORING_TIMEOUT_MS = 60000;

// --- Helper di packing dei flag di scoring (usati da firmware e riletti da app) ---
inline uint8_t scoreFlagsPack(bool valutato, bool colpito, uint8_t zona) {
    uint8_t f = 0;
    if (valutato) f |= 0x01;
    if (colpito)  f |= 0x02;
    f |= (uint8_t)((zona & 0x0F) << 2);   // zona 0..8 nei bit 2..5
    return f;
}
inline bool    scoreFlagValutato(uint8_t f) { return  f & 0x01; }
inline bool    scoreFlagColpito (uint8_t f) { return  f & 0x02; }
inline uint8_t scoreFlagZona    (uint8_t f) { return (f >> 2) & 0x0F; }

// =============================================================================
// BUFFER CIRCOLARE
// =============================================================================
static constexpr uint16_t CIRCULAR_BUFFER_SIZE = 750;  // campioni in PSRAM

inline uint16_t calcPreSamples(const Config& c) {
    return (uint16_t)((float)c.pre_trigger_ms / 1000.0f * odrToHz(c.odr));
}
inline uint16_t calcPostSamples(const Config& c) {
    return (uint16_t)((float)c.post_trigger_ms / 1000.0f * odrToHz(c.odr));
}
inline uint16_t calcTotalSamples(const Config& c) {
    return calcPreSamples(c) + calcPostSamples(c);
}

// =============================================================================
// DEBUG MACRO
// =============================================================================
// NOTA (v2.9): SensorLib (SensorCommDebug.hpp) definisce una propria macro DBG.
// Per evitare il warning "DBG redefined" quando entrambi gli header sono
// inclusi nello stesso TU (es. imu.cpp include config.h e SensorQMI8658.hpp),
// facciamo #undef preventivo: la nostra definizione ArchBB prevale in modo
// esplicito e intenzionale, senza collisioni silenziose.
#ifdef DBG
  #undef DBG
#endif
#ifdef DBG_RAW
  #undef DBG_RAW
#endif

#ifdef ARCHBB_DEBUG
  #define DBG(fmt, ...)     Serial.printf("[ARCHBB] " fmt "\n", ##__VA_ARGS__)
  #define DBG_RAW(fmt, ...) Serial.printf(fmt, ##__VA_ARGS__)
#else
  #define DBG(fmt, ...)
  #define DBG_RAW(fmt, ...)
#endif

