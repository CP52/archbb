// =============================================================================
// shot_angles.h — ArchBB: calcolo angoli biomeccanici dal burst (v1.2)
// Firmware 2.12.5 — Fase C scoring
// =============================================================================
//
// SCOPO
//   Estrarre dal burst IMU due angoli d'assetto dell'arco, misurati nella
//   FINESTRA DI STABILITA' che precede lo scocco (arco fermo in mira):
//     - CANT  : rollio laterale dell'arco (inclinazione dx/sx)
//     - ALZO  : elevazione dell'asse freccia rispetto all'orizzonte (pitch)
//
//   Questi angoli accompagnano lo scoring nello ScorePacket e finiscono nel CSV,
//   per permettere di CORRELARE la biomeccanica (come hai mirato) con l'esito
//   (dove e' andata la freccia). Sono una STIMA da validare sul campo: se il
//   cant correla con la dispersione laterale registrata dallo scoring, la
//   misura ha potere predittivo; altrimenti va rivista. I dati comandano.
//
// PERCHE' PRE-SCOCCO E NON "AL RILASCIO"
//   All'istante dello scocco l'accelerometro e' dominato dallo spike dinamico
//   dello strappo (az balza a ~+34 m/s^2), non dalla gravita': l'assetto
//   calcolato li' sarebbe falsato (un alzo reale di 12 deg verrebbe letto come
//   ~73 deg). Nella finestra pre-trigger, ad arco fermo, l'accelerometro e'
//   dominato dalla gravita' -> assetto pulito.
//
// GEOMETRIA DELLA FINESTRA
//   Non si prendono gli ULTIMISSIMI campioni prima del trigger: negli ~50ms che
//   precedono il rilascio l'arciere sta gia' "partendo" (clicker scattato, mano
//   di corda in apertura), c'e' micro-movimento. Si arretra di un GUARD GAP e si
//   media una finestra di STABILITA' precedente:
//
//     [ ........ mira stabile ........ | guard gap | SCOCCO | post ]
//                ^--- finestra media ---^  ~50ms    trigger_idx
//
//   Default: guard gap 50ms, finestra 200ms (a 224Hz: ~11 e ~44 campioni).
//   Entrambi ricavati dall'ODR reale, non assunti.
//
// FRAME DI RIFERIMENTO
//   I campioni del burst sono GIA' in frame CANONICO 0 deg (la trasformazione di
//   montaggio e' applicata a monte in imu.cpp). Quindi il calcolo e' IDENTICO
//   per tutti e 4 i montaggi. Convenzioni (da mount.h, ancorate a tiri reali):
//     ax = verticale / gravita'  (+ ad arco verticale)
//     ay = laterale dx/sx        (base del cant)
//     az = asse freccia / scocco
//   cant = atan2(ay, ax)   ->  +dx / -sx  ;  0 ad arco verticale
//   alzo = atan2(az, ax)   ->  +su / -giu ;  0 ad asse freccia orizzontale
//
// QUALITA' DELLA MISURA
//   La funzione restituisce anche la DISPERSIONE (deviazione standard del modulo
//   dell'accelerazione) nella finestra: bassa = arco fermo, misura affidabile;
//   alta = arciere in movimento, angolo meno attendibile. Permette all'app di
//   pesare o filtrare le stime.
// =============================================================================

#pragma once

#include <Arduino.h>
#include <stdint.h>
#include "config.h"   // ImuSample, odrToHz, OdrSetting

// Parametri di default della finestra (in ms); convertiti in campioni con l'ODR.
static constexpr uint16_t SHOT_ANGLE_GUARD_MS  = 50;   // gap minimo prima del trigger
static constexpr uint16_t SHOT_ANGLE_WINDOW_MS = 200;  // ampiezza finestra di media

// Soglie di STABILITA' della finestra (tarate sul test statico 13/07f).
// La finestra adattiva sceglie, fra tutte le posizioni pre-trigger, quella col
// vettore accelerazione piu' vicino alla sola gravita' (|a|~g, dispersione bassa):
// li' l'accelerometro misura l'assetto, non il movimento. Se nemmeno la migliore
// e' abbastanza pulita, l'angolo e' marcato non-stabile (stable=false).
//   Dai dati: finestre buone |g| in [9.9..10.3] sd<0.5 ; finestre nel movimento
//   |g|>11 sd>2. Soglie con margine:
static constexpr float SHOT_ANGLE_G_TOL_MS2  = 1.5f;   // |mean|a| - g| ammesso
static constexpr float SHOT_ANGLE_SD_MAX_MS2 = 1.0f;   // dispersione |a| ammessa
static constexpr float SHOT_ANGLE_GRAVITY    = 9.81f;  // g di riferimento

// Risultato del calcolo angoli.
struct ShotAngles {
    bool  valid;      // true se la finestra aveva abbastanza campioni validi
    float cant_deg;   // rollio laterale [deg]  (+dx / -sx)
    float alzo_deg;   // elevazione asse freccia [deg] (+su punta alto / -giu)
    float disp_ms2;   // dispersione |a| nella finestra [m/s^2] (qualita': basso=fermo)
    int   n_used;     // numero di campioni effettivamente mediati
    bool  stable;     // true se la finestra scelta e' STABILE (|g|~9.8, sd bassa):
                      //   assetto affidabile. false = finestra migliore comunque
                      //   dentro il movimento -> angolo poco attendibile.
    float g_mean;     // |a| medio della finestra scelta [m/s^2] (diagnostica)
};

// Calcola cant e alzo dalla finestra di stabilita' pre-scocco.
//   samples     : array del burst (gia' in frame canonico)
//   total       : numero totale di campioni nel burst
//   trigger_idx : indice del campione di scocco entro l'array
//   odr         : impostazione ODR (per convertire ms->campioni)
// Ritorna ShotAngles con valid=false se non ci sono abbastanza campioni pre-scocco.
ShotAngles shot_angles_compute(const ImuSample* samples, uint16_t total,
                               uint16_t trigger_idx, OdrSetting odr);

// Converte un angolo in gradi a centesimi di grado (int16) per lo ScorePacket.
// Satura a +-180.00 deg (+-18000) per sicurezza.
int16_t shot_angle_to_cdeg(float deg);
