// =============================================================================
// display.cpp — implementazione display ST7789V2 (v1.1)
// =============================================================================
//
// CORREZIONI v1.1:
//   - Rimosso setFreeFont(nullptr): API non valida in TFT_eSPI Arduino.
//     Si usa setTextFont(0) per tornare al font di default built-in.
//   - TFT_WIDTH/TFT_HEIGHT: questi simboli appartengono all'header TFT_eSPI
//     e vengono definiti dal file User_Setup.h. Per evitare conflitti di nome,
//     usiamo le costanti proprie DISPLAY_W e DISPLAY_H da config.h.
//   - La creazione dello sprite usa DISPLAY_W e DISPLAY_H esplicitamente.
//
// NOTA su User_Setup.h e TFT_WIDTH:
//   TFT_eSPI richiede che User_Setup.h definisca TFT_WIDTH e TFT_HEIGHT
//   per il costruttore TFT_eSPI(). Il file include/User_Setup.h deve esistere
//   con i valori corretti (240, 320). Il display fisico è 240×280 ma il
//   controller ST7789V2 è 240×320 — l'offset y=20 gestisce la differenza.
// =============================================================================

#include "display.h"
#include "ble_server.h"
#include "imu.h"
#include "trigger.h"
#include "battery.h"   // g_batt_pct per l'icona batteria reale
#include "power.h"     // gestione backlight/beep guidata dallo stato
#include "mount.h"     // v2.9: g_mount_orientation per indicazione a boot
#include "scoring_ui.h" // v2.11: UI dello stato STATE_SCORING

extern volatile bool g_shutdown;  // definita in main.cpp

static TFT_eSPI    tft    = TFT_eSPI();
static TFT_eSprite sprite = TFT_eSprite(&tft);

// Flag anti-flickering shutdown countdown.
// Definito qui, dichiarato extern in display.h.
// loop() lo alza durante il countdown PWR → display_task salta il render.
volatile bool g_display_suspended = false;

// =============================================================================
// Helper: barra orizzontale
// =============================================================================
static void draw_bar(int16_t x, int16_t y, int16_t w, int16_t h,
                     uint8_t pct, uint16_t col_fill, uint16_t col_bg) {
    int16_t fill_w = (int16_t)((float)pct / 100.0f * w);
    if (fill_w > 0) sprite.fillRect(x, y, fill_w, h, col_fill);
    if (fill_w < w) sprite.fillRect(x + fill_w, y, w - fill_w, h, col_bg);
    sprite.drawRect(x - 1, y - 1, w + 2, h + 2, COL_GRAY);
}

// Helper: icona batteria
static void draw_battery_icon(int16_t x, int16_t y, uint8_t pct) {
    uint16_t col = (pct > 60) ? COL_GREEN : (pct > 25) ? COL_AMBER : COL_RED;
    sprite.drawRect(x, y, 22, 11, COL_WHITE);
    sprite.fillRect(x + 22, y + 3, 3, 5, COL_WHITE);
    int16_t fw = (int16_t)(18.0f * pct / 100.0f);
    if (fw > 0) sprite.fillRect(x + 2, y + 2, fw, 7, col);
}

// =============================================================================
// display_init()
// =============================================================================
void display_init() {
    tft.init();
    tft.setRotation(0);

    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, HIGH);
    tft.fillScreen(COL_BG);

    // Crea sprite con dimensioni display fisico (240×280)
    sprite.createSprite(DISPLAY_W, DISPLAY_H);
    sprite.setColorDepth(16);

    DBG("Display init OK — %dx%d (controller 240x320, y_offset=%d)",
        DISPLAY_W, DISPLAY_H, DISPLAY_Y_OFFSET);

    // v2.11: inizializza il touch CST816T per lo scoring (reset + no auto-sleep).
    // Il bus I2C è già stato aperto da main.cpp; qui configuriamo solo il chip.
    scoring_ui_init();
}

// =============================================================================
// display_show_boot()
// =============================================================================
void display_show_boot() {
    sprite.fillSprite(COL_BG);

    // Header
    sprite.setTextColor(COL_CYAN, COL_BG);
    sprite.setTextDatum(TC_DATUM);
    // FIX: setTextFont(int) invece di setFreeFont(nullptr)
    sprite.setTextFont(0);
    sprite.setTextSize(2);

    sprite.drawString("->->->->", 120, 30, 4);

    sprite.setTextColor(COL_WHITE, COL_BG);
    sprite.drawString("ArchBB", 120, 75, 6);

    sprite.setTextSize(1);
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Archery Black Box", 120, 128, 2);

    sprite.setTextColor(COL_CYAN, COL_BG);
    sprite.drawString("v" FW_VERSION_STR, 120, 150, 2);

    // v2.9: indicazione orientamento di montaggio, cosi' l'arciere ha conferma
    // visiva all'accensione di come e' configurato il device sul riser.
    sprite.setTextColor(COL_AMBER, COL_BG);
    char mnt[24];
    snprintf(mnt, sizeof(mnt), "Montaggio: %s", mount_name(g_mount_orientation));
    sprite.drawString(mnt, 120, 168, 2);

    // Barra di boot animata
    sprite.drawRect(20, 188, 200, 12, COL_GRAY);
    for (int i = 0; i <= 100; i += 5) {
        sprite.fillRect(21, 189, (int16_t)(198.0f * i / 100.0f), 10, COL_CYAN);
        sprite.pushSprite(0, DISPLAY_Y_OFFSET);
        delay(15);
    }

    sprite.setTextColor(COL_DARKGRAY, COL_BG);
    sprite.drawString("C.Pagura / Anthropic 2026", 120, 238, 1);
    sprite.pushSprite(0, DISPLAY_Y_OFFSET);
    delay(800);
}

// =============================================================================
// display_screen_idle()
// =============================================================================
void display_screen_idle(bool ble_connected, uint16_t shot_count, uint8_t batt_pct) {
    sprite.fillSprite(COL_BG);

    // Header
    sprite.fillRect(0, 0, DISPLAY_W, 30, COL_DARKGRAY);
    sprite.setTextColor(COL_CYAN, COL_DARKGRAY);
    sprite.setTextDatum(TC_DATUM);
    sprite.drawString("ArchBB v" FW_VERSION_STR, 120, 8, 2);

    // Stato BLE
    int16_t y = 45;
    sprite.setTextDatum(TL_DATUM);
    if (ble_connected) {
        sprite.fillCircle(18, y + 7, 6, COL_GREEN);
        sprite.setTextColor(COL_GREEN, COL_BG);
        sprite.drawString("CONNESSO", 32, y, 2);
    } else {
        sprite.fillCircle(18, y + 7, 6, COL_AMBER);
        sprite.setTextColor(COL_AMBER, COL_BG);
        sprite.drawString("BLE: ricerca...", 32, y, 2);
    }

    // Colpi
    y = 85;
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Colpi sessione:", 15, y, 2);
    char buf[16];
    snprintf(buf, sizeof(buf), "%d", shot_count);
    sprite.setTextColor(COL_WHITE, COL_BG);
    sprite.drawString(buf, 15, y + 22, 4);

    // Batteria
    y = 155;
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Batteria", 15, y, 2);
    draw_battery_icon(170, y, batt_pct);
    snprintf(buf, sizeof(buf), "%d%%", batt_pct);
    sprite.setTextColor((batt_pct > 25) ? COL_GREEN : COL_RED, COL_BG);
    sprite.drawString(buf, 15, y + 22, 2);

    // Temperatura IMU — aggiornata ogni 10s per evitare race condition I2C
    // imu_task usa continuamente il bus I2C; leggere la temp troppo spesso
    // causa valori erratici per accesso concorrente non sincronizzato.
    y = 210;
    static float s_cached_temp   = 0.0f;
    static uint32_t s_last_temp_ms = 0;
    if (g_imu_ok && (millis() - s_last_temp_ms > 10000 || s_last_temp_ms == 0)) {
        // Aspetta mutex IMU prima di leggere temperatura
        if (xSemaphoreTake(g_imu_sample_mutex, pdMS_TO_TICKS(5)) == pdTRUE) {
            s_cached_temp = imu_read_temperature();
            xSemaphoreGive(g_imu_sample_mutex);
            s_last_temp_ms = millis();
        }
    }
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Temp IMU:", 15, y, 2);
    if (s_cached_temp > -100.0f && !isnan(s_cached_temp)) {
        snprintf(buf, sizeof(buf), "%.1f C", s_cached_temp);
        sprite.setTextColor(COL_CYAN, COL_BG);
        sprite.drawString(buf, 15, y + 20, 2);
    }

    // Footer
    sprite.setTextDatum(BC_DATUM);
    sprite.setTextColor(COL_DARKGRAY, COL_BG);
    sprite.drawString("Avvia app ArchBB sul telefono", 120, DISPLAY_H - 2, 1);

    sprite.pushSprite(0, DISPLAY_Y_OFFSET);
}

// =============================================================================
// display_screen_recording()
// =============================================================================
void display_screen_recording(uint16_t shot_count, float az_live, bool rec_blink) {
    sprite.fillSprite(COL_BG);

    // Header REC lampeggiante
    uint16_t hdr_col = rec_blink ? 0xC000 : COL_DARKGRAY;
    sprite.fillRect(0, 0, DISPLAY_W, 40, hdr_col);
    sprite.setTextDatum(TC_DATUM);
    sprite.setTextColor(COL_RED, hdr_col);
    sprite.drawString("  REC", 120, 10, 4);

    // Punto rosso animato
    if (rec_blink) sprite.fillCircle(28, 22, 8, COL_RED);

    // Stato trigger
    const char* phase_str = "ARMED";
    uint16_t    phase_col = COL_GREEN;
    switch (g_trigger_phase) {
        case TRIG_PHASE_CONFIRMING: phase_str = "DETECTING"; phase_col = COL_AMBER; break;
        case TRIG_PHASE_FIRED:      phase_str = "TRIGGERED"; phase_col = COL_RED;   break;
        case TRIG_PHASE_REARM:      phase_str = "REARM...";  phase_col = COL_GRAY;  break;
        default: break;
    }
    sprite.setTextColor(phase_col, COL_BG);
    sprite.drawString(phase_str, 120, 58, 4);

    // Contatore colpi
    char buf[32];
    sprite.setTextDatum(TL_DATUM);
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Colpi:", 15, 112, 2);
    snprintf(buf, sizeof(buf), "%d", shot_count);
    sprite.setTextColor(COL_WHITE, COL_BG);
    sprite.drawString(buf, 100, 109, 4);

    // Az live
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Az live:", 15, 162, 2);
    snprintf(buf, sizeof(buf), "%.2f m/s2", az_live);
    uint16_t az_col = (fabsf(az_live) > 15.0f) ? COL_AMBER : COL_CYAN;
    sprite.setTextColor(az_col, COL_BG);
    sprite.drawString(buf, 15, 180, 2);

    // Mini-misuratore Az
    float az_pct = constrain(fabsf(az_live) / 80.0f * 100.0f, 0.0f, 100.0f);
    draw_bar(15, 210, 210, 12, (uint8_t)az_pct, az_col, COL_DARKGRAY);
    sprite.setTextColor(COL_DARKGRAY, COL_BG);
    sprite.drawString("0", 15, 226, 1);
    sprite.drawString("80m/s2", 175, 226, 1);

    sprite.pushSprite(0, DISPLAY_Y_OFFSET);
}

// =============================================================================
// display_screen_triggered()
// =============================================================================
void display_screen_triggered(uint16_t shot_id, float az_peak, uint8_t send_progress_pct) {
    sprite.fillSprite(COL_BG);

    sprite.fillRect(0, 0, DISPLAY_W, 55, 0xA000);
    sprite.setTextDatum(TC_DATUM);
    sprite.setTextColor(COL_WHITE, 0xA000);
    sprite.drawString("SHOT!", 120, 8, 6);

    char buf[32];
    snprintf(buf, sizeof(buf), "# %d", shot_id);
    sprite.setTextColor(COL_CYAN, COL_BG);
    sprite.drawString(buf, 120, 72, 4);

    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Az picco:", 120, 122, 2);
    snprintf(buf, sizeof(buf), "%.1f m/s2", fabsf(az_peak));
    sprite.setTextColor(COL_AMBER, COL_BG);
    sprite.drawString(buf, 120, 144, 4);

    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Invio BLE:", 120, 196, 2);
    draw_bar(15, 214, 210, 18, send_progress_pct, COL_CYAN, COL_DARKGRAY);
    snprintf(buf, sizeof(buf), "%d%%", send_progress_pct);
    sprite.setTextColor(COL_WHITE, COL_BG);
    sprite.drawString(buf, 120, 238, 2);

    sprite.pushSprite(0, DISPLAY_Y_OFFSET);
}

// =============================================================================
// display_screen_live()
// =============================================================================
void display_screen_live(float ax, float ay, float az, float gx, float gy, float gz) {
    sprite.fillSprite(COL_BG);

    sprite.fillRect(0, 0, DISPLAY_W, 35, 0x000F);
    sprite.setTextDatum(TC_DATUM);
    sprite.setTextColor(COL_CYAN, 0x000F);
    sprite.drawString("LIVE  50Hz", 120, 8, 4);

    sprite.setTextDatum(TL_DATUM);
    int16_t y = 50;
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Accelerometro [m/s2]", 15, y, 1);
    y += 14;

    char row[24];
    auto draw_row = [&](const char* lbl, float val, uint16_t col) {
        snprintf(row, sizeof(row), "%s %+7.2f", lbl, val);
        sprite.setTextColor(col, COL_BG);
        sprite.drawString(row, 15, y, 2);
        y += 22;
    };
    draw_row("Ax:", ax, COL_RED);
    draw_row("Ay:", ay, COL_GREEN);
    draw_row("Az:", az, COL_CYAN);

    y += 4;
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Giroscopio [deg/s]", 15, y, 1);
    y += 14;
    draw_row("Gx:", gx, COL_RED);
    draw_row("Gy:", gy, COL_GREEN);
    draw_row("Gz:", gz, COL_CYAN);

    sprite.setTextDatum(BC_DATUM);
    sprite.setTextColor(COL_DARKGRAY, COL_BG);
    sprite.drawString("CMD STOP_LIVE per uscire", 120, DISPLAY_H - 2, 1);

    sprite.pushSprite(0, DISPLAY_Y_OFFSET);
}

// =============================================================================
// display_task() — Core 0, priorità LOW
// =============================================================================
void display_task(void* param) {
    DBG("display_task avviato su Core %d", xPortGetCoreID());
    display_show_boot();

    uint32_t last_render = 0;
    bool     rec_blink   = false;
    uint32_t last_blink  = 0;

    for (;;) {
        if (g_shutdown) { DBG("display_task: shutdown"); vTaskDelete(nullptr); }

        uint32_t now = millis();
        if (now - last_render < 100) { vTaskDelay(pdMS_TO_TICKS(20)); continue; }

        // Anti-flickering: se loop() sta gestendo il display (countdown PWR)
        // saltiamo completamente questo ciclo. loop() chiama pushSprite()
        // direttamente — due pushSprite() concorrenti causano il flickering.
        if (g_display_suspended) { vTaskDelay(pdMS_TO_TICKS(20)); continue; }

        last_render = now;

        if (now - last_blink > 500) { rec_blink = !rec_blink; last_blink = now; }

        // Leggi campione corrente
        ImuSample s = {};
        if (g_imu_ok && xSemaphoreTake(g_imu_sample_mutex, pdMS_TO_TICKS(2)) == pdTRUE) {
            s = g_latest_sample;
            xSemaphoreGive(g_imu_sample_mutex);
        }

        // ── Gestione risparmio energetico (v2.6) ────────────────────────────
        // Imposta il backlight in base allo stato ed emette il beep di conferma
        // allo scocco. power_tick() gestisce lo spegnimento del beep.
        power_update_for_state(g_device_state);
        power_tick();

        // Se il backlight è spento (attesa in mira in RECORDING) NON ha senso
        // renderizzare: lo schermo non si vede e sprechiamo CPU. Saltiamo il
        // rendering ma continuiamo il loop (il trigger gira su un altro task).
        if (!power_backlight_is_on()) {
            vTaskDelay(pdMS_TO_TICKS(80));
            continue;
        }
        // ────────────────────────────────────────────────────────────────────

        switch (g_device_state) {
            case STATE_IDLE:
                display_screen_idle(false, 0, g_batt_pct);
                break;
            case STATE_CONNECTED:
                display_screen_idle(true, g_shot_id, g_batt_pct);
                break;
            case STATE_RECORDING:
                display_screen_recording(g_shot_id, s.az, rec_blink);
                break;
            case STATE_TRIGGERED:
            case STATE_SENDING:
                display_screen_triggered(g_shot_id, g_trigger_az_peak, 50);
                break;
            case STATE_LIVE:
                display_screen_live(s.ax, s.ay, s.az, s.gx, s.gy, s.gz);
                break;
            case STATE_SCORING:
                // v2.11: la valutazione del tiro. scoring_ui_tick() gestisce
                // internamente touch, rendering (con proprio pushSprite) e la
                // sotto-macchina esito->zona->distanza; a fine valutazione invia
                // lo ScorePacket e riporta g_device_state a CONNECTED.
                scoring_ui_tick(sprite);
                break;
        }

        vTaskDelay(pdMS_TO_TICKS(80));
    }
    vTaskDelete(nullptr);
}


// =============================================================================
// display_show_shutdown_countdown()
// =============================================================================
// Schermata mostrata durante la pressione prolungata del tasto PWR.
// pct = 0 (appena iniziato) → 100 (shutdown confermato).
//
// DESIGN:
//   - Sfondo scuro con overlay semi-trasparente (simulato con fillRect scuro)
//   - Icona power centrata in alto
//   - Testo "SPEGNIMENTO..." in ambra
//   - Barra di progresso circolare (simulata con arco rettangolare)
//   - Percentuale numerica sotto la barra
//
// Questa funzione viene chiamata da loop() ogni 20ms durante il countdown.
// Non usa mutex sul TFT sprite — loop() e display_task condividono lo sprite
// ma entrambi chiamano pushSprite() in modo atomico (operazione SPI).
// Nel worst case si vede un frame "rotto" per 16ms — accettabile.
// =============================================================================
void display_show_shutdown_countdown(uint8_t pct) {
    sprite.fillSprite(COL_BG);

    // Overlay scuro sul 40% superiore
    sprite.fillRect(0, 0, DISPLAY_W, 110, COL_BLACK);

    // Icona "power" stilizzata — cerchio con linea verticale
    int16_t cx = DISPLAY_W / 2;  // 120
    int16_t cy = 55;
    uint16_t icon_col = (pct < 50) ? COL_AMBER : COL_RED;

    // Arco esterno (cerchio)
    sprite.drawCircle(cx, cy, 28, icon_col);
    sprite.drawCircle(cx, cy, 27, icon_col);  // doppio per spessore

    // Linea verticale in alto (il "gambo" dell'icona power)
    sprite.fillRect(cx - 2, cy - 36, 5, 20, COL_BG);        // cancella arco sopra
    sprite.fillRect(cx - 1, cy - 38, 3, 22, icon_col);       // disegna linea

    // Testo principale
    sprite.setTextDatum(TC_DATUM);
    sprite.setTextColor(icon_col, COL_BG);
    sprite.drawString("SPEGNIMENTO", cx, 100, 2);

    // Barra di progresso — rettangolare, larga, con bordo
    int16_t bar_x = 20;
    int16_t bar_y = 140;
    int16_t bar_w = DISPLAY_W - 40;  // 200px
    int16_t bar_h = 24;

    // Sfondo barra
    sprite.fillRect(bar_x, bar_y, bar_w, bar_h, COL_DARKGRAY);
    sprite.drawRect(bar_x - 1, bar_y - 1, bar_w + 2, bar_h + 2, COL_GRAY);

    // Fill barra proporzionale al pct
    if (pct > 0) {
        int16_t fill_w = (int16_t)((uint32_t)bar_w * pct / 100);
        // Gradiente simulato: ambra → rosso man mano che si avvicina al 100%
        uint16_t bar_col = (pct < 60) ? COL_AMBER : COL_RED;
        sprite.fillRect(bar_x, bar_y, fill_w, bar_h, bar_col);
    }

    // Percentuale
    char buf[8];
    snprintf(buf, sizeof(buf), "%d%%", pct);
    sprite.setTextColor(COL_WHITE, COL_BG);
    sprite.drawString(buf, cx, bar_y + bar_h + 8, 2);

    // Istruzione sotto
    sprite.setTextColor(COL_GRAY, COL_BG);
    sprite.drawString("Rilascia per annullare", cx, 208, 1);

    // Linea separatrice
    sprite.drawFastHLine(20, 225, DISPLAY_W - 40, COL_DARKGRAY);

    // Tempo rimanente (secondi)
    // SHUTDOWN_HOLD_MS = 2000ms, pct va da 0 a 100
    // tempo_rimanente = (100 - pct) * SHUTDOWN_HOLD_MS / 100 / 1000 secondi
    float sec_left = (100 - pct) * 2.0f / 100.0f;
    char tbuf[16];
    snprintf(tbuf, sizeof(tbuf), "%.1fs", sec_left);
    sprite.setTextColor(COL_DARKGRAY, COL_BG);
    sprite.drawString(tbuf, cx, 235, 1);

    sprite.pushSprite(0, DISPLAY_Y_OFFSET);
}

// =============================================================================
// display_show_shutdown_complete()
// =============================================================================
// Schermata finale mostrata per ~300ms prima del perform_shutdown().
// Breve, chiara: l'utente vede che il dispositivo sta per spegnersi.
// =============================================================================
void display_show_shutdown_complete() {
    sprite.fillSprite(COL_BLACK);

    sprite.setTextDatum(MC_DATUM);
    sprite.setTextColor(COL_WHITE, COL_BLACK);
    sprite.drawString("Arrivederci", DISPLAY_W / 2, DISPLAY_H / 2 - 16, 4);

    sprite.setTextColor(COL_DARKGRAY, COL_BLACK);
    sprite.drawString("ArchBB v" FW_VERSION_STR, DISPLAY_W / 2, DISPLAY_H / 2 + 20, 2);

    sprite.pushSprite(0, DISPLAY_Y_OFFSET);
}
