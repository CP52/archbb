// =============================================================================
// scoring_ui.cpp — ArchBB: UI dello scoring on-device (v2.0)
// Firmware 2.12.0 — Fase C + Backport UX dalla 1.83
// =============================================================================
// Vedi scoring_ui.h per la panoramica. Struttura del file:
//   [1] Mini-driver touch CST816T (I2C raw, guard di plausibilità)
//   [2] Mappatura raw->zona con le soglie calibrate
//   [3] Rendering delle schermate (sprite): esito / zona / distanza / RIEPILOGO
//   [4] Sotto-macchina a stati dello scoring
//
// COSA CAMBIA rispetto alla v1.0 (backport delle migliorie mature sulla 1.83):
//   §1  RIEPILOGO come punto di controllo esplicito (OK cementa / CORREGGI
//       riapre lo stesso tiro senza reinviare). È il cuore del backport:
//       impedisce di fallare uno score con un tocco distratto.
//   §2  Debounce del tap + COOLDOWN uniforme post-azione (~200ms): elimina il
//       doppio-conteggio e l'ereditarietà del tocco fra schermate consecutive.
//       Sostituisce il vecchio delay(180) puntuale sulla sola schermata zona.
//   §3  Pulsante ‹ INDIETRO in ZONA e DISTANZA (torna alla schermata precedente).
//   §4  Breadcrumb (contesto delle scelte già fatte) in ZONA e DISTANZA.
//   §6  Pulsante ? (IGNOTA) esplicito per distanza=0 nella schermata distanza.
//
// COSA NON CAMBIA (era già corretto nella v1.0, riverificato):
//   §5  Semantica MANCATO: la schermata zona si mostra comunque; il centro
//       (indice 4) è disattivato nel mancato, SPOT nel colpito. Nessun zona=0
//       d'ufficio.
//   §7  Simboli +/- disegnati geometricamente (font 6 di TFT_eSPI è solo
//       numerico). Testo con lettere ("OK","CONFERMA") in font 4.
//
// COSA NON SI TOCCA (vincoli hardware/protocollo — vedi briefing 1.69):
//   - Soglie touch THR_* calibrate sul campo: INVARIATE.
//   - Pin touch SDA=11 SCL=10 RST=13 INT=14: INVARIATI.
//   - ScorePacket / ble_send_score(): il CORREGGI NON lo richiama; l'OK sì.
//     Lo shot_id resta quello scritto da ble_server all'ingresso: nessuno lo
//     tocca durante lo scoring, quindi CORREGGI lo preserva "per costruzione".
// =============================================================================

#include "scoring_ui.h"
#include "config.h"
#include "scoring.h"      // g_pending_score, ble_send_score()
#include "ble_server.h"   // g_device_state, g_shot_id
#include "display.h"      // palette COL_*, DISPLAY_W/H/OFFSET
#include <Wire.h>

// =============================================================================
// [1] MINI-DRIVER TOUCH CST816T
// =============================================================================
// Pinout (da schematico + briefing clinometro): SDA=11 SCL=10 RST=13 INT=14.
// Indirizzo 0x15. Il bus I2C è già inizializzato in main.cpp (Wire.begin),
// condiviso con IMU (0x6B) e RTC: qui NON reinizializziamo il bus, usiamo
// soltanto le transazioni. Lo scoring gira dopo il burst (IMU non campiona un
// tiro), quindi il bus è libero: coerente col vincolo del design doc.

#ifndef TP_RST
  #define TP_RST 13
#endif
#ifndef TP_INT
  #define TP_INT 14
#endif
#ifndef CST816_ADDR
  #define CST816_ADDR 0x15
#endif

static constexpr uint8_t  TP_REG_GESTURE   = 0x01;
static constexpr uint8_t  TP_REG_DIS_SLEEP  = 0xFE;
static constexpr uint16_t TP_COORD_SENTINEL = 4095;   // 0x0FFF: lettura sporca
static constexpr uint16_t TP_COORD_MAX      = 320;    // controller 240x320

// --- Soglie di calibrazione raw->zona (validate sul campo) — NON TOCCARE ---
static constexpr uint16_t THR_X_LC = 89;    // X < 89  = colonna sx (0)
static constexpr uint16_t THR_X_CR = 164;   // X > 164 = colonna dx (2)
static constexpr uint16_t THR_Y_TM = 68;    // Y < 68  = riga alto (0)
static constexpr uint16_t THR_Y_MB = 198;   // Y > 198 = riga basso (2)

// --- §2 COOLDOWN post-azione ------------------------------------------------
// Dopo OGNI azione touch che cambia stato, ignoriamo i tap per questo intervallo.
// A cosa serve: il CST816, allo stacco del dito, produce micro-rimbalzi, e con
// due schermate consecutive lo stesso dito può contare due volte (tap su ZONA
// che avanza a DISTANZA + residuo che conta come tap su DISTANZA). Un cooldown
// uniforme risolve il problema alla radice, in un colpo solo per tutte le
// schermate. Sostituisce il vecchio delay(180) puntuale (bloccante) sulla sola
// zona: qui è NON bloccante (confronto di millis) e vale ovunque.
// A 80ms/loop (~12Hz) 200ms sono ~2-3 giri: impercettibile per un tap
// intenzionale, sufficiente a mangiare il rimbalzo del rilascio precedente.
static constexpr uint32_t TOUCH_COOLDOWN_MS = 200;

struct TouchRaw {
    bool     valid;    // supera il guard di plausibilità
    bool     present;  // il chip riporta un dito (prima del guard)
    uint16_t x, y;
};

static bool tpReadRegs(uint8_t reg, uint8_t* buf, uint8_t len) {
    Wire.beginTransmission(CST816_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom((int)CST816_ADDR, (int)len) != len) return false;
    for (uint8_t i = 0; i < len; i++) buf[i] = Wire.read();
    return true;
}
static bool tpWriteReg(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(CST816_ADDR);
    Wire.write(reg);
    Wire.write(val);
    return (Wire.endTransmission() == 0);
}

void scoring_ui_init() {
    // Reset hardware del touch.
    pinMode(TP_RST, OUTPUT);
    digitalWrite(TP_RST, LOW);  delay(10);
    digitalWrite(TP_RST, HIGH); delay(50);
    pinMode(TP_INT, INPUT_PULLUP);
    // Disabilita auto-sleep per reattività (il chip altrimenti dorme e dà errori).
    tpWriteReg(TP_REG_DIS_SLEEP, 0x01);
}

// Legge un evento di tocco con guard di plausibilità (scarta gli spuri del chip:
// fingers!=1, coord sentinella 4095, fuori range fisico).
static TouchRaw tpRead() {
    TouchRaw t = {false, false, 0, 0};
    uint8_t d[6] = {0};
    if (!tpReadRegs(TP_REG_GESTURE, d, 6)) return t;
    uint8_t fingers = d[1] & 0x0F;
    t.present = (fingers > 0);
    if (fingers != 1) return t;
    uint16_t x = ((uint16_t)(d[2] & 0x0F) << 8) | d[3];
    uint16_t y = ((uint16_t)(d[4] & 0x0F) << 8) | d[5];
    if (x == TP_COORD_SENTINEL || y == TP_COORD_SENTINEL) return t;
    if (x > TP_COORD_MAX || y > TP_COORD_MAX) return t;
    t.x = x; t.y = y; t.valid = true;
    return t;
}

// =============================================================================
// [2] MAPPATURA raw -> zona (0..8) con le soglie calibrate
// =============================================================================
static uint8_t tpZoneFromRaw(uint16_t x, uint16_t y) {
    uint8_t col = (x < THR_X_LC) ? 0 : ((x <= THR_X_CR) ? 1 : 2);
    uint8_t row = (y < THR_Y_TM) ? 0 : ((y <= THR_Y_MB) ? 1 : 2);
    return row * 3 + col;
}

// Stato del rilevatore di tap, a livello di modulo (per poterlo azzerare dalle
// transizioni di fase). 'tp_seen' = un tocco valido è in corso; 'tp_armed_release'
// = dobbiamo attendere un rilascio PULITO prima di accettare il prossimo tap.
static bool     tp_seen = false;
static uint16_t tp_lx = 0, tp_ly = 0;
static bool     tp_require_release = false;

// Forza il rilevatore a scartare il tocco in corso e ad attendere un rilascio
// completo prima di validare un nuovo tap. Va chiamata a OGNI transizione di
// schermata: evita che un tocco ancora premuto su un pulsante venga "ereditato"
// dalla schermata successiva se le aree si sovrappongono (bug del riepilogo che
// spariva: CONFERMA distanza e OK riepilogo condividono l'area x[120..224]
// y[178..220], quindi il tocco di CONFERMA cadeva anche su OK).
static void tpResetTap() {
    tp_seen = false;
    tp_require_release = true;
}

// Rileva un tocco COMPLETO (al rilascio) in modo non bloccante. Restituisce true
// una sola volta, al rilascio, con l'ultima posizione valida. Se è stato chiamato
// tpResetTap(), ignora il tocco finché non vede prima un rilascio pulito.
static bool tpTapReleased(uint16_t& out_x, uint16_t& out_y) {
    TouchRaw t = tpRead();
    // Se stiamo aspettando un rilascio pulito: consuma le letture ma non validare
    // nulla finché il dito non si stacca del tutto.
    if (tp_require_release) {
        if (!t.present) tp_require_release = false;   // dito staccato: sblocca
        tp_seen = false;
        return false;
    }
    if (t.valid) { tp_lx = t.x; tp_ly = t.y; tp_seen = true; return false; }
    if (!t.present && tp_seen) { tp_seen = false; out_x = tp_lx; out_y = tp_ly; return true; }
    return false;
}

// =============================================================================
// [3] RENDERING DELLE SCHERMATE (sprite anti-flicker)
// =============================================================================
// Tinte tenui simulate: il firmware non ha alpha, quindi per gli sfondi tenui
// usiamo colori scuri dedicati vicini alla palette (rosso/verde desaturati).
static constexpr uint16_t COL_RED_DIM   = 0x3000;  // rosso molto scuro
static constexpr uint16_t COL_GREEN_DIM = 0x0140;  // verde molto scuro
static constexpr uint16_t COL_AMBER_DIM = 0x2120;  // ambra molto scura
static constexpr uint16_t COL_CYAN_DIM  = 0x0110;  // ciano molto scuro

// Numerini tastierino per zona (mnemonica di presentazione).
static const uint8_t ZONE_KEYPAD[9] = { 7,8,9, 4,5,6, 1,2,3 };

// Etichette compatte delle 9 zone (allineate alla nomenclatura dell'app v1.22:
// alto-sx/alto/alto-dx / sx/centro/dx / basso-sx/basso/basso-dx). Il centro
// diventa "SPOT" se colpito.
static const char* const ZONE_ABBR[9] = {
    "alto-sx", "alto", "alto-dx",
    "sx",      "centro","dx",
    "basso-sx","basso", "basso-dx"
};
static const char* zoneLabel(bool colpito, uint8_t z) {
    if (colpito && z == 4) return "SPOT";
    return (z < 9) ? ZONE_ABBR[z] : "";
}

// --- Breadcrumb (§4): riga di contesto in cima a ZONA e DISTANZA ------------
// Mostra le scelte già fatte, col colore che richiama l'esito (verde COLPITO /
// rosso MANCATO). In ZONA mostra solo l'esito; in DISTANZA "esito > zona".
// stage: 0 = siamo in ZONA (mostra esito), 1 = siamo in DISTANZA (esito > zona).
static void drawBreadcrumb(TFT_eSprite& s, uint8_t stage) {
    bool colpito = g_pending_score.colpito;
    uint16_t col = colpito ? COL_GREEN : COL_RED;
    char line[40];
    if (stage == 0) {
        snprintf(line, sizeof(line), "%s", colpito ? "COLPITO" : "MANCATO");
    } else {
        // Il font 2 non ha un glifo affidabile per '›': uso ">" semplice.
        snprintf(line, sizeof(line), "%s > %s",
                 colpito ? "COLPITO" : "MANCATO",
                 zoneLabel(colpito, g_pending_score.zona));
    }
    s.setTextDatum(TL_DATUM);
    s.setTextColor(col, COL_BG);
    s.drawString(line, 6, 2, 2);
    s.drawFastHLine(0, 20, DISPLAY_W, COL_DARKGRAY);
    s.setTextDatum(MC_DATUM);   // ripristino il datum di default usato altrove
}

// --- Pulsante ‹ INDIETRO (§3): riquadro in basso a sinistra -----------------
// Disegnato come area tattile esplicita, coerente in ZONA e DISTANZA. La barra
// SKIP resta a destra; INDIETRO occupa il lato sinistro della fascia inferiore.
static void drawBackButton(TFT_eSprite& s) {
    const int16_t bx = 4, by = DISPLAY_H - 30, bw = 74, bh = 26;
    s.fillRect(bx, by, bw, bh, COL_BG);
    s.drawRect(bx, by, bw, bh, COL_DARKGRAY);
    s.setTextDatum(MC_DATUM);
    s.setTextColor(COL_GRAY, COL_BG);
    // Chevron '‹' disegnato geometricamente (due segmenti) + testo "indietro".
    int16_t chx = bx + 12, chy = by + bh/2;
    s.drawLine(chx + 4, chy - 6, chx - 3, chy,     COL_GRAY);
    s.drawLine(chx - 3, chy,     chx + 4, chy + 6, COL_GRAY);
    s.drawString("indietro", bx + bw/2 + 6, chy, 1);
}

// --- Schermata 1: esito rosso/verde ---
static void drawEsito(TFT_eSprite& s) {
    s.fillSprite(COL_BG);
    // semicampo sinistro (MANCATO, rosso)
    s.fillRect(0, 0, DISPLAY_W/2, DISPLAY_H - 32, COL_RED_DIM);
    // semicampo destro (COLPITO, verde)
    s.fillRect(DISPLAY_W/2, 0, DISPLAY_W/2, DISPLAY_H - 32, COL_GREEN_DIM);
    // divisore
    s.drawFastVLine(DISPLAY_W/2, 0, DISPLAY_H - 32, COL_DARKGRAY);

    s.setTextDatum(MC_DATUM);
    // MANCATO
    s.setTextColor(COL_RED, COL_RED_DIM);
    s.drawString("X", DISPLAY_W/4, 110, 6);
    s.drawString("MANCATO", DISPLAY_W/4, 165, 2);
    // COLPITO
    s.setTextColor(COL_GREEN, COL_GREEN_DIM);
    s.drawString("O", DISPLAY_W*3/4, 110, 6);
    s.drawString("COLPITO", DISPLAY_W*3/4, 165, 2);

    // barra SKIP (resta su esito, come richiesto)
    s.fillRect(0, DISPLAY_H - 32, DISPLAY_W, 32, COL_BG);
    s.drawFastHLine(0, DISPLAY_H - 32, DISPLAY_W, COL_DARKGRAY);
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("salta valutazione", DISPLAY_W/2, DISPLAY_H - 16, 2);

    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// Disegna una freccia direzionale dentro una cella (zona 0..8, escluso 4).
static void drawZoneGlyph(TFT_eSprite& s, uint8_t z, int16_t cx, int16_t cy, uint16_t col) {
    int col_i = z % 3, row_i = z / 3;
    int dx = col_i - 1, dy = row_i - 1;   // -1,0,+1
    int len = 11;
    int x2 = cx + dx*len, y2 = cy + dy*len;
    int x1 = cx - dx*len, y1 = cy - dy*len;
    s.drawLine(x1, y1, x2, y2, col);
    s.fillCircle(x2, y2, 3, col);   // punta di freccia al capo (x2,y2)
}

// --- Schermata 2: zona 3x3 (colpito=SPOT / mancato=centro disabilitato) ------
// §4 breadcrumb (esito) in cima; §3 INDIETRO in basso a sinistra.
static void drawZona(TFT_eSprite& s, bool colpito, int8_t sel_zone) {
    s.fillSprite(COL_BG);

    // §4 breadcrumb (esito) — sostituisce il vecchio titolo generico
    drawBreadcrumb(s, 0);

    s.setTextDatum(MC_DATUM);
    s.setTextColor(colpito ? COL_GREEN : COL_AMBER, COL_BG);
    s.drawString(colpito ? "DOVE HAI COLPITO" : "ZONA IMPATTO", DISPLAY_W/2, 30, 2);

    const int16_t gx = 6, gy = 44, cell = 66, gap = 4;   // 3*66+2*4 = 206
    for (uint8_t z = 0; z < 9; z++) {
        int cxi = z % 3, ryi = z / 3;
        int16_t x = gx + cxi * (cell + gap);
        int16_t y = gy + ryi * (cell + gap);
        int16_t ccx = x + cell/2, ccy = y + cell/2;

        bool is_center = (z == 4);
        bool selected  = (sel_zone == (int8_t)z);
        uint16_t border = COL_DARKGRAY, fill = COL_BG, fg = COL_GRAY;

        if (is_center && colpito) {          // SPOT
            border = COL_GREEN; fill = COL_GREEN_DIM; fg = COL_GREEN;
        } else if (is_center && !colpito) {  // centro disabilitato
            border = COL_DARKGRAY; fill = COL_BG; fg = COL_DARKGRAY;
        }
        if (selected) {
            border = colpito ? COL_GREEN : COL_RED;
            fill   = colpito ? COL_GREEN_DIM : COL_RED_DIM;
            fg     = colpito ? COL_GREEN : COL_RED;
        }

        s.fillRect(x, y, cell, cell, fill);
        s.drawRect(x, y, cell, cell, border);
        // numerino tastierino in alto a sx
        s.setTextDatum(TL_DATUM);
        s.setTextColor(fg, fill);
        char kb[2] = { (char)('0' + ZONE_KEYPAD[z]), 0 };
        s.drawString(kb, x + 5, y + 4, 1);
        s.setTextDatum(MC_DATUM);

        if (is_center && colpito) {
            s.drawCircle(ccx, ccy - 4, 10, COL_GREEN);
            s.fillCircle(ccx, ccy - 4, 4, COL_GREEN);
            s.setTextColor(COL_GREEN, fill);
            s.drawString("SPOT", ccx, ccy + 16, 1);
        } else if (is_center && !colpito) {
            s.drawFastHLine(ccx - 8, ccy, 16, COL_DARKGRAY);
        } else {
            drawZoneGlyph(s, z, ccx, ccy, fg);
        }
    }

    // §3 INDIETRO (torna a esito) + barra SKIP (destra) nella fascia inferiore
    drawBackButton(s);
    s.drawFastHLine(0, DISPLAY_H - 30, DISPLAY_W, COL_DARKGRAY);
    s.setTextDatum(MC_DATUM);
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("salta", DISPLAY_W - 44, DISPLAY_H - 15, 2);

    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// --- Schermata 3: distanza con SLIDER + tasti +/- + ? IGNOTA + INDIETRO/OK ---
// §4 breadcrumb (esito > zona); §6 pulsante ? per distanza=0; §3 INDIETRO.
// --- Schermata 3 (RIDISEGNO v2.13, criticita' campo #3): DISTANZA -----------
// Ergonomia: lo scoring va fatto veloce e col guanto. Il vecchio layout aveva
// tacche e CONFERMA orizzontali scomode. Nuovo schema (validato dall'uso: i
// tasti a tutta altezza sul bordo sono i piu' efficaci per il feedback tattile):
//   - SLIDER orizzontale grande a range fisso (DIST_MIN..DIST_MAX): un tocco
//     sulla barra imposta la distanza direttamente (tocco diretto);
//   - tasti +/- laterali grandi per l'aggiustamento fine;
//   - "?" per distanza IGNOTA (=0);
//   - in basso DUE tasti grandi verticali a tutta altezza: INDIETRO (sx) e
//     OK (dx), come nel riepilogo — discriminati per LATO, non per banda Y.
static constexpr uint8_t DIST_MIN = 5;
static constexpr uint8_t DIST_MAX = 60;
// Geometria slider (in coordinate sprite)
static constexpr int16_t SLD_X0 = 24;                 // inizio barra
static constexpr int16_t SLD_X1 = DISPLAY_W - 24;     // fine barra (216)
static constexpr int16_t SLD_Y  = 92;                 // asse barra
static constexpr int16_t SLD_W  = SLD_X1 - SLD_X0;    // larghezza utile (192)

// mappa distanza -> x sulla barra e viceversa
static int16_t distToX(uint8_t d) {
    if (d < DIST_MIN) d = DIST_MIN; if (d > DIST_MAX) d = DIST_MAX;
    return SLD_X0 + (int16_t)((int32_t)(d - DIST_MIN) * SLD_W / (DIST_MAX - DIST_MIN));
}
static uint8_t xToDist(int16_t x) {
    if (x < SLD_X0) x = SLD_X0; if (x > SLD_X1) x = SLD_X1;
    int v = DIST_MIN + (int)((int32_t)(x - SLD_X0) * (DIST_MAX - DIST_MIN) / SLD_W);
    if (v < DIST_MIN) v = DIST_MIN; if (v > DIST_MAX) v = DIST_MAX;
    return (uint8_t)v;
}

static void drawDistanza(TFT_eSprite& s, uint8_t dist) {
    s.fillSprite(COL_BG);

    // breadcrumb (esito > zona)
    drawBreadcrumb(s, 1);

    s.setTextDatum(MC_DATUM);
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("DISTANZA", DISPLAY_W/2, 30, 2);

    // valore grande al centro (o IGN)
    bool ignota = (dist == 0);
    if (ignota) {
        s.setTextColor(COL_AMBER, COL_BG);
        s.drawString("IGN", DISPLAY_W/2, 58, 6);
    } else {
        s.setTextColor(COL_CYAN, COL_BG);
        char buf[8]; snprintf(buf, sizeof(buf), "%d", dist);
        s.drawString(buf, DISPLAY_W/2 - 18, 58, 6);
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("m", DISPLAY_W/2 + 28, 66, 4);
    }

    // --- SLIDER: barra + tacca ---
    // binario
    s.fillRoundRect(SLD_X0, SLD_Y - 3, SLD_W, 6, 3, COL_DARKGRAY);
    if (!ignota) {
        // porzione attiva (da inizio alla tacca) in ciano
        int16_t px = distToX(dist);
        s.fillRoundRect(SLD_X0, SLD_Y - 3, px - SLD_X0, 6, 3, COL_CYAN);
        // tacca (cerchio pieno)
        s.fillCircle(px, SLD_Y, 11, COL_CYAN);
        s.fillCircle(px, SLD_Y, 6, COL_BG);
    }
    // estremi del range
    s.setTextColor(COL_GRAY, COL_BG);
    s.setTextDatum(TL_DATUM);
    char lo[4]; snprintf(lo, sizeof(lo), "%d", DIST_MIN);
    s.drawString(lo, SLD_X0 - 4, SLD_Y + 10, 1);
    s.setTextDatum(TR_DATUM);
    char hi[4]; snprintf(hi, sizeof(hi), "%d", DIST_MAX);
    s.drawString(hi, SLD_X1 + 4, SLD_Y + 10, 1);
    s.setTextDatum(MC_DATUM);

    // --- tasti +/- (grandi) e ? IGNOTA, in una fascia sotto lo slider ---
    // "-" a sinistra, "+" a destra, "?" al centro.
    const int16_t by = 118, bh = 40;
    // "-"
    s.fillRect(16, by, 56, bh, COL_CYAN_DIM);
    s.drawRect(16, by, 56, bh, COL_CYAN);
    { int16_t cx = 44, cy = by + bh/2; s.fillRect(cx - 12, cy - 2, 24, 4, COL_CYAN); }
    // "+"
    s.fillRect(DISPLAY_W - 72, by, 56, bh, COL_CYAN_DIM);
    s.drawRect(DISPLAY_W - 72, by, 56, bh, COL_CYAN);
    { int16_t cx = DISPLAY_W - 44, cy = by + bh/2;
      s.fillRect(cx - 12, cy - 2, 24, 4, COL_CYAN);
      s.fillRect(cx - 2, cy - 12, 4, 24, COL_CYAN); }
    // "?" IGNOTA (centro)
    s.fillRect(DISPLAY_W/2 - 28, by, 56, bh, ignota ? COL_AMBER_DIM : COL_BG);
    s.drawRect(DISPLAY_W/2 - 28, by, 56, bh, COL_AMBER);
    s.setTextColor(COL_AMBER, ignota ? COL_AMBER_DIM : COL_BG);
    s.drawString("?", DISPLAY_W/2, by + bh/2, 4);

    // --- DUE TASTI GRANDI VERTICALI: INDIETRO (sx) / OK (dx) ---
    // Riempiono la fascia bassa a tutta altezza: discriminazione per LATO (X),
    // massimo feedback tattile sul bordo. Stesso schema del riepilogo.
    const int16_t tTop = 170, tBot = DISPLAY_H;     // 170..280
    const int16_t tH = tBot - tTop, midX = DISPLAY_W/2, gap = 4;
    // sinistra: INDIETRO (torna a zona)
    s.fillRect(0, tTop, midX - gap, tH, COL_BG);
    s.drawRect(0, tTop, midX - gap, tH, COL_DARKGRAY);
    s.setTextColor(COL_GRAY, COL_BG);
    { int16_t ccx = (midX - gap)/2, ccy = tTop + tH/2;   // chevron '‹'
      s.drawLine(ccx + 8, ccy - 14, ccx - 8, ccy, COL_GRAY);
      s.drawLine(ccx - 8, ccy, ccx + 8, ccy + 14, COL_GRAY); }
    s.drawString("INDIETRO", (midX - gap)/2, tTop + tH/2 + 30, 2);
    // destra: OK/CONFERMA (verde pieno) -> RIEPILOGO
    s.fillRect(midX + gap, tTop, DISPLAY_W - (midX + gap), tH, COL_GREEN);
    s.setTextColor(COL_BLACK, COL_GREEN);
    s.drawString("OK", midX + (DISPLAY_W - midX)/2, tTop + tH/2, 4);

    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// --- Schermata 4 (NUOVA §1): RIEPILOGO — punto di controllo esplicito --------
// Mostra l'esito completo (colpito/mancato, zona, distanza, ARCS) e offre DUE
// sole azioni: OK (cementa e invia lo ScorePacket) e ‹ CORREGGI (riapre lo
// stesso tiro senza inviare nulla). Un tocco FUORI dai due pulsanti è ignorato:
// è questo che impedisce di cementare uno score per un tocco distratto.
//
// ARCS = ±(distanza*10 + (zona+1)), identico all'encoding app/1.83.
static int16_t arcsFromScore(bool colpito, uint8_t zona, uint8_t dist) {
    int16_t mag = (int16_t)dist * 10 + (zona + 1);   // zona+1 in [1..9]
    return colpito ? mag : -mag;
}

static void drawRiepilogo(TFT_eSprite& s) {
    bool colpito  = g_pending_score.colpito;
    uint8_t zona  = g_pending_score.zona;
    uint8_t dist  = g_pending_score.distanza_m;
    uint16_t esCol = colpito ? COL_GREEN : COL_RED;

    s.fillSprite(COL_BG);
    s.setTextDatum(MC_DATUM);

    // Intestazione
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("RIEPILOGO", DISPLAY_W/2, 12, 2);
    s.drawFastHLine(0, 24, DISPLAY_W, COL_DARKGRAY);

    // Esito grande
    s.setTextColor(esCol, COL_BG);
    s.drawString(colpito ? "COLPITO" : "MANCATO", DISPLAY_W/2, 52, 4);

    // Zona e distanza
    char line[40];
    s.setTextColor(COL_WHITE, COL_BG);
    snprintf(line, sizeof(line), "zona: %s", zoneLabel(colpito, zona));
    s.drawString(line, DISPLAY_W/2, 84, 2);
    if (dist == 0) snprintf(line, sizeof(line), "distanza: ignota");
    else           snprintf(line, sizeof(line), "distanza: %d m", dist);
    s.drawString(line, DISPLAY_W/2, 106, 2);

    // ARCS (intero-singolo che andrà nel CSV)
    s.setTextColor(COL_AMBER, COL_BG);
    snprintf(line, sizeof(line), "ARCS %d", arcsFromScore(colpito, zona, dist));
    s.drawString(line, DISPLAY_W/2, 130, 2);

    // --- Zona pulsanti: DUE QUADRONI AFFIANCATI che riempiono la fascia bassa --
    // Scelta di design: la discriminazione del tocco avviene sul LATO (X: sx vs
    // dx), non su una banda Y stretta. Così il tap può cadere ovunque nella metà
    // inferiore dello schermo — conta solo da che parte. È lo stesso principio
    // robusto della schermata esito (semicampo sx/dx), che non ha mai dato noie.
    // Altezza tattile ~126px per pulsante contro i 52 del vecchio OK a barra.
    const int16_t btnTop = 144, btnBot = 270;   // fascia pulsanti nello sprite
    const int16_t btnH   = btnBot - btnTop;      // 126px
    const int16_t midX   = DISPLAY_W / 2;        // confine sx|dx = 120
    const int16_t gap    = 4;                    // fessura centrale

    // Sinistra: CORREGGI (ambra desaturata, bordo ambra, chevron '‹' grande)
    s.fillRect(0, btnTop, midX - gap, btnH, COL_AMBER_DIM);
    s.drawRect(0, btnTop, midX - gap, btnH, COL_AMBER);
    {
        int16_t ccx = (midX - gap) / 2, ccy = btnTop + btnH/2 - 12;
        int16_t r = 18;   // chevron '‹' geometrico grande
        s.drawLine(ccx + r/2, ccy - r, ccx - r/2, ccy,     COL_AMBER);
        s.drawLine(ccx - r/2, ccy,     ccx + r/2, ccy + r, COL_AMBER);
    }
    s.setTextColor(COL_AMBER, COL_AMBER_DIM);
    s.drawString("CORREGGI", (midX - gap)/2, btnTop + btnH/2 + 24, 2);

    // Destra: OK (verde pieno, nero sopra, font 4). L'UNICA azione che cementa.
    // NB: font 4, NON font 6 (font 6 è solo numerico: 'O'/'K' non esistono).
    s.fillRect(midX + gap, btnTop, DISPLAY_W - (midX + gap), btnH, COL_GREEN);
    s.setTextColor(COL_BLACK, COL_GREEN);
    s.drawString("OK", midX + (DISPLAY_W - midX)/2, btnTop + btnH/2, 4);

    // Niente barra SKIP qui: a valutazione conclusa le uscite sono OK o CORREGGI.
    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// =============================================================================
// [4] SOTTO-MACCHINA A STATI DELLO SCORING
// =============================================================================
enum ScoringPhase : uint8_t {
    SC_ESITO = 0,   // schermata 1
    SC_ZONA,        // schermata 2
    SC_DISTANZA,    // schermata 3
    SC_RIEPILOGO,   // schermata 4 (NUOVA §1): punto di controllo esplicito
    SC_DONE         // concluso (transizione in uscita)
};

static ScoringPhase s_phase       = SC_ESITO;
static bool         s_entered     = false;   // per inizializzare all'ingresso
static uint32_t     s_last_touch_ms = 0;     // per il timeout: si resetta a ogni tocco
static uint32_t     s_cooldown_until_ms = 0; // §2: fino a quando ignorare i tap
static bool         s_need_redraw = true;
static uint8_t      s_last_distance = 18;    // ultima distanza usata (default)

static inline void touchCooldown() { s_cooldown_until_ms = millis() + TOUCH_COOLDOWN_MS; }
static inline bool inCooldown()    { return millis() < s_cooldown_until_ms; }

// Ingresso "pulito": azzera i campi di esito. Usato quando arriva un tiro NUOVO.
static void scoringEnter() {
    s_phase = SC_ESITO;
    s_last_touch_ms = millis();
    s_cooldown_until_ms = 0;
    s_need_redraw = true;
    tpResetTap();   // il primo tap deve seguire un rilascio pulito
    g_pending_score.valutato   = false;
    g_pending_score.colpito    = false;
    g_pending_score.zona       = 0;
    g_pending_score.distanza_m = 0;
}

// §1 Ripresa dal RIEPILOGO (CORREGGI): riapre lo STESSO tiro SENZA azzerare i
// valori. colpito/zona/distanza restano il punto di partenza, si riparte da
// esito. Non tocca shot_id né angoli (già nel ponte) e NON invia nulla: lo
// ScorePacket partirà solo con l'OK.
static void scoringResume() {
    s_phase = SC_ESITO;
    s_last_touch_ms = millis();
    touchCooldown();          // evita che il tap su CORREGGI conti anche su ESITO
    tpResetTap();             // e attende un rilascio pulito prima del prossimo tap
    s_need_redraw = true;
    // NB: g_pending_score.colpito/zona/distanza_m NON toccati -> valori conservati.
}

// Conclude lo scoring: invia il pacchetto e torna a CONNECTED/RECORDING.
static void scoringFinish(bool valutato) {
    g_pending_score.valutato = valutato;
    if (valutato) {
        if (g_pending_score.distanza_m >= 5) s_last_distance = g_pending_score.distanza_m;
    }
    g_pending_score.ready = false;
    ble_send_score();
    // Ripristina lo stato coerente con la modalita' reale.
    g_device_state = g_recording_enabled ? STATE_RECORDING : STATE_CONNECTED;
    s_entered = false;   // cosi' al prossimo ingresso si reinizializza
}

bool scoring_ui_tick(TFT_eSprite& sprite) {
    // Ingresso: inizializza una volta (tiro NUOVO -> partenza pulita).
    if (!s_entered) {
        s_entered = true;
        scoringEnter();
    }

    // Timeout di sicurezza: si misura dall'ULTIMO TOCCO, non dall'ingresso.
    if (millis() - s_last_touch_ms > SCORING_TIMEOUT_MS) {
        scoringFinish(false);
        return false;
    }

    // Redraw solo quando serve (evita flicker e spreco).
    if (s_need_redraw) {
        switch (s_phase) {
            case SC_ESITO:     drawEsito(sprite); break;
            case SC_ZONA:      drawZona(sprite, g_pending_score.colpito, -1); break;
            case SC_DISTANZA:  drawDistanza(sprite, g_pending_score.distanza_m); break;
            case SC_RIEPILOGO: drawRiepilogo(sprite); break;
            default: break;
        }
        s_need_redraw = false;
    }

    // §2 COOLDOWN: leggiamo comunque il touch (per non lasciare "seen" appeso nel
    // driver) ma NON agiamo finché il cooldown è attivo.
    uint16_t tx, ty;
    bool tap = tpTapReleased(tx, ty);
    if (inCooldown()) return true;
    if (!tap) return true;

    // Un tocco valido: resetta il timeout e apre un nuovo cooldown.
    s_last_touch_ms = millis();
    touchCooldown();

    // Fascia inferiore SKIP/INDIETRO su ESITO/ZONA. RIEPILOGO e DISTANZA hanno i
    // propri tasti verticali a tutta altezza e gestiscono i tap nel loro case.
    if (s_phase != SC_RIEPILOGO && s_phase != SC_DISTANZA && ty >= 248) {
        // In ESITO la fascia è tutta SKIP; in ZONA la parte sinistra (x < 82) è
        // INDIETRO, il resto è SKIP.
        if (s_phase != SC_ESITO && tx < 82) {
            s_phase = SC_ESITO;   // da ZONA si torna a ESITO
            s_need_redraw = true;
            tpResetTap();
            return true;
        }
        scoringFinish(false);   // SKIP immediato (non passa dal riepilogo)
        return false;
    }

    switch (s_phase) {
        case SC_ESITO: {
            g_pending_score.colpito = (tx > (DISPLAY_W / 2));
            s_phase = SC_ZONA;
            s_need_redraw = true;
            tpResetTap();
            break;
        }
        case SC_ZONA: {
            uint8_t z = tpZoneFromRaw(tx, ty);
            if (!g_pending_score.colpito && z == 4) break;   // centro disabilitato nel mancato
            g_pending_score.zona = z;
            // feedback: ridisegna con la cella selezionata (il cooldown già armato
            // copre il rimbalzo del rilascio; niente delay bloccante).
            drawZona(sprite, g_pending_score.colpito, (int8_t)z);
            g_pending_score.distanza_m = s_last_distance;   // default = ultima usata
            s_phase = SC_DISTANZA;
            s_need_redraw = true;
            tpResetTap();
            break;
        }
        case SC_DISTANZA: {
            // Layout v2.13 (coordinate raw ~ pixel sprite):
            //   SLIDER barra: y ~[80..104], x [24..216] -> tocco diretto = distanza
            //   "-" : x [16..72]  y [118..158]
            //   "?" : x [92..148] y [118..158]  (IGNOTA = 0)
            //   "+" : x [168..224] y [118..158]
            //   INDIETRO (sx) / OK (dx): y [170..280], discriminati per lato X
            uint8_t d = g_pending_score.distanza_m;

            // Tasti verticali in basso (fascia y >= 170): lato = azione.
            if (ty >= 170) {
                if (tx >= DISPLAY_W/2) {
                    // OK -> RIEPILOGO
                    g_pending_score.valutato = true;
                    s_phase = SC_RIEPILOGO;
                    s_need_redraw = true;
                    tpResetTap();
                } else {
                    // INDIETRO -> torna a ZONA
                    s_phase = SC_ZONA;
                    s_need_redraw = true;
                    tpResetTap();
                }
                break;
            }
            // Fascia tasti +/- e ? (y [118..158])
            if (ty >= 118 && ty <= 158) {
                if (tx >= 16 && tx <= 72) {
                    if (d == 0) d = DIST_MIN; else if (d > DIST_MIN) d--;   // "-"
                } else if (tx >= DISPLAY_W - 72 && tx <= DISPLAY_W - 16) {
                    if (d == 0) d = DIST_MIN; else if (d < DIST_MAX) d++;   // "+"
                } else if (tx >= DISPLAY_W/2 - 28 && tx <= DISPLAY_W/2 + 28) {
                    d = 0;   // "?" IGNOTA
                }
            }
            // Slider: tocco diretto sulla barra (y ~[76..108] attorno all'asse 92)
            else if (ty >= 76 && ty <= 108 && tx >= SLD_X0 - 8 && tx <= SLD_X1 + 8) {
                d = xToDist(tx);
            }
            g_pending_score.distanza_m = d;
            s_need_redraw = true;
            break;
        }
        case SC_RIEPILOGO: {
            // Due QUADRONI affiancati che riempiono la fascia bassa. La
            // discriminazione è sul LATO (X), non su una banda Y stretta: molto
            // meno sensibile alla coordinata Y del tocco (stesso principio della
            // schermata esito). Fascia attiva: y >= 144 (sotto le info/ARCS).
            //   sinistra (tx <  120) = CORREGGI
            //   destra   (tx >= 120) = OK
            // --- TARATURA (temporaneo): stampa il raw del tap sul riepilogo.
            //     Da rimuovere una volta validato sul campo.
            DBG("RIEPILOGO tap raw tx=%u ty=%u (attivo se ty>=144; sx=CORREGGI dx=OK)", tx, ty);
            if (ty < 144) break;                 // tocco sulle info in alto: ignora
            if (tx >= DISPLAY_W / 2) {
                scoringFinish(true);   // OK (lato destro): unico invio ScorePacket
                return false;
            } else {
                scoringResume();       // CORREGGI (lato sinistro): riapre, no invio
            }
            break;
        }
        default: break;
    }
    return true;
}
