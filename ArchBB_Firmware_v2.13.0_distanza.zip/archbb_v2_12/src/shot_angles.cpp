// =============================================================================
// shot_angles.cpp — ArchBB: calcolo angoli biomeccanici dal burst (v1.2)
// Firmware 2.12.5 — finestra adattiva + flag qualita, segni validati 13/07f
// =============================================================================
// Vedi shot_angles.h per la documentazione completa della strategia.
// =============================================================================

#include "shot_angles.h"
#include <math.h>

// -----------------------------------------------------------------------------
// shot_angle_to_cdeg()
//   gradi -> centesimi di grado (int16), con saturazione a +-18000 (+-180.00 deg).
// -----------------------------------------------------------------------------
int16_t shot_angle_to_cdeg(float deg) {
    float cd = deg * 100.0f;
    if (cd >  18000.0f) cd =  18000.0f;
    if (cd < -18000.0f) cd = -18000.0f;
    return (int16_t)lroundf(cd);
}

// -----------------------------------------------------------------------------
// shot_angles_compute()
//   Media VETTORIALE dell'accelerazione nella finestra di stabilita' pre-scocco,
//   poi ricava cant e alzo dagli assi mediati. La media vettoriale (mediare le
//   componenti e POI calcolare l'angolo) e' piu' corretta che mediare gli angoli
//   campione per campione: evita gli artefatti di wrap-around di atan2 e pesa
//   naturalmente i campioni per l'intensita' del vettore gravita'.
// -----------------------------------------------------------------------------
// Statistiche di una finestra [a,b): media vettoriale + media/sd del modulo.
static void windowStats(const ImuSample* s, int32_t a, int32_t b,
                        double& mx, double& my, double& mz,
                        double& gmean, double& gsd) {
    int32_t n = b - a;
    double sx=0, sy=0, sz=0;
    for (int32_t i=a; i<b; i++) { sx+=s[i].ax; sy+=s[i].ay; sz+=s[i].az; }
    mx = sx/n; my = sy/n; mz = sz/n;
    double sm=0;
    for (int32_t i=a; i<b; i++)
        sm += sqrt((double)s[i].ax*s[i].ax + (double)s[i].ay*s[i].ay + (double)s[i].az*s[i].az);
    gmean = sm/n;
    double var=0;
    for (int32_t i=a; i<b; i++) {
        double m = sqrt((double)s[i].ax*s[i].ax + (double)s[i].ay*s[i].ay + (double)s[i].az*s[i].az);
        double d = m - gmean; var += d*d;
    }
    gsd = (n>=2) ? sqrt(var/(n-1)) : 0.0;
}

ShotAngles shot_angles_compute(const ImuSample* samples, uint16_t total,
                               uint16_t trigger_idx, OdrSetting odr) {
    ShotAngles r = {false, 0.0f, 0.0f, 0.0f, 0, false, 0.0f};

    if (!samples || total == 0) return r;

    // Converte le durate della finestra in numero di campioni all'ODR reale.
    const uint16_t hz    = odrToHz(odr);
    const uint16_t guard = (uint16_t)((float)SHOT_ANGLE_GUARD_MS  / 1000.0f * hz);
    const uint16_t win   = (uint16_t)((float)SHOT_ANGLE_WINDOW_MS / 1000.0f * hz);

    // --- FINESTRA ADATTIVA (validata sul test statico 13/07f) ---
    // PROBLEMA della finestra a offset fisso: negli ~200ms prima del trigger
    // l'arciere sta gia' partendo (clicker, apertura), e la finestra pescava
    // DENTRO il movimento -> |a| lontano da g, angoli sballati (err 13-40 deg sui
    // dati reali). SOLUZIONE: far scorrere la finestra su tutto l'intervallo
    // pre-trigger [0, trigger-guard) e scegliere quella col vettore piu' vicino
    // alla SOLA gravita' (min |mean|a|-g| + sd). Li' l'accelerometro misura
    // l'assetto, non il movimento. Sul test statico questo ha portato l'errore
    // medio da ~13 deg (fisso) a ~3.7 deg (adattivo).
    if (trigger_idx <= guard) return r;
    int32_t we_max = (int32_t)trigger_idx - (int32_t)guard;   // fine massima (esclusiva)
    if (we_max < (int32_t)win) return r;                      // non c'e' spazio per una finestra

    int32_t best_start = -1, best_end = -1;
    double  best_score = 1e18, best_gmean = 0, best_gsd = 0;
    double  best_mx = 0, best_my = 0, best_mz = 0;
    for (int32_t we = win; we <= we_max; we++) {
        int32_t ws = we - (int32_t)win;
        double mx, my, mz, gmean, gsd;
        windowStats(samples, ws, we, mx, my, mz, gmean, gsd);
        double score = fabs(gmean - SHOT_ANGLE_GRAVITY) + gsd;   // piu' basso = piu' fermo
        if (score < best_score) {
            best_score = score;
            best_start = ws; best_end = we;
            best_gmean = gmean; best_gsd = gsd;
            best_mx = mx; best_my = my; best_mz = mz;
        }
    }
    if (best_start < 0) return r;
    int32_t n = best_end - best_start;
    if (n < 3) return r;

    double mx = best_mx, my = best_my, mz = best_mz;

    // Flag di STABILITA': la finestra scelta e' affidabile solo se il suo |a|
    // medio e' vicino a g e la dispersione e' bassa. Altrimenti l'angolo va
    // preso con cautela (arciere mai fermo nel burst).
    r.stable = (fabs(best_gmean - SHOT_ANGLE_GRAVITY) < SHOT_ANGLE_G_TOL_MS2)
               && (best_gsd < SHOT_ANGLE_SD_MAX_MS2);
    r.g_mean = (float)best_gmean;

    // --- Angoli dal vettore gravita' medio (frame canonico) ---
    // cant = atan2(ay, ax): rollio laterale. Positivo = inclinato a DESTRA.
    //   Validato sul test statico 13/07: tiro cant-antiorario -> +20, orario -> -28.
    //
    // alzo = atan2(az, ax): elevazione dell'asse di mira.
    //   CONVENZIONE (fissata col test statico ad angoli noti, 13/07f):
    //     positivo = PUNTA della freccia verso l'ALTO (mira in su)
    //     negativo = punta verso il BASSO (mira in giu)
    //
    //   STORIA DEL SEGNO (per non ripetere l'errore):
    //   - v2.12.3 aveva messo atan2(-az,ax), tarato sul CSV 13JUL (primo). Ma
    //     quel CSV erano "tocchi simulati" con l'arco maneggiato a caso (|g|
    //     ballerino, assetti non fisici): un ground-truth inaffidabile.
    //   - Il test STATICO controllato (arco fermo su supporto, angoli noti,
    //     |g|~9.8 sd<0.15) ha smentito quel segno: col gesto dichiarato
    //     "punta in alto" la formula col meno dava NEGATIVO. Verifica diretta:
    //       tiro "alto"  (az=+3.0) -> atan2(+az,ax) = +17.3  (giusto)
    //       tiro "basso" (az=-2.5) -> atan2(+az,ax) = -14.4  (giusto)
    //     Quindi il segno corretto e' SENZA meno: atan2(az, ax).
    //   Lezione: tarare i segni solo su dati statici ad angolo noto, mai su
    //   gesti ambigui.
    //
    //   NOTA offset di montaggio: nel test il "piatto" dava alzo ~+9, cant ~-5
    //   costanti -> tilt residuo del supporto, non errore di formula (le
    //   VARIAZIONI hanno verso corretto). Una calibrazione di offset mount e'
    //   un miglioramento futuro separato.
    r.cant_deg = (float)(atan2(my, mx) * 180.0 / M_PI);
    r.alzo_deg = (float)(atan2(mz, mx) * 180.0 / M_PI);

    // Dispersione |a| della finestra scelta (gia' calcolata nella ricerca):
    // basso = arco fermo, misura affidabile; e' la stessa grandezza usata per il
    // flag 'stable'.
    r.disp_ms2 = (float)best_gsd;
    r.n_used   = (int)n;
    r.valid    = true;
    return r;
}
