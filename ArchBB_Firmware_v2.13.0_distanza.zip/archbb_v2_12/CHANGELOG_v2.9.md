# ArchBB Firmware — CHANGELOG v2.9.0

**Data:** 3 luglio 2026
**Base:** v2.8.0

---

## Orientamento di montaggio configurabile (4 posizioni sul riser)

La scheda Waveshare può ora essere montata sul riser in **quattro orientamenti**,
per adattarsi ai fori liberi dei riser moderni (olimpici o compound):

| Orientamento | Codice | Posizione |
|--------------|--------|-----------|
| 0° | `MOUNT_0` | frontale, schermo verso arciere (riferimento) |
| −90° | `MOUNT_DX_M90` | lato destro del riser |
| +90° | `MOUNT_SX_P90` | lato sinistro del riser |
| 180° | `MOUNT_180` | lato opposto |

### Come funziona: trasformazione a monte

I quattro montaggi sono **rotazioni attorno all'asse gravità (ax)**: "l'alto resta
l'alto". Ciò che cambia è come l'asse **freccia (az)** e l'asse **laterale (ay)**
si distribuiscono sugli assi elettronici del sensore. La correzione è una matrice
di rotazione applicata **subito dopo la lettura IMU e a monte di tutto** (trigger,
circular buffer, burst BLE, metriche app): l'intero sistema a valle vede sempre
dati nel frame canonico 0°, e **nessun altro modulo è stato modificato**.

Poiché sono rotazioni di multipli di 90°, le matrici contengono solo 0 e ±1: la
trasformazione è una **permutazione con cambi di segno**, senza trigonometria,
senza errori di arrotondamento, a costo computazionale nullo.

### Determinazione empirica delle matrici

Le matrici sono state ricavate da **dati di campo reali**, non dalla teoria:
- Tumble test a 6 pose (firmware diagnostico v2.8-diag3) per mappare i versori.
- **Ancoraggio a 5 scocchi veri** (sessione 02JUL): frame canonico confermato
  gravità **+ax**, scocco **+az**.
- Validazione: tutte le matrici ortonormali, det=+1, `ax` invariante.

| Montaggio | accel canonico | gyro canonico |
|-----------|----------------|---------------|
| 0° | identità | identità |
| −90° DX | cax=ax, cay=−az, caz=ay | cgx=gx, cgy=−gz, cgz=gy |
| +90° SX | cax=ax, cay=az, caz=−ay | cgx=gx, cgy=gz, cgz=−gy |
| 180° | cax=ax, cay=−ay, caz=−az | cgx=gx, cgy=−gy, cgz=−gz |

Il giroscopio usa la **stessa matrice** dell'accelerometro (rigidamente solidali
sullo stesso PCB → unica trasformazione rigida).

### Impatto NVS / protocollo: ZERO

`mount_orientation` riusa il byte `_pad` libero di `Config`: **sizeof(Config)
resta 23 byte** (verificato). Nessuna corruzione NVS, protocollo BLE Config
invariato. Le config v2.8 esistenti (dove quel byte valeva 0) si comportano
correttamente come "frontale".

### File

- **NUOVI:** `mount.h` (enum, tabella matrici, `mount_apply`), `mount.cpp`.
- **MODIFICATI:**
  - `config.h`: `_pad` → `mount_orientation`, `config_version` 2→3, FW 2.9.0.
  - `imu.cpp`: chiamata `mount_apply()` a monte del trigger (righe ~216).
  - `ble_server.cpp`: validazione + propagazione a `g_mount_orientation`.
  - `main.cpp`: init orientamento da Config prima dell'avvio imu_task.
  - `display.cpp`: indicazione montaggio nella schermata di boot.

### App companion

`ArchBB_App_v1_16.html`: selettore visuale (4 pulsanti lato+angolo + diagramma
SVG del riser) nel tab CONFIG. Scrive `mount_orientation` (byte 21). Sincronizza
il selettore in lettura dalla scheda.

---

## Riferimenti scientifici

- AllAboutCircuits, "How to Interpret IMU Sensor Data for Dead-Reckoning:
  Rotation Matrix Creation" (2019) — trasformazione a monte via matrice di rotazione.
- Frosio et al., "Time- and Computation-Efficient Calibration of MEMS 3D
  Accelerometers" (Sensors, PMC8124870) — six-position test, allineamento assi.
- US11886245 — trasformazione dal frame di montaggio a un frame canonico in
  dispositivi wearable.

---

## Fix di compilazione (iterazione 2)

Due problemi emersi al primo build reale, entrambi risolti:

1. **`cannot bind packed field to float&`** — `mount_apply` prende parametri per
   riferimento, ma `ImuSample` è `packed`: i suoi float possono essere non
   allineati e Xtensa vieta di legarli a `float&`. **Fix:** in `imu.cpp` la
   trasformazione ora lavora su variabili LOCALI allineate (le stesse che poi
   riempiono la struct), non sui campi packed. Documentato nel commento di
   `mount_apply`. Verificato con test g++ che replica la condizione packed.

2. **`"DBG" redefined`** — SensorLib (`SensorCommDebug.hpp`) definisce una macro
   `DBG` che collideva con quella di `config.h`, e — peggio del warning — la
   ridefiniva VUOTA, sopprimendo silenziosamente i log ArchBB di `imu.cpp`.
   **Fix:** `#undef` preventivo in `config.h` + ripristino esplicito della `DBG`
   ArchBB in `imu.cpp` dopo l'include di SensorLib. I log di debug ora funzionano.

Nota: il warning `TOUCH_CS pin not defined` di TFT_eSPI è preesistente e innocuo
(non usiamo le funzioni touch di TFT_eSPI; il touch CST816T è gestito altrove).
