# CHANGELOG v2.10 — Fix Crash BLE (controllo di flusso robusto)

**Data:** 6 luglio 2026
**Parte da:** v2.9 (mount orientation) + fix flow-control parziale già in sorgente

---

## Contesto

Sessione di test al tavolino (06/07, WS a −90°): il device si è **resettato**
durante la trasmissione BLE del 5° tiro (`rst:0xc` a chunk 30/42). Sintomo
osservato dall'utente: "5 beep dalla WS ma solo 3 bing in cuffia" — cioè device
che rileva 5 tiri ma app che ne registra solo 3, con crash del device sul 5°.

## Causa

Congestione dello stack NimBLE: `notify()` chiamata più in fretta di quanto lo
stack riesca a smaltire → esaurimento buffer mbuf (`BLE_HS_ENOMEM`) → crash.
Confermato da doc Espressif (ESP-IDF issue #9097). Il vecchio delay FISSO di 20ms
tra chunk non bastava sotto pressione radio.

Nota: in NimBLE-Arduino 1.4.1 il valore di ritorno di `notify()` non è
pienamente affidabile (changelog upstream: "Notify/Indicate incorrectly
returning success"), quindi il back-pressure da solo non basta.

## Soluzione — difesa in profondità (4 livelli)

1. **Back-pressure** (`bldFlowNotify`): ritenta il pacchetto se notify fallisce
   (fino a 5 tentativi con attesa crescente).
2. **Delay adattivo**: parte a 6ms (veloce), sale a 30ms sotto congestione, poi
   si rilassa. Non dipende dal ritorno di notify. Sostituisce il delay fisso 20ms.
3. **Yield esplicito** (`taskYIELD()`): dopo ogni notify cede la CPU al task
   NimBLE su Core 0, riducendo contesa e non-rientranza.
4. **Check disconnessione nel ciclo**: verifica `getConnectedCount()` prima di
   ogni chunk; se il peer si disconnette a metà burst (come nel crash reale),
   interrompe con grazia invece di spingere notify nel vuoto.

I livelli 1-2 erano già nel sorgente; 3-4 aggiunti in questa versione.

## CORREZIONE (compilazione) — notify() è void in 1.4.1

Il primo build reale ha rivelato: `error: void value not ignored as it ought to
be` su `bool ok = ch->notify()`. In **NimBLE-Arduino 1.4.1 `notify()` ritorna
VOID**, non bool (il bool è stato aggiunto solo dalla 2.x). Il back-pressure con
retry basato sul successo era quindi impossibile da compilare.

**Correzione:** rimossa ogni dipendenza dal valore di ritorno. La strategia di
flow-control è stata ridisegnata in modo onesto per i limiti della 1.4.1:
- `bldFlowNotify` ora è un semplice wrapper void di `notify()`.
- Il delay non è più "adattivo sul fallimento" (impossibile senza il ritorno),
  ma **adattivo per POSIZIONE nel burst** (`bldChunkDelay`): rampa da MIN (8ms)
  a MAX (28ms), tarata sui dati reali per dare massima protezione nella fascia
  60-75% del burst, dove il crash 06/07 avveniva (chunk 25-32/42).

I livelli di difesa attivi in 1.4.1 sono quindi 3: **delay per posizione + yield
+ check disconnessione**. Il back-pressure sul ritorno resta commentato come
possibile aggiunta futura se si aggiornerà a NimBLE 2.x.

### Parametri della rampa (config nel .cpp)
| Costante | Valore | Significato |
|----------|--------|-------------|
| `BLD_DELAY_MIN_MS` | 8 | delay a inizio burst (stack libero) |
| `BLD_DELAY_MAX_MS` | 28 | delay nella fascia calda |
| `BLD_RAMP_START_FRAC` | 0.25 | inizia a rallentare al 25% del burst |
| `BLD_RAMP_FULL_FRAC` | 0.70 | raggiunge il MAX al 70% |

Verifica logica (g++): delay 8ms a inizio, 23-28ms nella zona crash (60-76%),
totale ~777ms (< 840ms del vecchio fisso). Compila con notify() void.

## File modificati

- `src/ble_server.cpp` — ciclo `ble_send_burst`: aggiunti check disconnessione
  e `taskYIELD()`; mantenuti back-pressure e delay adattivo preesistenti.
- `src/config.h` — `FW_VERSION_STR` = "2.10.0"; costanti flow-control documentate.

## Verifica

- Logica delay adattivo testata (g++): 42 chunk con congestione simulata →
  tutti inviati, delay entro [6, 30]ms, totale ~790ms (< 840ms del fisso).
- Sintassi e bilanciamento graffe verificati.
- ⚠️ Verifica funzionale reale (NimBLE sotto carico radio) da fare sul campo.

## Test sul campo (criterio di successo)

Flash → boot deve dire **v2.10.0** → monitor seriale aperto → 15-20 scocchi
ravvicinati → N beep = N bing = N tiri completi nel CSV, zero reset.
Nei log dei chunk ora compare `delay=Nms`: se sale sotto pressione e regge, il
fix lavora.

## Resta aperto

Problema B (app che perde/tronca notifiche in ricezione) → app v1.19 futura:
verifica completezza burst + rilevamento gap di sequenza.
