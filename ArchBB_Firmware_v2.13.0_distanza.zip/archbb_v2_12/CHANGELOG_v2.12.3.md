# CHANGELOG — ArchBB Firmware v2.12.3 (fix segno alzo)

**Data:** 13 luglio 2026
**Base:** v2.12.2
**File modificati:** `src/shot_angles.cpp`, `src/config.h` (versione).

## Sintomo (dal campo, CSV 13/07)
Scoccando intenzionalmente puntando verso il BASSO, il firmware riportava un
alzo POSITIVO ed esagerato (+16..18°) invece di negativo (~−19°).

## Diagnosi (i dati comandano)
Analisi degli accelerometri nella finestra pre-scocco dei 3 tiri del CSV:

| shot | ax | ay | az | alzo_fw (bug) | alzo corretto |
|---|---|---|---|---|---|
| 1 | +8.73 | +0.92 | +3.11 | +16.70 | **−19.60** |
| 2 | +9.96 | −0.37 | +3.34 | +17.54 | **−18.54** |
| 3 | +8.83 | +0.13 | +3.14 | +18.09 | **−19.55** |

La formula era `alzo = atan2(az, ax)`. Con l'orientamento fisico dell'IMU,
abbassare la canna produce `az > 0`, quindi senza segno meno l'alzo risulta
positivo. La formula fisicamente corretta è `atan2(-az, ax)`.

Il **cant** (`atan2(ay, ax)`) è invece CORRETTO e combacia col firmware
(+6.00 vs +6.81, −2.12 vs −2.57, +0.81 vs +0.51): NON toccato.

## Fix
Una riga in `shot_angles_compute()`:

    - r.alzo_deg = atan2(mz, mx) ...
    + r.alzo_deg = atan2(-mz, mx) ...

Convenzione risultante: alzo **positivo = mira in alto, negativo = mira in basso**.

## Verifica
- Test standalone della funzione coi campioni reali dello shot 1:
  → cant=+6.00, alzo=**−19.60**. Corretto.
- App v1.22: legge `alzo_fw` così com'è (`alzoCd/100`, nessuna manipolazione di
  segno). Nessun rischio di doppio-fix, nessuna modifica lato app necessaria.

## Nota sui dati già raccolti
I 3 tiri del CSV 13/07 hanno l'alzo col segno invertito e leggermente sovrastimato
in modulo (per la finestra). Se servono, si correggono a posteriori:
alzo_reale ≈ −alzo_fw (il segno è l'errore dominante).
