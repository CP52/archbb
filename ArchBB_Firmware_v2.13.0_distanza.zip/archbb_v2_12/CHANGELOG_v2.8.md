# ArchBB Firmware — CHANGELOG v2.8.0

**Data:** 2 luglio 2026
**Base:** v2.7.0

---

## Il "crollo batteria" non esisteva: era un bug del filtro

La diagnostica via BLE (v2.7) ha finalmente MISURATO il transitorio di
accensione, e i dati hanno risolto il mistero smentendo DUE mie ipotesi
precedenti (surface charge, transitorio hardware):

| grandezza | all'accensione | dopo 4 min | verdetto |
|-----------|----------------|------------|----------|
| **tensione** | 3.969 V | 3.949 V | stabile (drift 12 mV, stdev 6 mV) → HW perfetto |
| **% grezza (LUT)** | 66% | 63% | corretta e stabile |
| **% filtrata** | 97% → 66% | 64% | ← il "crollo" era QUI |

**Causa reale:** il filtro grace-period + EMA introdotto in v2.6/2.7 partiva dal
valore iniziale `g_batt_pct = 100` e ci metteva secondi a riallinearsi alla
misura vera, PRODUCENDO proprio il salto che doveva prevenire. Il fenomeno
fisico non esisteva: era un artefatto software.

## La soluzione: rimuovere codice

`battery.cpp` torna a un gauge ONESTO e minimale (v3.0):
- LUT empirica tensione→% (curve di scarica LiPo reali).
- Mediana mobile leggera (finestra 5) per il solo rumore ADC.
- **Rimossi:** grace period, EMA, smoothing direzionale, `battery_is_settled()`,
  costanti `BATT_SETTLE_MS` / `BATT_EMA_ALPHA*`.
- `g_batt_pct` parte da 0 e viene sovrascritto dalla PRIMA lettura reale in
  `battery_init()`: nessun consumatore vede mai un valore fittizio.

### Verifica sui DATI REALI

Il gauge v3.0 applicato alla sequenza di tensioni del CSV di diagnostica
(batteria "ferma a ~65%") parte da **67%** e resta **64-67%** per tutta la
sessione. Nessun salto. Valore subito onesto e stabile.

### Fondamento scientifico

La letteratura sui fuel gauge conferma l'approccio: per un'applicazione a
RIPOSO (nessun carico forte continuo) su chimica LiPo (curva OCV-SOC non piatta
come nel LiFePO4), l'**OCV lookup puro con filtro minimo** è corretto e
sufficiente. Coulomb counting / EKF sarebbero over-engineering, oltre che
impossibili senza sensore di corrente. Il gating a radio-idle (v2.6, mantenuto)
garantisce di leggere la OCV e non la tensione sotto carico.

## Mantenuto dalla v2.7

- Diagnostica batteria via BLE (comando `CMD_BATT_DIAG` 0x10, pacchetto
  `BattDiagPacket` 0x05 sulla caratteristica LIVE): strumento utile, resta
  disponibile per verifiche future.
- Gating anti IR-drop (v2.6), backlight state-driven + beep (v2.6).

### File modificati (da v2.7)

| File | Modifica |
|------|----------|
| `src/battery.cpp` | riscritto v3.0: gauge minimale onesto |
| `src/battery.h` | rimosse costanti grace/EMA e `battery_is_settled()` |
| `platformio.ini` / `config.h` | versione 2.8.0 |

## Validazione

- Logica v3.0 testata in g++ isolato **sui dati reali del CSV**: parte corretto,
  resta stabile 64-67%.
- Graffe bilanciate su tutti i file; nessun residuo di codice rimosso.
