# CHANGELOG — ArchBB Firmware v2.12.5 (angoli: segni + finestra adattiva)

**Data:** 13 luglio 2026
**Base:** v2.12.4
**File modificati:** `src/shot_angles.cpp`, `src/shot_angles.h`,
`src/ble_server.cpp` (log), `src/config.h` (versione).

Validato sul TEST STATICO ad angoli noti (BBarch_13JULf: arco fermo su supporto,
5 tiri con intenzione dichiarata, |g|~9.8-10.2 sd<0.2 -> finestre pulite).

---

## 1. Segno dell'alzo: RIPRISTINATO atan2(az,ax) (la 2.12.3 era sbagliata)
La v2.12.3 aveva messo atan2(-az,ax) tarando sul primo CSV (13JUL), che pero'
erano "tocchi simulati" con l'arco maneggiato a caso: ground-truth inaffidabile.
Il test statico controllato lo ha smentito. Con la convenzione dichiarata da
Cesare (punta in alto = alzo POSITIVO):

| tiro (intenzione) | az    | alzo atan2(az,ax) | atteso |
|-------------------|-------|-------------------|--------|
| 2 alto (punta su) | +3.02 | **+17.3**         | +      |
| 3 basso (punta giu)| -2.50 | **-14.4**         | -      |

Segno corretto: SENZA meno -> `alzo = atan2(az, ax)`.
Cant invariato (`atan2(ay,ax)`, + = destra): tiro cant-antiorario +19.9,
orario -27.7 -> segni opposti coerenti.

**Lezione documentata nel codice:** tarare i segni SOLO su dati statici ad
angolo noto, mai su gesti ambigui.

## 2. Finestra ADATTIVA (sostituisce l'offset fisso)
La finestra fissa pre-trigger pescava DENTRO il movimento di rilascio (|a|
lontano da g), producendo angoli sballati sui tiri reali. Ora la finestra scorre
su tutto l'intervallo pre-trigger e si sceglie quella col vettore piu' vicino
alla sola gravita' (min |mean|a|-g| + sd).

Errore medio combinato contro il ground-truth (analisi + funzione C++ reale):

| strategia        | err medio |
|------------------|-----------|
| fixed_50_200 (vecchia) | 13.2 deg |
| fixed_100_200    | 10.4 deg |
| **most_stable (nuova)** | **3.7 deg** |

Fattore ~4 di miglioramento. (Il residuo ~9 deg sul "piatto" NON e' errore di
finestra: e' il tilt di montaggio del supporto, costante fra i tiri.)

## 3. Flag di QUALITA' (stable)
ShotAngles ha due nuovi campi: `stable` (bool) e `g_mean` (float). `stable` e'
true se la finestra scelta ha |a| vicino a g (entro 1.5) e dispersione bassa
(<1.0): assetto affidabile. Se anche la finestra migliore e' nel movimento,
stable=false -> angolo da prendere con cautela. Soglie tarate sui dati.
Per ora e' LOGGATO (DBG a fine burst); NON trasmesso nello ScorePacket (nessuna
modifica al protocollo/app in questo giro).

## Verifica
- Funzione C++ reale compilata e girata sui dati del test: riproduce
  esattamente gli angoli attesi (alto +17.3, basso -14.4, cant -27.7/+19.9),
  tutte finestre stable=OK.
- Sintassi: g++ -fsyntax-only OK.

## Prossimi passi possibili (separati, non in questo giro)
- Calibrazione OFFSET di montaggio (il "piatto" non e' zero: alzo ~+9, cant ~-5
  costanti). Richiederebbe una routine di azzeramento a riser fermo.
- Trasmettere `stable` nello ScorePacket per marcare in app i tiri a bassa
  affidabilita' d'assetto (tocca protocollo + parsing app).
