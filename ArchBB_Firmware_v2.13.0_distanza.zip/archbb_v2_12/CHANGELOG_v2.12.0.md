# CHANGELOG — ArchBB Firmware v2.12.0 (Scoring UX Backport dalla 1.83)

**Data:** 12 luglio 2026
**Base:** v2.11.3 (Fase C)
**Origine migliorie:** sviluppo scoring sulla WS 1.83 (Fasi 1–3)
**File modificati:** `src/scoring_ui.cpp` (riscritto, v2.0), `src/scoring_ui.h`
(nota di versione), `src/config.h` (`FW_VERSION_STR` → "2.12.0"),
`src/ble_server.cpp` (fix `strncpy` del campo `fw_version`).

> **Bump versione + fix latente:** `FW_VERSION_STR` portato a "2.12.0" (prima il
> boot mostrava ancora 2.11.3). Nel farlo è emerso un baco preesistente: il campo
> `StatusPacket.fw_version` è `char[6]` ma la `strncpy` copiava solo 5 caratteri
> senza garantire il terminatore — con "2.11.3" (6 char) l'app riceveva "2.11."
> troncato. Ora copia `sizeof-1` e forza il `\0`. La dimensione del pacchetto NON
> cambia (il campo era già 6 byte): app v1.22 compatibile, legge "2.12.0".

> Metodo: file completi versionati, mai patch. Le soglie touch, i pin, lo
> ScorePacket e il flusso BLE restano **invariati**.

---

## In una riga

Il riepilogo diventa un **punto di controllo esplicito**: nessuno score si
cementa più per un tocco distratto. Attorno a questo, il touch è più robusto e
la navigazione più chiara.

---

## Migliorie applicate (mappate al briefing di backport)

### §1 — RIEPILOGO OK / CORREGGI (il cuore) ✅
- Nuova fase `SC_RIEPILOGO` fra `SC_DISTANZA` e l'uscita.
- CONFERMA sulla schermata distanza **non invia più** direttamente: porta al
  riepilogo.
- Riepilogo mostra esito + zona + distanza + **ARCS** (l'intero-singolo che
  finirà nel CSV, `±(dist*10+(zona+1))`).
- Due sole azioni:
  - **OK** (grande, nero su verde): l'**unica** che chiama `scoringFinish(true)`
    → `ble_send_score()`. È l'unico punto in cui parte lo ScorePacket.
  - **‹ CORREGGI** (secondario, sopra): chiama `scoringResume()`, che riapre lo
    **stesso tiro** da `SC_ESITO` **senza azzerare** colpito/zona/distanza e
    **senza inviare** nulla.
- Tap fuori dai due pulsanti: **ignorato**.
- `shot_id` preservato "per costruzione": lo scrive `ble_server` all'ingresso,
  nessuno lo tocca durante lo scoring, quindi CORREGGI lo mantiene senza codice
  dedicato.

### §2 — Debounce + cooldown ✅
- Nuovo **cooldown uniforme post-azione** (`TOUCH_COOLDOWN_MS = 200`), non
  bloccante (confronto `millis`), attivo su **tutte** le schermate.
- Sostituisce il vecchio `delay(180)` bloccante presente solo sulla schermata
  zona. Elimina il doppio-conteggio del rilascio e l'ereditarietà del tocco fra
  due schermate consecutive.
- Nota cadenza: il `display_task` gira a `vTaskDelay(80ms)` (~12 Hz). A questa
  frequenza il debounce di rilascio è di fatto già garantito dalla lentezza del
  loop; il parametro che conta è il cooldown, tarato su ~2–3 giri di loop.

### §3 — Pulsante ‹ INDIETRO ✅
- Presente in **ZONA** (torna a esito) e **DISTANZA** (torna a zona). Assente in
  esito (primo passo).
- Riquadro esplicito in basso a sinistra; hotspot `x < 82` nella fascia `y ≥ 248`.
- Conserva i valori già scelti.

### §4 — Breadcrumb ✅
- Riga di contesto in cima a ZONA (`COLPITO`/`MANCATO`) e DISTANZA
  (`COLPITO > dx`), col colore che richiama l'esito.

### §6 — Pulsante ? (IGNOTA) esplicito ✅
- Quarto riquadro nella fila delle tacche rapide: imposta `distanza = 0` (ignota).
- La schermata distanza mostra `IGN` / `ignota` quando `dist == 0`; i pulsanti
  +/− da IGN escono a 5 m.

### §5 — Semantica MANCATO (riverificata, già corretta) ✅
- Centro (indice 4) disattivato nel mancato, SPOT nel colpito. Nessun `zona=0`
  d'ufficio. Invariata dalla v1.0.

### §7 — Glifi font (riverificato) ✅
- +/− geometrici (font 6 solo numerico). Lettere ("OK", "CONFERMA") in font 4.

---

## Flusso risultante

```
STATE_SCORING (ingresso da ble_server, shot_id + angoli già nel ponte)
  │  scoringEnter()  [azzera esito, parte pulito]
  ▼
SC_ESITO ──tap semicampo──► SC_ZONA ──tap cella──► SC_DISTANZA ──CONFERMA──► SC_RIEPILOGO
   │  (barra SKIP)              │ (‹INDIETRO→esito)   │ (‹INDIETRO→zona)          │
   └──────────────┬────────────┴──────────┬──────────┘                          │
       SKIP immediato: scoringFinish(false)                          ┌───────────┴───────────┐
       (non passa dal riepilogo)                                     ▼                       ▼
                                                                  OK: scoringFinish(true)  CORREGGI: scoringResume()
                                                                  → ble_send_score()        → riapre SC_ESITO
                                                                  → CONNECTED/RECORDING        valori conservati,
                                                                                               NIENTE invio
```

---

## Verifiche fatte prima della consegna

- **Sintassi**: `g++ -std=c++17 -fsyntax-only` con stub minimi di
  Arduino/TFT_eSPI/Wire → **0 errori** (parentesi, campi `g_pending_score`,
  costanti palette, firme funzioni).
- **Invarianti flusso** (grep): `ble_send_score()` chiamato **solo** dentro
  `scoringFinish()`; `scoringResume()` **non** lo chiama; `SC_RIEPILOGO` coperto
  sia in redraw sia nel tick.
- **Residui**: nessun `delay(180)` residuo (solo menzioni nei commenti che
  spiegano la rimozione).

---

## Da verificare SUL CAMPO (i dati comandano)

1. **Aree tattili della schermata distanza**: il layout è stato ricompattato per
   fare posto al breadcrumb e al pulsante ?. Le soglie X delle quattro tacche
   (`<64`, `<122`, `<180`, resto) e le bande Y (`48..110`, `136..168`,
   `178..220`) sono da confermare con un dito reale sul pannello. Se una tacca
   "sfugge", si aggiustano quei numeri (nessun impatto sulle soglie zona THR_*).
2. **Hotspot INDIETRO vs SKIP** nella fascia inferiore: confine `x = 82`. Da
   verificare che INDIETRO non venga preso per SKIP e viceversa.
3. **Riepilogo**: confini `y` di OK (`198..250`) e CORREGGI (`152..190`) su dito
   reale.
4. **Cooldown 200 ms**: se in campo risulta troppo pigro fra due tap intenzionali
   (es. "+" ripetuti sulla distanza), abbassarlo a 150; se ancora doppia, alzarlo.

---

## Compatibilità

- **App v1.22**: nessuna modifica necessaria. Lo ScorePacket (pkt_type 0x06,
  10 byte) è identico; l'app continua ad associarlo via `shot_id`. Il backport è
  **solo lato UX del firmware**.
- **ScorePacket / protocollo BLE**: invariati.
- **Soglie touch / pin / memory_type**: invariati (`qio_qspi` sulla 1.69).
