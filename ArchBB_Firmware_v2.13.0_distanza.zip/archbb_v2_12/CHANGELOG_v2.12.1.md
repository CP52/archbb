# CHANGELOG — ArchBB Firmware v2.12.1 (hotfix post-campo)

**Data:** 13 luglio 2026
**Base:** v2.12.0
**File modificati:** `src/scoring_ui.cpp`, `src/power.cpp`, `src/config.h`.

Correzioni dai tre sintomi osservati alla prima verifica del riepilogo.

## 1. "OK" verde senza scritta ✅ (certo)
Il testo "OK" era disegnato in **font 6**, che in TFT_eSPI è SOLO numerico (niente
lettere): rettangolo verde muto. Portato a **font 4**. È la trappola §7 del
briefing, sfuggita proprio sul pulsante principale.

## 2. "OK" premuto non reagiva — strumentazione ✅
Gli hotspot (CORREGGI 152..190, OK 198..250) combaciano col disegno; il tap
dovrebbe passare. Sospetto principale: il pulsante SEMBRAVA morto perché senza
scritta (vedi §1), quindi il tap c'era ma pareva ignorato. Per chiudere il dubbio
sul campo ho aggiunto un **log temporaneo** di taratura nel case SC_RIEPILOGO:

    [ARCHBB] RIEPILOGO tap raw tx=.. ty=.. (OK se ty in 198..250)

A banco, col monitor collegato, premi OK e leggi il ty reale:
- se cade in 198..250 e ora reagisce → era solo il font, log da rimuovere;
- se cade FUORI → mi porti il valore e ritariamo la banda (come per le zone).

## 3. Manca il beep all'apertura scoring ✅ (baco preesistente, non del backport)
Il beep "colpo preso" era agganciato alla transizione RECORDING → SENDING in
`power_update_for_state`. Ma SENDING e SCORING vengono impostati ENTRAMBI dal task
BLE (Core 0) nello stesso giro di `ble_send_burst()`, senza che il display_task
(Core 1) giri in mezzo: quando il display legge lo stato è GIÀ SCORING, e non vede
mai SENDING. Il beep non scattava.
**Fix:** beep agganciato all'INGRESSO in SCORING (transizione che il display vede
davvero) — cioè l'istante "colpo riconosciuto, si apre la valutazione". Mantenuto
anche il vecchio aggancio SENDING←RECORDING come rete di sicurezza.

## Da verificare a banco
1. Boot mostra v2.12.1.
2. Riepilogo: "OK" ora si LEGGE (font 4) e, premuto, cementa+invia.
3. Leggi il log del tap sul riepilogo: conferma ty di OK e CORREGGI.
4. Beep: al riconoscimento del colpo (apertura scoring) ora suona.

## Nota
Il log di taratura (§2) è TEMPORANEO: una volta validato, lo rimuovo nella
versione successiva per rispettare la regola "niente Serial superfluo nel loop".
