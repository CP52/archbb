# CHANGELOG — ArchBB Firmware v2.12.2 (riepilogo a due quadroni)

**Data:** 13 luglio 2026
**Base:** v2.12.1
**File modificati:** `src/scoring_ui.cpp`, `src/config.h` (versione).

## Motivazione
Sul campo l'OK a barra orizzontale (alta 52px) risultava difficile da centrare:
se il dito cadeva appena sopra/sotto la banda Y, il tap sfuggiva. Problema di
sensibilità alla coordinata Y.

## Soluzione — due quadroni affiancati
Il riepilogo ora chiude con DUE riquadri grandi affiancati che riempiono la
fascia bassa (~126px di altezza tattile ciascuno):
- **sinistra**: CORREGGI (ambra, chevron '‹' grande) — riapre il tiro, no invio;
- **destra**: OK (verde pieno, nero) — cementa e invia lo ScorePacket.

La discriminazione del tocco passa dal LATO (X: sx vs dx), non più da una banda Y
stretta. È lo stesso principio robusto della schermata esito (semicampo sx/dx),
che non ha mai dato problemi di centratura. Un tap in qualunque punto della metà
inferiore conta: importa solo da che parte.

## Logica tick
    if (ty < 144) ignora           # tocco sulle info in alto
    else if (tx >= 120) OK         # lato destro
    else               CORREGGI    # lato sinistro

La guardia SKIP (ty>=248) resta esclusa per il riepilogo, quindi un OK toccato in
basso non viene scambiato per SKIP.

## Da verificare a banco
1. Boot mostra v2.12.2.
2. Riepilogo: due quadroni ben leggibili, OK a destra verde, CORREGGI a sinistra.
3. OK ora si centra facilmente da qualunque punto della metà destra bassa.
4. Il log di taratura ora stampa "sx=CORREGGI dx=OK": conferma che il lato
   giusto risponde. Una volta ok, al prossimo giro rimuovo il log.
