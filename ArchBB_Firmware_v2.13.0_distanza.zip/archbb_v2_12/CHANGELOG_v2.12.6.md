# CHANGELOG — ArchBB Firmware v2.12.6 (fix doppio beep)

**Data:** 13 luglio 2026
**Base:** v2.12.5
**File modificati:** `src/power.cpp`, `src/config.h` (versione).

## Sintomo
Sul PRIMO tiro, a volte, due beep invece di uno.

## Causa
La v2.12.1, per risolvere il beep mancante, aveva messo DUE agganci in
`power_update_for_state`: uno su ingresso SCORING, uno "di sicurezza" su
RECORDING->SENDING. La sequenza reale e' RECORDING -> SENDING -> SCORING. Se il
display_task gira abbastanza spesso da vedere ENTRAMBE le transizioni (piu'
probabile sul primo tiro, task appena avviati), scattano entrambi i beep:
  - giro A: vede SENDING (prev RECORDING) -> beep (ramo sicurezza)
  - giro B: vede SCORING (prev SENDING)   -> beep (ramo principale)
Il numero di beep dipendeva da quali stati intermedi il display riusciva a
osservare: fragile.

## Fix
Flag di ciclo `s_shot_beeped`: il beep scatta UNA sola volta alla prima
transizione utile del tiro (SENDING<-RECORDING o ingresso SCORING), poi e'
inibito fino al ritorno in uno stato a riposo (RECORDING/CONNECTED/IDLE), che
ri-arma per il tiro successivo. Il numero di beep non dipende piu' dal timing di
osservazione del display.

## Verifica (simulazione di tutti i percorsi)
- display vede solo SCORING: 1 beep OK
- display vede SENDING + SCORING (era il doppio): 1 beep OK
- due tiri consecutivi: 2 beep (uno per tiro) OK
- SCORING ripetuto nello stesso tiro (valutazione lunga): 1 beep OK
Nessun rischio di ri-arma a meta' tiro: CONNECTED e' impostato solo alla
connessione BLE, mai durante la sequenza di un colpo.

## Nota
Angoli v2.12.5 confermati sul CSV 13JULg: alzo/cant del firmware coincidono col
ricalcolo (+4.8/+16.4/-11.9), finestre pulite (|g|~10, sd~0.1). Il firmware
nuovo gira correttamente.
