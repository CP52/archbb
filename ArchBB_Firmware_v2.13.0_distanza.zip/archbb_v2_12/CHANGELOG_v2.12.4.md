# CHANGELOG — ArchBB v2.12.4 (fw) + App v1.23 — due bug distinti

**Data:** 13 luglio 2026

Due bug segnalati sul campo, in due componenti diversi.

---

## BUG 1 (FIRMWARE) — col "colpito" il riepilogo veniva saltato
**File:** `src/scoring_ui.cpp` (+ `config.h` versione)

### Causa (verificata sui dati e sulla geometria)
Il pulsante CONFERMA della schermata distanza (area x[16..224] y[178..220]) e il
quadrone OK del RIEPILOGO (lato destro x>=120, y>=144) si SOVRAPPONGONO
nell'area x[120..224] y[178..220]. Premendo CONFERMA nella sua metà destra, il
tocco — se il dito non si era ancora staccato — veniva ereditato dalla schermata
successiva (il riepilogo) come tap su OK, che chiama scoringFinish() e cementa lo
score: il riepilogo compariva e spariva in un lampo. Il sintomo emergeva col
"colpito" per via del punto in cui cade tipicamente il tocco, ma il difetto era
latente per entrambi gli esiti (sovrapposizione spaziale, non dipendente
dall'esito).

### Fix
Introdotto `tpResetTap()`: forza il rilevatore di tocco ad attendere un RILASCIO
PULITO (dito staccato) prima di validare un nuovo tap. Chiamato a OGNI
transizione di schermata (ESITO->ZONA, ZONA->DISTANZA, DISTANZA->RIEPILOGO,
INDIETRO, scoringEnter, scoringResume). Così un tocco ancora premuto su un
pulsante non "attraversa" nella schermata successiva anche se le aree si
sovrappongono. Il rilevatore di tap è passato da static locali a stato di modulo
per poter essere resettato dall'esterno.

### Verifica
Sintassi OK (g++ -fsyntax-only). Geometria della sovrapposizione confermata
numericamente (x[120..224] y[178..220]).

---

## BUG 2 (APP) — "nuovo file" mostrava la progressione dei tiri precedenti
**File:** `ArchBB_App_v1_23.html` (era v1.22)

### Causa
`csvNewFile()` resettava solo l'handle del file: `STATE.shots` (i colpi in RAM),
le code di scrittura e i contatori `g_csvWritten`/`g_csvFailed` restavano.
Aprendo un file nuovo, i burst vecchi erano ancora in memoria/coda e la
progressione precedente ricompariva. Anche `clearShots()` azzerava solo
`STATE.shots`, lasciando i contatori al valore vecchio.

### Fix
- Nuova `resetSession()`: azzera colpi, code (g_csvQueue, g_scoreWaitQueue,
  timer), e contatori di scrittura. Rinfresca la UI a vuoto (clearSessionUI()).
- `csvNewFile()`: crea prima il file nuovo; SOLO se l'utente conferma (non
  annulla il picker) chiama `resetSession()`. Se annulla, la sessione corrente
  resta intatta (ripristino di handle/header/nome).
- `clearShots()`: ora usa `resetSession()` (reset completo, contatori inclusi).

### Verifica
node --check sugli script estratti: nessun errore di sintassi.

### Nota
Il contatore shot_id nel CSV viene dal firmware (burst.shotId) e riparte da 1 a
ogni boot della scheda: è indipendente da questo fix, che riguarda lo stato di
sessione lato app.

---

## Da verificare sul campo
1. **Colpito**: valuta esito->zona->distanza->CONFERMA. Ora il RIEPILOGO deve
   comparire e RESTARE (come per il mancato), non sparire. OK cementa, CORREGGI
   riapre.
2. **Nuovo file**: config -> cancella sessione -> nuovo file. Il CSV nuovo deve
   partire pulito, senza i tiri precedenti. Il chip contatore riparte da 0.
3. Il log di taratura del riepilogo (dalla 2.12.1) è ancora attivo: quando tutto
   ok, lo rimuovo.
