// ============================================================================
//  ArchBB 1.83 — battery.cpp · FASE 5 (stato batteria via AXP2101)
//  Cesare Pagura · Padova/Noale IT · 20 luglio 2026
// ----------------------------------------------------------------------------
//  Vedi battery.h. Punto chiave: il PMU sta sul bus I2C GIA' ATTIVO, quindi
//  begin() riceve l'istanza Wire viva (NON facciamo Wire.begin()). Abilitiamo
//  le misure che ci servono (batteria connessa, tensione, tensione sistema) e
//  leggiamo valori gia' calcolati dal chip.
// ============================================================================
#include "battery.h"
#include "imu.h"        // i2cLock/i2cUnlock (mutex del bus I2C condiviso)
#include <Wire.h>

// IMPORTANTE (dettaglio scoperto leggendo XPowersLib.h): la libreria fa il
// typedef di XPowersPMU SOLO dentro un #if sul chip selezionato. Senza questa
// macro PRIMA dell'include si finisce nel ramo #else, che include tutte le
// classi ma NON definisce XPowersPMU -> errore "XPowersPMU non dichiarato".
// La 1.83 monta l'AXP2101: lo dichiariamo qui. (E' quel che fa l'esempio ufficiale.)
#define XPOWERS_CHIP_AXP2101
#include <XPowersLib.h>

volatile bool g_batt_ok = false;

// Oggetto PMU generico (come nell'esempio ufficiale AXP2101). L'istanza vive
// per tutta la vita del firmware: una sola, statica.
static XPowersPMU s_pmu;

bool battery_init() {
  if (g_batt_ok) return true;

  // begin() sul bus GIA' ATTIVO: passiamo Wire (avviato da touchInit) e i pin
  // solo per firma; XPowersLib non re-inizializza il bus se e' gia' vivo, ma
  // per sicurezza usiamo la stessa istanza Wire condivisa da touch/IMU.
  // AXP2101_SLAVE_ADDRESS e' l'indirizzo standard del PMU (0x34).
  if (!s_pmu.begin(Wire, AXP2101_SLAVE_ADDRESS, IMU_I2C_SDA, IMU_I2C_SCL)) {
    DBG("BATT: AXP2101 non risponde");
    g_batt_ok = false;
    return false;
  }

  // Abilita le misure che leggeremo. enableBattDetection fa sapere al chip di
  // stimare la percentuale; le *VoltageMeasure abilitano gli ADC interni.
  s_pmu.enableBattDetection();
  s_pmu.enableBattVoltageMeasure();
  s_pmu.enableSystemVoltageMeasure();

  // --- FASE 7: tasto PWRKEY come ingresso del modo BLE ----------------------
  //  Il PWRKEY del PMU e' il pulsante utente VERO della 1.83 (a differenza di
  //  GPIO0, che e' uno strapping pin e causava blocchi). Lo leggiamo via IRQ del
  //  PMU, in polling non-bloccante. Qui: puliamo eventuali flag pendenti e
  //  abilitiamo SOLO l'interrupt di pressione BREVE (short press). La pressione
  //  lunga resta al PMU per lo spegnimento hardware, che non tocchiamo.
  //  Tutto sotto il mutex del bus I2C (condiviso con IMU/touch/RTC).
  i2cLock();
  s_pmu.clearIrqStatus();                                 // parti da stato pulito
  s_pmu.enableIRQ(XPOWERS_AXP2101_PKEY_SHORT_IRQ);        // solo pressione breve
  s_pmu.clearIrqStatus();                                 // scarta flag spuri iniziali
  i2cUnlock();

  g_batt_ok = true;
  DBG("BATT: AXP2101 ok (%d%%, %.2fV, %s)",
      battery_percent(), battery_voltage(),
      battery_charging() ? "in carica" : "a batteria");
  return true;
}

int battery_percent() {
  if (!g_batt_ok) return -1;
  // Lettura I2C sotto il mutex del bus (chiamata dal loop, concorrente imu_task).
  // getBatteryPercent ritorna gia' -1 se la batteria non e' connessa.
  i2cLock();
  int p = s_pmu.getBatteryPercent();
  i2cUnlock();
  return p;
}

float battery_voltage() {
  if (!g_batt_ok) return NAN;
  i2cLock();
  uint16_t mv = s_pmu.getBattVoltage();   // millivolt
  i2cUnlock();
  if (mv == 0) return NAN;   // 0 = non misurabile
  return mv / 1000.0f;
}

bool battery_charging() {
  if (!g_batt_ok) return false;
  i2cLock();
  bool c = s_pmu.isCharging();
  i2cUnlock();
  return c;
}

// ----------------------------------------------------------------------------
//  FASE 7 — power_key_short_pressed(): pressione BREVE del tasto PWRKEY.
// ----------------------------------------------------------------------------
//  Polling non-bloccante, da chiamare nel loop. Ritorna true UNA volta per ogni
//  pressione breve del tasto power del PMU. Meccanismo AXP2101 (dal sorgente
//  XPowersLib): getIrqStatus() legge i registri di stato IRQ nella struttura
//  interna, poi isPekeyShortPressIrq() dice se c'e' stata una pressione breve;
//  clearIrqStatus() azzera i flag cosi' la prossima chiamata riparte pulita.
//
//  Perche' questo e non GPIO0: il PWRKEY e' il pulsante utente vero della
//  scheda, letto via I2C dal PMU. Non e' uno strapping pin, non ha i problemi
//  elettrici di GPIO0 che causavano i blocchi (fix2). Tutto sotto il mutex del
//  bus I2C (condiviso con IMU/touch/RTC).
bool power_key_short_pressed() {
  if (!g_batt_ok) return false;
  bool pressed = false;
  i2cLock();
  s_pmu.getIrqStatus();                    // popola statusRegister[] dal chip
  if (s_pmu.isPekeyShortPressIrq()) {
    pressed = true;
    s_pmu.clearIrqStatus();                // consuma l'evento (una volta sola)
  }
  i2cUnlock();
  return pressed;
}
