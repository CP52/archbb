# ArchBB 1.83 — FASE 22 · in ascolto, e il numero si legge

**22 agosto 2026** · `1.83-F22-ascolto` · CSV v5 invariato · config NVS invariata

Nasce dalla battuta del 22/08: quattro sedute per ~22 tiri, tre tiri scoccati e
non registrati, velocità annotate a mano e parzialmente perse.

---

## 1. Perché si perdevano i tiri — cause escluse una per una

Prima di cambiare qualcosa sono state misurate tutte le spiegazioni tecniche.

| causa | verifica | esito |
|---|---|---|
| ampiezza sotto soglia | lognormale troncata sui 18 picchi | coda ~2% → **esclusa** |
| campioni persi | `seq` continua su tutti i burst | 0 → **esclusa** |
| buchi di campionamento | max `dt` = 5482 µs, nessuno > 8 ms | 0 → **esclusa** |
| «2 campioni consecutivi» | minimo osservato 3 sopra soglia | mai violata |
| sessione chiusa | `sd_append_shot` fa **auto-start** | non perde nulla |

Il passo di campionamento è quello noto: 5000 µs il 58%, 4000 µs il 40%, media
4593 (217,7 Hz). Il battimento col tick FreeRTOS c'è ancora e **non fa danno**.

Resta una sola causa: **il dispositivo non era nella schermata di attesa.** Nei
menu, in BLE o nel dialogo RIPRENDI/NUOVA il trigger non è armato — e nessuna di
quelle schermate lo diceva.

Nota sul margine: il tiro più debole (picco 7,1 m/s²) sta sopra soglia per 3
campioni, e ne servono 2. Regge perché **larghezza e ampiezza dell'urto crescono
insieme** — il tiro da 7,1 dura 9 ms sopra soglia, quello da 39 ne dura 64. È il
filtro interno a ~12 Hz ad allargare l'urto. *Se un giorno quel filtro si apre
per vedere la banda 40–150 Hz, l'urto ridiventa stretto e la condizione dei due
campioni smette di funzionare: il trigger va ripensato insieme al filtro.*

---

## 2. Cosa cambia

### La fascia di stato

A tutta larghezza sotto la barra di sistema, leggibile da un metro senza mettere
a fuoco.

```
verde  «IN ASCOLTO»       schermata di attesa, trigger armato
grigio «NON IN ASCOLTO»   dialogo sessione, modo BLE
```

Una funzione sola (`drawFasciaAscolto`) per i due significati opposti: due
disegnatori separati sarebbero due occasioni di renderli simili per sbaglio.
`displayNonInAscolto()` è pubblica e va chiamata in cima a **qualunque**
schermata in cui il trigger non è armato.

Già applicata a: dialogo RIPRENDI/NUOVA (il candidato numero uno, perché si apre
proprio toccando lo schermo) e modo BLE.

### Il numero del prossimo tiro

Era font 2, una dozzina di pixel. Ora **font 8 (75 px)** fino a tre cifre, font 7
(48 px) da quattro in su — a font 8 la quarta cifra sborderebbe.

La soglia è sul **numero di cifre** e non su una larghezza misurata: `textWidth`
con i font a sette segmenti non è affidabile quanto contare i caratteri.

I font 6/7/8 di TFT_eSPI contengono **solo cifre**: la scritta «PROSSIMO TIRO» è
disegnata a parte con il font 2. È una regola già nota al progetto.

Il mirino decorativo al centro è stato tolto: occupava l'unico posto dove un
numero grande si legge davvero, per non dire nulla.

### Una collisione corretta

`displayTempoRiga` scriveva a y=244 e la riga fissa «In attesa dello SCOCCO» a
y=246: si sovrascrivevano a ogni giro del loop. Ora quella riga ha un solo
proprietario.

### La soglia del trigger

```c
static constexpr float TRIG_DEFAULT_THRESHOLD = 6.0f;   // era 4.0f
```

Il valore era **4,0 con accanto un commento che diceva 20,0** — due numeri in
contraddizione nella stessa riga, peggio di nessun commento perché al commento
ci si fida.

Il 6,0 viene dalla distribuzione dei picchi su 58 tiri di quattro sedute:

```
tiro vero più debole osservato     6,1 m/s²
falsi trigger (arco maneggiato)    4,7  e  6,8
coda stimata sotto 6,0             ~2%
```

Le due popolazioni **si sovrappongono**, quindi nessuna soglia le separa: va
scelto quale errore accettare. La scelta è asimmetrica — un falso trigger è un
record in più da scartare e `assetto_ok` lo marca già da solo, un tiro vero perso
non si recupera.

Il 20,0 veniva da una validazione di luglio; su queste sedute avrebbe perso tre
quarti dei tiri, perché l'urto ha mediana ~14 m/s² e non 40.

---

## 2bis. Il difetto della prima consegna: campo vuoto

La prima versione di questa fase mostrava il numero **vuoto**. Causa:

```
platformio.ini:  LOAD_GLCD, LOAD_FONT2, LOAD_FONT4, LOAD_FONT6, LOAD_FONT7
codice:          drawString(num, x, y, 8)
```

**TFT_eSPI compila solo i font dichiarati nei build_flags.** Chiedendo il font 8
senza `LOAD_FONT8` la libreria non ha i glifi, non disegna nulla, e non emette
errori — né a compilazione né a runtime.

Corretto in tre punti, perché uno solo non bastava:

1. `-D LOAD_FONT8=1` in `platformio.ini`.
2. Un `#if defined(LOAD_FONT8)` attorno alla scelta del font, con `#warning` e
   ripiego sul font 7: quella riga di `platformio.ini` è lontana da questa e
   prima o poi qualcuno la toglie per fare spazio.
3. Una sezione nuova nel banco: **«font usati nel codice ma non caricati»**.

Il banco aveva già una sezione sui font numerici, ma controllava i *caratteri*
dentro i font 6/7/8 (lettere e simboli, che quei font non hanno). Nessuno
controllava se il font **esistesse**. Cono d'ombra classico: lo strumento
guardava il problema vicino e non quello adiacente.

La prima stesura del controllo nuovo **è passata pur essendo rotta**: cercava
`LOAD_FONT8` senza distinguere le righe commentate, e rilevava solo i font usati
come letterale — mentre qui il font è scelto a runtime da una variabile. La prova
in negativo (commentare la riga e rilanciare) l'ha smascherata. Ora rileva sia i
letterali sia i riferimenti a `LOAD_FONTn` nel codice, e pretende che la riga sia
**attiva**.

*Un controllo nuovo va sempre provato in negativo: uno che non fallisce mai non
sta controllando niente.*

## 2ter. Il numero mostrato non era quello scritto

Chiudendo una sessione e aprendone una nuova, il display continuava da dove era
rimasto mentre il file ripartiva da 1. Causa: **due contatori diversi**.

```
g_shot_id     (trigger.cpp)     conta dall'ACCENSIONE, azzerato solo al boot
s_shotCount   (sd_storage.cpp)  conta nella SESSIONE, azzerato ad ogni nuova
                                e riletto dal CSV se si riprende
```

Il CSV, il nome del file burst e l'intestazione del burst usano tutti
`s_shotCount + 1`. Il display usava `g_shot_id + 1`.

Il difetto era peggiore di una svista estetica: rendeva inutile proprio ciò per
cui il numero era stato ingrandito — annotarlo accanto alla velocità per
allineare i due elenchi. Con numerazioni divergenti l'allineamento sarebbe stato
peggio di prima.

Ora un solo punto lo calcola (`prossimoTiro()` in `main.cpp`) e lo usano
schermata d'attesa, lampo del trigger e titolo dello scoring. Senza sessione
aperta ritorna 1, perché `sd_append_shot` fa auto-start e creerà una sessione
vergine.

| scenario | display | CSV |
|---|---|---|
| avvio, nessuna sessione | 1 | 1 |
| sessione aperta, 5 tiri | 6 | 6 |
| appena chiusa la sessione da 5 | 1 | 1 |
| RIPRENDI su seduta da 12 | 13 | 13 |

## 3. Verifiche

```
sh tools/sintassi/controlla.sh    tutti i file ok, sezione font nuova
sh tools/tempo/prova.sh            invariato
```

Il controllo dei font provato in **entrambe le direzioni**: con `LOAD_FONT8`
attivo dice «nessuno», commentandolo segnala «font 8 usato (3 riferimenti) ma
LOAD_FONT8 non attivo».

Geometria della nuova schermata, verificata numericamente su 240×284:

```
barra di sistema     0..20
fascia stato        22..48
orologio               60
«PROSSIMO TIRO»        96
numero (font 8)    110..186
IMU + temperatura     200
riga tempi         235..252
suggerimento          276
sovrapposizioni: nessuna
```

Larghezza del numero: 55 px per cifra a font 8 (3 cifre = 165 su 240), 32 px a
font 7 (4 cifre = 128). Sta dentro in tutti i casi.

**Non verificato**: nulla di tutto questo è passato dal display reale.

---

## 4. Cosa NON c'è, e perché

**Il beep.** Il codec ES8311 e l'amplificatore NS4150B sono a bordo e
`power_enable_codec_rail()` accende già il rail ALDO1, ma **il driver audio non
esiste**: servono l'inizializzazione I2C del codec, il canale I2S in uscita e la
generazione del tono. E soprattutto non è verificabile senza hardware — che il
suono esca si scopre al primo caricamento.

Le due modifiche visive di questa fase sono certe e risolvono il problema
misurato. Il beep va fatto dopo, con un banco di prova dedicato: un tono
all'avvio, per sentire se la catena funziona, prima di legarlo agli eventi.

---

## 5. Regola di metodo aggiunta

**Uno stato che il dispositivo conosce e non mostra è uno stato che l'utente
sbaglierà.** Il trigger sapeva perfettamente di non essere armato; nessuna
schermata lo diceva, e tre tiri sono andati persi senza che nessuno potesse
accorgersene fino alla lettura del CSV, giorni dopo. Nessuna delle cause cercate
era un difetto della catena di misura: erano tutte lì, in un'informazione
disponibile e non mostrata.
