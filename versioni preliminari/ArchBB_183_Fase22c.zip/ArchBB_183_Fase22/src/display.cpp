// ============================================================================
//  ArchBB 1.83 — display.cpp · FASE 1 (bring-up ST7789V2) · v2
//  Cesare Pagura · Padova/Noale IT · 11 luglio 2026
// ----------------------------------------------------------------------------
//  CORREZIONE v2 — la banda bianca in alto ("i dati comandano"):
//  In v1 applicavo l'offset y=20 con setViewport(0,20,240,284). ERRORE:
//  setViewport NON sposta l'indirizzamento della GRAM del controller, ritaglia
//  solo l'area di disegno SOFTWARE dentro un frame gia' mappato. Cosi' facendo
//  sommavo un secondo offset a quello che TFT_eSPI applica gia' via CGRAM_OFFSET
//  + setRotation, e la fascia 0..20 restava SCOPERTA -> GRAM non inizializzata
//  visibile = i ~20 pixel bianchi che vedevi in cima.
//
//  Fix corretto: RIMOSSO setViewport. L'offset di pannello e' responsabilita'
//  del driver (CGRAM_OFFSET nel .ini + dimensioni 240x284). La doc TFT_eSPI:
//  "gli offset sono determinati in setRotation e applicati a ogni operazione
//  grafica" e "puo' servire chiamare setRotation DOPO init() perche' si
//  applichino". Quindi: init() -> setRotation() -> fillScreen(), e basta.
//  Le coordinate (0,0) del disegno corrispondono al primo pixel visibile:
//  l'offset e' gestito dentro la libreria, trasparente al resto del codice.
// ============================================================================
#include "display.h"
#include "scoring.h"       // v2.16: elevIsSet/ELEV_NOT_SET per il riepilogo
#include "shot_angles.h"   // FASE 4c: nomi classi hold/release, shot_angle_to_cdeg
#include "mount.h"         // FASE 4c: mount_apply per il DIAG a 4 montaggi
#include <math.h>

// Istanza display condivisa (dichiarata extern in display.h). Scoring e altri
// moduli disegnano su questa stessa istanza.
TFT_eSPI tft = TFT_eSPI();

// ----------------------------------------------------------------------------
//  Backlight su GPIO diretto (TFT_BL=40).
// ----------------------------------------------------------------------------
void displayBacklight(bool on) {
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, on ? HIGH : LOW);   // active-high (da verificare su HW)
}

// ----------------------------------------------------------------------------
//  Inizializzazione completa.
// ----------------------------------------------------------------------------
void displayInit() {
  // 1) Backlight PRIMA dell'init.
  displayBacklight(true);

  // 2) Init libreria: reset HW (TFT_RST=38), sequenza ST7789, applica
  //    TFT_INVERSION_ON e TFT_RGB_ORDER=TFT_BGR dai -D.
  tft.init();

  // 3) setRotation DOPO init: e' QUI che TFT_eSPI applica l'offset CGRAM.
  //    Con CGRAM_OFFSET + TFT_HEIGHT=284, la libreria mappa la coordinata
  //    software (0,0) sulla riga fisica corretta. Nessun setViewport.
  tft.setRotation(0);   // portrait nativo 240x284

  // 4) Pulizia a nero SU TUTTA l'area: ora copre anche l'ex-fascia bianca.
  tft.fillScreen(ArchColor::BG);
}

// ----------------------------------------------------------------------------
//  displaySplash — "ciao mondo" ArchBB.
// ----------------------------------------------------------------------------
void displaySplash() {
  tft.fillScreen(ArchColor::BG);

  // Cornice: se l'offset e' giusto, il bordo superiore e' visibile e attaccato
  // al bordo del vetro, SENZA banda bianca sopra.
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);
  tft.drawRect(2, 2, ARCHBB_W - 4, ARCHBB_H - 4, ArchColor::ACCENT);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ArchBB", ARCHBB_W / 2, 70, 4);

  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString("1.83  Fase 1", ARCHBB_W / 2, 110, 2);

  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("bring-up display", ARCHBB_W / 2, 140, 2);
  tft.drawString("ST7789V2  240x284", ARCHBB_W / 2, 160, 2);

  const int cx = ARCHBB_W / 2, cy = 215;
  tft.drawCircle(cx, cy, 34, ArchColor::TEXT3);
  tft.drawCircle(cx, cy, 22, ArchColor::TEXT2);
  tft.fillCircle(cx, cy, 8,  ArchColor::BAD);   // "10" centrale, ora rosso vero
  tft.drawFastHLine(cx - 44, cy, 88, ArchColor::BORDER);
  tft.drawFastVLine(cx, cy - 44, 88, ArchColor::BORDER);
}

// ----------------------------------------------------------------------------
//  displayOffsetTest — verifica CHIRURGICA dell'offset verticale.
// ----------------------------------------------------------------------------
//  Riempie di nero, poi disegna:
//   - una riga BIANCA spessa 3px ESATTAMENTE sulla prima riga (y=0..2)
//   - una riga BIANCA spessa 3px ESATTAMENTE sull'ultima riga (y=281..283)
//  Se l'offset e' perfetto: vedi entrambe le righe attaccate ai bordi vetro,
//  niente bianco extra sopra, niente taglio sotto. Se resta bianco sopra la
//  riga alta -> offset ancora sbagliato. Se la riga bassa e' tagliata ->
//  altezza < 284. E' il test che isola il SOLO problema geometrico.
// ----------------------------------------------------------------------------
void displayOffsetTest() {
  tft.fillScreen(ArchColor::BG);
  tft.fillRect(0, 0,            ARCHBB_W, 3, ArchColor::TEXT);   // top
  tft.fillRect(0, ARCHBB_H - 3, ARCHBB_W, 3, ArchColor::TEXT);   // bottom
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("OFFSET TEST", ARCHBB_W / 2, ARCHBB_H / 2 - 10, 4);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("righe bianche = bordi", ARCHBB_W / 2, ARCHBB_H / 2 + 20, 2);
  tft.drawString("niente bianco extra?", ARCHBB_W / 2, ARCHBB_H / 2 + 38, 2);
}

// ----------------------------------------------------------------------------
//  displayDiagnosticPattern — verifica a occhio i 6 rischi §6.
// ----------------------------------------------------------------------------
void displayDiagnosticPattern() {
  tft.fillScreen(ArchColor::BG);

  const int barH = 40, barY = 30;
  tft.fillRect(10,  barY, 60, barH, TFT_RED);
  tft.fillRect(90,  barY, 60, barH, TFT_GREEN);
  tft.fillRect(170, barY, 60, barH, TFT_BLUE);

  tft.setTextDatum(TC_DATUM);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString("R",  40,  barY + barH + 4, 2);
  tft.drawString("G", 120,  barY + barH + 4, 2);
  tft.drawString("B", 200,  barY + barH + 4, 2);

  tft.drawFastHLine(0, 0,            ARCHBB_W, TFT_YELLOW);      // top
  tft.drawFastHLine(0, ARCHBB_H - 1, ARCHBB_W, TFT_MAGENTA);    // bottom
  tft.drawFastVLine(0, 0,            ARCHBB_H, TFT_CYAN);        // left
  tft.drawFastVLine(ARCHBB_W - 1, 0, ARCHBB_H, TFT_ORANGE);     // right

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString("DIAGNOSTICA S6", ARCHBB_W / 2, 130, 2);

  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("giallo=top magenta=bot", ARCHBB_W / 2, 155, 2);
  tft.drawString("ciano=sx arancio=dx",    ARCHBB_W / 2, 172, 2);
  tft.drawString("sfondo NERO, R-G-B ok?", ARCHBB_W / 2, 189, 2);

  for (int i = 0; i < 30; i++) {
    uint8_t v = map(i, 0, 29, 0, 255);
    tft.drawFastHLine(20, 210 + i, ARCHBB_W - 40, tft.color565(v, v, v));
  }
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("gradiente: liscio?", ARCHBB_W / 2, 255, 2);
}

// ----------------------------------------------------------------------------
//  displayEsito — banco di prova scoring.
// ----------------------------------------------------------------------------
void displayEsito(bool good) {
  const uint16_t bg  = good ? ArchColor::GOOD : ArchColor::BAD;
  const char*    txt = good ? "CENTRO" : "FUORI";
  const char*    sub = good ? "colpo valido" : "fuori bersaglio";

  tft.fillScreen(bg);
  tft.fillRect(0, 0, ARCHBB_W, 40, ArchColor::BG);
  tft.fillRect(0, ARCHBB_H - 40, ARCHBB_W, 40, ArchColor::BG);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ESITO TIRO", ARCHBB_W / 2, 20, 2);

  tft.setTextColor(ArchColor::TEXT, bg);
  tft.drawString(txt, ARCHBB_W / 2, ARCHBB_H / 2 - 10, 4);   // font 4: testo

  tft.setTextColor(ArchColor::TEXT, bg);
  tft.drawString(sub, ARCHBB_W / 2, ARCHBB_H / 2 + 35, 2);

  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("ArchBB 1.83", ARCHBB_W / 2, ARCHBB_H - 20, 2);
}

// ============================================================================
//  FASE 2 — banco di prova touch (rendering)
// ============================================================================

// Zone di layout del banco di prova (coordinate fisse).
static constexpr int TT_TITLE_Y = 16;
static constexpr int TT_DATA_Y  = 55;    // inizio blocco dati testuali
static constexpr int TT_ROW_H   = 26;    // passo verticale righe dati
static constexpr int TT_AREA_Y0 = 165;   // inizio area "touchpad" visiva
static constexpr int TT_AREA_Y1 = ARCHBB_H - 8;

// Memoria dell'ultimo crocino per cancellarlo senza ridisegnare tutto.
static int  s_lastCrossX = -1, s_lastCrossY = -1;

// Disegna la cornice fissa (chiamata una volta).
void displayTouchTestFrame() {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("TOUCH CST816", ARCHBB_W / 2, TT_TITLE_Y, 4);

  // Etichette statiche a sinistra; i valori li aggiorna displayTouchUpdate.
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("X:",   12, TT_DATA_Y + TT_ROW_H * 0, 4);
  tft.drawString("Y:",   12, TT_DATA_Y + TT_ROW_H * 1, 4);
  tft.drawString("dita:", 12, TT_DATA_Y + TT_ROW_H * 2, 2);
  tft.drawString("gest:", 12, TT_DATA_Y + TT_ROW_H * 3, 2);

  // Riquadro dell'area "touchpad" visiva dove appare il crocino.
  tft.drawRect(6, TT_AREA_Y0, ARCHBB_W - 12, TT_AREA_Y1 - TT_AREA_Y0,
               ArchColor::BORDER);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("tocca qui", ARCHBB_W / 2, (TT_AREA_Y0 + TT_AREA_Y1) / 2, 2);

  s_lastCrossX = s_lastCrossY = -1;
}

// Disegna un crocino (mirino ArchBB in miniatura) alla posizione data.
static void drawCross(int x, int y, uint16_t color) {
  tft.drawFastHLine(x - 8, y, 17, color);
  tft.drawFastVLine(x, y - 8, 17, color);
  tft.drawCircle(x, y, 5, color);
}

// Aggiorna i valori numerici e il crocino.
void displayTouchUpdate(bool touched, uint16_t x, uint16_t y,
                        uint8_t fingers, const char* gestureName, uint8_t rawGid) {
  // --- Blocco valori testuali: riscrivo con sfondo per cancellare i vecchi ---
  char line[24];
  tft.setTextDatum(ML_DATUM);

  // X
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  snprintf(line, sizeof(line), "%-4u", touched ? x : 0);
  tft.fillRect(70, TT_DATA_Y - 14 + TT_ROW_H * 0, 120, 24, ArchColor::BG);
  tft.drawString(line, 70, TT_DATA_Y + TT_ROW_H * 0, 4);

  // Y
  snprintf(line, sizeof(line), "%-4u", touched ? y : 0);
  tft.fillRect(70, TT_DATA_Y - 14 + TT_ROW_H * 1, 120, 24, ArchColor::BG);
  tft.drawString(line, 70, TT_DATA_Y + TT_ROW_H * 1, 4);

  // dita
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
  snprintf(line, sizeof(line), "%u  ", fingers);
  tft.fillRect(80, TT_DATA_Y - 8 + TT_ROW_H * 2, 100, 18, ArchColor::BG);
  tft.drawString(line, 80, TT_DATA_Y + TT_ROW_H * 2, 2);

  // gesture (nome + id grezzo per diagnostica)
  snprintf(line, sizeof(line), "%s (0x%02X)", gestureName, rawGid);
  tft.fillRect(80, TT_DATA_Y - 8 + TT_ROW_H * 3, 150, 18, ArchColor::BG);
  tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
  tft.drawString(line, 80, TT_DATA_Y + TT_ROW_H * 3, 2);

  // --- Crocino nell'area touchpad ------------------------------------------
  // Cancella il vecchio crocino (ridisegnandolo col colore di sfondo).
  if (s_lastCrossX >= 0) {
    drawCross(s_lastCrossX, s_lastCrossY, ArchColor::BG);
    // Ripristina il bordo dell'area se il crocino lo aveva sfiorato: semplice
    // ridisegno del rettangolo (poco costoso a questa cadenza).
    tft.drawRect(6, TT_AREA_Y0, ARCHBB_W - 12, TT_AREA_Y1 - TT_AREA_Y0,
                 ArchColor::BORDER);
  }

  if (touched) {
    // Clampo dentro l'area visiva del touchpad per il disegno del crocino.
    int cx = constrain((int)x, 12, ARCHBB_W - 12);
    int cy = constrain((int)y, TT_AREA_Y0 + 8, TT_AREA_Y1 - 8);
    drawCross(cx, cy, ArchColor::GOOD);
    s_lastCrossX = cx;
    s_lastCrossY = cy;
  } else {
    s_lastCrossX = s_lastCrossY = -1;
  }
}

// ============================================================================
//  FASE 3 — schermate di supporto allo scoring
// ============================================================================

void displayAttesaTiro(uint16_t nextShotId) {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ArchBB", ARCHBB_W/2, 40, 4);

  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("scoring on-device", ARCHBB_W/2, 68, 2);

  // Mirino centrale.
  const int cx = ARCHBB_W/2, cy = 150;
  tft.drawCircle(cx, cy, 40, ArchColor::TEXT3);
  tft.drawCircle(cx, cy, 26, ArchColor::TEXT2);
  tft.fillCircle(cx, cy, 10, ArchColor::BAD);
  tft.drawFastHLine(cx - 52, cy, 104, ArchColor::BORDER);
  tft.drawFastVLine(cx, cy - 52, 104, ArchColor::BORDER);

  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  char t[24]; snprintf(t, sizeof(t), "prossimo: tiro #%u", nextShotId);
  tft.drawString(t, ARCHBB_W/2, 220, 2);

  tft.setTextDatum(BC_DATUM);
  tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
  tft.drawString("TOCCA per registrare un tiro", ARCHBB_W/2, ARCHBB_H - 10, 2);
}

// ----------------------------------------------------------------------------
//  Helper interni al riepilogo 4c
// ----------------------------------------------------------------------------
//  Colore di una classe hold: verde=tenuto, ambra=lieve, rosso=abbassato/alzato.
static uint16_t holdColor(uint8_t c) {
  switch (c) {
    case HOLD_TENUTO:                   return ArchColor::GOOD;
    case HOLD_LIEVE:                    return ArchColor::AMBER;
    case HOLD_ABBASSATO: case HOLD_ALZATO: return ArchColor::BAD;
    default:                            return ArchColor::TEXT3;
  }
}
//  Colore di una classe release: verde=pulito, ambra=medio, rosso=strappo.
static uint16_t releaseColor(uint8_t c) {
  switch (c) {
    case RELEASE_PULITO:  return ArchColor::GOOD;
    case RELEASE_MEDIO:   return ArchColor::AMBER;
    case RELEASE_STRAPPO: return ArchColor::BAD;
    default:              return ArchColor::TEXT3;
  }
}

// ----------------------------------------------------------------------------
//  Layout del riepilogo 4c — costanti condivise da display E hit-test.
// ----------------------------------------------------------------------------
//  Stessa lezione delle costanti duplicate (§4.1 compendio): disegno e hit-test
//  DEVONO leggere le stesse Y, o prima o poi un tocco cade fuori dal pulsante
//  che vede a schermo. Le metto qui, un solo posto.
// Geometria del riepilogo (F13). Un solo posto: disegno e hit-test leggono
// queste, mai numeri scritti a mano (§4.1).
static constexpr int RIEP_ESITO_H  = 56;    // fascia COLPITO/MANCATO, font 6
static constexpr int RIEP_BTN_MARG = 8;     // distanza dai bordi laterali
static constexpr int RIEP_BTN_W    = 92;    // larghezza dei due pulsanti
static constexpr int RIEP_BTN_H    = 58;    // altezza
static constexpr int RIEP_BTN_Y    = ARCHBB_H - RIEP_BTN_H - 10;

void displayScoreRiepilogo(const ScoreResult& r, const char* zonaTxt) {
  const bool valutato = r.valutato;
  const bool colpito  = r.colpito;

  tft.fillScreen(ArchColor::BG);

  // --- FASCIA ESITO: grande, si legge al volo -------------------------------
  //  Prima era 40 px con font 4; ora 56 px con font 6. Il riepilogo si guarda
  //  con l'arco in mano e il sole in faccia: qui la leggibilita' conta piu'
  //  della densita' di informazione.
  uint16_t topColor = !valutato ? ArchColor::BORDER
                     : (colpito ? ArchColor::GOOD : ArchColor::BAD);
  tft.fillRect(0, 0, ARCHBB_W, RIEP_ESITO_H, topColor);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT, topColor);
  const char* esito = !valutato ? "NON VALUT." : (colpito ? "COLPITO" : "MANCATO");
  // FONT 4, non 6. Il 6 di TFT_eSPI e' SOLO NUMERICO (cifre, punto, due punti,
  // meno e poche lettere per l'AM/PM): scriverci "COLPITO" non da' errore, fa
  // sparire i caratteri. E' lo stesso inciampo del "+" sugli slider.
  //  Il font 4 e' alfanumerico completo. Per compensare l'altezza minore, la
  //  fascia resta da 56 px e il testo e' centrato: si legge lo stesso, perche'
  //  a distanza di braccio conta il contrasto della fascia colorata piu' della
  //  dimensione del carattere.
  tft.drawString(esito, ARCHBB_W/2, RIEP_ESITO_H/2, 4);

  // --- DUE SEMAFORI: tenuta e rilascio --------------------------------------
  //  Il colore E' l'informazione; il numero e' il dettaglio per chi lo vuole.
  //  Un quadrato verde si legge in un decimo di secondo, "-2.81 deg" no.
  //  Le soglie sono quelle del firmware (HoldClass/ReleaseClass): il display
  //  non ne inventa di proprie, altrimenti il colore e la classe salvata nel
  //  CSV potrebbero dire cose diverse (§4.1).
  const int qy = RIEP_ESITO_H + 10;
  const int qs = 46;                        // lato del quadrato
  const int col1 = 18, col2 = ARCHBB_W/2 + 6;

  auto semaforo = [&](int x, const char* etichetta, bool valido, uint8_t classe,
                      const char* valore) {
    uint16_t c = ArchColor::BORDER;
    if (valido) {
      // verde = buono, giallo = intermedio, rosso = da correggere.
      c = (classe == 0) ? ArchColor::GOOD
        : (classe == 1) ? ArchColor::AMBER
                        : ArchColor::BAD;
    }
    tft.fillRoundRect(x, qy, qs, qs, 8, c);
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString(etichetta, x + qs + 8, qy + 4, 2);
    tft.setTextColor(valido ? ArchColor::TEXT : ArchColor::TEXT3, ArchColor::BG);
    tft.drawString(valore, x + qs + 8, qy + 26, 2);
  };

  char hv[12], rv[12];
  if (r.hold_valid) snprintf(hv, sizeof(hv), "%+.1f", r.hold_cdeg / 100.0f);
  else              snprintf(hv, sizeof(hv), "n/d");
  if (r.release_valid) snprintf(rv, sizeof(rv), "%u", r.release_jerk);
  else                 snprintf(rv, sizeof(rv), "n/d");

  semaforo(col1, "TENUTA",   r.hold_valid,    r.hold_class,    hv);
  semaforo(col2, "RILASCIO", r.release_valid, r.release_class, rv);

  // --- DISTANZA ed ELEVAZIONE, grandi -------------------------------------
  //  Sono i due numeri che l'arciere ha appena inserito e che vuole
  //  ricontrollare prima di confermare: font 4, non 2.
  const int dy = qy + qs + 14;
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("DIST", col1, dy, 1);
  tft.drawString("ELEV", col2, dy, 1);

  char dd[10], ee[10];
  if (r.distanza_m == 0) snprintf(dd, sizeof(dd), "--");
  else                   snprintf(dd, sizeof(dd), "%um", r.distanza_m);
  if (!elevIsSet(r.elev_deg)) snprintf(ee, sizeof(ee), "n/i");
  else                        snprintf(ee, sizeof(ee), "%+d", (int)r.elev_deg);

  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString(dd, col1, dy + 12, 4);
  tft.setTextColor(elevIsSet(r.elev_deg) && r.elev_deg != 0
                   ? ArchColor::AMBER : ArchColor::TEXT, ArchColor::BG);
  tft.drawString(ee, col2, dy + 12, 4);

  // --- F21: PICCO D'URTO ----------------------------------------------------
  //  Sta qui, sotto distanza ed elevazione e sopra i pulsanti, nella fascia che
  //  era vuota. NIENTE COLORE, a differenza dei due semafori sopra: un verde o
  //  un rosso direbbero che si sa quale picco e' buono, e non si sa. E' un
  //  numero da guardare crescere nel corso della seduta, non un giudizio.
  //
  //  L'unita' e' scritta per esteso proprio perche' il numero NON e' un
  //  punteggio: 31,5 senza unita' sembrerebbe un voto su 100.
  {
    const int py = RIEP_BTN_Y - 48;
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("URTO", col1, py, 1);
    if (r.picco_valid) {
      char pv[12];
      snprintf(pv, sizeof(pv), "%.1f", r.picco_cms2 / 100.0f);
      tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
      // drawString ritorna la larghezza disegnata: l'unita' si aggancia al
      // numero invece che a una x scritta a mano, cosi' resta attaccata anche
      // quando il valore passa da una a tre cifre (§4.1 applicata al testo).
      int w = tft.drawString(pv, col1, py + 10, 4);
      tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
      tft.drawString("m/s2", col1 + w + 6, py + 20, 2);
    } else {
      tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
      tft.drawString("n/d", col1, py + 10, 4);
    }
  }

  // F21b — ARCS TOLTO DAL RIEPILOGO.
  //  Era scritto in font 1 in un angolo, e non serviva a nessuno: e' una
  //  CODIFICA, non una misura. Distanza e zona sono gia' a schermo, grandi, e
  //  l'ARCS non e' altro che le due rimesse in un numero solo. Il valore resta
  //  in ScoreResult e nel CSV, dove serve alla compatibilita' coi dati 1.69:
  //  toglierlo dallo schermo non toglie niente al dato.
  //  Resta la ZONA, che invece e' leggibile ("SPOT", "alto-dx") ed e' la
  //  conferma di quello che si e' appena inserito.
  if (valutato) {
    tft.setTextDatum(TR_DATUM);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString(zonaTxt, ARCHBB_W - 10, dy + 2, 1);
  }

  // --- PULSANTI VERTICALI, contro i bordi ----------------------------------
  //  Prima erano due barre orizzontali sovrapposte al centro. Verticali e ai
  //  lati si premono col pollice senza spostare la presa e senza coprire il
  //  contenuto: la mano entra dal bordo, non dal mezzo dello schermo.
  tft.fillRoundRect(RIEP_BTN_MARG, RIEP_BTN_Y, RIEP_BTN_W, RIEP_BTN_H, 8,
                    ArchColor::BG_CARD);
  tft.drawRoundRect(RIEP_BTN_MARG, RIEP_BTN_Y, RIEP_BTN_W, RIEP_BTN_H, 8,
                    ArchColor::BORDER);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG_CARD);
  tft.drawString("CORREGGI", RIEP_BTN_MARG + RIEP_BTN_W/2,
                 RIEP_BTN_Y + RIEP_BTN_H/2, 2);

  const int okx = ARCHBB_W - RIEP_BTN_MARG - RIEP_BTN_W;
  tft.fillRoundRect(okx, RIEP_BTN_Y, RIEP_BTN_W, RIEP_BTN_H, 8, ArchColor::ACCENT);
  tft.setTextColor(ArchColor::BG, ArchColor::ACCENT);
  tft.drawString("OK", okx + RIEP_BTN_W/2, RIEP_BTN_Y + RIEP_BTN_H/2, 4);
}

// Zone toccabili del riepilogo: 1=CORREGGI (sinistra), 2=OK (destra), 0=altro.
//  Usa LE STESSE costanti del disegno. La regola §4.1 nasce proprio qui: nella
//  1.69 i numeri di posizione duplicati fra disegno e hit-test hanno prodotto
//  pulsanti che si vedevano in un posto e rispondevano in un altro.
uint8_t hitRiepilogo(uint16_t x, uint16_t y) {
  if (y < RIEP_BTN_Y || y >= RIEP_BTN_Y + RIEP_BTN_H) return 0;
  if (x >= RIEP_BTN_MARG && x < RIEP_BTN_MARG + RIEP_BTN_W) return 1;
  const int okx = ARCHBB_W - RIEP_BTN_MARG - RIEP_BTN_W;
  if (x >= okx && x < okx + RIEP_BTN_W) return 2;
  return 0;
}

// ============================================================================
//  FASE 4a — attesa del TIRO REALE (IMU armata)
// ============================================================================
void displayAttesaTiroIMU(uint16_t nextShotId, float tempC) {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ArchBB", ARCHBB_W/2, 38, 4);

  // Riga di stato IMU: pallino verde pulsante "ARMATO" + temperatura on-chip.
  // La temperatura e' un check vitale a colpo d'occhio: se e' un valore
  // plausibile (~20-40 C) l'IMU sta rispondendo davvero, non e' un placeholder.
  const int badgeY = 66;
  tft.fillCircle(ARCHBB_W/2 - 58, badgeY, 6, ArchColor::GOOD);
  tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
  tft.setTextDatum(ML_DATUM);
  tft.drawString("IMU ARMATA", ARCHBB_W/2 - 46, badgeY, 2);
  if (!isnan(tempC)) {
    char tt[16]; snprintf(tt, sizeof(tt), "%.0f\xB0""C", tempC);  // \xB0 = grado
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.setTextDatum(MR_DATUM);
    tft.drawString(tt, ARCHBB_W - 16, badgeY, 2);
  }

  // Mirino centrale (identico all'attesa Fase 3, per continuita' visiva).
  const int cx = ARCHBB_W/2, cy = 150;
  tft.drawCircle(cx, cy, 40, ArchColor::TEXT3);
  tft.drawCircle(cx, cy, 26, ArchColor::TEXT2);
  tft.fillCircle(cx, cy, 10, ArchColor::BAD);
  tft.drawFastHLine(cx - 52, cy, 104, ArchColor::BORDER);
  tft.drawFastVLine(cx, cy - 52, 104, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  char t[24]; snprintf(t, sizeof(t), "prossimo: tiro #%u", nextShotId);
  tft.drawString(t, ARCHBB_W/2, 218, 2);

  // F20: la riga viene disegnata dalla macchina dei tempi. Il forza=true la
  // obbliga a ridisegnare anche se il testo non e' cambiato: lo schermo e'
  // appena stato ripulito e la sua cache non lo sa.
  displayTempoRiga(0, 0, true);

  // Il tocco resta come trigger manuale a banco: lo si dice in piccolo, non e'
  // piu' l'azione primaria (ora e' la freccia a comandare).
  tft.setTextDatum(BC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("(tocca = tiro manuale)", ARCHBB_W/2, ARCHBB_H - 10, 2);
}

// ----------------------------------------------------------------------------
//  FASE 20 — riga di stato dal vivo (vedi display.h)
// ----------------------------------------------------------------------------
//  La quota e l'altezza della fascia sono costanti condivise fra il disegno
//  completo della schermata e il ridisegno parziale. Se fossero due numeri
//  distinti, il ridisegno parziale cancellerebbe una fascia diversa da quella
//  che scrive — ed e' il tipo di errore che si vede solo come una riga di
//  pixel sporchi che nessuno riesce a spiegare (§4.1).
static constexpr int16_t TEMPO_RIGA_Y = 244;
static constexpr int16_t TEMPO_RIGA_H = 17;

void displayTempoRiga(uint8_t stato, uint32_t msNelloStato, bool forza) {
  char testo[28];
  uint16_t colore;
  switch (stato) {
    case 1:   // TEMPO_MOTO
      snprintf(testo, sizeof(testo), "arco in movimento");
      colore = ArchColor::ACCENT; break;
    case 2:   // TEMPO_ANCORA
      snprintf(testo, sizeof(testo), "in mira  %lu.%lu s",
               (unsigned long)(msNelloStato / 1000),
               (unsigned long)((msNelloStato % 1000) / 100));
      colore = ArchColor::GOOD; break;
    default:  // TEMPO_RIPOSO
      snprintf(testo, sizeof(testo), "In attesa dello SCOCCO");
      colore = ArchColor::AMBER; break;
  }

  // Cache: senza, questa funzione ridisegnerebbe cinquanta volte al secondo e
  // la riga sfarfallerebbe. Con la cache ridisegna solo ai cambi di stato e a
  // ogni decimo di secondo mentre il cronometro corre.
  static char ultimo[28] = "";
  if (!forza && strncmp(ultimo, testo, sizeof(ultimo)) == 0) return;
  strncpy(ultimo, testo, sizeof(ultimo) - 1); ultimo[sizeof(ultimo)-1] = '\0';

  tft.fillRect(0, TEMPO_RIGA_Y - TEMPO_RIGA_H/2, ARCHBB_W, TEMPO_RIGA_H,
               ArchColor::BG);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(colore, ArchColor::BG);
  tft.drawString(testo, ARCHBB_W/2, TEMPO_RIGA_Y, 2);
}

// ----------------------------------------------------------------------------
//  FASE 5 — displayStatusBar: batteria (sx) + sessione (centro) + SD (dx)
// ----------------------------------------------------------------------------
//  Estetica: una fascia scura in cima, tre gruppi ben distanziati, icona
//  batteria DISEGNATA (non testuale) col livello colorato per soglia — verde
//  sopra 40%, ambra 15..40%, rosso sotto. Il badge sessione e' un pallino REC
//  rosso pulsante quando aperta, un cerchietto vuoto quando chiusa. Lo spazio SD
//  a destra. Tutto in font 1/2 per non rubare spazio al mirino sottostante.
void displayStatusBar(const StatusInfo& st) {
  const int barH = 20;
  // Sfondo fascia + linea di separazione sotto.
  tft.fillRect(0, 0, ARCHBB_W, barH, ArchColor::BG_CARD);
  tft.drawFastHLine(0, barH, ARCHBB_W, ArchColor::BORDER);

  // --- BATTERIA (sinistra) --------------------------------------------------
  //  Icona: corpo 22x11 + polo +. Riempimento proporzionale, colore per soglia.
  const int bx = 6, by = 5, bw = 22, bh = 11;
  tft.drawRect(bx, by, bw, bh, ArchColor::TEXT2);               // corpo
  tft.fillRect(bx + bw, by + 3, 2, bh - 6, ArchColor::TEXT2);   // polo +
  if (st.battPct >= 0) {
    int lvl = (st.battPct * (bw - 2)) / 100;                    // px di riempimento
    uint16_t col = (st.battPct > 40) ? ArchColor::GOOD
                 : (st.battPct > 15) ? ArchColor::AMBER
                                     : ArchColor::BAD;
    if (lvl > 0) tft.fillRect(bx + 1, by + 1, lvl, bh - 2, col);
    // Percentuale accanto all'icona.
    char pb[10]; snprintf(pb, sizeof(pb), "%d%%", st.battPct);
    tft.setTextDatum(ML_DATUM);
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG_CARD);
    tft.drawString(pb, bx + bw + 6, by + bh/2, 2);
    // Spina "in carica" (piccola freccia ambra) se sotto carica.
    if (st.battCharging) {
      tft.setTextColor(ArchColor::AMBER, ArchColor::BG_CARD);
      tft.drawString("\x18", bx + bw + 34, by + bh/2, 1);       // 0x18 = up-arrow
    }
  } else {
    tft.setTextDatum(ML_DATUM);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
    tft.drawString("n/d", bx + bw + 6, by + bh/2, 2);
  }

  // --- SESSIONE (centro) ----------------------------------------------------
  //  REC ● rosso + conteggio tiri se aperta; ○ "no sess" grigio se chiusa.
  //  FASE 6b: non mostriamo piu' "S%03u" (il numero interno e' slegato dal nome
  //  cartella datato: sarebbe ingannevole). Conta il numero di TIRI, che e' il
  //  dato utile all'arciere.
  tft.setTextDatum(MC_DATUM);
  if (st.sessionOpen) {
    char sb[18]; snprintf(sb, sizeof(sb), "REC  %u tiri", st.sessionShots);
    tft.fillCircle(ARCHBB_W/2 - 42, barH/2, 4, ArchColor::BAD);   // pallino REC
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG_CARD);
    tft.drawString(sb, ARCHBB_W/2 + 6, barH/2, 2);
  } else {
    tft.drawCircle(ARCHBB_W/2 - 34, barH/2, 4, ArchColor::TEXT3); // cerchietto vuoto
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
    tft.drawString("no sess", ARCHBB_W/2 + 4, barH/2, 2);
  }

  // --- SD (destra) ----------------------------------------------------------
  tft.setTextDatum(MR_DATUM);
  if (st.sdOk) {
    char db[14];
    if (st.sdFreeMb >= 1024) snprintf(db, sizeof(db), "SD %.1fG", st.sdFreeMb / 1024.0f);
    else                     snprintf(db, sizeof(db), "SD %luM", (unsigned long)st.sdFreeMb);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG_CARD);
    tft.drawString(db, ARCHBB_W - 6, barH/2, 2);
  } else {
    tft.setTextColor(ArchColor::BAD, ArchColor::BG_CARD);
    tft.drawString("no SD", ARCHBB_W - 6, barH/2, 2);
  }
}

// ----------------------------------------------------------------------------
//  FASE 5 — schermata di attesa CON barra di stato in cima.
// ----------------------------------------------------------------------------
//  Riusa il layout di displayAttesaTiroIMU ma lascia i primi ~22px alla barra.
//  Per non duplicare il corpo, ridisegniamo qui la scena spostata di poco sotto
//  la barra. (Il mirino centrale resta al suo posto: 284px di altezza danno
//  spazio a sufficienza.)
// ============================================================================
//  FASE 22 — SCHERMATA DI ATTESA, RIDISEGNATA
// ============================================================================
//  IL PROBLEMA CHE RISOLVE, misurato sulla battuta del 22/08.
//    Tre tiri circa non sono stati registrati. Analizzando i dati sono state
//    escluse una per una tutte le cause tecniche:
//        ampiezza sotto soglia      ~2%   (lognormale troncata sui picchi)
//        campioni persi              0
//        buchi di campionamento      0
//        due campioni consecutivi    margine minimo 3 contro 2 richiesti
//        sessione chiusa             sd_append_shot fa auto-start: NON perde
//    Resta una sola causa: il dispositivo NON ERA nella schermata di attesa.
//    Nei menu, in BLE o nel dialogo RIPRENDI/NUOVA il trigger non e' armato —
//    e nessuna di quelle schermate lo dichiara.
//
//  Da qui le due modifiche:
//    1) FASCIA DI STATO in cima, verde e a tutta larghezza: si legge da un
//       metro senza mettere a fuoco. Le schermate che NON ascoltano portano la
//       fascia grigia con scritto che non ascoltano (vedi displayNonInAscolto).
//    2) NUMERO DEL PROSSIMO TIRO IN GRANDE. Era font 2, alto una dozzina di
//       pixel: illeggibile con l'arco in mano, e peggio ancora per un presbite.
//       Ora font 8 (75 px) o font 7 (48 px) secondo quante cifre servono.
//
//  VINCOLO DEI FONT NUMERICI: i font 6/7/8 di TFT_eSPI contengono SOLO cifre.
//  La parola "TIRO" va disegnata a parte con un font normale — non si puo'
//  concatenare in una sola drawString. E' una regola gia' nota al progetto e il
//  banco di sintassi ha un controllo apposta.
// ----------------------------------------------------------------------------

// Geometria condivisa fra disegno e ridisegni parziali (§4.1): un letterale
// duplicato qui non darebbe un tasto morto, darebbe una fascia di pixel sporchi
// che nessuno riesce a spiegare.
static constexpr int16_t ASC_Y = 22;    // sommita' della fascia di stato
static constexpr int16_t ASC_H = 26;

// La fascia. Estratta perche' la usano sia l'attesa sia le schermate che
// devono dichiarare di NON ascoltare: una funzione sola, due significati
// opposti, nessun modo di disegnarle in due stili diversi per sbaglio.
static void drawFasciaAscolto(bool inAscolto) {
  const uint16_t sfondo = inAscolto ? ArchColor::GOOD : ArchColor::BG_CARD;
  const uint16_t testo  = inAscolto ? ArchColor::BG   : ArchColor::TEXT3;
  tft.fillRect(0, ASC_Y, ARCHBB_W, ASC_H, sfondo);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(testo, sfondo);
  tft.drawString(inAscolto ? "IN ASCOLTO" : "NON IN ASCOLTO",
                 ARCHBB_W / 2, ASC_Y + ASC_H / 2, 4);
}

void displayNonInAscolto() { drawFasciaAscolto(false); }

void displayAttesaTiroIMU_v5(uint16_t nextShotId, float tempC, const StatusInfo& st) {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  displayStatusBar(st);
  drawFasciaAscolto(true);

  // Diagnosi SD, se manca: la CAUSA si legge sul dispositivo senza seriale.
  if (!st.sdOk && st.sdDiag) {
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(ArchColor::BAD, ArchColor::BG);
    tft.drawString(st.sdDiag, ARCHBB_W/2, ASC_Y + ASC_H + 10, 1);
  } else if (st.hasTime) {
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString(st.clock, ARCHBB_W/2, ASC_Y + ASC_H + 12, 2);
  }

  // --- IL NUMERO, in grande -----------------------------------------------
  //  Il mirino decorativo che stava qui e' stato tolto: occupava il centro
  //  dello schermo per non dire nulla, e il centro e' l'unico posto dove un
  //  numero grande si legge davvero.
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("PROSSIMO TIRO", ARCHBB_W/2, 96, 2);

  char num[8];
  snprintf(num, sizeof(num), "%u", (unsigned)nextShotId);

  //  ATTENZIONE AI FONT DISPONIBILI, non solo a quelli esistenti.
  //  TFT_eSPI compila SOLO i font dichiarati in platformio.ini. Alla prima
  //  stesura di questa fase il font 8 non era fra quelli: la libreria non
  //  aveva i glifi, non ha disegnato nulla, e il campo e' rimasto VUOTO —
  //  senza un errore di compilazione ne' uno a runtime. Adesso LOAD_FONT8 c'e';
  //  il guardiano qui sotto serve perche' quella riga di platformio.ini e'
  //  lontana da questa e prima o poi qualcuno la toglie per fare spazio.
  //
  //  Font 8 = cifre da 75 px, font 7 = 48 px. Con quattro cifre il font 8
  //  sborderebbe (circa 55 px per cifra su 240 disponibili), quindi si scala.
  //  La soglia e' sulle CIFRE e non su una larghezza misurata: textWidth con i
  //  font a sette segmenti non e' affidabile quanto contare i caratteri.
#if defined(LOAD_FONT8)
  const uint8_t fontNum = (strlen(num) <= 3) ? 8 : 7;
#else
  #warning "LOAD_FONT8 assente: il numero del prossimo tiro sara' meta' grande"
  const uint8_t fontNum = 7;
#endif
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString(num, ARCHBB_W/2, 148, fontNum);

  // --- riga IMU + temperatura ---------------------------------------------
  const int badgeY = 200;
  tft.fillCircle(ARCHBB_W/2 - 58, badgeY, 5, ArchColor::GOOD);
  tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
  tft.setTextDatum(ML_DATUM);
  tft.drawString("IMU ARMATA", ARCHBB_W/2 - 48, badgeY, 2);
  if (!isnan(tempC)) {
    char tt[16]; snprintf(tt, sizeof(tt), "%.0f\xB0""C", tempC);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.setTextDatum(MR_DATUM);
    tft.drawString(tt, ARCHBB_W - 14, badgeY, 2);
  }

  // Stato della macchina dei tempi. Prima la riga fissa "In attesa dello
  // SCOCCO" stava a y=246 e displayTempoRiga scriveva a y=244: si
  // sovrascrivevano a ogni giro del loop. Adesso la riga la disegna un solo
  // proprietario.
  displayTempoRiga(0, 0, true);

  tft.setTextDatum(BC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString(st.sessionOpen ? "tocca = CHIUDI sessione"
                                : "tocca = APRI sessione",
                 ARCHBB_W/2, ARCHBB_H - 8, 2);
}

// ----------------------------------------------------------------------------
//  FASE 5 — displaySessionNoSd: avviso "nessuna microSD".
// ----------------------------------------------------------------------------
//  Feedback onesto quando si tocca per gestire la sessione ma la card manca:
//  meglio dirlo che fingere. Un riquadro ambra centrale, breve e bloccante.
void displaySessionNoSd() {
  const int bw = 200, bh = 70;
  const int bx = (ARCHBB_W - bw)/2, by = (ARCHBB_H - bh)/2;
  tft.fillRoundRect(bx, by, bw, bh, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(bx, by, bw, bh, 8, ArchColor::AMBER);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::AMBER, ArchColor::BG_CARD);
  tft.drawString("NESSUNA microSD", ARCHBB_W/2, by + 24, 2);
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG_CARD);
  tft.drawString("inserisci una card FAT32", ARCHBB_W/2, by + 46, 2);
  delay(800);
}

// ----------------------------------------------------------------------------
//  FASE 5 — scelta sessione: geometria CONDIVISA disegno+hit (lezione §4.1)
// ----------------------------------------------------------------------------
//  Disegno e handler leggono le STESSE costanti: niente letterali duplicati che
//  prima o poi divergono (la cantonata piu' costosa della 1.69).
namespace SChoice {
  constexpr int BTN_X   = 20;
  constexpr int BTN_W   = ARCHBB_W - 40;      // pulsanti larghi, centrati
  constexpr int BTN_H   = 56;
  constexpr int RESUME_Y = 120;               // top del pulsante RIPRENDI
  constexpr int NEW_Y    = 190;               // top del pulsante NUOVA
}

void displaySessionChoice(const char* lastName, uint16_t lastShots) {
  using namespace SChoice;
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  // Il dialogo piu' pericoloso: si apre toccando, e mentre e' aperto il
  // trigger NON e' armato. E' il candidato numero uno per i tiri persi del
  // 22/08, e finora era indistinguibile a colpo d'occhio dall'attesa.
  displayNonInAscolto();

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("SESSIONE", ARCHBB_W/2, 62, 4);
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
  tft.drawString("c'e' gia' una sessione", ARCHBB_W/2, 88, 2);

  // Pulsante RIPRENDI (verde): accoda all'ultima.
  tft.fillRoundRect(BTN_X, RESUME_Y, BTN_W, BTN_H, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(BTN_X, RESUME_Y, BTN_W, BTN_H, 8, ArchColor::GOOD);
  tft.setTextColor(ArchColor::GOOD, ArchColor::BG_CARD);
  tft.drawString("RIPRENDI", ARCHBB_W/2, RESUME_Y + 18, 4);
  // Nome cartella (datato o numerato) + conteggio tiri. Il nome puo' essere
  // lungo (SESS_20260721_1430): font 1 per starci.
  char sub[36];
  snprintf(sub, sizeof(sub), "%s (%u tiri)", lastName ? lastName : "?", lastShots);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
  tft.drawString(sub, ARCHBB_W/2, RESUME_Y + 44, 1);

  // Pulsante NUOVA (ciano): apre una sessione vergine.
  tft.fillRoundRect(BTN_X, NEW_Y, BTN_W, BTN_H, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(BTN_X, NEW_Y, BTN_W, BTN_H, 8, ArchColor::ACCENT);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG_CARD);
  tft.drawString("NUOVA", ARCHBB_W/2, NEW_Y + 20, 4);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
  tft.drawString("inizia da capo", ARCHBB_W/2, NEW_Y + 44, 2);
}

uint8_t hitSessionChoice(uint16_t x, uint16_t y) {
  using namespace SChoice;
  if (x >= BTN_X && x <= BTN_X + BTN_W) {
    if (y >= RESUME_Y && y <= RESUME_Y + BTN_H) return 1;   // RIPRENDI
    if (y >= NEW_Y    && y <= NEW_Y    + BTN_H) return 2;    // NUOVA
  }
  return 0;
}

// ----------------------------------------------------------------------------
//  FASE 5 — displaySavedFlash: doppio flash verde "SALVATO".
// ----------------------------------------------------------------------------
void displayScartato() {
    tft.fillScreen(ArchColor::BAD);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(ArchColor::TEXT, ArchColor::BAD);
    tft.drawString("SCARTATO", ARCHBB_W / 2, ARCHBB_H / 2 - 12, 4);
    tft.setTextColor(ArchColor::TEXT2, ArchColor::BAD);
    tft.drawString("niente sulla card", ARCHBB_W / 2, ARCHBB_H / 2 + 22, 2);
    delay(700);
}

void displaySavedFlash(uint16_t shotNum) {
  const int bw = 200, bh = 80;
  const int bx = (ARCHBB_W - bw)/2, by = (ARCHBB_H - bh)/2;
  char t[24]; snprintf(t, sizeof(t), "tiro #%u", shotNum);

  for (int i = 0; i < 2; i++) {         // due lampeggi
    tft.fillRoundRect(bx, by, bw, bh, 10, ArchColor::GOOD);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(ArchColor::BG, ArchColor::GOOD);
    tft.drawString("SALVATO", ARCHBB_W/2, by + 30, 4);
    tft.drawString(t, ARCHBB_W/2, by + 58, 2);
    delay(110);
    tft.fillRoundRect(bx, by, bw, bh, 10, ArchColor::BG);   // spegni
    tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);
    delay(70);
  }
}

// ============================================================================
//  Flash di conferma "TIRO RILEVATO"
// ============================================================================
void displayTriggerFlash(uint16_t shotId, float azPeak) {
  tft.fillScreen(ArchColor::AMBER);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::BG, ArchColor::AMBER);   // nero su ambra
  tft.drawString("TIRO", ARCHBB_W/2, ARCHBB_H/2 - 40, 4);
  tft.drawString("RILEVATO", ARCHBB_W/2, ARCHBB_H/2 - 8, 4);

  char t[24]; snprintf(t, sizeof(t), "#%u", shotId);
  tft.drawString(t, ARCHBB_W/2, ARCHBB_H/2 + 34, 6);   // font 6 numerico: ok

  char p[28]; snprintf(p, sizeof(p), "az picco %.0f m/s2", azPeak);
  tft.setTextColor(ArchColor::BG, ArchColor::AMBER);
  tft.drawString(p, ARCHBB_W/2, ARCHBB_H/2 + 74, 2);

  delay(120);   // breve, bloccante: e' l'unico delay volutamente accettato qui
}

// ----------------------------------------------------------------------------
//  FASE 7 — displayBleMode: schermata del modo "colloquio con smartphone".
// ----------------------------------------------------------------------------
//  Layout (dall'alto):
//    - icona Bluetooth stilizzata + titolo "MODO BLE"
//    - stato connessione: "IN ASCOLTO..." (ambra pulsante) o "CONNESSO" (verde)
//    - card col nome device (quello che appare nello scanner dell'app)
//    - riga riassunto: batteria | SD | orologio
//    - piede: istruzione per uscire (ripremere l'ingranaggio)
//
//  Coerente con la palette ArchBB (fondo nero, accento ciano, card grigio-blu).
//  Nessuna animazione nel loop: la ridisegniamo solo quando cambia lo stato di
//  connessione (il main tiene memoria dell'ultimo stato disegnato).
void displayBleMode(bool connected, const char* devName, const StatusInfo& st) {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  // In BLE la catena IMU e' sospesa: qui non si registra niente, e va detto.
  // Vedi la nota in cima a displayAttesaTiroIMU_v5.
  displayNonInAscolto();

  // --- Glifo Bluetooth stilizzato (semplice "runa" a segmenti) -------------
  //  Non serve un font-icona: due triangoli speculari attorno a un'asta danno
  //  la classica rune BT riconoscibile. Colore = stato (ambra/attesa, verde/on).
  const uint16_t accent = connected ? ArchColor::GOOD : ArchColor::ACCENT;
  const int cx = ARCHBB_W / 2, gy = 62;
  tft.drawLine(cx, gy - 16, cx, gy + 16, accent);          // asta verticale
  tft.drawLine(cx, gy - 16, cx + 10, gy - 6, accent);      // alette alto
  tft.drawLine(cx + 10, gy - 6, cx - 10, gy + 6, accent);
  tft.drawLine(cx, gy + 16, cx + 10, gy + 6, accent);      // alette basso
  tft.drawLine(cx + 10, gy + 6, cx - 10, gy - 6, accent);

  // --- Titolo --------------------------------------------------------------
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("MODO BLE", cx, gy + 40, 4);

  // --- Stato connessione ---------------------------------------------------
  if (connected) {
    tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
    tft.drawString("APP CONNESSA", cx, gy + 72, 2);
  } else {
    tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
    tft.drawString("in ascolto...", cx, gy + 72, 2);
  }

  // --- Card col nome device ------------------------------------------------
  const int cardX = 16, cardY = 130, cardW = ARCHBB_W - 32, cardH = 44;
  tft.fillRoundRect(cardX, cardY, cardW, cardH, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(cardX, cardY, cardW, cardH, 8, ArchColor::BORDER);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
  tft.drawString("cerca nell'app:", cx, cardY + 12, 1);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG_CARD);
  tft.drawString(devName ? devName : "ArchBB-183", cx, cardY + 30, 2);

  // --- Riga riassunto: batteria | SD | orologio ----------------------------
  int ry = 196;
  char line[40];
  // Batteria
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
  if (st.battPct >= 0) snprintf(line, sizeof(line), "Batt %d%%%s",
                                st.battPct, st.battCharging ? " (in carica)" : "");
  else                 snprintf(line, sizeof(line), "Batt n/d");
  tft.drawString(line, cardX, ry, 2);
  // SD
  ry += 22;
  if (st.sdOk) snprintf(line, sizeof(line), "SD  %lu MB liberi", (unsigned long)st.sdFreeMb);
  else         snprintf(line, sizeof(line), "SD  assente");
  tft.setTextColor(st.sdOk ? ArchColor::TEXT2 : ArchColor::AMBER, ArchColor::BG);
  tft.drawString(line, cardX, ry, 2);
  // Orologio
  ry += 22;
  if (st.hasTime) snprintf(line, sizeof(line), "Ora  %s", st.clock);
  else            snprintf(line, sizeof(line), "Ora  non impostata");
  tft.setTextColor(st.hasTime ? ArchColor::TEXT2 : ArchColor::TEXT3, ArchColor::BG);
  tft.drawString(line, cardX, ry, 2);

  // --- Piede: come uscire --------------------------------------------------
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("premi l'ingranaggio per uscire", cx, ARCHBB_H - 12, 1);
}
