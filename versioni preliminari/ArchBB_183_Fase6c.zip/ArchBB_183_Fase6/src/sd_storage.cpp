// ============================================================================
//  ArchBB 1.83 — sd_storage.cpp · FASE 5 (persistenza microSD)
//  Cesare Pagura · Padova/Noale IT · 20 luglio 2026
// ----------------------------------------------------------------------------
//  Vedi sd_storage.h per l'architettura (bus SPI dedicato, struttura file,
//  formato burst). Qui c'e' l'implementazione. Tre scelte pratiche guidano
//  tutto il file:
//
//   1) Un SPIClass dedicato sull'host FSPI. Il display usa HSPI; noi FSPI. I due
//      bus non si toccano mai -> nessuna transazione condivisa da gestire.
//
//   2) Apri-scrivi-CHIUDI a ogni operazione. Non teniamo mai file aperti fra un
//      tiro e l'altro. close() forza il flush su card: se la batteria muore, cio'
//      che era chiuso e' salvo. E' il pattern anti-corruzione dei datalogger.
//
//   3) Lo STATO vive sulla card, non in RAM. Numero sessione e numero tiro si
//      DERIVANO dal filesystem (prime cartelle/righe libere). Un reset non perde
//      il filo: si riprende leggendo cosa c'e' gia' su card.
// ============================================================================
#include "sd_storage.h"
#include "rtc_clock.h"   // FASE 6: data/ora per nomi cartella e session.txt
#include <FS.h>
#include <SD.h>
#include <SPI.h>

// ----------------------------------------------------------------------------
//  Stato globale
// ----------------------------------------------------------------------------
volatile bool g_sd_ok        = false;
volatile bool g_session_open = false;

// SPIClass dedicato all'host FSPI (separato dall'HSPI del display).
static SPIClass s_sdSPI(FSPI);

// Stato della sessione corrente (in RAM, ma sempre RICOSTRUIBILE dalla card).
static uint16_t s_sessionId   = 0;   // 0 = nessuna sessione aperta
static uint16_t s_shotCount   = 0;   // tiri salvati nella sessione corrente
static char     s_sessDir[48] = "";  // es. "/ARCHBB/SESS_20260721_1430" o "/ARCHBB/SESS_0001"

// Versione del formato CSV: se un domani cambiano le colonne, l'app la legge in
// testa al file e sa come interpretarlo. Stessa disciplina degli ScorePacket.
static constexpr uint8_t CSV_FORMAT_VER = 1;

// Magic + versione dell'header del burst binario.
static const char BURST_MAGIC[4] = { 'A', 'B', 'B', '1' };
static constexpr uint8_t BURST_FORMAT_VER = 1;

// Radice di tutti i dati ArchBB sulla card.
static const char* ROOT_DIR = "/ARCHBB";

// ----------------------------------------------------------------------------
//  Helper interni
// ----------------------------------------------------------------------------

// Costruisce "/ARCHBB/SESS_NNNN" in out.
static void buildSessDir(char* out, size_t outSz, uint16_t id) {
  snprintf(out, outSz, "%s/SESS_%04u", ROOT_DIR, id);
}

// Costruisce il path del burst del tiro n dentro la sessione corrente.
static void buildBurstPath(char* out, size_t outSz, uint16_t shotNum) {
  snprintf(out, outSz, "%s/burst_%04u.bin", s_sessDir, shotNum);
}

// Trova il primo numero di sessione libero scandendo /ARCHBB/. Non tiene un
// contatore: CHIEDE alla card. Cosi' dopo un reset non si sovrascrive nulla.
static uint16_t firstFreeSessionId() {
  for (uint16_t id = 1; id <= 9999; id++) {
    char dir[24];
    buildSessDir(dir, sizeof(dir), id);
    if (!SD.exists(dir)) return id;   // primo buco = nostra sessione
  }
  return 0;   // improbabile (9999 sessioni): card da svuotare
}

// Trova l'ULTIMA sessione esistente enumerando le cartelle reali in /ARCHBB e
// prendendo il nome piu' alto in ordine alfabetico. Funziona con ENTRAMBI gli
// schemi di naming: sia "SESS_0001" (zero-padded) sia "SESS_20260721_1430"
// (datato) ordinano correttamente come stringhe -> l'ultimo alfabetico e' il
// piu' recente. Scrive il path completo in outDir. Ritorna true se trovata.
//  (Sostituisce la vecchia scansione per indice numerico, che non vedeva le
//   cartelle datate — bug evitato: enumerare il filesystem, non indovinare i nomi.)
static bool lastExistingSessionDir(char* outDir, size_t outSz) {
  File root = SD.open(ROOT_DIR);
  if (!root || !root.isDirectory()) { if (root) root.close(); return false; }

  char best[48] = "";
  File e = root.openNextFile();
  while (e) {
    if (e.isDirectory()) {
      const char* nm = e.name();
      // e.name() puo' essere il path completo o il solo nome a seconda del core:
      // isoliamo il basename dopo l'ultimo '/'.
      const char* base = strrchr(nm, '/');
      base = base ? base + 1 : nm;
      if (strncmp(base, "SESS_", 5) == 0) {
        if (strcmp(base, best) > 0) {
          snprintf(best, sizeof(best), "%s", base);
        }
      }
    }
    e.close();
    e = root.openNextFile();
  }
  root.close();

  if (best[0] == '\0') return false;
  snprintf(outDir, outSz, "%s/%s", ROOT_DIR, best);
  return true;
}

// Conta i tiri gia' salvati in uno shots.csv: numero di righe-dati (esclusi il
// commento '#' e l'header colonne). Serve a far ripartire il contatore dal
// punto giusto quando si RIPRENDE una sessione, cosi' i nuovi burst non
// sovrascrivono i vecchi (burst_NNNN.bin numerati da dove eravamo).
static uint16_t countCsvRows(const char* csvPath) {
  File f = SD.open(csvPath, FILE_READ);
  if (!f) return 0;
  uint16_t rows = 0;
  while (f.available()) {
    String line = f.readStringUntil('\n');
    if (line.length() == 0) continue;
    if (line[0] == '#') continue;                 // commento di versione
    if (line.startsWith("shot,")) continue;       // header colonne
    rows++;
  }
  f.close();
  return rows;
}

// ----------------------------------------------------------------------------
//  sd_init — monta la card sull'host FSPI dedicato (VERSIONE DIAGNOSTICA)
// ----------------------------------------------------------------------------
//  "I dati comandano": se il mount fallisce, non basta sapere CHE fallisce,
//  serve sapere PERCHE'. Questa versione distingue le cause tipiche:
//    - card assente / nessun dialogo sul bus   -> pin o hardware
//    - card risponde ma filesystem illeggibile -> formato (exFAT invece di FAT32)
//    - mount ok solo a frequenza bassa          -> bus troppo veloce/piste
//  Prova due frequenze (prima prudente 400kHz-ish via 4MHz, poi la nominale):
//  molte card fanno l'handshake iniziale solo a bassa frequenza.
//
//  Il risultato diagnostico e' loggato (env debug) E memorizzato in g_sd_diag
//  cosi' il main puo' mostrarlo a schermo. In campo, muto: conta solo g_sd_ok.
// ----------------------------------------------------------------------------
char g_sd_diag[48] = "non inizializzata";   // ultima diagnosi leggibile

static bool tryMount(uint32_t freq) {
  // SD.begin puo' essere richiamata piu' volte: se un tentativo fallisce,
  // SD.end() libera lo stato prima del successivo.
  SD.end();
  return SD.begin(SD_PIN_CS, s_sdSPI, freq);
}

bool sd_init() {
  if (g_sd_ok) return true;   // gia' montata: idempotente

  // Avvia il bus FSPI sui NOSTRI pin (ordine SPIClass: SCK, MISO, MOSI, SS).
  s_sdSPI.begin(SD_PIN_SCK, SD_PIN_MISO, SD_PIN_MOSI, SD_PIN_CS);

  // --- Tentativo 1: frequenza BASSA (handshake robusto) --------------------
  //  4 MHz e' conservativo: se la card e le piste sono ok, monta di sicuro qui.
  bool mounted = tryMount(4000000UL);
  uint32_t usedFreq = 4000000UL;

  // --- Tentativo 2: frequenza nominale, solo se il primo e' andato ---------
  //  Se il mount basso e' riuscito, riproviamo alla frequenza piena: se anche
  //  quella regge, lavoriamo veloci; se no, restiamo a 4 MHz (comunque ok per
  //  ~20 KB a tiro).
  if (mounted) {
    if (tryMount(SD_SPI_FREQ_HZ)) usedFreq = SD_SPI_FREQ_HZ;
    else {
      tryMount(4000000UL);        // ripristina il mount basso che funzionava
      usedFreq = 4000000UL;
    }
  }

  if (!mounted) {
    // Nessun mount nemmeno a bassa frequenza. Distinguiamo "card assente" da
    // "card presente ma filesystem illeggibile": cardType() interroga il bus.
    uint8_t ct = SD.cardType();
    if (ct == CARD_NONE) {
      snprintf(g_sd_diag, sizeof(g_sd_diag), "nessun dialogo (pin/card assente)");
    } else {
      // La card risponde sul bus (cardType != NONE) ma begin fallisce -> quasi
      // sempre e' il FILESYSTEM: card formattata exFAT (o >32GB di fabbrica),
      // che la lib SD di Arduino-ESP32 non legge. Serve FAT32.
      snprintf(g_sd_diag, sizeof(g_sd_diag), "card ok ma non FAT32 (riformatta)");
    }
    DBG("SD: mount FALLITO -> %s", g_sd_diag);
    g_sd_ok = false;
    return false;
  }

  // Mount riuscito: doppio-controllo che non sia CARD_NONE (SD.begin talvolta
  // passa con card assente su alcuni core).
  uint8_t ct = SD.cardType();
  if (ct == CARD_NONE) {
    snprintf(g_sd_diag, sizeof(g_sd_diag), "mount vuoto (CARD_NONE)");
    DBG("SD: %s", g_sd_diag);
    g_sd_ok = false;
    return false;
  }

  // Assicura la cartella radice /ARCHBB.
  if (!SD.exists(ROOT_DIR)) {
    if (!SD.mkdir(ROOT_DIR)) {
      snprintf(g_sd_diag, sizeof(g_sd_diag), "montata ma sola-lettura?");
      DBG("SD: impossibile creare %s", ROOT_DIR);
      g_sd_ok = false;
      return false;
    }
  }

  // Nome tipo card per la diagnosi (utile a colpo d'occhio).
  const char* ctName = (ct == CARD_MMC) ? "MMC" :
                       (ct == CARD_SD)  ? "SDSC" :
                       (ct == CARD_SDHC)? "SDHC" : "?";
  snprintf(g_sd_diag, sizeof(g_sd_diag), "%s %luMB @%luMHz",
           ctName, (unsigned long)sd_total_mb(), (unsigned long)(usedFreq/1000000UL));

  g_sd_ok = true;
  DBG("SD: montata (%s, %lu MB liberi)", g_sd_diag, (unsigned long)sd_free_mb());
  return true;
}

// ----------------------------------------------------------------------------
//  buildHybridSessDir — nome cartella IBRIDO (datato se RTC valido, numerato se no)
// ----------------------------------------------------------------------------
//  FASE 6: se l'RTC e' impostato, la cartella e' PARLANTE: SESS_20260721_1430.
//  Se l'RTC non e' ancora impostato (finche' non arriva il BLE), si ricade sul
//  nome NUMERATO SESS_0001 — sempre univoco dal filesystem. Cosi' i nomi datati
//  arrivano appena l'ora e' valida, ma NON si rompe nulla adesso.
//
//  Anti-collisione: due sessioni nello stesso minuto (raro) avrebbero lo stesso
//  nome datato. Aggiungiamo un suffisso 'b','c',... finche' il nome e' libero,
//  cosi' non si sovrascrive MAI una sessione esistente.
//  Ritorna true se ha prodotto un nome datato, false se numerato (fallback).
static bool buildHybridSessDir(char* out, size_t outSz) {
  char stamp[14];
  rtc_compact_string(stamp, sizeof(stamp));   // "YYYYMMDD_HHMM" o "" se non valido

  if (stamp[0] != '\0') {
    // RTC valido -> nome datato, con suffisso anti-collisione se serve.
    snprintf(out, outSz, "%s/SESS_%s", ROOT_DIR, stamp);
    if (!SD.exists(out)) return true;         // libero: fatto
    for (char suf = 'b'; suf <= 'z'; suf++) {
      snprintf(out, outSz, "%s/SESS_%s%c", ROOT_DIR, stamp, suf);
      if (!SD.exists(out)) return true;
    }
    // 25 sessioni nello stesso minuto: impossibile in pratica. Cade al numerato.
  }

  // Fallback numerato (RTC non valido, o collisione estrema).
  uint16_t id = firstFreeSessionId();
  buildSessDir(out, outSz, id);
  return false;
}

// ----------------------------------------------------------------------------
//  sd_session_start — apre una nuova sessione
// ----------------------------------------------------------------------------
uint16_t sd_session_start() {
  if (!g_sd_ok) return 0;

  // Se c'e' gia' una sessione aperta, la chiudiamo pulita prima di aprirne una
  // nuova: una sola sessione attiva alla volta.
  if (g_session_open) sd_session_stop();

  // Nome cartella ibrido: datato se RTC valido, numerato altrimenti.
  buildHybridSessDir(s_sessDir, sizeof(s_sessDir));
  if (!SD.mkdir(s_sessDir)) {
    DBG("SD: mkdir sessione %s fallito", s_sessDir);
    s_sessDir[0] = '\0';
    return 0;
  }
  // ID progressivo per compatibilita' interna (session.txt, contatori): resta il
  // primo-libero numerico, indipendente dal nome cartella.
  uint16_t id = firstFreeSessionId();

  // --- session.txt: metadati leggibili della sessione -----------------------
  {
    char p[64]; snprintf(p, sizeof(p), "%s/session.txt", s_sessDir);
    File f = SD.open(p, FILE_WRITE);
    if (f) {
      f.printf("ArchBB session %u\n", id);
      f.printf("fw=%s\n", ARCHBB_FW_VERSION);
      f.printf("csv_format=%u\n", CSV_FORMAT_VER);
      f.printf("burst_format=%u\n", BURST_FORMAT_VER);
      f.printf("odr_hz=%u\n", odrToHz(ODR_250HZ));
      f.printf("started_ms=%lu\n", (unsigned long)millis());
      // FASE 6: data/ora reale dall'RTC (o "non impostata" se RTC non valido).
      { char iso[24]; rtc_iso_string(iso, sizeof(iso)); f.printf("datetime=%s\n", iso); }
      f.printf("shots=0\n");   // aggiornato in stop()
      f.close();
    }
  }

  // --- shots.csv: header con versione e nomi colonna -------------------------
  //  L'header vive una volta sola, in testa al file. I campi nuovi andranno
  //  SEMPRE in coda (come nei pacchetti BLE): i file vecchi restano leggibili
  //  perche' l'app mappa per NOME colonna, non per posizione.
  {
    char p[64]; snprintf(p, sizeof(p), "%s/shots.csv", s_sessDir);
    File f = SD.open(p, FILE_WRITE);
    if (!f) { DBG("SD: creazione shots.csv fallita"); return 0; }
    f.printf("# ArchBB CSV v%u  fw=%s\n", CSV_FORMAT_VER, ARCHBB_FW_VERSION);
    // Colonne. cant/alzo/hold in centesimi di grado (interi), jerk in m/s^3.
    // I flag *_valid non li scriviamo come colonna: usiamo la SENTINELLA nel
    // valore stesso (campo vuoto) per "non calcolato", coerente con elev.
    f.println("shot,ts_ms,colpito,zona,dist_m,elev_deg,arcs,"
              "cant_cdeg,alzo_cdeg,angoli_stabili,"
              "hold_cdeg,hold_class,release_jerk,release_class,"
              "burst_file");
    f.close();
  }

  s_sessionId   = id;
  s_shotCount   = 0;
  g_session_open = true;
  DBG("SD: sessione %u aperta (%s)", id, s_sessDir);
  return id;
}

// ----------------------------------------------------------------------------
//  sd_session_resume_last — RIAPRE l'ultima sessione esistente (accoda)
// ----------------------------------------------------------------------------
//  Riprende la cartella con numero piu' alto gia' su card e fa ripartire il
//  contatore tiri dal numero di righe gia' in shots.csv. I nuovi tiri si
//  ACCODANO: appendCsvRow scrive in fondo, e i burst_NNNN.bin riprendono da
//  dove eravamo (nessuna sovrascrittura). Ritorna il numero di sessione ripresa,
//  o 0 se non c'e' nessuna sessione da riprendere (allora il chiamante apre una
//  nuova). Non ricrea header ne' session.txt: la sessione esiste gia'.
uint16_t sd_session_resume_last() {
  if (!g_sd_ok) return 0;
  if (g_session_open) sd_session_stop();

  // Trova l'ultima cartella reale (datata o numerata) e riprendila.
  if (!lastExistingSessionDir(s_sessDir, sizeof(s_sessDir))) {
    return 0;   // niente da riprendere -> il chiamante fara' start
  }

  // Riparti dal conteggio reale delle righe gia' scritte.
  char csv[64]; snprintf(csv, sizeof(csv), "%s/shots.csv", s_sessDir);
  if (!SD.exists(csv)) {
    // Cartella esiste ma senza CSV (sessione corrotta/vuota): trattala come
    // nuova ripartendo l'header. Raro, ma non lasciamo lo stato ambiguo.
    File f = SD.open(csv, FILE_WRITE);
    if (f) {
      f.printf("# ArchBB CSV v%u  fw=%s\n", CSV_FORMAT_VER, ARCHBB_FW_VERSION);
      f.println("shot,ts_ms,colpito,zona,dist_m,elev_deg,arcs,"
                "cant_cdeg,alzo_cdeg,angoli_stabili,"
                "hold_cdeg,hold_class,release_jerk,release_class,"
                "burst_file");
      f.close();
    }
    s_shotCount = 0;
  } else {
    s_shotCount = countCsvRows(csv);
  }

  // s_sessionId: manteniamo un id numerico interno (primo-libero) solo per i
  // log e i contatori; l'IDENTITA' della sessione ora e' il nome cartella.
  s_sessionId    = firstFreeSessionId();
  g_session_open = true;
  DBG("SD: sessione RIPRESA %s (%u tiri gia' presenti)", s_sessDir, s_shotCount);
  return s_sessionId;
}

// ----------------------------------------------------------------------------
//  sd_session_stop — chiude la sessione corrente
// ----------------------------------------------------------------------------
void sd_session_stop() {
  if (!g_session_open) return;

  // Aggiorna il conteggio tiri in session.txt riscrivendolo (file minuscolo).
  // Riscrivere per intero un file di 7 righe e' piu' semplice e sicuro che
  // cercare-e-sostituire una riga in mezzo.
  char p[64]; snprintf(p, sizeof(p), "%s/session.txt", s_sessDir);
  File f = SD.open(p, FILE_WRITE);   // FILE_WRITE tronca e riscrive da capo
  if (f) {
    f.printf("ArchBB session %u\n", s_sessionId);
    f.printf("fw=%s\n", ARCHBB_FW_VERSION);
    f.printf("csv_format=%u\n", CSV_FORMAT_VER);
    f.printf("burst_format=%u\n", BURST_FORMAT_VER);
    f.printf("odr_hz=%u\n", odrToHz(ODR_250HZ));
    f.printf("ended_ms=%lu\n", (unsigned long)millis());
    { char iso[24]; rtc_iso_string(iso, sizeof(iso)); f.printf("ended_datetime=%s\n", iso); }
    f.printf("shots=%u\n", s_shotCount);
    f.close();
  }

  DBG("SD: sessione %u chiusa (%u tiri)", s_sessionId, s_shotCount);
  g_session_open = false;
  s_sessionId    = 0;
  s_shotCount    = 0;
  s_sessDir[0]   = '\0';
}

uint16_t sd_session_id()         { return s_sessionId; }
uint16_t sd_session_shot_count() { return s_shotCount; }

// True se c'e' almeno una cartella SESS_* su card (da riprendere).
bool sd_has_previous_session() {
  if (!g_sd_ok) return false;
  char dir[48];
  return lastExistingSessionDir(dir, sizeof(dir));
}

// Info sull'ultima sessione (nome cartella + tiri gia' salvati) senza aprirla.
// name riceve il basename della cartella (es. "SESS_20260721_1430" o "SESS_0001").
void sd_last_session_info(char* name, size_t nameSz, uint16_t& shots) {
  if (nameSz) name[0] = '\0';
  shots = 0;
  if (!g_sd_ok) return;
  char dir[48];
  if (!lastExistingSessionDir(dir, sizeof(dir))) return;
  // basename dopo l'ultimo '/'
  const char* base = strrchr(dir, '/');
  base = base ? base + 1 : dir;
  snprintf(name, nameSz, "%s", base);
  char csv[64]; snprintf(csv, sizeof(csv), "%s/shots.csv", dir);
  shots = countCsvRows(csv);
}

// ----------------------------------------------------------------------------
//  writeBurstBin — scrive burst_NNNN.bin (header 16B + campioni grezzi)
// ----------------------------------------------------------------------------
//  Ritorna true se il file e' stato scritto per intero. Il chiamante usa il
//  ritorno solo per il log: il fallimento del .bin NON invalida il tiro (il CSV
//  e' il dato che conta). Nome file restituito in outName per la colonna CSV.
static bool writeBurstBin(uint16_t shotNum, const ImuSample* burst, uint16_t n,
                          uint16_t trigIdx, OdrSetting odr,
                          char* outName, size_t outNameSz) {
  outName[0] = '\0';
  if (burst == nullptr || n == 0) return false;

  char path[64]; buildBurstPath(path, sizeof(path), shotNum);
  File f = SD.open(path, FILE_WRITE);
  if (!f) { DBG("SD: apertura %s fallita", path); return false; }

  // --- Header 16 byte, little-endian (nativo ESP32) -------------------------
  //   [0..3]  magic "ABB1"
  //   [4]     format version
  //   [5]     odr code (OdrSetting)
  //   [6..7]  n_campioni (uint16)
  //   [8..9]  trigger_idx (uint16)
  //   [10..11] shot_num (uint16)
  //   [12..15] riservati (0) — margine per estensioni future senza rompere il passo
  uint8_t hdr[16] = {0};
  memcpy(hdr, BURST_MAGIC, 4);
  hdr[4] = BURST_FORMAT_VER;
  hdr[5] = (uint8_t)odr;
  hdr[6] = (uint8_t)(n & 0xFF);        hdr[7] = (uint8_t)(n >> 8);
  hdr[8] = (uint8_t)(trigIdx & 0xFF);  hdr[9] = (uint8_t)(trigIdx >> 8);
  hdr[10]= (uint8_t)(shotNum & 0xFF);  hdr[11]= (uint8_t)(shotNum >> 8);

  size_t wrote = f.write(hdr, sizeof(hdr));
  // I campioni COSI' COME SONO IN RAM: ImuSample e' packed 30B, il file e'
  // rileggibile con uno struct a passo 30 senza conversioni.
  wrote += f.write((const uint8_t*)burst, (size_t)n * sizeof(ImuSample));
  f.close();

  size_t expected = sizeof(hdr) + (size_t)n * sizeof(ImuSample);
  if (wrote != expected) {
    DBG("SD: burst troncato (%u/%u byte)", (unsigned)wrote, (unsigned)expected);
    return false;
  }
  // Solo il nome-file (senza path) va nella colonna CSV: l'app lo cerca dentro
  // la cartella della sessione, quindi il path relativo basta.
  snprintf(outName, outNameSz, "burst_%04u.bin", shotNum);
  return true;
}

// ----------------------------------------------------------------------------
//  appendCsvRow — appende UNA riga a shots.csv e CHIUDE (flush)
// ----------------------------------------------------------------------------
//  Il campo vuoto (due virgole di fila) e' la SENTINELLA di "non calcolato",
//  coerente con la filosofia dei *_valid: un hold non valido non scrive uno 0
//  (che sarebbe "tenuta perfetta"), scrive NIENTE. Chi rilegge distingue.
static bool appendCsvRow(uint16_t shotNum, const ScoreResult& r,
                         const char* burstName) {
  char p[64]; snprintf(p, sizeof(p), "%s/shots.csv", s_sessDir);
  File f = SD.open(p, FILE_APPEND);      // append: non tocca cio' che c'e' gia'
  if (!f) { DBG("SD: append shots.csv fallito"); return false; }

  // Costruiamo la riga in un buffer e la scriviamo in un colpo solo.
  char row[224];
  int k = 0;

  // shot, ts_ms, colpito, zona, dist_m
  k += snprintf(row+k, sizeof(row)-k, "%u,%lu,%u,",
                shotNum, (unsigned long)millis(), r.colpito ? 1 : 0);
  // zona: valida solo se colpito
  if (r.colpito) k += snprintf(row+k, sizeof(row)-k, "%u,", r.zona);
  else           k += snprintf(row+k, sizeof(row)-k, ",");
  // dist_m: 0 = ignota -> campo vuoto
  if (r.distanza_m > 0) k += snprintf(row+k, sizeof(row)-k, "%u,", r.distanza_m);
  else                  k += snprintf(row+k, sizeof(row)-k, ",");
  // elev_deg: sentinella ELEV_NOT_SET -> campo vuoto
  if (elevIsSet(r.elev_deg)) k += snprintf(row+k, sizeof(row)-k, "%d,", r.elev_deg);
  else                       k += snprintf(row+k, sizeof(row)-k, ",");
  // arcs
  k += snprintf(row+k, sizeof(row)-k, "%d,", r.arcs);

  // cant_cdeg, alzo_cdeg, angoli_stabili — solo se angles_valid
  if (r.angles_valid) {
    k += snprintf(row+k, sizeof(row)-k, "%d,%d,%u,",
                  r.cant_cdeg, r.alzo_cdeg, r.angles_stable ? 1 : 0);
  } else {
    k += snprintf(row+k, sizeof(row)-k, ",,,");
  }

  // hold_cdeg, hold_class — solo se hold_valid
  if (r.hold_valid) k += snprintf(row+k, sizeof(row)-k, "%d,%u,", r.hold_cdeg, r.hold_class);
  else              k += snprintf(row+k, sizeof(row)-k, ",,");

  // release_jerk, release_class — solo se release_valid
  if (r.release_valid) k += snprintf(row+k, sizeof(row)-k, "%u,%u,", r.release_jerk, r.release_class);
  else                 k += snprintf(row+k, sizeof(row)-k, ",,");

  // burst_file (ultima colonna): nome del .bin o vuoto se non salvato
  k += snprintf(row+k, sizeof(row)-k, "%s", burstName ? burstName : "");

  f.println(row);
  f.close();                              // <-- flush: la riga e' su card
  return true;
}

// ----------------------------------------------------------------------------
//  sd_save_shot — orchestrazione: burst prima, CSV dopo (o solo CSV)
// ----------------------------------------------------------------------------
bool sd_save_shot(const ScoreResult& res,
                  const ImuSample* burst, uint16_t n, uint16_t trigIdx,
                  OdrSetting odr) {
  if (!g_sd_ok) return false;

  // Auto-start: chi tira senza aver aperto una sessione non perde il dato.
  if (!g_session_open) {
    if (sd_session_start() == 0) return false;   // card piena/assente
  }

  uint16_t shotNum = s_shotCount + 1;   // numero 1-based del tiro nella sessione

  // 1) Burst grezzo (sacrificabile): se fallisce, si prosegue col CSV.
  char burstName[20] = "";
  bool burstOk = writeBurstBin(shotNum, burst, n, trigIdx, odr,
                               burstName, sizeof(burstName));
  (void)burstOk;   // il ritorno serve solo al log; non blocca il CSV

  // 2) CSV (dato prezioso): se questo fallisce, il tiro NON e' salvato.
  if (!appendCsvRow(shotNum, res, burstName)) return false;

  s_shotCount = shotNum;   // contabilizza il tiro solo dopo il CSV riuscito
  DBG("SD: tiro %u salvato (burst=%s)", shotNum, burstName[0] ? burstName : "no");
  return true;
}

// ----------------------------------------------------------------------------
//  Spazio libero/totale (per la barra di stato in ATTESA)
// ----------------------------------------------------------------------------
uint32_t sd_free_mb() {
  if (!g_sd_ok) return 0;
  uint64_t freeB = SD.totalBytes() - SD.usedBytes();
  return (uint32_t)(freeB / (1024ULL * 1024ULL));
}

uint32_t sd_total_mb() {
  if (!g_sd_ok) return 0;
  return (uint32_t)(SD.totalBytes() / (1024ULL * 1024ULL));
}
