// ============================================================================
//  ArchBB 1.83 — battery.h · FASE 5 (stato batteria via AXP2101)
//  Cesare Pagura · Padova/Noale IT · 20 luglio 2026
// ----------------------------------------------------------------------------
//  PERCHE' E' DIVERSO DALLA 1.69
//    Sulla 1.69 la batteria si leggeva con un partitore resistivo su un ADC:
//    misura grezza di tensione (OCV), rumorosa, da correggere a mano, e con la
//    trappola nota che collegare l'USB falsa la lettura (parte la carica).
//
//    La 1.83 monta il PMU AXP2101, un chip di gestione alimentazione che sta
//    sul bus I2C GIA' CONDIVISO (SDA=15/SCL=14, lo stesso di IMU e touch). Il
//    PMU calcola LUI la percentuale di carica, la tensione di batteria e lo
//    stato (in carica / a batteria), gia' filtrati. Leggiamo valori puliti via
//    I2C, niente ADC, niente partitore, nessun pin nuovo.
//
//  BUS CONDIVISO (stessa disciplina di IMU e touch)
//    battery_init() NON chiama Wire.begin(): il bus e' gia' vivo (touchInit in
//    Fase 2). Passa a XPowersLib l'istanza Wire attiva. Un begin() ripetuto
//    romperebbe touch e IMU. E' la trappola gia' imparata sulla 1.83.
//
//  LIBRERIA
//    XPowersLib (lewisxhe) — stesso autore di SensorLib che gia' usi per il
//    QMI8658. API pulita per l'AXP2101. La aggiungiamo a lib_deps.
//
//  ROBUSTEZZA
//    Se il PMU non risponde (raro: e' saldato, ma teniamo il pattern difensivo
//    di tutto il progetto), g_batt_ok resta false e le letture tornano
//    sentinelle (-1 percentuale, NAN tensione): la barra di stato mostrera'
//    "batt n/d" invece di un numero inventato. Coerente con i *_valid ovunque.
// ============================================================================
#pragma once
#include <Arduino.h>
#include "config.h"

// ----------------------------------------------------------------------------
//  Stato globale (definito in battery.cpp)
// ----------------------------------------------------------------------------
extern volatile bool g_batt_ok;   // true se l'AXP2101 risponde

// ----------------------------------------------------------------------------
//  API
// ----------------------------------------------------------------------------

// Inizializza l'AXP2101 sul bus I2C GIA' ATTIVO (non chiama Wire.begin()).
// Ritorna true se il chip risponde. Da chiamare in setup(), dopo touchInit()
// (che ha avviato il bus) e senza vincoli d'ordine con imu_init().
bool battery_init();

// Percentuale di carica 0..100, oppure -1 se non disponibile (PMU assente o
// percentuale non ancora calcolata dal chip). L'AXP2101 la stima internamente:
// e' il valore da mostrare all'arciere.
int battery_percent();

// Tensione di batteria in volt, oppure NAN se non disponibile. Utile come
// dettaglio diagnostico (una batteria "100%" ma a 3.3V sta per spegnersi).
float battery_voltage();

// True se in questo momento la batteria si sta caricando (USB collegato e
// carica attiva). Serve a mostrare l'icona "in carica" ed evitare allarmi di
// batteria scarica mentre e' attaccata.
bool battery_charging();
