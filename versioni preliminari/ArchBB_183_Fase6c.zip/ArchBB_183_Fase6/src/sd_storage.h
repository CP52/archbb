// ============================================================================
//  ArchBB 1.83 — sd_storage.h · FASE 5 (persistenza microSD)
//  Cesare Pagura · Padova/Noale IT · 20 luglio 2026
// ----------------------------------------------------------------------------
//  PERCHE' ESISTE QUESTO MODULO (il motivo della migrazione a 1.83)
//    La 1.69 mandava tutto via BLE all'app e non salvava nulla a bordo. La 1.83
//    ha lo slot microSD: il burst grezzo che cattura in PSRAM (Fase 4b) puo'
//    finalmente essere RIVERSATO su card, cosi' le sessioni restano a bordo,
//    ri-analizzabili a freddo. Questo modulo e' quel riversamento.
//
//  IL BUS SPI DELLA SD (fatto hardware, misurato dal pinout ufficiale 1.83-S3)
//    MOSI=GPIO1, SCK=GPIO2, MISO=GPIO3, CS=GPIO42. E' un bus SPI TUTTO SUO,
//    separato dal display (che gira su SCLK=6/MOSI=7 con HSPI). Nessuna contesa:
//    usiamo l'host FSPI con un SPIClass dedicato. Un bus, un chip, niente
//    transazioni condivise da sincronizzare — la situazione piu' semplice.
//
//  STRUTTURA FILE — robusta PER COSTRUZIONE (v. §struttura sotto)
//    Il principio guida: il dato che NON si puo' ricreare (i risultati dello
//    scoring) vive in un file piccolo ad APPEND, chiuso e flushato a ogni tiro,
//    cosi' un crash perde al massimo l'ultimo tiro. Il burst grezzo, che e'
//    SACRIFICABILE (se si corrompe hai comunque i risultati nel CSV), sta in un
//    file suo per tiro: se la sua scrittura fallisce, il CSV e' gia' al sicuro.
//
//      /ARCHBB/
//         SESS_0001/
//            shots.csv        <- 1 riga per tiro, append+flush (dato prezioso)
//            burst_0001.bin   <- burst grezzo tiro 1 (ri-analizzabile)
//            burst_0002.bin
//            session.txt      <- metadati: avvio, versione fw, n. tiri
//         SESS_0002/ ...
//
//    NUMERAZIONE DERIVATA DAL FILESYSTEM, non da un contatore in RAM/NVS:
//    all'avvio della sessione si scandisce /ARCHBB/ e si prende il primo
//    SESS_NNNN libero; il numero del tiro deriva da quante righe ha gia'
//    shots.csv. La SD *e'* lo stato: niente da tenere sincronizzato altrove,
//    robusto ai reset. (Quando arrivera' la Fase NVS, la coerenza sara' gia'
//    garantita dal filesystem, non da un secondo store da allineare.)
//
//  FORMATO DEL BURST BINARIO (.bin) — zero-parsing
//    Header di 16 byte (magic "ABB1" + versione + ODR + n_campioni +
//    trigger_idx + shot_id) seguito da n * sizeof(ImuSample) byte COSI' COME
//    SONO IN RAM. ImuSample e' packed e static_assert-ato a 30 byte: il file e'
//    direttamente rileggibile con uno struct a passo 30, senza conversioni,
//    da uno script Python o dalla companion app.
// ============================================================================
#pragma once
#include <Arduino.h>
#include "config.h"
#include "scoring.h"   // ScoreResult (i risultati da serializzare nel CSV)

// ----------------------------------------------------------------------------
//  Pin del bus SPI della microSD (1.83-S3) — vedi header sopra.
// ----------------------------------------------------------------------------
//  Non passano dai build_flags perche' il modulo SD e' l'unico a usarli: li
//  teniamo qui come costanti, vicino al codice che li adopera. Coerente con la
//  scelta fatta per i pin IMU (costanti in config.h, non -D).
static constexpr int SD_PIN_MOSI = 1;
static constexpr int SD_PIN_SCK  = 2;
static constexpr int SD_PIN_MISO = 3;
static constexpr int SD_PIN_CS   = 42;

// Frequenza del bus SD. Si parte prudenti (20 MHz): "prima acceso e pulito, poi
// si alza", stessa filosofia del display in Fase 1. Le microSD reggono molto di
// piu', ma su fili non schermati e bus condiviso col resto della scheda 20 MHz
// e' un compromesso sicuro per il bring-up.
static constexpr uint32_t SD_SPI_FREQ_HZ = 20000000;

// ----------------------------------------------------------------------------
//  Stato globale del modulo (definito in sd_storage.cpp)
// ----------------------------------------------------------------------------
extern volatile bool g_sd_ok;          // true se la card e' montata e scrivibile
extern volatile bool g_session_open;   // true se una sessione e' attualmente aperta

// Diagnosi leggibile dell'ultimo tentativo di mount (Fase 5). In caso di NO SD
// dice PERCHE': "nessun dialogo (pin/card assente)", "card ok ma non FAT32",
// ecc. Mostrata a schermo dal main quando la card manca, cosi' la causa si
// legge sul dispositivo senza collegare la seriale.
extern char g_sd_diag[48];

// ----------------------------------------------------------------------------
//  API — inizializzazione
// ----------------------------------------------------------------------------

// Monta la microSD sull'host FSPI dedicato (pin sopra). Crea /ARCHBB/ se manca.
// Ritorna true se la card risponde ed e' scrivibile. NON apre nessuna sessione:
// il montaggio della card e l'apertura di una sessione sono due cose distinte
// (si puo' avere la card montata e nessuna sessione in corso). Da chiamare in
// setup(), dopo display/touch/IMU. Idempotente: una seconda chiamata non rompe.
bool sd_init();

// ----------------------------------------------------------------------------
//  API — gestione sessione
// ----------------------------------------------------------------------------

// Apre una NUOVA sessione: sceglie il primo SESS_NNNN libero in /ARCHBB/, crea
// la cartella, scrive session.txt (metadati) e l'header di shots.csv. Da questo
// momento sd_save_shot() scrive nella nuova sessione. Ritorna il numero di
// sessione (>=1) o 0 se fallisce (card assente/piena). Se una sessione era gia'
// aperta, la chiude prima (una sola sessione attiva alla volta).
uint16_t sd_session_start();

// Riapre l'ultima sessione ESISTENTE su card e vi ACCODA i nuovi tiri (il
// contatore riparte dal numero di righe gia' in shots.csv, i burst_NNNN.bin
// riprendono da dove eravamo). Ritorna il numero di sessione ripresa, o 0 se
// non c'e' nessuna sessione da riprendere (in tal caso usare sd_session_start).
uint16_t sd_session_resume_last();

// True se esiste almeno una sessione su card che si potrebbe riprendere. Il
// main la usa per decidere se offrire la scelta "riprendi / nuova" oppure
// aprire direttamente una nuova (se non c'e' nulla da riprendere).
bool sd_has_previous_session();

// Info sull'ultima sessione esistente (per il testo della schermata di scelta):
// scrive in name il nome cartella (es. "SESS_20260721_1430" o "SESS_0001") e in
// shots quanti tiri contiene. Se non c'e' nessuna sessione, name[0]='\0'. Non
// modifica lo stato: e' pura lettura.
void sd_last_session_info(char* name, size_t nameSz, uint16_t& shots);

// Chiude la sessione corrente: aggiorna session.txt col conteggio finale dei
// tiri e marca g_session_open=false. Non cancella nulla. No-op se non c'e'
// sessione aperta. Da chiamare al tap-lungo di stop, o prima di aprirne una nuova.
void sd_session_stop();

// Numero della sessione attualmente aperta (0 se nessuna).
uint16_t sd_session_id();

// Quanti tiri sono stati salvati finora nella sessione corrente.
uint16_t sd_session_shot_count();

// ----------------------------------------------------------------------------
//  API — salvataggio del tiro (il cuore del modulo)
// ----------------------------------------------------------------------------

// Salva un tiro completo: appende la riga risultati a shots.csv (chiudendo il
// file subito per flush) e, se il burst e' fornito, scrive burst_NNNN.bin.
//
//   res     : il ScoreResult del tiro (esito, zona, dist, elev, angoli, metriche)
//   burst   : puntatore ai campioni grezzi del burst (frame canonico), o nullptr
//             se non disponibile (tiro manuale senza IMU / buffer non READY)
//   n       : numero di campioni nel burst (0 se burst==nullptr)
//   trigIdx : indice del campione di scocco entro il burst (= pre-samples)
//   odr     : l'ODR con cui il burst e' stato campionato (per l'header .bin)
//
// Se non c'e' una sessione aperta, ne apre UNA automaticamente (auto-start al
// primo tiro): l'arciere che spara senza aver premuto "start" non perde il dato.
//
// Ritorna true se ALMENO il CSV e' stato scritto (il dato prezioso e' salvo);
// il fallimento del solo .bin non rende false il risultato, ma viene loggato.
bool sd_save_shot(const ScoreResult& res,
                  const ImuSample* burst, uint16_t n, uint16_t trigIdx,
                  OdrSetting odr);

// ----------------------------------------------------------------------------
//  API — spazio libero (per la barra di stato in ATTESA)
// ----------------------------------------------------------------------------

// Megabyte liberi sulla card (0 se card assente). Calcolato da totalBytes -
// usedBytes. E' una query relativamente costosa (scandisce la FAT): la si
// chiama con parsimonia, tipicamente una volta all'ingresso in ATTESA, non nel
// loop. Il valore cambia lentamente (20 KB a tiro), non serve rinfrescarlo spesso.
uint32_t sd_free_mb();

// Megabyte totali della card (0 se assente). Per mostrare "liberi / totali".
uint32_t sd_total_mb();
