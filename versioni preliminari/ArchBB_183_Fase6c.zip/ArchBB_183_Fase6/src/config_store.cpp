// ============================================================================
//  ArchBB 1.83 — config_store.cpp · FASE 6 (NVS + CONFIG)
//  Cesare Pagura · Padova/Noale IT · 20 luglio 2026
// ----------------------------------------------------------------------------
//  Vedi config_store.h per l'architettura. Qui l'implementazione su NVS via
//  Preferences (wrapper standard Arduino-ESP32). La struct Config viaggia come
//  BLOB unico: un solo putBytes/getBytes, atomico quanto basta, e il checksum
//  in coda cattura le scritture interrotte.
// ============================================================================
#include "config_store.h"
#include "mount.h"       // g_mount_orientation
#include "trigger.h"     // (per un futuro trigger_configure; ora via extern sotto)
#include <Preferences.h>

// Istanza globale in RAM: la copia di lavoro che tutti leggono a runtime.
Config g_config;

// Namespace e chiave NVS. Nomi corti (l'NVS ha un limite di 15 char per chiave).
static const char* NVS_NS  = "archbb";
static const char* NVS_KEY = "config";

// ----------------------------------------------------------------------------
//  checksum — somma dei byte di Config ESCLUSO il campo checksum stesso.
// ----------------------------------------------------------------------------
//  Semplice ma efficace per il caso d'uso (scrittura interrotta): una FNV-1a a
//  32 bit sui byte che precedono il checksum. Non e' crittografia, e' un
//  rilevatore di corruzione — e per quello basta e avanza.
static uint32_t configChecksum(const Config& c) {
  const uint8_t* p = reinterpret_cast<const uint8_t*>(&c);
  size_t n = sizeof(Config) - sizeof(c.checksum);   // tutto tranne il checksum finale
  uint32_t h = 2166136261u;                         // offset FNV-1a
  for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 16777619u; }
  return h;
}

// ----------------------------------------------------------------------------
//  config_set_defaults — riempie g_config coi DEFAULT compilati.
// ----------------------------------------------------------------------------
//  Sono ESATTAMENTE i valori attuali del firmware (le costanti di config.h):
//  cosi', config vuoto = comportamento identico a prima dell'NVS.
void config_set_defaults() {
  g_config.version            = CONFIG_VERSION;
  // trigger
  g_config.trig_mode          = (uint8_t)TRIG_DEFAULT_MODE;       // az_threshold
  g_config.trig_threshold_ms2 = TRIG_DEFAULT_THRESHOLD;          // 20.0
  g_config.trig_confirm_n     = TRIG_DEFAULT_CONFIRM_N;          // 2
  g_config.trig_rearm_ms      = TRIG_DEFAULT_REARM_MS;           // 2000
  // finestre
  g_config.window_pre_ms      = WINDOW_PRE_MS;                    // 2000
  g_config.window_post_ms     = WINDOW_POST_MS;                   // 1000
  // montaggio (1.83 = FLIPZ)
  g_config.mount_orientation  = ARCHBB_MOUNT_DEFAULT;            // 4
  // offset di calibrazione: 0 = non calibrato (procedure future)
  g_config.offset_cant_deg    = 0.0f;
  g_config.offset_alzo_deg    = 0.0f;
  g_config.offset_g_ms2       = 0.0f;
  // fisica arco
  g_config.bow_mass_kg        = 0.0f;                            // non impostata
  // checksum coerente
  g_config.checksum           = configChecksum(g_config);
}

// ----------------------------------------------------------------------------
//  config_load — legge da NVS in g_config, con fallback ai default.
// ----------------------------------------------------------------------------
bool config_load() {
  Preferences prefs;
  // readOnly: apre il namespace senza crearlo se non serve scrivere.
  if (!prefs.begin(NVS_NS, /*readOnly=*/true)) {
    DBG("CFG: NVS namespace assente -> default");
    config_set_defaults();
    return false;
  }

  // Il blob deve esistere ed avere ESATTAMENTE la dimensione della struct.
  size_t len = prefs.getBytesLength(NVS_KEY);
  if (len != sizeof(Config)) {
    DBG("CFG: blob assente o dimensione errata (%u vs %u) -> default",
        (unsigned)len, (unsigned)sizeof(Config));
    prefs.end();
    config_set_defaults();
    return false;
  }

  Config tmp;
  size_t got = prefs.getBytes(NVS_KEY, &tmp, sizeof(Config));
  prefs.end();
  if (got != sizeof(Config)) {
    DBG("CFG: lettura incompleta -> default");
    config_set_defaults();
    return false;
  }

  // Versione: se non combacia, la struct in NVS e' di un altro firmware ->
  // migrazione ai default (non interpretiamo byte di un layout diverso).
  if (tmp.version != CONFIG_VERSION) {
    DBG("CFG: versione NVS %u != %u -> default (migrazione)", tmp.version, CONFIG_VERSION);
    config_set_defaults();
    return false;
  }

  // Checksum: se non torna, il blocco e' corrotto (scrittura interrotta) ->
  // default. Meglio ripartire puliti che lavorare su valori spazzatura.
  uint32_t expect = configChecksum(tmp);
  if (tmp.checksum != expect) {
    DBG("CFG: checksum errato (%08x vs %08x) -> default", tmp.checksum, expect);
    config_set_defaults();
    return false;
  }

  // Tutto valido: e' la nostra fonte di verita'.
  g_config = tmp;
  DBG("CFG: caricato da NVS (v%u ok)", tmp.version);
  return true;
}

// ----------------------------------------------------------------------------
//  config_save — scrive g_config in NVS (aggiorna version + checksum).
// ----------------------------------------------------------------------------
bool config_save() {
  g_config.version  = CONFIG_VERSION;
  g_config.checksum = configChecksum(g_config);

  Preferences prefs;
  if (!prefs.begin(NVS_NS, /*readOnly=*/false)) {
    DBG("CFG: apertura NVS in scrittura fallita");
    return false;
  }
  size_t wrote = prefs.putBytes(NVS_KEY, &g_config, sizeof(Config));
  prefs.end();

  bool ok = (wrote == sizeof(Config));
  DBG("CFG: salvato in NVS (%u byte) -> %s", (unsigned)wrote, ok ? "OK" : "FALLITO");
  return ok;
}

// ----------------------------------------------------------------------------
//  config_reset — default + scrittura (ripristino di fabbrica).
// ----------------------------------------------------------------------------
bool config_reset() {
  config_set_defaults();
  DBG("CFG: ripristino default di fabbrica");
  return config_save();
}

// ----------------------------------------------------------------------------
//  config_apply — rende OPERATIVI i valori di g_config.
// ----------------------------------------------------------------------------
//  Centralizza il "come i parametri diventano attivi". Oggi cabla montaggio e
//  trigger (che hanno gia' variabili runtime). Le finestre pre/post restano
//  legate alle costanti compilate in questo passo (parametrizzare il circular
//  buffer e' un cambiamento piu' profondo, da fare a parte senza rischiare
//  regressioni): se un domani si vorranno editabili, e' qui che si applicheranno.
//
//  NB: il trigger espone i suoi setter runtime tramite variabili static in
//  trigger.cpp; finche' non c'e' una trigger_configure() pubblica, qui usiamo
//  g_mount_orientation (gia' extern) e lasciamo il trigger ai suoi default —
//  che COINCIDONO coi default del config. Quando aggiungeremo trigger_configure,
//  questa funzione la chiamera'. Per ora l'unico effetto vivo e' il montaggio.
void config_apply() {
  // Montaggio: g_mount_orientation e' letto dall'imu_task. Lo allineiamo al
  // config. (E' l'unico parametro che cambia comportamento gia' in questo passo.)
  g_mount_orientation = g_config.mount_orientation;

  DBG("CFG applicato: mount=%u trig_thr=%.1f confirm=%u rearm=%u pre=%u post=%u",
      g_config.mount_orientation, g_config.trig_threshold_ms2,
      g_config.trig_confirm_n, g_config.trig_rearm_ms,
      g_config.window_pre_ms, g_config.window_post_ms);
}
