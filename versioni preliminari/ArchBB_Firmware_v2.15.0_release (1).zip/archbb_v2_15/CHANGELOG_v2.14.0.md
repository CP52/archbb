# ArchBB — Firmware v2.14.0 (WS-1.69)

## Metrica HOLD (follow-through) + canale temperatura

Origine: analisi della sessione **14 luglio 2026** (44 tiri, 42 utili).
Tutto ciò che segue è tarato su **dati misurati**, non su valori scelti a tavolino.

---

## 1. Nuova metrica: `hold_deg`

**Cos'è:** variazione dell'angolo di elevazione a **+900 ms** dallo scocco,
rispetto all'assetto di mira. Negativo = braccio abbassato.

**Perché serve:** incrociata con l'esito dà la diagnosi, ed è per questo che
compare **prima** dello scoring:

| | TENUTO | ABBASSATO |
|---|---|---|
| **mancato** | errore di stima distanza/drop (gesto ok) | errore di esecuzione |
| **colpito** | tiro buono (replicabile) | fortuna/compensazione |

**Come si calcola:**
1. la finestra calma pre-scocco (già cercata per cant/alzo) dà il **bias del gyro**
   — lì l'arco è fermo, quindi tutto ciò che `gy` legge *è* bias (principio ZUPT);
2. si integra `gy` bias-corretto per 900 ms dal trigger, **trapezoidale**, con
   `dt` reale preso dai timestamp.

**Costo:** ~40 righe, zero memoria aggiuntiva (i campioni sono già nel circular
buffer), una sola passata sui campioni post-scocco.

---

## 2. Perché il giroscopio e non `atan2(az,ax)`

Dopo il rilascio l'accelerometro è dominato dal rinculo del riser (ampiezza ≫ g):
`atan2` è inutilizzabile nel post-scocco. Il giroscopio misura velocità angolare —
il rinculo la perturba ma non la satura (picco misurato |gy| ≈ 50 dps su 512 di
fondo scala). L'integrazione è **l'unica strada** nel post.

---

## 3. Perché `dt` reale e non `1/ODR`

**Misura (44 burst):** il campionamento **non è a passo costante**, alterna
**4005 e 5005 µs**. È il tick FreeRTOS da 1 ms che batte contro il periodo ideale
di 4448 µs: il polling di `getDataReady()` non può cadere a metà tick.

- `dt` **mediano** → 249.69 Hz (**fuorviante**: cade sul valore più frequente)
- `dt` **medio** → **224.91 Hz** (vero)
- durata burst 2.9835 s, **sd 0.5 ms su 44 tiri** → nessuna deriva accumulata

Non è un difetto: è jitter deterministico. Ma integrare con `dt` costante
accumula errore lungo i 900 ms, quindi si usa `timestamp_us` campione per
campione — è già dentro `ImuSample`, costo zero.

---

## 4. Soglie: **4° / 8°**, non 3° / 6°

La proposta iniziale era 3/6. **Il dato l'ha bocciata.**

Il rumore di integrazione è stato **quantificato** con un test a vuoto: si
integra `gy` per ~1 s *dentro* la finestra pre-scocco (arco fermo → angolo vero
= 0), e tutto ciò che si legge **è** l'errore.

```
|deriva| media 1.03°   mediana 0.97°   p95 2.10°   max 2.45°
```

Una soglia "tenuto" a 3° starebbe **dentro il rumore**: il 70% del budget se lo
mangia lo strumento. Nuove soglie ancorate al p95 misurato:

| classe | soglia | razionale |
|---|---|---|
| TENUTO | ≤ 4° | ~2× p95 |
| LIEVE | 4–8° | zona grigia |
| ABBASSATO | > 8° | ~4× p95 → zero falsi positivi |

**Il bias non è il collo di bottiglia — il rumore lo è.** Misurato:

```
bias su 249ms  -> p95 2.81°
bias su 996ms  -> p95 2.10°
bias globale di sessione (stima imbattibile) -> p95 1.89°
```

Rimuovere il bias guadagna solo **1.4×**. ~2° è il **floor fisico** del QMI8658
a 512 dps su 1 s: non c'è calibrazione che scenda sotto.

---

## 5. `hold_deg` e non la pendenza

La firma temporale osservata sul campo è confermata statisticamente:

| variabile | TENUTI | ABBASSATI | Mann-Whitney |
|---|---|---|---|
| strappo iniziale (30 ms) | +0.66° | +1.22° | p=0.086 **non discrimina** |
| pendenza 150–900 ms | −3.04 °/s | −18.85 °/s | **p=0.0001 discrimina** |

Verrebbe da implementare la pendenza. **Il dato dice di no:**

```
hold_deg : tenuti [-3.9 .. +2.4] | abbassati <= -8.5  -> GAP PULITO
pendenza : tenuti fino a -13.2   | abbassati fino a -3.8 -> SOVRAPPONE
correlazione: r = 0.892
```

Il **tiro 15** aveva pendenza −13.2 °/s (peggiore di 4 "abbassati") ma
`hold_deg` −2.7: era sceso e **rientrato**. Conta dove sei alla fine, non come ci
sei arrivato. La pendenza non aggiunge informazione — aggiunge falsi positivi.

**SNR finale: 6.1×** (gap 12.85° contro rumore p95 2.10°), separazione pulita.

---

## 5-bis. Le due soglie NON hanno la stessa affidabilità

Va capito prima di fidarsi di una classificazione.

**Soglia 8° (LIEVE|ABBASSATO) — SOLIDA**

```
tenuto peggiore     : -3.83
abbassato migliore  : -8.85
gap                 :  5.02°  = 2.4x il p95 del rumore
```

Nessuna sovrapposizione. La distinzione TENUTO vs ABBASSATO — **l'unica che
conta per la diagnosi** — è affidabile.

**Soglia 4° (TENUTO|LIEVE) — FRAGILE PER COSTRUZIONE**

**21 tiri su 42** cadono nella fascia `[1.9 .. 6.1]`, cioè entro ±p95 dalla
soglia: per quei tiri il rumore *può* cambiare la classe.

Non è un difetto da correggere — è una **proprietà del dato**. La distribuzione
ha il picco proprio lì:

```
0-2 (sicuro tenuto)  10  ##########
2-4 (tenuto)         14  ##############
4-6 (lieve)           7  #######
6-8 (lieve)           3  ###
8-12 (abbassato)      5  #####
>12 (grave)           3  ###
```

**Conseguenze pratiche:**
- LIEVE va letto come *"zona grigia"*, non come un verdetto. Un tiro a −4.2 e uno
  a −3.8 sono lo stesso tiro, misurato due volte.
- Per confronti fini fra tiri della stessa classe usare il **valore numerico**,
  non l'etichetta. Per questo il display mostra entrambi.
- Se due esecuzioni della stessa analisi classificano diversamente un tiro vicino
  ai 4°, **non è necessariamente un bug**: è il rumore. Verificare sul **gap**,
  non sui confini.

*(Esempio reale: il tiro 37 risulta TENUTO al firmware (−3.49) e LIEVE allo
script offline (−5.89). Causa: il firmware dimensiona la finestra con
`odrToHz()` = 224 Hz nominali → 44 campioni; lo script usava i 224.91 Hz
misurati → 45 campioni. Un campione di differenza sposta la finestra calma
scelta, quindi il bias, quindi hold. Non è un errore di nessuno dei due: il
firmware è coerente con la propria costante. Ma illustra bene quanto sia sottile
il confine dei 4°.)*

---

## 6. Ipotesi testate e BOCCIATE

**«Abbassare il fondo scala a 128 dps per ridurre il rumore»** → il dato dice no:
`|gyro|` max misurato = **243 dps** (su gx, anche in fase di mira). 128 saturerebbe
su 258 campioni, 256 avrebbe solo 1.05× di margine. **512 dps resta, non si tocca.**

**«Chiamare `calibration()` di SensorLib all'avvio»** → il COD del QMI8658 calibra
il **gain**, non l'offset: non risolverebbe. In più è 1.6 s bloccanti e va rifatto
ad ogni cambio di temperatura. La stima per-tiro dalla finestra calma è superiore:
compensa la deriva termica automaticamente.

**Anomalia rilevata (non impatta hold):** bias `gx` = +4.27 dps, `gz` = +4.18 dps,
`gy` = +0.42 dps. gx e gz hanno un offset ~10× quello di gy (t-test gx vs gz:
p=0.82, indistinguibili tra loro), **costante** — non deriva in 45 min di sessione
(p=0.26/0.57/0.19). È offset di fabbrica di questo esemplare. `hold_deg` usa `gy`:
non ne soffre. **Conseguenza pratica: lo strappo laterale (gz integrato) NON è
misurabile a 900 ms** — SNR 0.5×, il segnale sta sotto il rumore.

---

## 7. `pressure_hpa` → `temp_c` (canale morto riusato)

Il `BurstHeader` aveva un `float pressure_hpa` che **nessun sensore alimentava**:
il BMP280 non è mai stato montato, `ble_server.cpp` ci scriveva la costante
`0.0f`, e nel CSV della sessione 14JUL c'erano **29.568 campioni tutti a zero**.

Nel frattempo `imu_read_temperature()` esisteva già in `imu.cpp` e **nessuno la
chiamava**.

Ora quel campo porta la temperatura dell'IMU. **Stesso tipo, stesso offset (19),
stessa lunghezza del BurstHeader (24 byte)**: zero impatto sul protocollo.

**Perché serve:** il bias del gyro MEMS dipende dalla temperatura. La sessione
14JUL non ha mostrato deriva termica, ma la scheda era già a regime. Una sessione
invernale a 5 °C contro una estiva a 35 °C è un test finora **impossibile da
fare**: senza il canale non c'è nemmeno il dato.

---

## 8. Protocollo

**`ScorePacket`: 10 → 13 byte**, `SCORE_FORMAT_VERSION` 1 → 2.

```
pkt_type(1) + shot_id(2) + score_flags(1) + distanza_m(1)
+ cant_cdeg(2) + alzo_cdeg(2) + hold_cdeg(2) + hold_class(1) + score_ver(1) = 13
```

13 è **libera** (occupate: 6/8/9/15/24/30) → la discriminazione per lunghezza
esatta resta valida. Verificato con `static_assert` e con test host su offset.

`hold_class`: 0=TENUTO 1=LIEVE 2=ABBASSATO 3=ALZATO **4=N/D**.
La classe 4 è la **sentinella**, non `hold=0`: zero è un valore *legittimo e
ottimo* (follow-through perfetto), non può segnalare "non misurato".

---

## 9. Display

Banda **HOLD** in cima alla schermata ESITO: valore + etichetta, colore
verde/ambra/rosso coerente col codice colore già in uso.

L'ordine è il punto: vedere "ABBASSATO" **mentre** si sta per premere MANCATO dà
la diagnosi immediata. Se il dato arrivasse solo nell'app a casa, il nesso col
gesto appena compiuto andrebbe perso.

I semicampi tattili sono ristretti (`top = HOLD_BAND_H+1`) e il touch ha ora il
vincolo `ty > HOLD_BAND_H`: un dito appoggiato sulla banda **non** registra più
un esito per errore.

---

## 10. Validazione

**Test host** (`test_hold.cpp`): la logica reale di `shot_angles.cpp` compilata e
girata sui 42 tiri, confrontata col riferimento Python.

```
hold : diff max 0.000048°   [IDENTICI]
cant : diff max 0.000049°   [IDENTICI]
alzo : diff max 0.000047°   [IDENTICI]
classificazione: TENUTO 24 | LIEVE 10 | ABBASSATO 8 | ALZATO 0 | N/D 0
```

**Test protocollo**: dimensioni, unicità delle lunghezze, offset — tutti OK.
**Test end-to-end**: ScorePacket serializzati in C++ e parsati con la logica JS
dell'app → 4/4, più retrocompatibilità v1 (10 byte) e rifiuto di lunghezze non
valide.

> **Nota metodologica:** durante la verifica il mio script Python di analisi
> usava passo 8 nella ricerca della finestra adattiva, il firmware passo 1.
> Divergevano. Il firmware era **più corretto** (ricerca esaustiva). Allineato il
> Python, coincidono a 5×10⁻⁵.

---

## 11. Stato di validazione — cosa manca

**`hold_deg` è validata come misura** (SNR 6.1×, separazione pulita).
**NON è validata come predittore dell'esito.**

```
5/5 TENUTI    -> colpito
1/1 ABBASSATO -> mancato
```

Direzione giusta, ma su **11 tiri su 44 con esito** e **2 soli mancati**:
statisticamente non conclusivo.

**Serve una sessione con esito su TUTTI i tiri** — con la 2.13.0 i problemi di
scrittura sul campo sono risolti, quindi ora è possibile.

**E prima di ogni sessione: CALIBRA A LIVELLA.** Il cant medio della 14JUL era
−4.8° contro i −5.1° del test statico a banco: coincidono. Un arciere non tiene
5° di cant sistematico — è offset di montaggio, e senza calibrazione i dati se lo
portano addosso.

---

## File modificati

| file | modifica |
|---|---|
| `config.h` | v1.3: ScorePacket 13B, temp_c, SCORE_FORMAT_VERSION=2, FW 2.14.0 |
| `shot_angles.h` | v1.3: HoldClass, campi hold in ShotAngles, soglie, doc |
| `shot_angles.cpp` | v1.3: `integrate_gy()`, `classify_hold()`, `hold_class_name()` |
| `scoring.h` | campi hold in PendingScore |
| `ble_server.cpp` | temp_c nell'header, hold nel pending e nello ScorePacket |
| `scoring_ui.cpp` | banda HOLD + protezione touch |
