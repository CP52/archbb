# DIAG ASSI — quale montaggio descrive la scheda sul riser

**26 luglio 2026 · env `archbb_183_assi`**

---

## Il problema, in una tabella

Sessione 1.83 del 25/07, nove tiri su sagoma 3D a terra, tirando verso il basso:

| grandezza | valori | media | σ |
|---|---|---|---|
| `atan2(ay,ax)` — chiamata **cant** | 17,07 · 17,16 · 17,34 · 17,37 · 16,98 · 16,36 · 15,86 · 16,34 · 18,32 | **+16,98°** | 0,72° |
| `atan2(az,ax)` — chiamata **alzo** | −0,04 · +1,65 · +0,44 · −2,44 · +1,61 · +0,13 · +0,60 · +0,52 · +1,07 | **+0,39°** | 1,22° |

Una è un assetto **tenuto** a 17° con 0,7° di ripetibilità. L'altra oscilla
attorno a zero di un paio di gradi. Nessun arciere ruota il braccio d'arco di
17°: quello è l'**alzo**, e il paio di gradi è il **cant** involontario. Le due
etichette sono scambiate.

## La prova incrociata

I 44 tiri della 1.69 hanno **distanze diverse**, e l'alzo con la distanza deve
crescere mentre il cant no. Sugli 11 tiri con punteggio:

| | 14 m | 18 m | 20 m | 30 m | 40 m | ρ con la distanza |
|---|---|---|---|---|---|---|
| `atan2(ay,ax)` | −3,5 | −3,1 | −8,4 | −4,4 | −4,5 | −0,09 (p 0,80) |
| `atan2(az,ax)` | +2,2 | +7,9 | +5,3 | +16,8 | +14,6 | **+0,53** (p 0,09) |

Sulla 1.69 le etichette sono giuste. Sulla 1.83 il rapporto è invertito:
**y e z sono scambiati fra le due schede.**

## Perché la caratterizzazione del 22/07 non l'aveva vista

Quella caratterizzazione concluse *«in posizione 0 gli assi hanno i ruoli
giusti, nessuno scambio»*, e introdusse il flip-Z. Era corretta **per la posa in
cui fu fatta** — al banco. Il montaggio reale sul riser è un'altra cosa, e
nessuno dei due si deduce dall'altro.

Da qui la regola operativa: **si misura con la scheda montata come si tira.**

## Cosa fa il DIAG

Tre pose statiche, catturate da sole quando l'arco sta fermo. La cattura è
automatica e non a tocco per una ragione pratica: toccare il display muove
l'arco, e la posa che vuoi misurare è proprio quella indisturbata.

### La taratura all'avvio (v2)

All'accensione il DIAG **sta zitto tre secondi e misura il rumore di fondo** del
tuo esemplare sul tuo supporto, poi fissa le soglie a quattro volte quel valore.
Le soglie non si indovinano, si misurano — la stessa logica dello ZUPT usato per
il bias del giroscopio.

La v1 aveva soglie fisse, e non scattava mai. Due errori distinti:

**1. Il giroscopio ha un offset di fabbrica, e io guardavo il modulo.** Misurato
sulle finestre calme dei nove tiri del 25/07: |gyro| medio **8,26 dps**, con bias
per asse gx −2,47, gy −6,11, gz −0,14. La soglia era 2,0 dps sul modulo:
irraggiungibile *per costruzione*, perché il bias non sparisce stando fermi.

La cura non è alzare la soglia, è guardare la grandezza giusta. **Un corpo fermo
ha giroscopio costante, non nullo.** Ora si misura la dispersione per asse, che
dell'offset non sa nulla, e si prende la peggiore delle tre — basta un asse che
si muove perché la posa non sia ferma.

**2. Anche la soglia sull'accelerometro era troppo stretta:** sd di |a| misurata
0,216 m/s² in mira, contro i 0,08 che chiedevo.

### Sullo schermo si vede quale criterio blocca

```
ACC 0.012 / 0.050  ok
GYR 0.87  / 0.60   --
```

Nella v1 mostravo due numeri senza dire quale fermava la cattura: chi guarda lo
schermo non può indovinarlo, e la diagnosi diventa impossibile proprio quando
serve.

### Ripiego manuale

Se dopo 8 secondi non è scattata, il tocco cattura comunque. Su cavalletto
toccare non è un problema, restare bloccati sì. Resta un ripiego, e lo schermo lo
dichiara: il seriale marca la posa come `MANUALE`.

| posa | come | cosa rivela |
|---|---|---|
| **1 · a piombo** | arco verticale, freccia orizzontale | l'offset del supporto, che viene sottratto |
| **2 · punta in basso** | abbassa la punta di ~20° | l'asse che raccoglie la gravità è quello della **freccia**, con segno negativo |
| **3 · riser a destra** | inclina il riser a destra di ~20° | l'asse che la raccoglie è quello **laterale**, con segno positivo |

Poi prova **tutte le otto combinazioni** (4 rotazioni × flip-Z on/off) e dice
quale le soddisfa, col margine sul secondo classificato.

**Non serve un angolo preciso.** Il verdetto non usa il valore dell'angolo, solo
quale asse lo raccoglie e con che segno. Bastano due pose fatte a occhio.

**Le pose 2 e 3 si valutano come differenza dalla posa 1**, così l'inclinazione
del supporto sparisce e non serve che l'arco sia perfettamente a piombo.

## Verifica su host, prima del flash

Ho simulato tutte e otto le verità fisiche possibili, generando cosa leggerebbe
il sensore in ciascun caso e controllando che il DIAG la riconosca:

```
8/8 corretti, margine 40,0                              (pose pulite a 20°)
8/8 corretti, margine 34,0    supporto storto (+9° alzo, −5° cant),
                              pose sbavate di ±4°
8/8 corretti, margine  4,0    caso severo: pose di soli 8°
```

L'ultimo caso scende sotto la soglia di allarme (5,0) e il DIAG lo segnala come
**margine risicato**, invece di spacciare per buono un verdetto fragile. La
soglia è tarata lì per questo.

## Uso

```
pio run -e archbb_183_assi -t upload
pio device monitor -b 115200
```

Seleziona l'ambiente **esplicitamente** nella barra di stato di VS Code prima di
Upload: il pulsante ▶ generico usa il default, che è la produzione.

Poi monta la scheda sul riser **come quando tiri** e segui le istruzioni a
schermo. Un tocco rifà la posa corrente; a verdetto raggiunto, un tocco
ricomincia da capo. Il monitor seriale stampa tutti e otto i candidati ordinati,
non solo il vincitore.

## Cosa aspettarsi

Applicando i candidati ai dati veri del 25/07, due soli danno la struttura
giusta (cant piccolo, alzo ~17°):

```
MOUNT_DX_M90  flip ON    cant −0,39° ± 1,22    alzo +16,98° ± 0,72
MOUNT_SX_P90  flip ON    cant +0,39° ± 1,22    alzo −16,98° ± 0,72
```

Tirando verso il basso l'alzo dev'essere **negativo** (convenzione: positivo =
punta in su), quindi il candidato atteso è `MOUNT_SX_P90`. Ma l'offset del
supporto entra nel valore assoluto, quindi il segno va letto dal DIAG, non da
qui — è esattamente ciò per cui esiste.

**Se il verdetto è una delle due rotazioni a 90°, la correzione è una voce di
configurazione, non una modifica al codice.** Il sistema dei montaggi ha già lo
scambio y↔z: `MOUNT_DX_M90` fa `cay=−az, caz=ay`.

## Nota tecnica: niente matrici duplicate

Il DIAG chiama `mount_apply_ex()`, la stessa funzione del firmware con il flip-Z
passato come parametro invece che fissato a compilazione. `mount_apply()` è ora
un rinvio a una riga.

Riscrivere le quattro matrici dentro il DIAG sarebbe stata la duplicazione più
pericolosa possibile: due copie della stessa geometria, e il giorno che una
cambia il DIAG certifica un montaggio che il firmware non applica. Una sola
implementazione, due punti d'ingresso.

## Quello che va rifatto dopo il verdetto

- **`hold_cdeg` misura l'asse sbagliato.** È l'integrale di `gy`; se y è l'asse
  freccia, `gy` è la velocità di rollio, non l'abbassamento del braccio d'arco.
  Con il montaggio corretto il problema si risolve da solo, perché la
  trasformazione avviene a monte.
- **Manca la taratura a piombo** che la 1.69 aveva (azzeramento di cant e alzo
  assoluti, offset persistiti). Finché non c'è, solo le **variazioni** sono
  affidabili — il che per le metriche di dispersione basta, ma va scritto.
- **Il quadrante del cant nell'app v0.2 va rifatto**: σ = 0,72° che ci ho messo
  al centro è la dispersione dell'**alzo**. Il cant vero ha σ = 1,22°.

---

## Parte 2 — Prova dinamica: gli assi del GIROSCOPIO

Si avvia con un tocco sul verdetto delle pose statiche.

### Perché non bastano le pose

Le tre pose a gravità nota validano l'**accelerometro**. Una posa statica ha
velocità angolare **zero**: non dice assolutamente nulla sul giroscopio.

Se gli assi del giroscopio fossero permutati rispetto a quelli
dell'accelerometro, cant e alzo continuerebbero a uscire giusti — vengono
dall'accelerometro — e nessuna prova statica se ne accorgerebbe. Ma tutto ciò
che si **integra** — traccia 2D, hold, torsione — dipende dal giroscopio, e
sbaglierebbe in silenzio.

È il dubbio nato guardando la traccia della seduta del 27/07: durante il
rilascio il movimento grosso sta su `gx` (−4,28° medio) e non su `gy` (−2,53°),
mentre l'intuizione dell'arciere dice che il movimento ampio dovrebbe essere
l'alzo. Dai dati di tiro non si risolve.

### I tre movimenti

| | come | l'accelerometro lo vede? |
|---|---|---|
| **1 · ALZO** | abbassa la punta di ~30° | sì, la gravità si sposta |
| **2 · CANT** | rolla il riser a destra di ~30° | sì |
| **3 · YAW** | ruota l'arco a destra, punta orizzontale | **no** |

Un solo verso, non avanti-e-indietro: un movimento che torna al punto di
partenza ha integrale nullo e non direbbe niente.

I primi due fanno da **controprova indipendente**: l'asse del giroscopio che
integra la stessa escursione misurata dall'accelerometro è quello giusto. Il
terzo l'accelerometro non lo vede — ed è esattamente il motivo per cui serve il
giroscopio — quindi si conclude per esclusione.

### Come funziona

- **Bias fresco prima di ogni movimento.** Non si riusa quello della taratura
  iniziale: fra un movimento e l'altro passano decine di secondi e l'offset del
  giroscopio deriva con la temperatura. Lo schermo dice `tieni fermo` finché non
  ce l'ha, poi `pronto - muovi`.
- **Inizio e fine automatici**: sopra 12 dps parte, sotto 4 dps per mezzo
  secondo finisce. Integrazione a dt reale.
- **Movimenti sotto i 12° vengono rifiutati** (`TROPPO POCO`) invece di essere
  registrati: sotto quella soglia il rumore pesa quanto il gesto.

### Il verdetto

Atteso con il frame canonico: **alzo → `gy`**, **cant → `gz`**, **yaw → `gx`**.
Ogni riga è verde se l'asse dominante è quello atteso, rossa altrimenti, e
accanto c'è la controprova dell'accelerometro.

Se esce **`assi NON come attesi`**, mandami i numeri del monitor seriale: serve
un rimappaggio del giroscopio, e i tre integrali dicono esattamente quale.
