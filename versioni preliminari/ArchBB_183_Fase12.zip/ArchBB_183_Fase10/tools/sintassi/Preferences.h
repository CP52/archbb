#pragma once
#include <Arduino.h>
class Preferences { public:
  bool begin(const char*, bool readOnly = false); void end();
  bool clear(); bool remove(const char*);
  size_t putBytes(const char*, const void*, size_t);
  size_t getBytes(const char*, void*, size_t);
  size_t getBytesLength(const char*);
  size_t putUInt(const char*, uint32_t); uint32_t getUInt(const char*, uint32_t d = 0);
  bool isKey(const char*);
};
