#!/bin/sh
# ============================================================================
#  ArchBB — controllo di sintassi senza toolchain ESP32
# ----------------------------------------------------------------------------
#  A COSA SERVE
#    Compilare per ESP32 richiede la toolchain completa e un paio di minuti.
#    Questo banco usa g++ con stub minimi di Arduino.h / TFT_eSPI.h / FreeRTOS
#    e fa un -fsyntax-only in gnu++11 — lo STESSO standard del core Arduino-ESP32.
#    Non sostituisce la build vera: non linka, non vede gli header veri delle
#    librerie. Ma intercetta in due secondi gli errori di linguaggio, che sono
#    la maggioranza di quelli che si fanno scrivendo.
#
#  PERCHE' gnu++11 E NON PIU' RECENTE
#    E' lo standard con cui il core compila. Provare in C++17 darebbe per buone
#    cose che sul dispositivo non passano — ad esempio l'inizializzazione con
#    graffe di una struct che ha inizializzatori di default sui membri: legale
#    da C++14, errore in C++11. E' esattamente l'errore che ha motivato questo
#    banco.
#
#  USO   sh tools/sintassi/controlla.sh          (dalla radice del progetto)
# ============================================================================
STUB="$(dirname "$0")"
SRC="$(dirname "$0")/../../src"
STD="-std=gnu++11 -Wall -Wextra -fsyntax-only"
esito=0

prova() {
  file="$1"; shift
  printf "  %-28s " "$(basename "$file")"
  if g++ $STD -I"$STUB" -I"$SRC" "$@" "$file" 2>/tmp/archbb_sint.log; then
    if [ -s /tmp/archbb_sint.log ]; then echo "ok (con warning)"; cat /tmp/archbb_sint.log | head -6
    else echo "ok"; fi
  else
    echo "ERRORE"; head -12 /tmp/archbb_sint.log; esito=1
  fi
}

echo "Controllo di sintassi (gnu++11)"
prova "$SRC/main_diag_assi.cpp" -D ARCHBB_DIAG_ASSI=1 -D ARCHBB_HW_FLIP_Z=0
prova "$SRC/mount.cpp"
prova "$SRC/shot_angles.cpp"
prova "$SRC/sd_storage.cpp"
prova "$SRC/ble_service.cpp"
prova "$SRC/config_store.cpp"
prova "$SRC/scoring.cpp"
prova "$SRC/circular_buffer.cpp"
prova "$SRC/main.cpp"
prova "$SRC/display.cpp"

# NON coperti: touch.cpp, imu.cpp, battery.cpp, rtc_clock.cpp, config_ui.cpp,
# touch_cal.cpp. Dipendono da librerie hardware (SensorLib/QMI8658, driver del
# PMU) e da define che arrivano dai build_flags di PlatformIO. Stubbarli
# costerebbe piu' della copertura che darebbero: sono file stabili, che non si
# toccano da mesi. Se un giorno li si modifica, si compila per davvero.
prova "$SRC/mount.cpp" -D ARCHBB_HW_FLIP_Z=0   # anche col flip spento
exit $esito
