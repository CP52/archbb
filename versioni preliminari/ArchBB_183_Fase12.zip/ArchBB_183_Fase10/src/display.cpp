// ============================================================================
//  ArchBB 1.83 — display.cpp · FASE 1 (bring-up ST7789V2) · v2
//  Cesare Pagura · Padova/Noale IT · 11 luglio 2026
// ----------------------------------------------------------------------------
//  CORREZIONE v2 — la banda bianca in alto ("i dati comandano"):
//  In v1 applicavo l'offset y=20 con setViewport(0,20,240,284). ERRORE:
//  setViewport NON sposta l'indirizzamento della GRAM del controller, ritaglia
//  solo l'area di disegno SOFTWARE dentro un frame gia' mappato. Cosi' facendo
//  sommavo un secondo offset a quello che TFT_eSPI applica gia' via CGRAM_OFFSET
//  + setRotation, e la fascia 0..20 restava SCOPERTA -> GRAM non inizializzata
//  visibile = i ~20 pixel bianchi che vedevi in cima.
//
//  Fix corretto: RIMOSSO setViewport. L'offset di pannello e' responsabilita'
//  del driver (CGRAM_OFFSET nel .ini + dimensioni 240x284). La doc TFT_eSPI:
//  "gli offset sono determinati in setRotation e applicati a ogni operazione
//  grafica" e "puo' servire chiamare setRotation DOPO init() perche' si
//  applichino". Quindi: init() -> setRotation() -> fillScreen(), e basta.
//  Le coordinate (0,0) del disegno corrispondono al primo pixel visibile:
//  l'offset e' gestito dentro la libreria, trasparente al resto del codice.
// ============================================================================
#include "display.h"
#include "scoring.h"       // v2.16: elevIsSet/ELEV_NOT_SET per il riepilogo
#include "shot_angles.h"   // FASE 4c: nomi classi hold/release, shot_angle_to_cdeg
#include "mount.h"         // FASE 4c: mount_apply per il DIAG a 4 montaggi
#include <math.h>

// Istanza display condivisa (dichiarata extern in display.h). Scoring e altri
// moduli disegnano su questa stessa istanza.
TFT_eSPI tft = TFT_eSPI();

// ----------------------------------------------------------------------------
//  Backlight su GPIO diretto (TFT_BL=40).
// ----------------------------------------------------------------------------
void displayBacklight(bool on) {
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, on ? HIGH : LOW);   // active-high (da verificare su HW)
}

// ----------------------------------------------------------------------------
//  Inizializzazione completa.
// ----------------------------------------------------------------------------
void displayInit() {
  // 1) Backlight PRIMA dell'init.
  displayBacklight(true);

  // 2) Init libreria: reset HW (TFT_RST=38), sequenza ST7789, applica
  //    TFT_INVERSION_ON e TFT_RGB_ORDER=TFT_BGR dai -D.
  tft.init();

  // 3) setRotation DOPO init: e' QUI che TFT_eSPI applica l'offset CGRAM.
  //    Con CGRAM_OFFSET + TFT_HEIGHT=284, la libreria mappa la coordinata
  //    software (0,0) sulla riga fisica corretta. Nessun setViewport.
  tft.setRotation(0);   // portrait nativo 240x284

  // 4) Pulizia a nero SU TUTTA l'area: ora copre anche l'ex-fascia bianca.
  tft.fillScreen(ArchColor::BG);
}

// ----------------------------------------------------------------------------
//  displaySplash — "ciao mondo" ArchBB.
// ----------------------------------------------------------------------------
void displaySplash() {
  tft.fillScreen(ArchColor::BG);

  // Cornice: se l'offset e' giusto, il bordo superiore e' visibile e attaccato
  // al bordo del vetro, SENZA banda bianca sopra.
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);
  tft.drawRect(2, 2, ARCHBB_W - 4, ARCHBB_H - 4, ArchColor::ACCENT);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ArchBB", ARCHBB_W / 2, 70, 4);

  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString("1.83  Fase 1", ARCHBB_W / 2, 110, 2);

  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("bring-up display", ARCHBB_W / 2, 140, 2);
  tft.drawString("ST7789V2  240x284", ARCHBB_W / 2, 160, 2);

  const int cx = ARCHBB_W / 2, cy = 215;
  tft.drawCircle(cx, cy, 34, ArchColor::TEXT3);
  tft.drawCircle(cx, cy, 22, ArchColor::TEXT2);
  tft.fillCircle(cx, cy, 8,  ArchColor::BAD);   // "10" centrale, ora rosso vero
  tft.drawFastHLine(cx - 44, cy, 88, ArchColor::BORDER);
  tft.drawFastVLine(cx, cy - 44, 88, ArchColor::BORDER);
}

// ----------------------------------------------------------------------------
//  displayOffsetTest — verifica CHIRURGICA dell'offset verticale.
// ----------------------------------------------------------------------------
//  Riempie di nero, poi disegna:
//   - una riga BIANCA spessa 3px ESATTAMENTE sulla prima riga (y=0..2)
//   - una riga BIANCA spessa 3px ESATTAMENTE sull'ultima riga (y=281..283)
//  Se l'offset e' perfetto: vedi entrambe le righe attaccate ai bordi vetro,
//  niente bianco extra sopra, niente taglio sotto. Se resta bianco sopra la
//  riga alta -> offset ancora sbagliato. Se la riga bassa e' tagliata ->
//  altezza < 284. E' il test che isola il SOLO problema geometrico.
// ----------------------------------------------------------------------------
void displayOffsetTest() {
  tft.fillScreen(ArchColor::BG);
  tft.fillRect(0, 0,            ARCHBB_W, 3, ArchColor::TEXT);   // top
  tft.fillRect(0, ARCHBB_H - 3, ARCHBB_W, 3, ArchColor::TEXT);   // bottom
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("OFFSET TEST", ARCHBB_W / 2, ARCHBB_H / 2 - 10, 4);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("righe bianche = bordi", ARCHBB_W / 2, ARCHBB_H / 2 + 20, 2);
  tft.drawString("niente bianco extra?", ARCHBB_W / 2, ARCHBB_H / 2 + 38, 2);
}

// ----------------------------------------------------------------------------
//  displayDiagnosticPattern — verifica a occhio i 6 rischi §6.
// ----------------------------------------------------------------------------
void displayDiagnosticPattern() {
  tft.fillScreen(ArchColor::BG);

  const int barH = 40, barY = 30;
  tft.fillRect(10,  barY, 60, barH, TFT_RED);
  tft.fillRect(90,  barY, 60, barH, TFT_GREEN);
  tft.fillRect(170, barY, 60, barH, TFT_BLUE);

  tft.setTextDatum(TC_DATUM);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString("R",  40,  barY + barH + 4, 2);
  tft.drawString("G", 120,  barY + barH + 4, 2);
  tft.drawString("B", 200,  barY + barH + 4, 2);

  tft.drawFastHLine(0, 0,            ARCHBB_W, TFT_YELLOW);      // top
  tft.drawFastHLine(0, ARCHBB_H - 1, ARCHBB_W, TFT_MAGENTA);    // bottom
  tft.drawFastVLine(0, 0,            ARCHBB_H, TFT_CYAN);        // left
  tft.drawFastVLine(ARCHBB_W - 1, 0, ARCHBB_H, TFT_ORANGE);     // right

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  tft.drawString("DIAGNOSTICA S6", ARCHBB_W / 2, 130, 2);

  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("giallo=top magenta=bot", ARCHBB_W / 2, 155, 2);
  tft.drawString("ciano=sx arancio=dx",    ARCHBB_W / 2, 172, 2);
  tft.drawString("sfondo NERO, R-G-B ok?", ARCHBB_W / 2, 189, 2);

  for (int i = 0; i < 30; i++) {
    uint8_t v = map(i, 0, 29, 0, 255);
    tft.drawFastHLine(20, 210 + i, ARCHBB_W - 40, tft.color565(v, v, v));
  }
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("gradiente: liscio?", ARCHBB_W / 2, 255, 2);
}

// ----------------------------------------------------------------------------
//  displayEsito — banco di prova scoring.
// ----------------------------------------------------------------------------
void displayEsito(bool good) {
  const uint16_t bg  = good ? ArchColor::GOOD : ArchColor::BAD;
  const char*    txt = good ? "CENTRO" : "FUORI";
  const char*    sub = good ? "colpo valido" : "fuori bersaglio";

  tft.fillScreen(bg);
  tft.fillRect(0, 0, ARCHBB_W, 40, ArchColor::BG);
  tft.fillRect(0, ARCHBB_H - 40, ARCHBB_W, 40, ArchColor::BG);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ESITO TIRO", ARCHBB_W / 2, 20, 2);

  tft.setTextColor(ArchColor::TEXT, bg);
  tft.drawString(txt, ARCHBB_W / 2, ARCHBB_H / 2 - 10, 6);

  tft.setTextColor(ArchColor::TEXT, bg);
  tft.drawString(sub, ARCHBB_W / 2, ARCHBB_H / 2 + 35, 2);

  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("ArchBB 1.83", ARCHBB_W / 2, ARCHBB_H - 20, 2);
}

// ============================================================================
//  FASE 2 — banco di prova touch (rendering)
// ============================================================================

// Zone di layout del banco di prova (coordinate fisse).
static constexpr int TT_TITLE_Y = 16;
static constexpr int TT_DATA_Y  = 55;    // inizio blocco dati testuali
static constexpr int TT_ROW_H   = 26;    // passo verticale righe dati
static constexpr int TT_AREA_Y0 = 165;   // inizio area "touchpad" visiva
static constexpr int TT_AREA_Y1 = ARCHBB_H - 8;

// Memoria dell'ultimo crocino per cancellarlo senza ridisegnare tutto.
static int  s_lastCrossX = -1, s_lastCrossY = -1;

// Disegna la cornice fissa (chiamata una volta).
void displayTouchTestFrame() {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("TOUCH CST816", ARCHBB_W / 2, TT_TITLE_Y, 4);

  // Etichette statiche a sinistra; i valori li aggiorna displayTouchUpdate.
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("X:",   12, TT_DATA_Y + TT_ROW_H * 0, 4);
  tft.drawString("Y:",   12, TT_DATA_Y + TT_ROW_H * 1, 4);
  tft.drawString("dita:", 12, TT_DATA_Y + TT_ROW_H * 2, 2);
  tft.drawString("gest:", 12, TT_DATA_Y + TT_ROW_H * 3, 2);

  // Riquadro dell'area "touchpad" visiva dove appare il crocino.
  tft.drawRect(6, TT_AREA_Y0, ARCHBB_W - 12, TT_AREA_Y1 - TT_AREA_Y0,
               ArchColor::BORDER);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("tocca qui", ARCHBB_W / 2, (TT_AREA_Y0 + TT_AREA_Y1) / 2, 2);

  s_lastCrossX = s_lastCrossY = -1;
}

// Disegna un crocino (mirino ArchBB in miniatura) alla posizione data.
static void drawCross(int x, int y, uint16_t color) {
  tft.drawFastHLine(x - 8, y, 17, color);
  tft.drawFastVLine(x, y - 8, 17, color);
  tft.drawCircle(x, y, 5, color);
}

// Aggiorna i valori numerici e il crocino.
void displayTouchUpdate(bool touched, uint16_t x, uint16_t y,
                        uint8_t fingers, const char* gestureName, uint8_t rawGid) {
  // --- Blocco valori testuali: riscrivo con sfondo per cancellare i vecchi ---
  char line[24];
  tft.setTextDatum(ML_DATUM);

  // X
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  snprintf(line, sizeof(line), "%-4u", touched ? x : 0);
  tft.fillRect(70, TT_DATA_Y - 14 + TT_ROW_H * 0, 120, 24, ArchColor::BG);
  tft.drawString(line, 70, TT_DATA_Y + TT_ROW_H * 0, 4);

  // Y
  snprintf(line, sizeof(line), "%-4u", touched ? y : 0);
  tft.fillRect(70, TT_DATA_Y - 14 + TT_ROW_H * 1, 120, 24, ArchColor::BG);
  tft.drawString(line, 70, TT_DATA_Y + TT_ROW_H * 1, 4);

  // dita
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
  snprintf(line, sizeof(line), "%u  ", fingers);
  tft.fillRect(80, TT_DATA_Y - 8 + TT_ROW_H * 2, 100, 18, ArchColor::BG);
  tft.drawString(line, 80, TT_DATA_Y + TT_ROW_H * 2, 2);

  // gesture (nome + id grezzo per diagnostica)
  snprintf(line, sizeof(line), "%s (0x%02X)", gestureName, rawGid);
  tft.fillRect(80, TT_DATA_Y - 8 + TT_ROW_H * 3, 150, 18, ArchColor::BG);
  tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
  tft.drawString(line, 80, TT_DATA_Y + TT_ROW_H * 3, 2);

  // --- Crocino nell'area touchpad ------------------------------------------
  // Cancella il vecchio crocino (ridisegnandolo col colore di sfondo).
  if (s_lastCrossX >= 0) {
    drawCross(s_lastCrossX, s_lastCrossY, ArchColor::BG);
    // Ripristina il bordo dell'area se il crocino lo aveva sfiorato: semplice
    // ridisegno del rettangolo (poco costoso a questa cadenza).
    tft.drawRect(6, TT_AREA_Y0, ARCHBB_W - 12, TT_AREA_Y1 - TT_AREA_Y0,
                 ArchColor::BORDER);
  }

  if (touched) {
    // Clampo dentro l'area visiva del touchpad per il disegno del crocino.
    int cx = constrain((int)x, 12, ARCHBB_W - 12);
    int cy = constrain((int)y, TT_AREA_Y0 + 8, TT_AREA_Y1 - 8);
    drawCross(cx, cy, ArchColor::GOOD);
    s_lastCrossX = cx;
    s_lastCrossY = cy;
  } else {
    s_lastCrossX = s_lastCrossY = -1;
  }
}

// ============================================================================
//  FASE 3 — schermate di supporto allo scoring
// ============================================================================

void displayAttesaTiro(uint16_t nextShotId) {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ArchBB", ARCHBB_W/2, 40, 4);

  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("scoring on-device", ARCHBB_W/2, 68, 2);

  // Mirino centrale.
  const int cx = ARCHBB_W/2, cy = 150;
  tft.drawCircle(cx, cy, 40, ArchColor::TEXT3);
  tft.drawCircle(cx, cy, 26, ArchColor::TEXT2);
  tft.fillCircle(cx, cy, 10, ArchColor::BAD);
  tft.drawFastHLine(cx - 52, cy, 104, ArchColor::BORDER);
  tft.drawFastVLine(cx, cy - 52, 104, ArchColor::BORDER);

  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  char t[24]; snprintf(t, sizeof(t), "prossimo: tiro #%u", nextShotId);
  tft.drawString(t, ARCHBB_W/2, 220, 2);

  tft.setTextDatum(BC_DATUM);
  tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
  tft.drawString("TOCCA per registrare un tiro", ARCHBB_W/2, ARCHBB_H - 10, 2);
}

// ----------------------------------------------------------------------------
//  Helper interni al riepilogo 4c
// ----------------------------------------------------------------------------
//  Colore di una classe hold: verde=tenuto, ambra=lieve, rosso=abbassato/alzato.
static uint16_t holdColor(uint8_t c) {
  switch (c) {
    case HOLD_TENUTO:                   return ArchColor::GOOD;
    case HOLD_LIEVE:                    return ArchColor::AMBER;
    case HOLD_ABBASSATO: case HOLD_ALZATO: return ArchColor::BAD;
    default:                            return ArchColor::TEXT3;
  }
}
//  Colore di una classe release: verde=pulito, ambra=medio, rosso=strappo.
static uint16_t releaseColor(uint8_t c) {
  switch (c) {
    case RELEASE_PULITO:  return ArchColor::GOOD;
    case RELEASE_MEDIO:   return ArchColor::AMBER;
    case RELEASE_STRAPPO: return ArchColor::BAD;
    default:              return ArchColor::TEXT3;
  }
}

// ----------------------------------------------------------------------------
//  Layout del riepilogo 4c — costanti condivise da display E hit-test.
// ----------------------------------------------------------------------------
//  Stessa lezione delle costanti duplicate (§4.1 compendio): disegno e hit-test
//  DEVONO leggere le stesse Y, o prima o poi un tocco cade fuori dal pulsante
//  che vede a schermo. Le metto qui, un solo posto.
static constexpr int RIEP_CORR_Y = 208, RIEP_CORR_H = 30;
static constexpr int RIEP_OK_Y   = RIEP_CORR_Y + RIEP_CORR_H + 6;   // 244
static constexpr int RIEP_OK_H   = 34;

void displayScoreRiepilogo(const ScoreResult& r, const char* zonaTxt) {
  const bool valutato = r.valutato;
  const bool colpito  = r.colpito;

  uint16_t topColor = !valutato ? ArchColor::BORDER
                     : (colpito ? ArchColor::GOOD : ArchColor::BAD);
  tft.fillScreen(ArchColor::BG);

  // --- Fascia esito (piu' bassa che in 4a: 40px, per far spazio sotto) -------
  tft.fillRect(0, 0, ARCHBB_W, 40, topColor);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT, topColor);
  const char* esito = !valutato ? "NON VALUTATO" : (colpito ? "COLPITO" : "MANCATO");
  tft.drawString(esito, ARCHBB_W/2, 20, 4);

  if (valutato) {
    // --- BLOCCO SCORING: due righe compatte, font 2 -------------------------
    //  zona + distanza sulla prima riga, elev + ARCS sulla seconda. Denso ma
    //  leggibile: lo scoring \"grezzo\" e' gia' noto all'arciere che l'ha appena
    //  inserito; qui conta di piu' lo spazio per le metriche NUOVE.
    tft.setTextDatum(ML_DATUM);
    int yy = 52;
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("zona", 14, yy, 2);
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
    tft.drawString(zonaTxt, 60, yy, 2);

    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("dist", 150, yy, 2);
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
    char d[12];
    if (r.distanza_m == 0) snprintf(d, sizeof(d), "--");
    else                   snprintf(d, sizeof(d), "%um", r.distanza_m);
    tft.drawString(d, 190, yy, 2);

    yy += 20;
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("elev", 14, yy, 2);
    char ev[14];
    if (!elevIsSet(r.elev_deg)) {
      tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
      snprintf(ev, sizeof(ev), "n/i");
    } else {
      tft.setTextColor(r.elev_deg == 0 ? ArchColor::TEXT : ArchColor::AMBER, ArchColor::BG);
      snprintf(ev, sizeof(ev), "%+do", (int)r.elev_deg);
    }
    tft.drawString(ev, 60, yy, 2);

    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("ARCS", 150, yy, 2);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    char a[10]; snprintf(a, sizeof(a), "%d", r.arcs);
    tft.drawString(a, 190, yy, 2);

    // --- CARD METRICHE (Fase 4c) --------------------------------------------
    //  Le quattro grandezze biomeccaniche in una card dedicata. Ogni riga:
    //  etichetta (grigia) + valore numerico + classe colorata. Se la finestra
    //  non e' stabile, cant/alzo vanno in GRIGIO con un "~" davanti: l'angolo
    //  c'e' ma e' poco attendibile, e va DETTO — stessa filosofia dell'elev n/i.
    const int cardY = 92, cardH = 108;
    tft.fillRoundRect(10, cardY, ARCHBB_W - 20, cardH, 8, ArchColor::BG_CARD);
    tft.drawRoundRect(10, cardY, ARCHBB_W - 20, cardH, 8, ArchColor::BORDER);

    tft.setTextDatum(ML_DATUM);
    int my = cardY + 14;

    // Riga CANT / ALZO (assetto pre-scocco).
    if (r.angles_valid) {
      const bool stab = r.angles_stable;
      uint16_t col = stab ? ArchColor::TEXT : ArchColor::TEXT3;   // grigio se instabile
      const char* pfx = stab ? "" : "~";                          // ~ marca l'inaffidabile

      tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
      tft.drawString("cant", 22, my, 2);
      tft.setTextColor(col, ArchColor::BG_CARD);
      char cbuf[16]; snprintf(cbuf, sizeof(cbuf), "%s%+.1f%c", pfx, r.cant_cdeg/100.0f, 'o');
      tft.drawString(cbuf, 66, my, 2);

      tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
      tft.drawString("alzo", 138, my, 2);
      tft.setTextColor(col, ArchColor::BG_CARD);
      char abuf[16]; snprintf(abuf, sizeof(abuf), "%s%+.1f%c", pfx, r.alzo_cdeg/100.0f, 'o');
      tft.drawString(abuf, 182, my, 2);
    } else {
      tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
      tft.drawString("assetto: n/d (finestra corta)", 22, my, 2);
    }

    // Riga di avviso instabilita' (solo se serve): un angolo c'e' ma non fidarsi.
    my += 20;
    if (r.angles_valid && !r.angles_stable) {
      tft.setTextColor(ArchColor::AMBER, ArchColor::BG_CARD);
      tft.drawString("~ arco non fermo: assetto incerto", 22, my, 1);
    }

    // Riga HOLD (follow-through).
    my += 16;
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
    tft.drawString("tenuta", 22, my, 2);
    if (r.hold_valid) {
      tft.setTextColor(ArchColor::TEXT, ArchColor::BG_CARD);
      char hbuf[12]; snprintf(hbuf, sizeof(hbuf), "%+.1f%c", r.hold_cdeg/100.0f, 'o');
      tft.drawString(hbuf, 92, my, 2);
      tft.setTextColor(holdColor(r.hold_class), ArchColor::BG_CARD);
      tft.drawString(hold_class_name(r.hold_class), 156, my, 2);
    } else {
      tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
      tft.drawString("n/d", 92, my, 2);
    }

    // Riga RELEASE (pulizia rilascio).
    my += 22;
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
    tft.drawString("rilascio", 22, my, 2);
    if (r.release_valid) {
      tft.setTextColor(ArchColor::TEXT, ArchColor::BG_CARD);
      char rbuf[12]; snprintf(rbuf, sizeof(rbuf), "%u", r.release_jerk);
      tft.drawString(rbuf, 92, my, 2);
      tft.setTextColor(releaseColor(r.release_class), ArchColor::BG_CARD);
      tft.drawString(release_class_name(r.release_class), 156, my, 2);
    } else {
      tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
      tft.drawString("n/d", 92, my, 2);
    }
  }

  // --- CORREGGI (secondario) + OK (primario) ---------------------------------
  tft.fillRoundRect(20, RIEP_CORR_Y, ARCHBB_W - 40, RIEP_CORR_H, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(20, RIEP_CORR_Y, ARCHBB_W - 40, RIEP_CORR_H, 8, ArchColor::BORDER);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG_CARD);
  tft.drawString("< CORREGGI", ARCHBB_W/2, RIEP_CORR_Y + RIEP_CORR_H/2, 2);

  tft.fillRoundRect(20, RIEP_OK_Y, ARCHBB_W - 40, RIEP_OK_H, 10, ArchColor::GOOD);
  tft.setTextColor(ArchColor::BG, ArchColor::GOOD);   // nero su verde
  tft.drawString("OK", ARCHBB_W/2, RIEP_OK_Y + RIEP_OK_H/2, 4);
}

// Zone toccabili del riepilogo (per il main): ritorna 1=CORREGGI, 2=OK, 0=altro.
uint8_t hitRiepilogo(uint16_t x, uint16_t y) {
  if (y >= RIEP_CORR_Y && y < RIEP_CORR_Y + RIEP_CORR_H && x >= 20 && x < ARCHBB_W - 20) return 1;
  if (y >= RIEP_OK_Y   && y < RIEP_OK_Y   + RIEP_OK_H   && x >= 20 && x < ARCHBB_W - 20) return 2;
  return 0;
}

// ============================================================================
//  FASE 4a — attesa del TIRO REALE (IMU armata)
// ============================================================================
void displayAttesaTiroIMU(uint16_t nextShotId, float tempC) {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ArchBB", ARCHBB_W/2, 38, 4);

  // Riga di stato IMU: pallino verde pulsante "ARMATO" + temperatura on-chip.
  // La temperatura e' un check vitale a colpo d'occhio: se e' un valore
  // plausibile (~20-40 C) l'IMU sta rispondendo davvero, non e' un placeholder.
  const int badgeY = 66;
  tft.fillCircle(ARCHBB_W/2 - 58, badgeY, 6, ArchColor::GOOD);
  tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
  tft.setTextDatum(ML_DATUM);
  tft.drawString("IMU ARMATA", ARCHBB_W/2 - 46, badgeY, 2);
  if (!isnan(tempC)) {
    char tt[16]; snprintf(tt, sizeof(tt), "%.0f\xB0""C", tempC);  // \xB0 = grado
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.setTextDatum(MR_DATUM);
    tft.drawString(tt, ARCHBB_W - 16, badgeY, 2);
  }

  // Mirino centrale (identico all'attesa Fase 3, per continuita' visiva).
  const int cx = ARCHBB_W/2, cy = 150;
  tft.drawCircle(cx, cy, 40, ArchColor::TEXT3);
  tft.drawCircle(cx, cy, 26, ArchColor::TEXT2);
  tft.fillCircle(cx, cy, 10, ArchColor::BAD);
  tft.drawFastHLine(cx - 52, cy, 104, ArchColor::BORDER);
  tft.drawFastVLine(cx, cy - 52, 104, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  char t[24]; snprintf(t, sizeof(t), "prossimo: tiro #%u", nextShotId);
  tft.drawString(t, ARCHBB_W/2, 218, 2);

  tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
  tft.drawString("In attesa dello SCOCCO", ARCHBB_W/2, 244, 2);

  // Il tocco resta come trigger manuale a banco: lo si dice in piccolo, non e'
  // piu' l'azione primaria (ora e' la freccia a comandare).
  tft.setTextDatum(BC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("(tocca = tiro manuale)", ARCHBB_W/2, ARCHBB_H - 10, 2);
}

// ----------------------------------------------------------------------------
//  FASE 5 — displayStatusBar: batteria (sx) + sessione (centro) + SD (dx)
// ----------------------------------------------------------------------------
//  Estetica: una fascia scura in cima, tre gruppi ben distanziati, icona
//  batteria DISEGNATA (non testuale) col livello colorato per soglia — verde
//  sopra 40%, ambra 15..40%, rosso sotto. Il badge sessione e' un pallino REC
//  rosso pulsante quando aperta, un cerchietto vuoto quando chiusa. Lo spazio SD
//  a destra. Tutto in font 1/2 per non rubare spazio al mirino sottostante.
void displayStatusBar(const StatusInfo& st) {
  const int barH = 20;
  // Sfondo fascia + linea di separazione sotto.
  tft.fillRect(0, 0, ARCHBB_W, barH, ArchColor::BG_CARD);
  tft.drawFastHLine(0, barH, ARCHBB_W, ArchColor::BORDER);

  // --- BATTERIA (sinistra) --------------------------------------------------
  //  Icona: corpo 22x11 + polo +. Riempimento proporzionale, colore per soglia.
  const int bx = 6, by = 5, bw = 22, bh = 11;
  tft.drawRect(bx, by, bw, bh, ArchColor::TEXT2);               // corpo
  tft.fillRect(bx + bw, by + 3, 2, bh - 6, ArchColor::TEXT2);   // polo +
  if (st.battPct >= 0) {
    int lvl = (st.battPct * (bw - 2)) / 100;                    // px di riempimento
    uint16_t col = (st.battPct > 40) ? ArchColor::GOOD
                 : (st.battPct > 15) ? ArchColor::AMBER
                                     : ArchColor::BAD;
    if (lvl > 0) tft.fillRect(bx + 1, by + 1, lvl, bh - 2, col);
    // Percentuale accanto all'icona.
    char pb[10]; snprintf(pb, sizeof(pb), "%d%%", st.battPct);
    tft.setTextDatum(ML_DATUM);
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG_CARD);
    tft.drawString(pb, bx + bw + 6, by + bh/2, 2);
    // Spina "in carica" (piccola freccia ambra) se sotto carica.
    if (st.battCharging) {
      tft.setTextColor(ArchColor::AMBER, ArchColor::BG_CARD);
      tft.drawString("\x18", bx + bw + 34, by + bh/2, 1);       // 0x18 = up-arrow
    }
  } else {
    tft.setTextDatum(ML_DATUM);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
    tft.drawString("n/d", bx + bw + 6, by + bh/2, 2);
  }

  // --- SESSIONE (centro) ----------------------------------------------------
  //  REC ● rosso + conteggio tiri se aperta; ○ "no sess" grigio se chiusa.
  //  FASE 6b: non mostriamo piu' "S%03u" (il numero interno e' slegato dal nome
  //  cartella datato: sarebbe ingannevole). Conta il numero di TIRI, che e' il
  //  dato utile all'arciere.
  tft.setTextDatum(MC_DATUM);
  if (st.sessionOpen) {
    char sb[18]; snprintf(sb, sizeof(sb), "REC  %u tiri", st.sessionShots);
    tft.fillCircle(ARCHBB_W/2 - 42, barH/2, 4, ArchColor::BAD);   // pallino REC
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG_CARD);
    tft.drawString(sb, ARCHBB_W/2 + 6, barH/2, 2);
  } else {
    tft.drawCircle(ARCHBB_W/2 - 34, barH/2, 4, ArchColor::TEXT3); // cerchietto vuoto
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
    tft.drawString("no sess", ARCHBB_W/2 + 4, barH/2, 2);
  }

  // --- SD (destra) ----------------------------------------------------------
  tft.setTextDatum(MR_DATUM);
  if (st.sdOk) {
    char db[14];
    if (st.sdFreeMb >= 1024) snprintf(db, sizeof(db), "SD %.1fG", st.sdFreeMb / 1024.0f);
    else                     snprintf(db, sizeof(db), "SD %luM", (unsigned long)st.sdFreeMb);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG_CARD);
    tft.drawString(db, ARCHBB_W - 6, barH/2, 2);
  } else {
    tft.setTextColor(ArchColor::BAD, ArchColor::BG_CARD);
    tft.drawString("no SD", ARCHBB_W - 6, barH/2, 2);
  }
}

// ----------------------------------------------------------------------------
//  FASE 5 — schermata di attesa CON barra di stato in cima.
// ----------------------------------------------------------------------------
//  Riusa il layout di displayAttesaTiroIMU ma lascia i primi ~22px alla barra.
//  Per non duplicare il corpo, ridisegniamo qui la scena spostata di poco sotto
//  la barra. (Il mirino centrale resta al suo posto: 284px di altezza danno
//  spazio a sufficienza.)
void displayAttesaTiroIMU_v5(uint16_t nextShotId, float tempC, const StatusInfo& st) {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  // Barra di stato in cima (Fase 5).
  displayStatusBar(st);

  // Se manca la SD, una riga di diagnosi appena sotto la barra: cosi' la CAUSA
  // (pin/formato) si legge sul dispositivo senza collegare la seriale.
  if (!st.sdOk && st.sdDiag) {
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(ArchColor::BAD, ArchColor::BG);
    tft.drawString(st.sdDiag, ARCHBB_W/2, 30, 1);
  }

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("ArchBB", ARCHBB_W/2, 46, 4);

  // Orologio (Fase 6): mostrato SOLO se l'RTC e' valido (impostato). Se non lo
  // e', non compare nulla — niente data-spazzatura a schermo.
  if (st.hasTime) {
    tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
    tft.drawString(st.clock, ARCHBB_W/2, 62, 2);
  }

  // Riga IMU armata + temperatura (come la versione 4c, spostata sotto la barra).
  // FASE 6b: abbassata a 88 (era 74) per non sovrapporsi all'orologio a y=62.
  const int badgeY = 88;
  tft.fillCircle(ARCHBB_W/2 - 58, badgeY, 6, ArchColor::GOOD);
  tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
  tft.setTextDatum(ML_DATUM);
  tft.drawString("IMU ARMATA", ARCHBB_W/2 - 46, badgeY, 2);
  if (!isnan(tempC)) {
    char tt[16]; snprintf(tt, sizeof(tt), "%.0f\xB0""C", tempC);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.setTextDatum(MR_DATUM);
    tft.drawString(tt, ARCHBB_W - 16, badgeY, 2);
  }

  // Mirino centrale.
  const int cx = ARCHBB_W/2, cy = 156;
  tft.drawCircle(cx, cy, 40, ArchColor::TEXT3);
  tft.drawCircle(cx, cy, 26, ArchColor::TEXT2);
  tft.fillCircle(cx, cy, 10, ArchColor::BAD);
  tft.drawFastHLine(cx - 52, cy, 104, ArchColor::BORDER);
  tft.drawFastVLine(cx, cy - 52, 104, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  char t[24]; snprintf(t, sizeof(t), "prossimo: tiro #%u", nextShotId);
  tft.drawString(t, ARCHBB_W/2, 222, 2);

  tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
  tft.drawString("In attesa dello SCOCCO", ARCHBB_W/2, 246, 2);

  // Suggerimenti in basso: il tocco gestisce la sessione (Fase 5 ridisegnata).
  tft.setTextDatum(BC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString(st.sessionOpen ? "tocca = CHIUDI sessione"
                                : "tocca = APRI sessione",
                 ARCHBB_W/2, ARCHBB_H - 10, 2);
}

// ----------------------------------------------------------------------------
//  FASE 5 — displaySessionNoSd: avviso "nessuna microSD".
// ----------------------------------------------------------------------------
//  Feedback onesto quando si tocca per gestire la sessione ma la card manca:
//  meglio dirlo che fingere. Un riquadro ambra centrale, breve e bloccante.
void displaySessionNoSd() {
  const int bw = 200, bh = 70;
  const int bx = (ARCHBB_W - bw)/2, by = (ARCHBB_H - bh)/2;
  tft.fillRoundRect(bx, by, bw, bh, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(bx, by, bw, bh, 8, ArchColor::AMBER);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::AMBER, ArchColor::BG_CARD);
  tft.drawString("NESSUNA microSD", ARCHBB_W/2, by + 24, 2);
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG_CARD);
  tft.drawString("inserisci una card FAT32", ARCHBB_W/2, by + 46, 2);
  delay(800);
}

// ----------------------------------------------------------------------------
//  FASE 5 — scelta sessione: geometria CONDIVISA disegno+hit (lezione §4.1)
// ----------------------------------------------------------------------------
//  Disegno e handler leggono le STESSE costanti: niente letterali duplicati che
//  prima o poi divergono (la cantonata piu' costosa della 1.69).
namespace SChoice {
  constexpr int BTN_X   = 20;
  constexpr int BTN_W   = ARCHBB_W - 40;      // pulsanti larghi, centrati
  constexpr int BTN_H   = 56;
  constexpr int RESUME_Y = 120;               // top del pulsante RIPRENDI
  constexpr int NEW_Y    = 190;               // top del pulsante NUOVA
}

void displaySessionChoice(const char* lastName, uint16_t lastShots) {
  using namespace SChoice;
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("SESSIONE", ARCHBB_W/2, 40, 4);
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
  tft.drawString("c'e' gia' una sessione", ARCHBB_W/2, 74, 2);

  // Pulsante RIPRENDI (verde): accoda all'ultima.
  tft.fillRoundRect(BTN_X, RESUME_Y, BTN_W, BTN_H, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(BTN_X, RESUME_Y, BTN_W, BTN_H, 8, ArchColor::GOOD);
  tft.setTextColor(ArchColor::GOOD, ArchColor::BG_CARD);
  tft.drawString("RIPRENDI", ARCHBB_W/2, RESUME_Y + 18, 4);
  // Nome cartella (datato o numerato) + conteggio tiri. Il nome puo' essere
  // lungo (SESS_20260721_1430): font 1 per starci.
  char sub[36];
  snprintf(sub, sizeof(sub), "%s (%u tiri)", lastName ? lastName : "?", lastShots);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
  tft.drawString(sub, ARCHBB_W/2, RESUME_Y + 44, 1);

  // Pulsante NUOVA (ciano): apre una sessione vergine.
  tft.fillRoundRect(BTN_X, NEW_Y, BTN_W, BTN_H, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(BTN_X, NEW_Y, BTN_W, BTN_H, 8, ArchColor::ACCENT);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG_CARD);
  tft.drawString("NUOVA", ARCHBB_W/2, NEW_Y + 20, 4);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
  tft.drawString("inizia da capo", ARCHBB_W/2, NEW_Y + 44, 2);
}

uint8_t hitSessionChoice(uint16_t x, uint16_t y) {
  using namespace SChoice;
  if (x >= BTN_X && x <= BTN_X + BTN_W) {
    if (y >= RESUME_Y && y <= RESUME_Y + BTN_H) return 1;   // RIPRENDI
    if (y >= NEW_Y    && y <= NEW_Y    + BTN_H) return 2;    // NUOVA
  }
  return 0;
}

// ----------------------------------------------------------------------------
//  FASE 5 — displaySavedFlash: doppio flash verde "SALVATO".
// ----------------------------------------------------------------------------
void displaySavedFlash(uint16_t shotNum) {
  const int bw = 200, bh = 80;
  const int bx = (ARCHBB_W - bw)/2, by = (ARCHBB_H - bh)/2;
  char t[24]; snprintf(t, sizeof(t), "tiro #%u", shotNum);

  for (int i = 0; i < 2; i++) {         // due lampeggi
    tft.fillRoundRect(bx, by, bw, bh, 10, ArchColor::GOOD);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(ArchColor::BG, ArchColor::GOOD);
    tft.drawString("SALVATO", ARCHBB_W/2, by + 30, 4);
    tft.drawString(t, ARCHBB_W/2, by + 58, 2);
    delay(110);
    tft.fillRoundRect(bx, by, bw, bh, 10, ArchColor::BG);   // spegni
    tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);
    delay(70);
  }
}

// ============================================================================
//  Flash di conferma "TIRO RILEVATO"
// ============================================================================
void displayTriggerFlash(uint16_t shotId, float azPeak) {
  tft.fillScreen(ArchColor::AMBER);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::BG, ArchColor::AMBER);   // nero su ambra
  tft.drawString("TIRO", ARCHBB_W/2, ARCHBB_H/2 - 40, 4);
  tft.drawString("RILEVATO", ARCHBB_W/2, ARCHBB_H/2 - 8, 4);

  char t[24]; snprintf(t, sizeof(t), "#%u", shotId);
  tft.drawString(t, ARCHBB_W/2, ARCHBB_H/2 + 34, 6);   // font 6 numerico: ok

  char p[28]; snprintf(p, sizeof(p), "az picco %.0f m/s2", azPeak);
  tft.setTextColor(ArchColor::BG, ArchColor::AMBER);
  tft.drawString(p, ARCHBB_W/2, ARCHBB_H/2 + 74, 2);

  delay(120);   // breve, bloccante: e' l'unico delay volutamente accettato qui
}

// ============================================================================
//  FASE 4c — DIAG ANGOLI (test statico dei segni di montaggio)
// ============================================================================
//  A COSA SERVE (e perche' e' l'arbitro, non un accessorio)
//    shot_angles usa cant=atan2(ay,ax), alzo=atan2(az,ax) su un frame CANONICO
//    (ax=gravita', ay=laterale, az=freccia). Se sull'hardware 1.83 il QMI8658
//    e' montato con un altro orientamento, gli assi grezzi NON sono canonici e
//    la matrice mount sbagliata darebbe angoli con segno/asse errato.
//
//    Questa schermata calcola cant/alzo per TUTTI e 4 i montaggi in parallelo,
//    a partire dagli stessi assi grezzi. Ad arco fermo su supporto ad angolo
//    NOTO (es. "+15 punta su, +20 cant destra") si legge quale montaggio da'
//    i segni ATTESI con |g|~9.8 e sd bassa. Quello e' il montaggio vero -> si
//    scrive in config.h (ARCHBB_MOUNT_DEFAULT). Nessuna deduzione a tavolino:
//    la scheda lo dice.
//
//  COME LEGGERLA
//    - Riga GREZZO: ax/ay/az del sensore cosi' com'e'. Da soli non dicono i
//      segni finali (dipendono dal montaggio), ma dicono se l'IMU risponde.
//    - |g| e sd: il semaforo di FIDUCIA. Verde se |g| in [9.3..10.3] e sd<0.15
//      (arco davvero fermo): solo allora i segni sono validabili. Rosso = stai
//      ancora muovendo, aspetta.
//    - Tabella 4 montaggi: per ognuno, cant e alzo. Cerca la RIGA i cui segni
//      corrispondono al gesto noto. Il montaggio corrente (da config) e'
//      evidenziato in ciano con un '>'.
// ----------------------------------------------------------------------------
void displayAngleDiag(float ax, float ay, float az,
                      float gmean, float gsd, uint16_t nUsed) {
  tft.fillScreen(ArchColor::BG);

  // --- Titolo -----------------------------------------------------------------
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("DIAG ANGOLI", ARCHBB_W/2, 14, 4);

  // --- Semaforo di fiducia (|g| e sd) -----------------------------------------
  //  La misura dei segni ha senso SOLO se l'arco e' fermo. Questo semaforo dice
  //  se lo e': verde -> puoi fidarti, rosso -> aspetta che si fermi.
  const bool trustworthy = (fabsf(gmean - 9.81f) < 0.5f) && (gsd < 0.15f);
  uint16_t sc = trustworthy ? ArchColor::GOOD : ArchColor::BAD;
  tft.fillRoundRect(10, 34, ARCHBB_W - 20, 26, 6, ArchColor::BG_CARD);
  tft.drawRoundRect(10, 34, ARCHBB_W - 20, 26, 6, sc);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(sc, ArchColor::BG_CARD);
  char gbuf[28]; snprintf(gbuf, sizeof(gbuf), "|g| %.2f  sd %.3f  n%u", gmean, gsd, nUsed);
  tft.drawString(gbuf, 18, 47, 2);
  tft.setTextDatum(MR_DATUM);
  tft.drawString(trustworthy ? "FERMO" : "MUOVI", ARCHBB_W - 18, 47, 2);

  // --- Assi grezzi del sensore ------------------------------------------------
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("grezzo", 12, 74, 2);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
  char rbuf[36];
  snprintf(rbuf, sizeof(rbuf), "x%+.1f y%+.1f z%+.1f", ax, ay, az);
  tft.drawString(rbuf, 66, 74, 2);

  // --- Intestazione tabella ---------------------------------------------------
  const int tblY = 92, rowH = 24;
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("montaggio", 14, tblY, 2);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("cant", 150, tblY, 2);
  tft.drawString("alzo", 205, tblY, 2);
  tft.drawFastHLine(10, tblY + 13, ARCHBB_W - 20, ArchColor::BORDER);

  // --- Una riga per montaggio (ora sono 5) ------------------------------------
  //  Per ogni montaggio applichiamo mount_apply agli assi grezzi (i gyro non
  //  servono qui: dummy) e calcoliamo cant/alzo canonici. Cosi' si vede, fianco
  //  a fianco, cosa produrrebbe OGNI scelta. Il corrente e' evidenziato in ciano
  //  con un '>'. Nomi brevi per stare in larghezza.
  const uint8_t current = ARCHBB_MOUNT_DEFAULT;
  static const char* SHORT[MOUNT_COUNT] = {
    "0 front", "DX -90", "SX +90", "180 opp"
  };
  for (uint8_t m = 0; m < MOUNT_COUNT; m++) {
    float mx = ax, myv = ay, mz = az, gdx = 0, gdy = 0, gdz = 0;
    mount_apply(m, mx, myv, mz, gdx, gdy, gdz);
    float cant = atan2f(myv, mx) * 180.0f / (float)M_PI;
    float alzo = atan2f(mz,  mx) * 180.0f / (float)M_PI;

    int ry = tblY + 21 + m * rowH;
    bool isCur = (m == current);
    uint16_t rowCol = isCur ? ArchColor::ACCENT : ArchColor::TEXT;

    if (isCur) {
      tft.fillRoundRect(10, ry - 10, ARCHBB_W - 20, rowH - 2, 5, ArchColor::BG_CARD);
    }

    tft.setTextDatum(ML_DATUM);
    tft.setTextColor(rowCol, isCur ? ArchColor::BG_CARD : ArchColor::BG);
    char nm[14]; snprintf(nm, sizeof(nm), "%s%s", isCur ? ">" : " ",
                          (m < MOUNT_COUNT) ? SHORT[m] : "?");
    tft.drawString(nm, 12, ry, 2);

    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(rowCol, isCur ? ArchColor::BG_CARD : ArchColor::BG);
    char cb[10]; snprintf(cb, sizeof(cb), "%+.0f", cant);
    tft.drawString(cb, 150, ry, 2);
    char ab[10]; snprintf(ab, sizeof(ab), "%+.0f", alzo);
    tft.drawString(ab, 205, ry, 2);
  }

  // --- Piede: istruzioni --------------------------------------------------------
  tft.setTextDatum(BC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("arco fermo, angolo noto -> leggi i segni", ARCHBB_W/2, ARCHBB_H - 22, 1);
  tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
  tft.drawString("spegni per uscire", ARCHBB_W/2, ARCHBB_H - 8, 1);
}

// ----------------------------------------------------------------------------
//  FASE 7 — displayBleMode: schermata del modo "colloquio con smartphone".
// ----------------------------------------------------------------------------
//  Layout (dall'alto):
//    - icona Bluetooth stilizzata + titolo "MODO BLE"
//    - stato connessione: "IN ASCOLTO..." (ambra pulsante) o "CONNESSO" (verde)
//    - card col nome device (quello che appare nello scanner dell'app)
//    - riga riassunto: batteria | SD | orologio
//    - piede: istruzione per uscire (ripremere l'ingranaggio)
//
//  Coerente con la palette ArchBB (fondo nero, accento ciano, card grigio-blu).
//  Nessuna animazione nel loop: la ridisegniamo solo quando cambia lo stato di
//  connessione (il main tiene memoria dell'ultimo stato disegnato).
void displayBleMode(bool connected, const char* devName, const StatusInfo& st) {
  tft.fillScreen(ArchColor::BG);
  tft.drawRect(0, 0, ARCHBB_W, ARCHBB_H, ArchColor::BORDER);

  // --- Glifo Bluetooth stilizzato (semplice "runa" a segmenti) -------------
  //  Non serve un font-icona: due triangoli speculari attorno a un'asta danno
  //  la classica rune BT riconoscibile. Colore = stato (ambra/attesa, verde/on).
  const uint16_t accent = connected ? ArchColor::GOOD : ArchColor::ACCENT;
  const int cx = ARCHBB_W / 2, gy = 40;
  tft.drawLine(cx, gy - 16, cx, gy + 16, accent);          // asta verticale
  tft.drawLine(cx, gy - 16, cx + 10, gy - 6, accent);      // alette alto
  tft.drawLine(cx + 10, gy - 6, cx - 10, gy + 6, accent);
  tft.drawLine(cx, gy + 16, cx + 10, gy + 6, accent);      // alette basso
  tft.drawLine(cx + 10, gy + 6, cx - 10, gy - 6, accent);

  // --- Titolo --------------------------------------------------------------
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
  tft.drawString("MODO BLE", cx, gy + 40, 4);

  // --- Stato connessione ---------------------------------------------------
  if (connected) {
    tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
    tft.drawString("APP CONNESSA", cx, gy + 72, 2);
  } else {
    tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
    tft.drawString("in ascolto...", cx, gy + 72, 2);
  }

  // --- Card col nome device ------------------------------------------------
  const int cardX = 16, cardY = 130, cardW = ARCHBB_W - 32, cardH = 44;
  tft.fillRoundRect(cardX, cardY, cardW, cardH, 8, ArchColor::BG_CARD);
  tft.drawRoundRect(cardX, cardY, cardW, cardH, 8, ArchColor::BORDER);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG_CARD);
  tft.drawString("cerca nell'app:", cx, cardY + 12, 1);
  tft.setTextColor(ArchColor::TEXT, ArchColor::BG_CARD);
  tft.drawString(devName ? devName : "ArchBB-183", cx, cardY + 30, 2);

  // --- Riga riassunto: batteria | SD | orologio ----------------------------
  int ry = 196;
  char line[40];
  // Batteria
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
  if (st.battPct >= 0) snprintf(line, sizeof(line), "Batt %d%%%s",
                                st.battPct, st.battCharging ? " (in carica)" : "");
  else                 snprintf(line, sizeof(line), "Batt n/d");
  tft.drawString(line, cardX, ry, 2);
  // SD
  ry += 22;
  if (st.sdOk) snprintf(line, sizeof(line), "SD  %lu MB liberi", (unsigned long)st.sdFreeMb);
  else         snprintf(line, sizeof(line), "SD  assente");
  tft.setTextColor(st.sdOk ? ArchColor::TEXT2 : ArchColor::AMBER, ArchColor::BG);
  tft.drawString(line, cardX, ry, 2);
  // Orologio
  ry += 22;
  if (st.hasTime) snprintf(line, sizeof(line), "Ora  %s", st.clock);
  else            snprintf(line, sizeof(line), "Ora  non impostata");
  tft.setTextColor(st.hasTime ? ArchColor::TEXT2 : ArchColor::TEXT3, ArchColor::BG);
  tft.drawString(line, cardX, ry, 2);

  // --- Piede: come uscire --------------------------------------------------
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
  tft.drawString("premi l'ingranaggio per uscire", cx, ARCHBB_H - 12, 1);
}
