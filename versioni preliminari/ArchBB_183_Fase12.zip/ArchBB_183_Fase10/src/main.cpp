// ============================================================================
//  ArchBB 1.83 — main.cpp · FASE 4c (angoli cant/alzo dal burst) · v1
//  Cesare Pagura · Padova/Noale IT · 19 luglio 2026
// ----------------------------------------------------------------------------
//  COSA AGGIUNGE LA FASE 4c (rispetto alla 4a/4b)
//    La catena IMU era pronta fino al BUFFER CONGELATO: al FIRED il circular
//    buffer cattura la finestra PRE+POST attorno allo scocco e diventa READY.
//    Mancava l'ultimo anello: LEGGERE quel burst e calcolarne gli ANGOLI
//    biomeccanici. Ora, al DONE dello scoring:
//
//      circular_buffer_get_burst() -> shot_angles_compute() -> ScoreResult
//                                   -> riepilogo esteso (cant/alzo/hold/release)
//
//  IL PUNTO CRITICO: IL FRAME DI MONTAGGIO (perche' c'e' il DIAG ANGOLI)
//    shot_angles fu validato sul frame CANONICO della 1.69. La 1.83 e' un'altra
//    scheda: gli assi grezzi del suo QMI8658 potrebbero non essere canonici.
//    Percio' imu_task ora applica mount_apply() a monte (frame canonico a
//    valle), MA quale montaggio sia quello giusto NON si decide a tavolino: si
//    misura col DIAG ANGOLI (menu d'avvio), test statico ad angolo noto. Il
//    default e' MOUNT_DX_M90 (ipotesi \"come 1.69 a destra\"), da CONFERMARE.
//
//  ALLOCAZIONE DEL BURST: STATIC, MAI SULLO STACK
//    Il burst e' CIRCULAR_BUFFER_SIZE * sizeof(ImuSample) = 750*30 = ~22 KB.
//    Su stack (locale del loop) farebbe saltare la UI task. Lo teniamo STATIC:
//    vive una volta sola nel .bss, azzerato all'avvio, riusato a ogni tiro.
// ============================================================================
// ============================================================================
//  ArchBB 1.83 — main.cpp (FIRMWARE DI PRODUZIONE)
// ----------------------------------------------------------------------------
//  Questo file e' attivo SOLO quando NON si compila il test montaggi. L'env
//  archbb_183_mount_test definisce -D ARCHBB_MOUNT_TEST=1, che disattiva tutto
//  questo file e attiva main_mount_test.cpp al suo posto. Cosi' entrambi i main
//  vivono in src/ senza conflitto (un solo setup()/loop() compilato), senza
//  bisogno di src_filter fragili con path relativi.
// ============================================================================
#if !defined(ARCHBB_MOUNT_TEST) && !defined(ARCHBB_RAW_DIAG) && !defined(ARCHBB_DIAG_ASSI)

#include <Arduino.h>
#include "display.h"
#include "touch.h"
#include "scoring.h"
#include "config.h"
#include "imu.h"
#include "trigger.h"
#include "circular_buffer.h"
#include "touch_cal.h"
#include "mount.h"          // FASE 4c: frame di montaggio (g_mount_orientation)
#include "shot_angles.h"    // FASE 4c: shot_angles_compute, shot_angle_to_cdeg
#include "sd_storage.h"     // FASE 5: persistenza microSD (sessioni, CSV+burst)
#include "battery.h"        // FASE 5: stato batteria via AXP2101
#include "config_store.h"   // FASE 6: config NVS (fonte di verita' unica)
#include "config_ui.h"      // FASE 6: schermata CONFIG on-device (lettura + reset)
#include "rtc_clock.h"      // FASE 6: orologio RTC PCF85063 (data sessioni)
#include "ble_service.h"    // FASE 7: modo BLE modale (colloquio con smartphone)
#include <esp_mac.h>        // FASE 7: esp_read_mac (suffisso MAC nel nome device)
#include <esp_system.h>     // FIX-DIAG: esp_reset_reason (motivo dell'ultimo reset)

// Flag di shutdown pulito (predisposto: i task lo controllano nella 1.69 e
// teniamo il pattern anche se in Fase 4 non lo attiviamo mai).
volatile bool g_shutdown = false;

// ----------------------------------------------------------------------------
//  FASE 7 — INGRESSO nel modo BLE (via PWRKEY del PMU, NON GPIO0).
// ----------------------------------------------------------------------------
//  Il pulsante utente della 1.83 e' il PWRKEY dell'AXP2101, letto via I2C dal
//  PMU (funzione power_key_short_pressed() in battery.cpp). GPIO0 e' stato
//  BANDITO: e' uno strapping pin di boot e usarlo a runtime causava blocchi
//  (falsi LOW -> enterBleMode spurio -> hang -> reset). Il PWRKEY non ha questi
//  problemi: e' un ingresso del PMU pensato apposta come tasto utente.
//
//  ARCHBB_BLE_ENTRY:
//    2 = PWRKEY (default, corretto e stabile)
//    1 = GPIO0  (SOLO test storico, sconsigliato: causava blocchi)
//    0 = nessun ingresso (BLE non attivabile)
#define ARCHBB_BLE_ENTRY 2
static constexpr int PIN_BLE_BUTTON = 0;   // GPIO0 = BOOT (usato solo se ENTRY==1)

// Gestione degli HANDLE dei task IMU/trigger: servono per SOSPENDERLI quando si
// entra in modo BLE (Core 1 libero, niente polling I2C) e RIPRENDERLI all'uscita.
// Prima erano creati con handle nullptr (non serviva riferirli); ora li teniamo.
static TaskHandle_t s_imuTaskHandle     = nullptr;
static TaskHandle_t s_triggerTaskHandle = nullptr;

enum class AppFlow : uint8_t { ATTESA, SCORING, RIEPILOGO, SESSION_CHOICE, BLE_MODE };
static AppFlow     s_flow = AppFlow::ATTESA;
static ScoreResult s_lastResult;
static uint32_t    s_lastTempMs = 0;   // per rinfrescare la temperatura in attesa

// ----------------------------------------------------------------------------
//  BURST STATIC (Fase 4c) — ~22 KB, MAI sullo stack.
// ----------------------------------------------------------------------------
//  Buffer di lavoro dove copiamo il burst congelato per darlo a
//  shot_angles_compute. static -> vive nel .bss, allocato una volta, riusato a
//  ogni tiro. In PSRAM ci sarebbe stato bene, ma il .bss interno basta e avanza
//  (22 KB su ~320 KB di RAM interna) ed evita una dipendenza da ps_malloc qui.
static ImuSample s_burst[CIRCULAR_BUFFER_SIZE];

// ----------------------------------------------------------------------------
//  FASE 5 — metadati del burst appena letto, per la scrittura SD DIFFERITA.
// ----------------------------------------------------------------------------
//  computeShotAngles() copia il burst in s_burst al DONE. La scrittura su SD
//  avviene invece piu' tardi, al tap OK del riepilogo (hit==2), PRIMA di
//  enterAttesa() che resetta il buffer. Fra i due momenti dobbiamo ricordare
//  QUANTI campioni e DOVE sta il trigger: li salviamo qui quando leggiamo il
//  burst, e li riusiamo alla scrittura. s_burstN=0 -> nessun burst valido da
//  salvare (tiro manuale senza IMU): si salvera' il solo CSV.
static uint16_t s_burstN     = 0;   // campioni validi in s_burst
static uint16_t s_burstTrig  = 0;   // indice di scocco entro s_burst

// ----------------------------------------------------------------------------
//  FASE 5 — gestione SESSIONE via tocco (ridisegnato: niente piu' tap-lungo).
// ----------------------------------------------------------------------------
//  In ATTESA, con IMU viva, il tocco apre/chiude la sessione. Usiamo il fronte
//  di RILASCIO gia' debounced (tapReleased): un tocco pulito = un toggle. Non
//  serve piu' distinguere breve/lungo -> il bug del cronometro fragile sparisce
//  perche' non c'e' piu' nulla da cronometrare.

// StatusInfo condiviso per la barra di stato (Fase 5): ricostruito a ogni
// ingresso in ATTESA. Vive qui per non riallocarlo a ogni refresh.
static StatusInfo s_status;

// ----------------------------------------------------------------------------
//  Debounce/cooldown per i tap di RIEPILOGO (identico alla Fase 4a).
// ----------------------------------------------------------------------------
static constexpr uint8_t  REL_STABLE_N = 2;
static constexpr uint32_t COOLDOWN_MS  = 300;
static bool     s_stable       = false;
static uint8_t  s_relCnt       = 0;
static uint32_t s_lastActionMs = 0;

static bool tapReleased(const TouchData& td) {
  bool raw = td.valid && (td.fingers > 0);
  if (raw) { s_relCnt = 0; s_stable = true; return false; }
  if (s_stable && ++s_relCnt >= REL_STABLE_N) {
    s_stable = false; s_relCnt = 0;
    uint32_t now = millis();
    if (now - s_lastActionMs >= COOLDOWN_MS) { s_lastActionMs = now; return true; }
  }
  return false;
}

// ----------------------------------------------------------------------------
//  computeShotAngles — legge il burst congelato e popola le metriche 4c.
// ----------------------------------------------------------------------------
//  Chiamata al DONE dello scoring, PRIMA di enterAttesa() (che resetta il
//  buffer). Se il buffer non e' READY (tiro manuale a banco senza IMU, o burst
//  non congelato) lascia i campi a \"non valido\": il riepilogo lo mostra come
//  n/d. cant/alzo e hold/release restano indipendenti fra loro (v. shot_angles).
// ----------------------------------------------------------------------------
static void computeShotAngles(ScoreResult& res) {
  // Default: tutto \"non calcolato\". Se qualcosa manca, il riepilogo dira' n/d.
  res.angles_valid = res.angles_stable = false;
  res.hold_valid   = res.release_valid = false;
  res.cant_cdeg = res.alzo_cdeg = 0;
  res.hold_cdeg = 0; res.release_jerk = 0;
  res.hold_class = HOLD_NA; res.release_class = RELEASE_NA;

  // FASE 5: nessun burst valido finche' non lo leggiamo davvero (sotto). Cosi'
  // un tiro manuale senza IMU non eredita i metadati del burst precedente.
  s_burstN = 0; s_burstTrig = 0;

  // Il burst ha senso solo se l'IMU e' viva e il buffer ha catturato la finestra.
  if (!g_imu_ok) return;
  if (circular_buffer_state() != BUFFER_READY) return;   // niente da leggere

  uint16_t trig_idx = 0;
  uint16_t n = circular_buffer_get_burst(s_burst, CIRCULAR_BUFFER_SIZE, &trig_idx);
  if (n == 0) return;

  // FASE 5: memorizza i metadati del burst per la scrittura SD differita (al
  // tap OK del riepilogo). Il burst e' gia' in s_burst e ci resta fino ad allora.
  s_burstN    = n;
  s_burstTrig = trig_idx;

  // ODR_250HZ = 224 Hz reale: shot_angles lo usa solo per dimensionare le
  // finestre in campioni; l'integrazione usa i timestamp reali del burst.
  ShotAngles a = shot_angles_compute(s_burst, n, trig_idx, ODR_250HZ,
                                     g_config.offset_cant_deg,
                                     g_config.offset_alzo_deg);

  if (a.valid) {
    res.angles_valid  = true;
    res.angles_stable = a.stable;
    res.cant_cdeg = shot_angle_to_cdeg(a.cant_deg);
    res.alzo_cdeg = shot_angle_to_cdeg(a.alzo_deg);
  }
  if (a.hold_valid) {
    res.hold_valid = true;
    res.hold_cdeg  = shot_angle_to_cdeg(a.hold_deg);
    res.hold_class = a.hold_class;
  }
  if (a.release_valid) {
    res.release_valid = true;
    // jerk e' un modulo >=0; lo saturiamo a 65535 per il campo uint16.
    float j = a.release_jerk;
    res.release_jerk  = (j > 65535.0f) ? 65535 : (uint16_t)(j + 0.5f);
    res.release_class = a.release_class;
  }
}

// ----------------------------------------------------------------------------
//  FASE 5 — refreshStatus: ricostruisce lo StatusInfo per la barra di stato.
// ----------------------------------------------------------------------------
//  Legge batteria (AXP2101, I2C singola), spazio SD (dalla CACHE, non piu' dalla
//  FAT) e stato sessione (variabili RAM). Tutte letture non-bloccanti: sicura da
//  chiamare a ogni refresh in ATTESA (ogni 3s).
//
//  FIX BLOCCO: prima qui si chiamava sd_free_mb() quando ancora scandiva la FAT
//  a ogni invocazione -> una scansione lenta/incagliata bloccava la UI dopo un
//  paio di refresh. Ora sd_free_mb() ritorna la cache aggiornata solo al mount e
//  dopo un salvataggio: il refresh non tocca piu' il filesystem.
static void refreshStatus() {
  s_status.battPct      = battery_percent();
  s_status.battCharging = battery_charging();
  s_status.sdOk         = g_sd_ok;
  s_status.sdFreeMb     = g_sd_ok ? sd_free_mb() : 0;
  s_status.sdDiag       = g_sd_diag;     // diagnosi (mostrata se !sdOk)
  s_status.sessionOpen  = g_session_open;
  s_status.sessionId    = sd_session_id();
  s_status.sessionShots = sd_session_shot_count();
  // FASE 6: orologio dalla RTC, solo se valida (impostata).
  RtcTime rt = rtc_now();
  s_status.hasTime = rt.valid;
  if (rt.valid) snprintf(s_status.clock, sizeof(s_status.clock), "%02u:%02u", rt.hour, rt.minute);
  else          s_status.clock[0] = '\0';
}

// ----------------------------------------------------------------------------
//  Entra in ATTESA: disegna la schermata IMU-armata e ARMA il trigger.
// ----------------------------------------------------------------------------
static void enterAttesa() {
  // Il tiro precedente e' concluso -> libera il buffer per il prossimo.
  // In 4c il burst e' gia' stato LETTO (computeShotAngles) al DONE: qui si
  // resetta soltanto, tornando in RUNNING per la finestra mobile del prossimo.
  circular_buffer_reset();
  float tC = g_imu_ok ? imu_read_temperature() : NAN;
  refreshStatus();                                       // FASE 5: aggiorna barra
  displayAttesaTiroIMU_v5((uint16_t)(g_shot_id + 1), tC, s_status);
  s_lastTempMs = millis();
  // Svuota un eventuale semaforo residuo (un trigger arrivato mentre eravamo
  // ancora nel riepilogo non deve far partire subito il tiro dopo).
  if (g_trigger_fired_sem) xSemaphoreTake(g_trigger_fired_sem, 0);
  trigger_set_armed(true);
  s_flow = AppFlow::ATTESA;
}

// ----------------------------------------------------------------------------
//  Avvia lo scoring del tiro corrente: DISARMA il trigger e mostra il flash.
// ----------------------------------------------------------------------------
static void startScoringForShot(float azPeak) {
  trigger_set_armed(false);               // niente tiri fantasma durante lo score
  displayTriggerFlash(g_shot_id, azPeak); // feedback visivo istantaneo
  scoringStart(g_shot_id);
  // Reset debounce del main: il tap dato dentro lo scoring non deve trapelare.
  s_stable = false; s_relCnt = 0; s_lastActionMs = millis();
  s_flow = AppFlow::SCORING;
}

// ----------------------------------------------------------------------------
//  FASE 7 — bleButtonPressed(): fronte di pressione del tasto BOOT, debounced.
// ----------------------------------------------------------------------------
//  GPIO0 e' attivo-basso (pull-up). Rileviamo il FRONTE di pressione (HIGH->LOW)
//  una volta sola per pressione, con un debounce temporale semplice: dopo un
//  evento valido ignoriamo il tasto per DEBOUNCE_MS, cosi' un rimbalzo meccanico
//  non genera due toggle. Non usiamo il rilascio: il fronte di pressione da'
//  una risposta immediata (l'utente vuole "entro/esco" al tocco, non al lascia).
static bool bleButtonPressed() {
#if ARCHBB_BLE_ENTRY == 2
  // PWRKEY del PMU (via I2C): il tasto utente vero della 1.83. Non-bloccante,
  // ritorna true una volta per pressione breve. Nessun problema di strapping.
  // THROTTLE: interroghiamo il PMU al massimo ogni ~120ms invece che a ogni giro
  // di loop (~15ms). Una pressione dura ben piu' di 120ms, quindi non se ne
  // perde nessuna, e alleggeriamo il bus I2C condiviso con IMU/touch.
  static uint32_t lastPollMs = 0;
  uint32_t now = millis();
  if (now - lastPollMs < 120) return false;
  lastPollMs = now;
  return power_key_short_pressed();
#elif ARCHBB_BLE_ENTRY == 1
  // GPIO0 (SOLO test storico: causava blocchi, non usare sul campo).
  static bool     wasLow        = false;
  static uint32_t lastEdgeMs    = 0;
  constexpr uint32_t DEBOUNCE_MS = 250;
  bool low = (digitalRead(PIN_BLE_BUTTON) == LOW);
  uint32_t now = millis();
  if (low && !wasLow && (now - lastEdgeMs >= DEBOUNCE_MS)) {
    wasLow = true; lastEdgeMs = now; return true;
  }
  if (!low) wasLow = false;
  return false;
#else
  // Nessun ingresso: BLE non attivabile.
  return false;
#endif
}

// ----------------------------------------------------------------------------
//  FASE 7 — enterBleMode(): sospende i task IMU e avvia il colloquio BLE.
// ----------------------------------------------------------------------------
//  L'ordine conta:
//    1) DISARMA il trigger e SOSPENDI imu_task/trigger_task: da qui Core 1 e'
//       libero e nessuno tocca piu' l'I2C in polling (il rischio di contesa col
//       BLE sparisce per costruzione — vedi ble_service.h).
//    2) ble_start(): NimBLE su Core 0, advertising col nome device.
//    3) Disegna la schermata "in ascolto".
//  Il nome advertising porta le ultime 2 cifre esadecimali del MAC cosi' due
//  ArchBB vicini si distinguono nello scanner. Lo componiamo una volta.
static char s_bleDevName[24] = "ArchBB-183";
static bool s_bleLastConnected = false;   // per ridisegnare solo al cambio stato

static void enterBleMode() {
  // 1) Ferma la catena IMU. trigger_set_armed(false) prima, poi sospendi: cosi'
  //    non resta un semaforo di trigger appeso da raccogliere all'uscita.
  trigger_set_armed(false);

  // --- SOSPENSIONE SICURA DEI TASK (fix deadlock PWRKEY) -------------------
  //  ATTENZIONE: sospendere un task MENTRE detiene il mutex del bus I2C lascia
  //  il mutex preso per sempre -> il primo i2cLock() successivo (refreshStatus,
  //  ble_start) si blocca in eterno. Era esattamente il blocco al PWRKEY.
  //
  //  SOLUZIONE: prendiamo NOI il mutex I2C prima di sospendere. Se imu_task e' a
  //  meta' di una transazione (dentro i2cLock), questa Take aspetta che la
  //  rilasci; solo allora sospendiamo, a bus LIBERO. Poi rilasciamo: da qui in
  //  poi nel modo BLE il bus e' usato solo dal loop UI (i task sono fermi), che
  //  prende/rilascia il mutex normalmente.
  i2cLock();                                     // attende che i task lascino il bus
  if (s_imuTaskHandle)     vTaskSuspend(s_imuTaskHandle);
  if (s_triggerTaskHandle) vTaskSuspend(s_triggerTaskHandle);
  i2cUnlock();                                   // bus libero, task fermi a bus pulito

  // Svuota un eventuale trigger residuo (un tiro proprio mentre premevi PWRKEY).
  if (g_trigger_fired_sem) xSemaphoreTake(g_trigger_fired_sem, 0);

  // 2) Componi il nome device col suffisso MAC (una volta) e avvia il BLE.
  {
    uint8_t mac[6] = {0};
    esp_read_mac(mac, ESP_MAC_BT);   // MAC del radio Bluetooth
    snprintf(s_bleDevName, sizeof(s_bleDevName), "ArchBB-183-%02X%02X", mac[4], mac[5]);
  }
  ble_start(s_bleDevName, &g_config);

  // 3) Schermata "in ascolto" (non connesso). refreshStatus riempie batt/SD/ora.
  refreshStatus();
  s_bleLastConnected = false;
  displayBleMode(false, s_bleDevName, s_status);

  s_flow = AppFlow::BLE_MODE;
}

// ----------------------------------------------------------------------------
//  FASE 7 — exitBleMode(): chiude il BLE, applica il config, torna in ATTESA.
// ----------------------------------------------------------------------------
//  L'ordine speculare all'ingresso:
//    1) ble_stop(): disconnette, ferma NimBLE, libera lo stack (~40KB).
//    2) Se l'app ha EDITATO il config, config_save()+config_apply() lo rendono
//       operativo (oggi: il montaggio; trigger/finestre quando arriveranno i
//       loro setter runtime — vedi README §BLE).
//    3) RIPRENDI i task IMU e rientra in ATTESA (enterAttesa riarma il trigger).
static void exitBleMode() {
  bool cfgEdited = ble_config_was_edited();
  bool timeSet   = ble_time_was_set();

  ble_stop();

  // Persisti + applica se qualcosa e' cambiato. config_reset (dall'app) ha gia'
  // scritto in NVS; una WRITE del config invece ha solo aggiornato la RAM: qui
  // la salviamo. config_save e' idempotente e poco costoso, lo chiamiamo se il
  // flag "edited" e' attivo.
  if (cfgEdited) {
    config_save();
    config_apply();   // rende operativo il montaggio (unico campo cablato oggi)
  }

  // Riprendi la catena IMU (se esiste: potrebbe non esserci a banco senza IMU).
  if (s_imuTaskHandle)     vTaskResume(s_imuTaskHandle);
  if (s_triggerTaskHandle) vTaskResume(s_triggerTaskHandle);

  // Feedback breve se l'ora e' stata sincronizzata (utile: ora le sessioni si
  // datano corrette). Poi torna in ATTESA, che riarma il trigger.
  if (timeSet) {
    RtcTime rt = rtc_now();
    if (rt.valid) {
      tft.fillScreen(ArchColor::BG);
      tft.setTextDatum(MC_DATUM);
      tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
      tft.drawString("ORA SINCRONIZZATA", ARCHBB_W/2, ARCHBB_H/2 - 12, 4);
      char t[24]; snprintf(t, sizeof(t), "%02u:%02u %02u/%02u/%04u",
                           rt.hour, rt.minute, rt.day, rt.month, rt.year);
      tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
      tft.drawString(t, ARCHBB_W/2, ARCHBB_H/2 + 20, 2);
      delay(1200);
    }
  }

  enterAttesa();   // ridisegna ATTESA e riarma il trigger
}

// ----------------------------------------------------------------------------
//  runAngleDiag — TEST STATICO dei segni di montaggio (Fase 4c).
// ----------------------------------------------------------------------------
//  Modalita' \"capolinea\" chiamata dal menu d'avvio: media in continuo gli assi
//  GREZZI del sensore (~1s a finestra scorrevole) e li passa a displayAngleDiag,
//  che mostra cant/alzo per tutti e 4 i montaggi. L'IMU deve essere gia'
//  inizializzata (imu_init in setup, PRIMA del menu) ma i task NON ancora
//  avviati (cosi' nessuno muove g_latest_sample: leggiamo noi, direttamente).
//  Si esce solo spegnendo: e' un banco di misura, non un passo del flusso.
// ----------------------------------------------------------------------------
static void runAngleDiag() {
  // Media mobile semplice su ~1s: a 224Hz sono ~224 campioni, ma leggiamo
  // \"quando pronto\" a intervalli di ~25ms per non intasare il refresh video.
  // Bastano ~40 letture/s per una media stabile e un display fluido.
  constexpr int WIN = 40;               // campioni nella finestra di media
  static float bx[WIN], by[WIN], bz[WIN];
  int head = 0, filled = 0;

  // --- Output seriale CSV (Fase 4c, dietro ARCHBB_DEBUG) --------------------
  //  Al tavolino col monitor aperto la seriale da' il DATO COPIABILE: gli assi
  //  grezzi mediati e i cant/alzo dei 4 montaggi in CSV, pronti da incollare in
  //  un foglio o in uno script. Il display resta il colpo d'occhio (8/s), la
  //  seriale va piu' rada (~1/s) cosi' ogni riga e' una media gia' stabile e il
  //  terminale non si allaga. Cautele HWCDC (memoria di progetto): stampa SOLO
  //  se il monitor e' pronto (availableForWrite>0), mai a raffica. Qui e' sicuro
  //  perche' i task IMU non sono ancora avviati: runAngleDiag gira nel menu.
#ifdef ARCHBB_DEBUG
  uint32_t s_lastCsvMs = 0;
  bool     s_hdrPrinted = false;
#endif

  for (;;) {
    float ax, ay, az, gx, gy, gz;
    if (imu_read_raw(ax, ay, az, gx, gy, gz)) {
      bx[head] = ax; by[head] = ay; bz[head] = az;
      head = (head + 1) % WIN;
      if (filled < WIN) filled++;
    }

    // Media e sd del modulo |a| sulla finestra corrente.
    float mx = 0, my = 0, mz = 0, gm = 0;
    for (int i = 0; i < filled; i++) {
      mx += bx[i]; my += by[i]; mz += bz[i];
      gm += sqrtf(bx[i]*bx[i] + by[i]*by[i] + bz[i]*bz[i]);
    }
    if (filled > 0) { mx/=filled; my/=filled; mz/=filled; gm/=filled; }
    float var = 0;
    for (int i = 0; i < filled; i++) {
      float m = sqrtf(bx[i]*bx[i] + by[i]*by[i] + bz[i]*bz[i]);
      var += (m - gm) * (m - gm);
    }
    float sd = (filled >= 2) ? sqrtf(var / (filled - 1)) : 0.0f;

    displayAngleDiag(mx, my, mz, gm, sd, (uint16_t)filled);

    // --- Riga CSV sulla seriale (~1/s), solo in debug e col monitor pronto ---
#ifdef ARCHBB_DEBUG
    if ((bool)Serial && Serial.availableForWrite() > 0) {
      if (!s_hdrPrinted) {
        Serial.println();
        Serial.println("ARCHBB_DIAG_ANGOLI_CSV");
        Serial.println("t_ms,ax,ay,az,gmean,gsd,n,"
                       "cant0,alzo0,cantDX,alzoDX,cantSX,alzoSX,cant180,alzo180,cantFZ,alzoFZ");
        s_hdrPrinted = true;
      }
      uint32_t now = millis();
      if (now - s_lastCsvMs >= 1000 && filled >= 2) {
        s_lastCsvMs = now;
        // Stessi grezzi mediati -> cant/alzo per TUTTI i montaggi, fianco a fianco.
        float c[MOUNT_COUNT], a[MOUNT_COUNT];
        for (uint8_t m = 0; m < MOUNT_COUNT; m++) {
          float px = mx, py = my, pz = mz, d0 = 0, d1 = 0, d2 = 0;
          mount_apply(m, px, py, pz, d0, d1, d2);
          c[m] = atan2f(py, px) * 180.0f / (float)M_PI;
          a[m] = atan2f(pz, px) * 180.0f / (float)M_PI;
        }
        // %.3f sugli assi (i segni richiedono precisione), %.1f sugli angoli.
        // NB: mount_apply applica gia' il flip-Z hardware a monte (ARCHBB_HW_FLIP_Z),
        // quindi questi cant/alzo sono nel frame corretto della 1.83.
        Serial.printf("%lu,%.3f,%.3f,%.3f,%.3f,%.3f,%d,"
                      "%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f\n",
                      (unsigned long)now, mx, my, mz, gm, sd, filled,
                      c[MOUNT_0],       a[MOUNT_0],
                      c[MOUNT_DX_M90],  a[MOUNT_DX_M90],
                      c[MOUNT_SX_P90],  a[MOUNT_SX_P90],
                      c[MOUNT_180],     a[MOUNT_180]);
      }
    }
#endif

    delay(120);   // ~8 refresh/s: fluido e non affamato di CPU
  }
}

// ============================================================================
//  setup()
// ============================================================================
void setup() {
  Serial.begin(115200);
  Serial.setTxTimeoutMs(0);   // Serial.printf non blocca col monitor chiuso

  // FASE 7: ingresso modo BLE. Col PWRKEY (ENTRY==2, default) NON serve alcun
  // pinMode: il tasto e' letto via I2C dal PMU (init in battery_init). GPIO0 si
  // configura solo nel caso di test storico ENTRY==1.
#if ARCHBB_BLE_ENTRY == 1
  pinMode(PIN_BLE_BUTTON, INPUT_PULLUP);
#endif

  // --- FASE 6: CONFIG da NVS (fonte di verita' unica) ----------------------
  //  Carica il config dall'NVS in g_config (o default se assente/corrotto), poi
  //  lo rende operativo. config_apply() imposta g_mount_orientation dal config:
  //  sostituisce l'assegnazione diretta di prima. Da qui il montaggio (e in
  //  futuro trigger/finestre via BLE) vengono dal config, non da costanti fisse.
  bool cfgFromNvs = config_load();
  config_apply();

  // --- Init hardware, nell'ordine giusto -----------------------------------
  displayInit();

  // --- FIX-DIAG: MOTIVO DELL'ULTIMO RESET a schermo ------------------------
  //  "I dati comandano": invece di indovinare perche' si blocca, facciamo dire
  //  al firmware perche' e' ripartito. Se l'ultimo boot e' finito in watchdog o
  //  panic (blocco -> reset automatico), qui lo vediamo scritto. Se e' un reset
  //  pulito (accensione, tasto RESET) non ci fermiamo. Resta 2s solo se il reset
  //  precedente era ANOMALO, cosi' non rallenta l'uso normale.
  {
    esp_reset_reason_t rr = esp_reset_reason();
    const char* txt = nullptr;
    switch (rr) {
      case ESP_RST_PANIC:    txt = "RESET: PANIC (crash SW)";        break;
      case ESP_RST_TASK_WDT: txt = "RESET: TASK WATCHDOG";           break;
      case ESP_RST_INT_WDT:  txt = "RESET: INT WATCHDOG";            break;
      case ESP_RST_WDT:      txt = "RESET: WATCHDOG (altro)";        break;
      case ESP_RST_BROWNOUT: txt = "RESET: BROWNOUT (tensione)";     break;
      default: break;   // POWERON / EXT / SW: reset normale, non mostrare nulla
    }
    if (txt) {
      tft.fillScreen(ArchColor::BG);
      tft.setTextDatum(MC_DATUM);
      tft.setTextColor(ArchColor::BAD, ArchColor::BG);
      tft.drawString("ULTIMO RIAVVIO", ARCHBB_W/2, ARCHBB_H/2 - 24, 2);
      tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
      tft.drawString(txt, ARCHBB_W/2, ARCHBB_H/2, 2);
      tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
      tft.drawString("(diagnostica blocco)", ARCHBB_W/2, ARCHBB_H/2 + 26, 1);
      delay(2500);
    }
  }

  touchInit();     // avvia Wire (bus I2C condiviso) e configura il CST816

  // --- IMU inizializzata PRIMA del menu (serve al DIAG ANGOLI) --------------
  // In 4a l'IMU si inizializzava dopo il menu touch; in 4c la anticipiamo,
  // perche' il DIAG ANGOLI (test statico) deve poter leggere il sensore mentre
  // e' nel menu. I task NON partono ancora: g_latest_sample resta fermo, il
  // DIAG legge coi propri imu_read_raw() senza conflitti.
  bool imuOk = imu_init(ODR_250HZ, 8, 512);   // usa il bus GIA' attivo

  // --- FASE 5: batteria (AXP2101) sul bus I2C GIA' attivo -------------------
  // Dopo touchInit (che ha avviato Wire): battery_init NON re-inizializza il bus.
  bool battOk = battery_init();

  // --- FASE 6: RTC PCF85063 sul bus I2C GIA' attivo ------------------------
  // Stesso bus di IMU/touch/batteria. rtc_init NON chiama Wire.begin(). Serve a
  // datare le sessioni. Impostazione dell'ora via BLE (futuro).
  bool rtcOk = rtc_init();

  // --- FASE 5: microSD sul suo bus SPI dedicato (FSPI, pin 1/2/3/42) --------
  // Bus separato dal display: nessuna contesa. Se la card e' assente, sd_init
  // torna false e il firmware prosegue senza salvare (g_sd_ok resta false).
  bool sdOk = sd_init();

  // --- MENU D'AVVIO (OPT-IN): CALIBRA / DIAG touch / DIAG ANGOLI ------------
  // Subito dopo il touch e prima di avviare i task. E' l'unico momento in cui
  // bloccare e' innocuo (nessun task, nessun tiro). Default = salta dopo 3s.
  {
    int scelta = touch_cal_offer(tft, 3000);
    if (scelta == 1) {
      TouchCalResult r = touch_cal_run(tft);
      (void)r;   // i coefficienti si ricopiano a mano in config.h (voluto)
    } else if (scelta == 2) {
      touch_cal_diag(tft);
    } else if (scelta == 3) {
      // DIAG ANGOLI: test statico dei segni di montaggio (Fase 4c).
      if (imuOk) runAngleDiag();   // non ritorna: si esce spegnendo
      // Se l'IMU non c'e', il menu non offre nemmeno la voce (v. touch_cal_offer).
    } else if (scelta == 4) {
      // CONFIG (Fase 6): lettura parametri NVS + ripristina default. Ritorna
      // all'uscita (a differenza di DIAG angoli). Dopo un eventuale reset,
      // riapplichiamo il config cosi' il montaggio torna operativo dal valore
      // ripristinato.
      config_ui_show(tft);
      config_apply();
    }
  }

  bool bufOk = circular_buffer_init();        // buffer in PSRAM (Fase 4b)
  trigger_init();

  // --- Task FreeRTOS su Core 1 ----------------------------------------------
  // Priorita': IMU la piu' alta (non deve perdere campioni), trigger appena
  // sotto, la UI (loop) gira alla priorita' di default di Arduino.
  if (imuOk) {
    // FASE 7: salviamo gli handle per poter sospendere/riprendere i task quando
    // si entra/esce dal modo BLE.
    xTaskCreatePinnedToCore(imu_task,     "imu",     4096, nullptr, 5, &s_imuTaskHandle,     1);
    xTaskCreatePinnedToCore(trigger_task, "trigger", 4096, nullptr, 4, &s_triggerTaskHandle, 1);
  }

  // --- Schermata iniziale + arma il trigger ---------------------------------
  enterAttesa();

  if ((bool)Serial && Serial.availableForWrite() > 0) {
    Serial.printf("=== ArchBB 1.83 — Fase 5 (microSD) — IMU %s, buffer %s, mount %s ===\n",
                  imuOk ? "OK" : "ASSENTE", bufOk ? "OK" : "FALLITO",
                  mount_name(g_mount_orientation));
    Serial.printf("    BATT %s | SD %s",
                  battOk ? "OK" : "ASSENTE", sdOk ? "OK" : "ASSENTE");
    if (sdOk) Serial.printf(" (%lu MB liberi / %lu MB)",
                            (unsigned long)sd_free_mb(), (unsigned long)sd_total_mb());
    Serial.println();
    Serial.printf("    CONFIG %s (v%u)\n",
                  cfgFromNvs ? "da NVS" : "default", g_config.version);
    { char iso[24]; rtc_iso_string(iso, sizeof(iso));
      Serial.printf("    RTC %s (%s)\n", rtcOk ? "OK" : "ASSENTE", iso); }
  }
}

// ============================================================================
//  loop()  =  TASK UI (touch + scoring + display)
// ============================================================================
void loop() {
  TouchData td = touchRead();

  switch (s_flow) {

    // ---------------------------------------------------------------------
    case AppFlow::ATTESA: {
      // 0) FASE 7: tasto BOOT (ingranaggio) = entra nel modo BLE. Solo da ATTESA
      //    (non durante scoring/riepilogo). enterBleMode sospende i task IMU.
      if (bleButtonPressed()) {
        enterBleMode();
        break;
      }

      // 1) Tiro REALE: il trigger IMU ha sparato? E' l'UNICO modo di tirare
      //    quando l'IMU e' viva (lo scoring e' chiuso: la freccia comanda).
      if (g_trigger_fired_sem &&
          xSemaphoreTake(g_trigger_fired_sem, 0) == pdTRUE) {
        startScoringForShot(g_trigger_az_peak);
        break;
      }

      // 2) TOCCO in ATTESA = gestione SESSIONE (Fase 5, ridisegnato).
      //    Non piu' tap-lungo: qualunque tocco pulito apre/chiude la sessione.
      //    Niente cronometro fragile da distinguere dal tap-breve -> il bug
      //    "parte sempre come breve" sparisce alla radice (non c'e' piu' un
      //    breve da cui distinguere). tapReleased() da' il fronte di rilascio
      //    gia' debounced e col cooldown: un tocco = un toggle, pulito.
      //
      //    ECCEZIONE: se l'IMU e' ASSENTE, il tocco resta il tiro manuale
      //    (unica ancora di salvezza a banco). In campo l'IMU c'e' sempre,
      //    quindi questo ramo non si vede mai.
      if (tapReleased(td)) {
        if (!g_imu_ok) {
          // IMU assente: il tocco e' l'unico trigger disponibile.
          g_shot_id++;
          startScoringForShot(0.0f);
          break;
        }
        // IMU viva: il tocco gestisce la sessione.
        if (g_sd_ok) {
          if (g_session_open) {
            // Sessione aperta -> chiudi (comportamento invariato).
            sd_session_stop();
            refreshStatus();
            displayAttesaTiroIMU_v5((uint16_t)(g_shot_id + 1),
                                    imu_read_temperature(), s_status);
            s_lastTempMs = millis();
          } else if (sd_has_previous_session()) {
            // Nessuna sessione aperta ma ce n'e' una su card -> CHIEDI:
            // riprendere l'ultima (accoda) o iniziarne una nuova?
            char lastName[24] = ""; uint16_t lastShots = 0;
            sd_last_session_info(lastName, sizeof(lastName), lastShots);
            displaySessionChoice(lastName, lastShots);
            s_stable = false; s_relCnt = 0; s_lastActionMs = millis();
            s_flow = AppFlow::SESSION_CHOICE;
          } else {
            // Card vuota (nessuna sessione precedente) -> apri direttamente.
            sd_session_start();
            refreshStatus();
            displayAttesaTiroIMU_v5((uint16_t)(g_shot_id + 1),
                                    imu_read_temperature(), s_status);
            s_lastTempMs = millis();
          }
        } else {
          // Nessuna SD: il tocco non ha effetto utile. Lampeggia un avviso
          // breve invece di fingere che sia successo qualcosa.
          displaySessionNoSd();
          s_lastTempMs = 0;   // forza il refresh alla prossima iterazione
        }
        break;
      }

      // 3) Rinfresca temperatura + barra di stato ogni 3s (feedback "IMU viva").
      if (millis() - s_lastTempMs > 3000) {
        s_lastTempMs = millis();
        refreshStatus();
        displayAttesaTiroIMU_v5((uint16_t)(g_shot_id + 1),
                                g_imu_ok ? imu_read_temperature() : NAN, s_status);
      }
      break;
    }

    // ---------------------------------------------------------------------
    case AppFlow::SCORING: {
      ScoringState st = scoringUpdate(td);
      if (st == ScoringState::DONE) {
        s_lastResult = scoringGetResult();

        // --- FASE 4c: leggi il burst congelato e calcola gli angoli ---------
        // QUI, prima del riepilogo e prima di enterAttesa (che resetta il
        // buffer). Se il buffer non e' READY (tiro manuale senza IMU) le
        // metriche restano \"non valide\" -> il riepilogo mostra n/d.
        computeShotAngles(s_lastResult);

        s_stable = false; s_relCnt = 0; s_lastActionMs = millis();
        displayScoreRiepilogo(s_lastResult,
                              zonaLabel(s_lastResult.colpito, s_lastResult.zona));
        s_flow = AppFlow::RIEPILOGO;
      }
      break;
    }

    // ---------------------------------------------------------------------
    case AppFlow::SESSION_CHOICE: {
      static uint16_t cx = 0, cy = 0;
      if (td.valid && td.fingers > 0) { cx = td.x; cy = td.y; }
      if (tapReleased(td)) {
        uint8_t hit = hitSessionChoice(cx, cy);
        if (hit == 1) {                     // RIPRENDI -> accoda all'ultima
          sd_session_resume_last();
          refreshStatus();
          displayAttesaTiroIMU_v5((uint16_t)(g_shot_id + 1),
                                  g_imu_ok ? imu_read_temperature() : NAN, s_status);
          s_lastTempMs = millis();
          s_flow = AppFlow::ATTESA;
        } else if (hit == 2) {              // NUOVA -> sessione vergine
          sd_session_start();
          refreshStatus();
          displayAttesaTiroIMU_v5((uint16_t)(g_shot_id + 1),
                                  g_imu_ok ? imu_read_temperature() : NAN, s_status);
          s_lastTempMs = millis();
          s_flow = AppFlow::ATTESA;
        }
        // tocco fuori dai pulsanti: resta nella schermata di scelta.
      }
      break;
    }

    // ---------------------------------------------------------------------
    case AppFlow::RIEPILOGO: {
      static uint16_t rx = 0, ry = 0;
      if (td.valid && td.fingers > 0) { rx = td.x; ry = td.y; }
      if (tapReleased(td)) {
        uint8_t hit = hitRiepilogo(rx, ry);
        if (hit == 2) {                  // OK -> cementa e torna in attesa
          // --- FASE 5: SCRITTURA SU microSD --------------------------------
          //  Qui, PRIMA di enterAttesa() (che resetta il buffer). Il burst e'
          //  gia' in s_burst (letto da computeShotAngles al DONE) e i suoi
          //  metadati in s_burstN/s_burstTrig. Passiamo il puntatore solo se il
          //  burst e' valido; altrimenti nullptr -> si salva il solo CSV.
          //  sd_save_shot auto-apre una sessione se non ce n'e' una (l'arciere
          //  che tira senza aver premuto "start" non perde il dato).
          if (g_sd_ok) {
            const ImuSample* bp = (s_burstN > 0) ? s_burst : nullptr;
            bool saved = sd_save_shot(s_lastResult, bp, s_burstN, s_burstTrig, ODR_250HZ);
            if (saved) {
              // Feedback di scrittura riuscita: doppio flash verde col numero
              // del tiro appena salvato (= conteggio attuale della sessione).
              displaySavedFlash(sd_session_shot_count());
            }
          }
          enterAttesa();                 // riarma il trigger per il prossimo tiro
        } else if (hit == 1) {           // CORREGGI -> riapre lo scoring corrente
          scoringResume();
          s_flow = AppFlow::SCORING;
        }
        // tocco fuori dai pulsanti: ignorato.
      }
      break;
    }

    // ---------------------------------------------------------------------
    case AppFlow::BLE_MODE: {
      // 1) Tasto BOOT di nuovo = ESCI dal modo BLE (chiude tutto, applica config,
      //    riprende i task, torna in ATTESA).
      if (bleButtonPressed()) {
        exitBleMode();
        break;
      }

      // 2) Ridisegna la schermata SOLO quando cambia lo stato di connessione
      //    (app agganciata / staccata): niente refresh nel loop stretto. Lo
      //    STATUS periodico (batteria/SD/ora) lo notifica il ble_task all'app;
      //    a schermo aggiorniamo il colpo d'occhio solo sul cambio connessione.
      bool nowConnected = g_ble_connected;
      if (nowConnected != s_bleLastConnected) {
        s_bleLastConnected = nowConnected;
        refreshStatus();
        displayBleMode(nowConnected, s_bleDevName, s_status);
      }
      break;
    }
  }

  // Cede il Core 1 agli altri task. 15ms: UI fluida (~66 Hz touch), IMU/trigger
  // hanno CPU in abbondanza.
  delay(15);
}

#endif // firmware di produzione (escluso nei build di test)
