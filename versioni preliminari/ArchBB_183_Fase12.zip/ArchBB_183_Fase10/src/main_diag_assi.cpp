// ============================================================================
//  ArchBB 1.83 — main_diag_assi.cpp · DIAG ASSI
//  Decide quale montaggio descrive la scheda MONTATA SUL RISER.
//  Cesare Pagura · Padova/Noale IT · 26 luglio 2026
// ----------------------------------------------------------------------------
//  PERCHE' ESISTE
//    Sui nove tiri del 25/07 il firmware riportava cant = +16,98° (σ 0,72°) e
//    alzo = +0,39° (σ 1,22°). L'arciere tirava verso il basso su una sagoma 3D
//    a terra, senza ruotare il braccio d'arco: i 17° erano l'ALZO, non il cant.
//    Le due grandezze erano scambiate.
//
//    La prova decisiva e' arrivata dai 44 tiri della 1.69, dove ci sono tiri a
//    distanze diverse — e l'alzo con la distanza deve crescere, il cant no:
//        atan2(ay,ax)  vs distanza:  rho -0,09  p 0,80   -> e' il cant
//        atan2(az,ax)  vs distanza:  rho +0,53  p 0,09   -> e' l'alzo
//    Sulla 1.83 il rapporto e' invertito. Quindi sulla 1.83 gli assi y e z sono
//    scambiati rispetto alla 1.69: la scheda e' montata ruotata di 90°, non
//    frontale.
//
//    La caratterizzazione del 22/07 aveva concluso "nessuno scambio di assi".
//    Era corretta PER LA POSA IN CUI FU FATTA — al banco. Il montaggio reale
//    sul riser e' un'altra cosa, e nessuno dei due si deduce dall'altro. Da qui
//    la regola operativa di questo strumento: si misura CON LA SCHEDA MONTATA
//    COME SI TIRA, mai smontata sul tavolo.
//
//  COSA FA
//    Guida tre pose statiche ad assetto noto e, alla fine, prova TUTTE le otto
//    combinazioni (4 rotazioni x flip-Z on/off) dicendo quale le soddisfa.
//    Non chiede all'utente di interpretare numeri grezzi: risponde.
//
//  PERCHE' TRE POSE E NON UNA
//    Una posa da' i moduli, non i versi. Due pose con lo stesso |angolo| ma
//    verso opposto sono indistinguibili se si guarda solo il modulo — ed e'
//    esattamente l'errore che ha prodotto il FLIPZ. Qui:
//      POSA 1  a piombo          -> misura l'OFFSET del supporto (si sottrae)
//      POSA 2  punta in BASSO    -> l'asse che raccoglie la gravita' e' quello
//                                   della FRECCIA, e il segno dev'essere
//                                   NEGATIVO (convenzione: + = punta in su)
//      POSA 3  riser a DESTRA    -> l'asse che raccoglie la gravita' e' quello
//                                   LATERALE, segno POSITIVO (+ = destra)
//    Le pose 2 e 3 si valutano come DIFFERENZA dalla posa 1: cosi' l'offset del
//    supporto sparisce e non serve che l'arco sia perfettamente a piombo.
//
//  NON SERVE UN ANGOLO PRECISO
//    Il verdetto non usa il valore dell'angolo, solo QUALE asse lo raccoglie e
//    con che SEGNO. Bastano "punta giu' di circa 20°" e "riser a destra di circa
//    20°" fatti a occhio. L'angolo misurato viene comunque mostrato, cosi' se
//    hai un'inclinometro puoi confrontarlo.
//
//  USO
//    pio run -e archbb_183_assi -t upload
//    (in VS Code seleziona l'ambiente nella barra di stato PRIMA di Upload)
//    Poi: monta la scheda sul riser come tiri, e segui le istruzioni a schermo.
// ============================================================================
#ifdef ARCHBB_DIAG_ASSI

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <math.h>

#include "config.h"
#include "display.h"
#include "touch.h"
#include "imu.h"
#include "mount.h"

// ----------------------------------------------------------------------------
//  Criterio di IMMOBILITA' — v2, TARATO SUL RUMORE VERO
// ----------------------------------------------------------------------------
//  LA v1 NON SCATTAVA MAI, e per due errori distinti.
//
//  1) IL GIROSCOPIO HA UN OFFSET DI FABBRICA, e io guardavo il MODULO.
//     Misurato sulle finestre calme dei nove tiri del 25/07 (arciere in mira,
//     il piu' fermo che ci sia): |gyro| medio 8,26 dps, con bias per asse
//     gx -2,47, gy -6,11, gz -0,14. La mia soglia era 2,0 dps sul modulo:
//     irraggiungibile PER COSTRUZIONE, perche' il bias non sparisce stando
//     fermi — e' un offset costante, non movimento.
//     La cura non e' alzare la soglia: e' guardare la grandezza giusta. Un
//     corpo fermo ha giroscopio COSTANTE, non nullo. Quindi si misura la
//     DISPERSIONE per asse, che del bias non sa nulla.
//
//  2) ANCHE LA SOGLIA SULL'ACCELEROMETRO ERA TROPPO STRETTA.
//     Misurato: sd di |a| = 0,216 m/s^2 in mira, contro i 0,08 che chiedevo.
//
//  LA CURA STRUTTURALE: NON SI INDOVINANO LE SOGLIE, SI MISURANO.
//     All'avvio il DIAG sta zitto tre secondi e misura il rumore di FONDO del
//     tuo esemplare sul tuo supporto. Le soglie diventano un multiplo di quel
//     numero. Cosi' funziona su qualunque scheda, qualunque cavalletto, e
//     senza che nessuno debba ritarare niente a mano. E' la stessa logica dello
//     ZUPT usato per il bias del giroscopio: la condizione di quiete la si
//     misura, non la si presume.
static constexpr float    K_SOGLIA        = 4.0f;   // margine sul rumore misurato
static constexpr float    MIN_SD_ACC      = 0.05f;  // pavimenti: mai piu' stretto
static constexpr float    MIN_SD_GYR      = 0.30f;  //   della risoluzione utile
static constexpr uint32_t TARATURA_MS     = 3000;
static constexpr uint32_t FERMO_MS        = 1000;
static constexpr int      N_FIN           = 48;     // ~0,22 s a 218 Hz
static constexpr uint32_t RIPIEGO_MS      = 8000;   // dopo tanto, tocco manuale

// Soglie effettive, riempite dalla taratura.
static float s_soglia_acc = MIN_SD_ACC;
static float s_soglia_gyr = MIN_SD_GYR;

// Escursione minima che rende una posa utilizzabile: sotto i 6 gradi il rumore
// e l'offset del supporto pesano quanto il gesto, e il verdetto non e' affidabile.
static constexpr float ESCURSIONE_MIN_DEG = 6.0f;

// NOTA C++11 (il core ESP32 compila in gnu++11)
//   Questa struct NON deve avere inizializzatori di default sui membri
//   (`bool fatta = false;`). In C++11 un membro con inizializzatore rende la
//   struct NON AGGREGATA, e l'inizializzazione con graffe `{true, x, y, z}`
//   diventa illegale ("no match for operator="). Da C++14 sarebbe ammessa, ma
//   alzare lo standard per una comodita' di scrittura non vale il rischio di
//   toccare la toolchain di un progetto che compila.
struct Posa {
    bool  fatta;
    float ax, ay, az;    // GREZZI del sensore (nessuna trasformazione)
};

static Posa s_posa[3];
static int  s_corrente = 0;

// Finestra mobile: sei assi, perche' ora serve la dispersione anche del gyro.
static float    s_buf[N_FIN][6];
static int      s_n = 0, s_w = 0;
static uint32_t s_fermo_da = 0;
static uint32_t s_posa_da  = 0;     // da quanto siamo su questa posa (ripiego)

// Stato: prima si tara, poi si misura.
enum class Fase : uint8_t { TARATURA, POSE, VERDETTO, MOVIMENTI, VERDETTO_GYRO };
static Fase     s_fase = Fase::TARATURA;
static bool     s_imu_ok = false;   // se falso il loop non fa nulla
static uint32_t s_taratura_da = 0;

// Ultime dispersioni calcolate, per mostrarle e per decidere.
static float s_sd_acc = 99, s_sd_gyr = 99;
static bool  s_ok_acc = false, s_ok_gyr = false;

static const char* NOME_POSA[3] = {
    "1 - A PIOMBO",
    "2 - PUNTA IN BASSO",
    "3 - RISER A DESTRA",
};
static const char* ISTR_POSA[3] = {
    "arco verticale, freccia orizzontale",
    "abbassa la punta di ~20 gradi",
    "inclina il riser a destra ~20 gradi",
};

// ----------------------------------------------------------------------------
//  dispersioni() — sd di |a| e sd MASSIMA fra i tre assi del giroscopio.
// ----------------------------------------------------------------------------
//  Il giroscopio si giudica sulla DISPERSIONE PER ASSE, mai sul modulo: il
//  modulo contiene l'offset di fabbrica (misurato su questo esemplare: gy
//  -6,11 dps), che e' costante e quindi non dice nulla sul movimento. La
//  dispersione lo ignora per costruzione, senza doverlo stimare.
//  Si prende il MASSIMO fra i tre assi e non la media: basta un asse che si
//  muove perche' la posa non sia ferma, e una media lo annacquerebbe.
static void dispersioni(float& sd_acc, float& sd_gyr,
                        float& mx, float& my, float& mz)
{
    mx = my = mz = 0;
    if (s_n < 2) { sd_acc = sd_gyr = 99.0f; return; }

    float m[6] = {0,0,0,0,0,0};
    for (int i = 0; i < s_n; i++)
        for (int k = 0; k < 6; k++) m[k] += s_buf[i][k];
    for (int k = 0; k < 6; k++) m[k] /= s_n;
    mx = m[0]; my = m[1]; mz = m[2];

    // accelerometro: dispersione del MODULO (l'assetto e' costante, quindi il
    // modulo isola il tremolio dal valore statico di gravita').
    float mod_medio = sqrtf(m[0]*m[0] + m[1]*m[1] + m[2]*m[2]);
    float va = 0;
    for (int i = 0; i < s_n; i++) {
        float mo = sqrtf(s_buf[i][0]*s_buf[i][0] + s_buf[i][1]*s_buf[i][1]
                       + s_buf[i][2]*s_buf[i][2]);
        float d = mo - mod_medio; va += d * d;
    }
    sd_acc = sqrtf(va / (s_n - 1));

    // giroscopio: sd per asse, si tiene la peggiore.
    sd_gyr = 0;
    for (int k = 3; k < 6; k++) {
        float v = 0;
        for (int i = 0; i < s_n; i++) { float d = s_buf[i][k] - m[k]; v += d * d; }
        float sdk = sqrtf(v / (s_n - 1));
        if (sdk > sd_gyr) sd_gyr = sdk;
    }
}

// ----------------------------------------------------------------------------
//  Valutazione dei candidati
// ----------------------------------------------------------------------------
//  Per ogni combinazione (montaggio, flip) si calcolano cant e alzo nelle tre
//  pose e si controlla che le DIFFERENZE dalla posa 1 abbiano la forma attesa:
//
//    posa 2 (punta giu'):   alzo deve scendere molto, cant restare fermo
//    posa 3 (riser a dx):   cant deve salire molto,  alzo restare fermo
//
//  Punteggio = (quanto e' grande e ben orientato cio' che deve muoversi)
//              - (quanto si muove cio' che dovrebbe stare fermo)
//  Il candidato col punteggio piu' alto vince. Non si usa il valore assoluto
//  dell'angolo: solo la sua direzione. Cosi' non serve un goniometro.
struct Esito {
    uint8_t mount;
    bool    flip;
    float   punteggio;
    float   d_alzo2, d_cant2;    // variazioni misurate, per mostrarle a schermo
    float   d_cant3, d_alzo3;
};

static void angoli(uint8_t m, bool flip, const Posa& p, float& cant, float& alzo)
{
    // Copie locali: mount_apply_ex lavora in-place. Il giroscopio non serve al
    // verdetto (le pose sono statiche) ma la firma lo richiede.
    float ax = p.ax, ay = p.ay, az = p.az, gx = 0, gy = 0, gz = 0;
    mount_apply_ex(m, flip, ax, ay, az, gx, gy, gz);
    cant = degrees(atan2f(ay, ax));
    alzo = degrees(atan2f(az, ax));
}

static Esito valuta(uint8_t m, bool flip)
{
    Esito e; e.mount = m; e.flip = flip;
    float c1, a1, c2, a2, c3, a3;
    angoli(m, flip, s_posa[0], c1, a1);
    angoli(m, flip, s_posa[1], c2, a2);
    angoli(m, flip, s_posa[2], c3, a3);

    e.d_alzo2 = a2 - a1;   e.d_cant2 = c2 - c1;
    e.d_cant3 = c3 - c1;   e.d_alzo3 = a3 - a1;

    // Posa 2: alzo GIU' (negativo) e cant fermo. Posa 3: cant a DESTRA
    // (positivo) e alzo fermo.
    e.punteggio = (-e.d_alzo2 - fabsf(e.d_cant2))
                + ( e.d_cant3 - fabsf(e.d_alzo3));
    return e;
}

static Esito s_migliore, s_secondo;
static bool  s_verdetto = false;
static float s_escursione = 0;

// ============================================================================
//  PROVA DINAMICA — a quali assi del GIROSCOPIO corrispondono alzo, cant, yaw
// ============================================================================
//  PERCHE' NON BASTA LA PROVA STATICA
//    Le tre pose a gravita' nota validano l'ACCELEROMETRO. Una posa statica ha
//    velocita' angolare ZERO: non dice assolutamente nulla sul giroscopio. Se
//    gli assi del giroscopio fossero permutati rispetto a quelli
//    dell'accelerometro, cant e alzo continuerebbero a uscire giusti (vengono
//    dall'accelerometro) e nessuna prova statica se ne accorgerebbe.
//    Tutto cio' che si INTEGRA — traccia 2D, hold, torsione — dipende invece
//    dal giroscopio, e sbaglierebbe in silenzio.
//
//  I TRE MOVIMENTI
//    1. ALZO   abbassa la punta di ~30 gradi e fermati
//    2. CANT   rolla il riser a destra di ~30 gradi e fermati
//    3. YAW    ruota tutto l'arco a destra di ~30 gradi, punta orizzontale
//    Un solo verso, non avanti-e-indietro: un movimento che torna al punto di
//    partenza ha integrale nullo e non direbbe niente.
//
//  LA PROPRIETA' UTILE
//    I primi due movimenti cambiano la direzione della gravita', quindi
//    l'ACCELEROMETRO li vede e fa da controprova indipendente: l'asse del
//    giroscopio che integra la stessa escursione misurata dall'accelerometro
//    e' quello giusto. Il terzo (rotazione attorno alla verticale) NON cambia
//    la gravita' — ed e' esattamente il motivo per cui serve il giroscopio.
//    Per quello si procede per esclusione: e' l'asse rimasto.
static constexpr float MOV_INIZIO_DPS = 12.0f;   // sopra: il movimento e' iniziato
static constexpr float MOV_FINE_DPS   = 4.0f;    // sotto per un po': e' finito
static constexpr uint32_t MOV_FERMO_MS = 500;    // quanto restare fermi per chiudere
static constexpr float MOV_MIN_DEG     = 12.0f;  // sotto: movimento troppo piccolo

struct Movimento {
    bool  fatto;
    float ig[3];        // integrale di gx, gy, gz [gradi]
    float d_alzo;       // variazione vista dall'ACCELEROMETRO (controprova)
    float d_cant;
};

static Movimento s_mov[3];
static int  s_mov_corrente = 0;
static bool s_mov_attivo = false;          // true = sto integrando
static uint32_t s_mov_fermo_da = 0;
static float s_mov_acc[3];                 // accumulatori dell'integrale
static float s_mov_bias[3];                // bias misurato prima del movimento
// Flag esplicito invece di controllare "bias != 0": un bias esattamente nullo
// e' improbabile ma legittimo, e usarlo come sentinella e' il tipo di scorciatoia
// che poi non si capisce piu' perche' non funziona.
static bool  s_mov_bias_pronto = false;
static float s_mov_a0[3];                  // accelerometro all'inizio
static uint32_t s_mov_t_prec = 0;

static const char* NOME_MOV[3] = { "1 - ALZO", "2 - CANT", "3 - YAW" };
static const char* ISTR_MOV[3] = {
    "abbassa la punta di ~30 gradi",
    "rolla il riser a destra ~30 gradi",
    "ruota l'arco a destra, punta orizzontale",
};

// Quale asse ha integrato di piu', e con che segno.
static int asse_dominante(const float ig[3], float& valore)
{
    int k = 0;
    for (int i = 1; i < 3; i++) if (fabsf(ig[i]) > fabsf(ig[k])) k = i;
    valore = ig[k];
    return k;
}

static const char* NOME_ASSE[3] = { "gx", "gy", "gz" };

static void stampa_dinamica()
{
    if (!(bool)Serial || Serial.availableForWrite() <= 0) return;
    Serial.println();
    Serial.println("=== PROVA DINAMICA — assi del giroscopio ===");
    for (int m = 0; m < 3; m++) {
        float v; int k = asse_dominante(s_mov[m].ig, v);
        Serial.printf("%-8s  gx %+7.2f  gy %+7.2f  gz %+7.2f  -> %s (%+.1f)"
                      "   [accel: d_alzo %+6.2f  d_cant %+6.2f]\n",
                      NOME_MOV[m], s_mov[m].ig[0], s_mov[m].ig[1], s_mov[m].ig[2],
                      NOME_ASSE[k], v, s_mov[m].d_alzo, s_mov[m].d_cant);
    }
}

static void calcola_verdetto()
{
    bool primo = true;
    for (uint8_t m = 0; m < MOUNT_COUNT; m++) {
        for (int f = 0; f < 2; f++) {
            Esito e = valuta(m, (bool)f);
            if (primo) { s_migliore = e; s_secondo = e; primo = false; continue; }
            if (e.punteggio > s_migliore.punteggio) { s_secondo = s_migliore; s_migliore = e; }
            else if (e.punteggio > s_secondo.punteggio) { s_secondo = e; }
        }
    }
    // Escursione effettiva delle due pose: se e' piccola, il verdetto e' fragile.
    s_escursione = fminf(fabsf(s_migliore.d_alzo2), fabsf(s_migliore.d_cant3));
    s_verdetto = true;
}

// ----------------------------------------------------------------------------
//  Disegno — stessa palette e stesso oggetto tft del resto del firmware
// ----------------------------------------------------------------------------

static void schermata_posa(float ax, float ay, float az,
                           bool fermo, uint32_t da_ms)
{
    tft.fillScreen(ArchColor::BG);
    tft.setTextDatum(TC_DATUM);

    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    tft.drawString("DIAG ASSI", ARCHBB_W / 2, 6, 2);

    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
    tft.drawString(NOME_POSA[s_corrente], ARCHBB_W / 2, 32, 2);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString(ISTR_POSA[s_corrente], ARCHBB_W / 2, 54, 1);

    // Letture grezze: servono a capire subito se il sensore risponde.
    char riga[48];
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
    snprintf(riga, sizeof(riga), "ax %+6.2f", ax); tft.drawString(riga, 14, 84, 2);
    snprintf(riga, sizeof(riga), "ay %+6.2f", ay); tft.drawString(riga, 14, 106, 2);
    snprintf(riga, sizeof(riga), "az %+6.2f", az); tft.drawString(riga, 14, 128, 2);

    // Barra di immobilita': si riempie mentre l'arco sta fermo.
    int larg = ARCHBB_W - 28;
    int pieno = fermo ? (int)(larg * fminf(1.0f, (float)da_ms / FERMO_MS)) : 0;
    tft.drawRect(14, 168, larg, 12, ArchColor::TEXT3);
    tft.fillRect(15, 169, pieno > 2 ? pieno - 2 : 0, 10, fermo ? ArchColor::GOOD : ArchColor::BG);

    tft.setTextDatum(TC_DATUM);
    tft.setTextColor(fermo ? ArchColor::GOOD : ArchColor::AMBER, ArchColor::BG);
    tft.drawString(fermo ? "fermo - non toccare" : "in movimento", ARCHBB_W / 2, 188, 2);

    // I DUE CRITERI, SEPARATI E COLORATI. Nella v1 mostravo due numeri senza
    // dire quale bloccava: chi guarda lo schermo non puo' indovinarlo, e la
    // diagnosi diventa impossibile proprio quando serve.
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(s_ok_acc ? ArchColor::GOOD : ArchColor::AMBER, ArchColor::BG);
    snprintf(riga, sizeof(riga), "ACC %.3f / %.3f  %s",
             s_sd_acc, s_soglia_acc, s_ok_acc ? "ok" : "--");
    tft.drawString(riga, 14, 206, 1);
    tft.setTextColor(s_ok_gyr ? ArchColor::GOOD : ArchColor::AMBER, ArchColor::BG);
    snprintf(riga, sizeof(riga), "GYR %.2f / %.2f  %s",
             s_sd_gyr, s_soglia_gyr, s_ok_gyr ? "ok" : "--");
    tft.drawString(riga, 14, 220, 1);
    tft.setTextDatum(TC_DATUM);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    snprintf(riga, sizeof(riga), "posa %d di 3", s_corrente + 1);
    tft.drawString(riga, ARCHBB_W / 2, 238, 1);

    // Ripiego manuale: se dopo 8 s non e' scattata, il tocco cattura comunque.
    // Su cavalletto muovere l'arco toccando non e' un problema, e restare
    // bloccati lo e'. Ma resta un RIPIEGO, e lo schermo lo dice.
    if (millis() - s_posa_da > RIPIEGO_MS) {
        tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
        tft.drawString("tocca per catturare comunque", ARCHBB_W / 2, 258, 1);
    } else {
        tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
        tft.drawString("tocca per rifare la posa", ARCHBB_W / 2, 258, 1);
    }
}

static void schermata_verdetto()
{
    tft.fillScreen(ArchColor::BG);
    tft.setTextDatum(TC_DATUM);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    tft.drawString("VERDETTO", ARCHBB_W / 2, 6, 2);

    // Escursione insufficiente: si dice, non si finge un risultato.
    if (s_escursione < ESCURSIONE_MIN_DEG) {
        tft.setTextColor(ArchColor::BAD, ArchColor::BG);
        tft.drawString("POSE TROPPO BLANDE", ARCHBB_W / 2, 40, 2);
        tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
        tft.drawString("inclina di piu' (~20 gradi)", ARCHBB_W / 2, 66, 1);
        char r[40]; snprintf(r, sizeof(r), "escursione minima: %.1f gradi", s_escursione);
        tft.drawString(r, ARCHBB_W / 2, 86, 1);
        tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
        tft.drawString("tocca per rifare", ARCHBB_W / 2, 250, 1);
        return;
    }

    tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
    tft.drawString(mount_name(s_migliore.mount), ARCHBB_W / 2, 38, 2);
    char r[52];
    snprintf(r, sizeof(r), "flip-Z  %s", s_migliore.flip ? "ATTIVO" : "spento");
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
    tft.drawString(r, ARCHBB_W / 2, 62, 2);

    // Le variazioni misurate: la prova di cosa ha deciso il verdetto.
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
    tft.drawString("posa 2 (punta giu'):", 12, 94, 1);
    snprintf(r, sizeof(r), "  alzo %+.1f   cant %+.1f",
             s_migliore.d_alzo2, s_migliore.d_cant2);
    tft.drawString(r, 12, 110, 2);
    tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
    tft.drawString("posa 3 (riser a destra):", 12, 136, 1);
    snprintf(r, sizeof(r), "  cant %+.1f   alzo %+.1f",
             s_migliore.d_cant3, s_migliore.d_alzo3);
    tft.drawString(r, 12, 152, 2);

    // Margine sul secondo classificato: se e' risicato, il verdetto e' incerto
    // e va rifatto con pose piu' nette. Un numero solo non basta mai a decidere.
    float margine = s_migliore.punteggio - s_secondo.punteggio;
    tft.setTextDatum(TC_DATUM);
    if (margine < 5.0f) {
        tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
        snprintf(r, sizeof(r), "margine risicato (%.1f) - rifai", margine);
    } else {
        tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
        snprintf(r, sizeof(r), "margine netto (%.1f)", margine);
    }
    tft.drawString(r, ARCHBB_W / 2, 184, 1);

    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    snprintf(r, sizeof(r), "-> config mount = %u", s_migliore.mount);
    tft.drawString(r, ARCHBB_W / 2, 208, 2);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString(s_migliore.flip == (bool)ARCHBB_HW_FLIP_Z
                   ? "flip-Z gia' corretto nel firmware"
                   : "ATTENZIONE: cambia ARCHBB_HW_FLIP_Z",
                   ARCHBB_W / 2, 232, 1);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    tft.drawString("tocca -> prova dinamica del gyro", ARCHBB_W / 2, 258, 1);
}

static void schermata_movimento(float gmod, bool attivo, float parziale)
{
    tft.fillScreen(ArchColor::BG);
    tft.setTextDatum(TC_DATUM);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    tft.drawString("PROVA DINAMICA", ARCHBB_W / 2, 6, 2);

    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
    tft.drawString(NOME_MOV[s_mov_corrente], ARCHBB_W / 2, 32, 2);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString(ISTR_MOV[s_mov_corrente], ARCHBB_W / 2, 54, 1);
    tft.drawString("lentamente, in un verso solo", ARCHBB_W / 2, 70, 1);

    char r[44];
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
    snprintf(r, sizeof(r), "gx %+7.2f", s_mov_acc[0]); tft.drawString(r, 14, 100, 2);
    snprintf(r, sizeof(r), "gy %+7.2f", s_mov_acc[1]); tft.drawString(r, 14, 122, 2);
    snprintf(r, sizeof(r), "gz %+7.2f", s_mov_acc[2]); tft.drawString(r, 14, 144, 2);

    tft.setTextDatum(TC_DATUM);
    if (attivo) {
        tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
        snprintf(r, sizeof(r), "in movimento  %.0f gradi", parziale);
    } else if (!s_mov_bias_pronto) {
        // Prima di poter integrare serve un bias fresco: fra un movimento e
        // l'altro passano decine di secondi e l'offset deriva con la temperatura.
        tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
        snprintf(r, sizeof(r), "tieni fermo   (%.0f dps)", gmod);
    } else {
        tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
        snprintf(r, sizeof(r), "pronto - muovi   (%.0f dps)", gmod);
    }
    tft.drawString(r, ARCHBB_W / 2, 186, 2);

    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    snprintf(r, sizeof(r), "movimento %d di 3", s_mov_corrente + 1);
    tft.drawString(r, ARCHBB_W / 2, 224, 1);
    tft.drawString("tocca per rifare", ARCHBB_W / 2, 252, 1);
}

static void schermata_verdetto_gyro()
{
    tft.fillScreen(ArchColor::BG);
    tft.setTextDatum(TC_DATUM);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    tft.drawString("ASSI DEL GIROSCOPIO", ARCHBB_W / 2, 6, 2);

    // Attesi con il frame canonico: alzo -> gy, cant -> gz, yaw -> gx.
    static const int ATTESO[3] = { 1, 2, 0 };
    static const char* ETICH[3] = { "alzo", "cant", "yaw " };

    int y = 34;
    bool tutto_ok = true;
    char r[52];
    for (int m = 0; m < 3; m++) {
        float v; int k = asse_dominante(s_mov[m].ig, v);
        bool ok = (k == ATTESO[m]) && (fabsf(v) >= MOV_MIN_DEG);
        if (!ok) tutto_ok = false;

        tft.setTextDatum(TL_DATUM);
        tft.setTextColor(ok ? ArchColor::GOOD : ArchColor::BAD, ArchColor::BG);
        snprintf(r, sizeof(r), "%s -> %s  %+6.1f", ETICH[m], NOME_ASSE[k], v);
        tft.drawString(r, 14, y, 2);

        // Controprova con l'accelerometro, dove ha senso: i primi due movimenti
        // cambiano la direzione della gravita', il terzo no.
        tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
        if (m == 0)      snprintf(r, sizeof(r), "   accel: %+.1f", s_mov[m].d_alzo);
        else if (m == 1) snprintf(r, sizeof(r), "   accel: %+.1f", s_mov[m].d_cant);
        else             snprintf(r, sizeof(r), "   accel: cieco (per esclusione)");
        tft.drawString(r, 14, y + 20, 1);
        y += 40;
    }

    tft.setTextDatum(TC_DATUM);
    if (tutto_ok) {
        tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
        tft.drawString("assi COERENTI col frame", ARCHBB_W / 2, 200, 2);
        tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
        tft.drawString("traccia, hold e torsione sono giuste", ARCHBB_W / 2, 222, 1);
    } else {
        tft.setTextColor(ArchColor::BAD, ArchColor::BG);
        tft.drawString("assi NON come attesi", ARCHBB_W / 2, 200, 2);
        tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
        tft.drawString("manda i numeri: serve un rimappaggio", ARCHBB_W / 2, 222, 1);
    }
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("tocca per ricominciare", ARCHBB_W / 2, 252, 1);
}

static void stampa_seriale()
{
    if (!(bool)Serial || Serial.availableForWrite() <= 0) return;
    Serial.println();
    Serial.println("=== DIAG ASSI — pose grezze (frame SENSORE) ===");
    for (int i = 0; i < 3; i++) {
        Serial.printf("posa %d  ax %+7.3f  ay %+7.3f  az %+7.3f\n",
                      i + 1, s_posa[i].ax, s_posa[i].ay, s_posa[i].az);
    }
    Serial.println("--- tutti i candidati, dal migliore ---");
    for (uint8_t m = 0; m < MOUNT_COUNT; m++) {
        for (int f = 0; f < 2; f++) {
            Esito e = valuta(m, (bool)f);
            Serial.printf("%-16s flip %-3s  punteggio %+7.2f  |  "
                          "posa2 alzo %+6.1f cant %+6.1f  |  posa3 cant %+6.1f alzo %+6.1f\n",
                          mount_name(m), f ? "ON" : "off", e.punteggio,
                          e.d_alzo2, e.d_cant2, e.d_cant3, e.d_alzo3);
        }
    }
    Serial.printf("VERDETTO: mount=%u (%s)  flip=%s\n",
                  s_migliore.mount, mount_name(s_migliore.mount),
                  s_migliore.flip ? "ON" : "off");
}

// ----------------------------------------------------------------------------
//  setup / loop
// ----------------------------------------------------------------------------
void setup()
{
    Serial.begin(115200);
    Serial.setTxTimeoutMs(0);

    displayInit();
    touchInit();                       // avvia Wire (bus condiviso) + mutex I2C
    bool imuOk = imu_init(ODR_250HZ, 8, 512);

    // NIENTE imu_task: il DIAG lavora su pose STATICHE e usa imu_read_raw(),
    // che legge il sensore in frame SENSORE senza applicare mount_apply.
    // E' la stessa scelta di main_mount_test.cpp, per la stessa ragione: se
    // leggessimo dati gia' rimappati applicheremmo il montaggio due volte.
    if (!imuOk) {
        tft.fillScreen(ArchColor::BG);
        tft.setTextDatum(MC_DATUM);
        tft.setTextColor(ArchColor::BAD, ArchColor::BG);
        tft.drawString("IMU FAIL", ARCHBB_W/2, ARCHBB_H/2, 4);
        return;                      // s_imu_ok resta false: il loop si ferma
    }
    s_imu_ok = true;

    tft.fillScreen(ArchColor::BG);
    tft.setTextDatum(TC_DATUM);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    tft.drawString("DIAG ASSI", ARCHBB_W / 2, 90, 4);
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
    tft.drawString("monta la scheda sul riser", ARCHBB_W / 2, 130, 2);
    tft.drawString("come quando tiri", ARCHBB_W / 2, 152, 2);
    delay(2500);
}

// ----------------------------------------------------------------------------
//  Schermata di taratura
// ----------------------------------------------------------------------------
static void schermata_taratura(uint32_t trascorso)
{
    tft.fillScreen(ArchColor::BG);
    tft.setTextDatum(TC_DATUM);
    tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
    tft.drawString("TARATURA", ARCHBB_W / 2, 60, 4);
    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
    tft.drawString("non toccare l'arco", ARCHBB_W / 2, 100, 2);
    tft.setTextColor(ArchColor::TEXT3, ArchColor::BG);
    tft.drawString("misuro il rumore di fondo", ARCHBB_W / 2, 124, 1);
    tft.drawString("del TUO esemplare sul TUO supporto", ARCHBB_W / 2, 140, 1);

    int larg = ARCHBB_W - 40;
    int pieno = (int)(larg * fminf(1.0f, (float)trascorso / TARATURA_MS));
    tft.drawRect(20, 170, larg, 14, ArchColor::BORDER);
    tft.fillRect(21, 171, pieno > 2 ? pieno - 2 : 0, 12, ArchColor::ACCENT);

    char riga[48];
    tft.setTextColor(ArchColor::TEXT2, ArchColor::BG);
    snprintf(riga, sizeof(riga), "acc %.3f   gyr %.2f", s_sd_acc, s_sd_gyr);
    tft.drawString(riga, ARCHBB_W / 2, 200, 2);
}

void loop()
{
    // Senza IMU non c'e' niente da misurare: si lascia a schermo l'errore
    // invece di sovrascriverlo con una taratura che non finira' mai.
    if (!s_imu_ok) { delay(200); return; }

    // ── lettura: sempre, il piu' in fretta possibile ────────────────────────
    //  Il campionamento e' DISACCOPPIATO dal ridisegno. Nella v1 il delay(60)
    //  dopo il disegno limitava la finestra a ~16 campioni al secondo: quattro
    //  secondi solo per riempirla. Ora si legge a ogni giro e si ridisegna a
    //  10 Hz, come fa main_mount_test.cpp.
    float rax, ray, raz, rgx, rgy, rgz;
    if (imu_read_raw(rax, ray, raz, rgx, rgy, rgz)) {
        s_buf[s_w][0] = rax; s_buf[s_w][1] = ray; s_buf[s_w][2] = raz;
        s_buf[s_w][3] = rgx; s_buf[s_w][4] = rgy; s_buf[s_w][5] = rgz;
        s_w = (s_w + 1) % N_FIN;
        if (s_n < N_FIN) s_n++;
    }

    float mx, my, mz;
    dispersioni(s_sd_acc, s_sd_gyr, mx, my, mz);
    s_ok_acc = (s_n >= N_FIN) && (s_sd_acc < s_soglia_acc);
    s_ok_gyr = (s_n >= N_FIN) && (s_sd_gyr < s_soglia_gyr);

    uint32_t ora = millis();
    static uint32_t s_ultimo_disegno = 0;
    bool ridisegna = (ora - s_ultimo_disegno) > 100;

    // ── FASE 1: TARATURA ────────────────────────────────────────────────────
    if (s_fase == Fase::TARATURA) {
        if (s_taratura_da == 0) s_taratura_da = ora;
        uint32_t trascorso = ora - s_taratura_da;

        if (trascorso >= TARATURA_MS && s_n >= N_FIN) {
            // Soglie = multiplo del rumore misurato, con un pavimento sotto
            // cui non si scende (oltre, si inseguirebbe la risoluzione).
            s_soglia_acc = fmaxf(MIN_SD_ACC, K_SOGLIA * s_sd_acc);
            s_soglia_gyr = fmaxf(MIN_SD_GYR, K_SOGLIA * s_sd_gyr);
            if ((bool)Serial && Serial.availableForWrite() > 0) {
                Serial.printf("taratura: rumore acc %.4f gyr %.3f -> soglie %.4f / %.3f\n",
                              s_sd_acc, s_sd_gyr, s_soglia_acc, s_soglia_gyr);
            }
            s_fase = Fase::POSE;
            s_posa_da = ora; s_fermo_da = 0;
            s_n = 0; s_w = 0;
            return;
        }
        if (ridisegna) { s_ultimo_disegno = ora; schermata_taratura(trascorso); }
        return;
    }

    // ── tocco ───────────────────────────────────────────────────────────────
    TouchData td = touchRead();
    static uint32_t s_ultimo_tocco = 0;
    bool tocco = td.valid && (ora - s_ultimo_tocco > 400);
    if (tocco) s_ultimo_tocco = ora;

    // ── FASE 3: VERDETTO ────────────────────────────────────────────────────
    if (s_fase == Fase::VERDETTO) {
        if (tocco) {                       // avanza alla prova dinamica
            s_fase = Fase::MOVIMENTI;
            s_mov_corrente = 0; s_mov_attivo = false; s_mov_fermo_da = 0;
            s_mov_bias_pronto = false;
            for (int i = 0; i < 3; i++) s_mov[i].fatto = false;
            s_n = 0; s_w = 0;
            tft.fillScreen(ArchColor::BG);
            tft.setTextDatum(MC_DATUM);
            tft.setTextColor(ArchColor::ACCENT, ArchColor::BG);
            tft.drawString("PROVA DINAMICA", ARCHBB_W / 2, ARCHBB_H / 2 - 30, 4);
            tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
            tft.drawString("tre rotazioni lente,", ARCHBB_W / 2, ARCHBB_H / 2 + 6, 2);
            tft.drawString("una per asse", ARCHBB_W / 2, ARCHBB_H / 2 + 28, 2);
            delay(2200);
            return;
        }
        if (ridisegna) { s_ultimo_disegno = ora; schermata_verdetto(); }
        return;
    }

    // ── PROVA DINAMICA ──────────────────────────────────────────────────────
    if (s_fase == Fase::MOVIMENTI) {
        if (tocco) {                       // rifa' il movimento corrente
            s_mov_attivo = false; s_mov_fermo_da = 0; s_n = 0; s_w = 0;
            s_mov_bias_pronto = false;
            return;
        }
        float gmod = sqrtf(rgx*rgx + rgy*rgy + rgz*rgz);

        if (!s_mov_attivo) {
            // Fermi: si aggiorna il bias e si aspetta che il movimento parta.
            // Il bias si prende ADESSO e non all'avvio del DIAG: fra una prova
            // e l'altra passano decine di secondi, e l'offset del giroscopio
            // deriva con la temperatura.
            if (s_n >= N_FIN && s_ok_gyr) {
                for (int k = 0; k < 3; k++) {
                    float m = 0;
                    for (int i = 0; i < s_n; i++) m += s_buf[i][3 + k];
                    s_mov_bias[k] = m / s_n;
                }
                s_mov_a0[0] = mx; s_mov_a0[1] = my; s_mov_a0[2] = mz;
                s_mov_bias_pronto = true;
            }
            if (gmod > MOV_INIZIO_DPS && s_mov_bias_pronto) {
                s_mov_attivo = true;
                s_mov_acc[0] = s_mov_acc[1] = s_mov_acc[2] = 0;
                s_mov_t_prec = micros();
                s_mov_fermo_da = 0;
            }
        } else {
            // In movimento: integrazione a dt REALE.
            uint32_t t = micros();
            float dt = (t - s_mov_t_prec) / 1e6f;
            s_mov_t_prec = t;
            if (dt > 0 && dt < 0.1f) {
                s_mov_acc[0] += (rgx - s_mov_bias[0]) * dt;
                s_mov_acc[1] += (rgy - s_mov_bias[1]) * dt;
                s_mov_acc[2] += (rgz - s_mov_bias[2]) * dt;
            }
            if (gmod < MOV_FINE_DPS) {
                if (s_mov_fermo_da == 0) s_mov_fermo_da = ora;
            } else {
                s_mov_fermo_da = 0;
            }
            // Fine del movimento: fermo abbastanza a lungo.
            if (s_mov_fermo_da && ora - s_mov_fermo_da > MOV_FERMO_MS) {
                float v; asse_dominante(s_mov_acc, v);
                if (fabsf(v) < MOV_MIN_DEG) {
                    // Troppo piccolo per concludere: si rifa' senza registrarlo.
                    s_mov_attivo = false; s_mov_fermo_da = 0;
                    tft.fillScreen(ArchColor::BG);
                    tft.setTextDatum(MC_DATUM);
                    tft.setTextColor(ArchColor::AMBER, ArchColor::BG);
                    tft.drawString("TROPPO POCO", ARCHBB_W/2, ARCHBB_H/2 - 12, 2);
                    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
                    tft.drawString("ruota di piu' (~30 gradi)", ARCHBB_W/2, ARCHBB_H/2 + 14, 1);
                    delay(1600);
                    s_n = 0; s_w = 0;
                    return;
                }
                Movimento& M = s_mov[s_mov_corrente];
                M.fatto = true;
                for (int k = 0; k < 3; k++) M.ig[k] = s_mov_acc[k];
                // Controprova con l'accelerometro: variazione di alzo e cant
                // fra l'assetto iniziale e quello finale.
                M.d_alzo = degrees(atan2f(mz, mx))
                         - degrees(atan2f(s_mov_a0[2], s_mov_a0[0]));
                M.d_cant = degrees(atan2f(my, mx))
                         - degrees(atan2f(s_mov_a0[1], s_mov_a0[0]));

                if ((bool)Serial && Serial.availableForWrite() > 0) {
                    Serial.printf("mov %d: gx %+.2f gy %+.2f gz %+.2f | accel d_alzo %+.2f d_cant %+.2f\n",
                                  s_mov_corrente + 1, M.ig[0], M.ig[1], M.ig[2],
                                  M.d_alzo, M.d_cant);
                }
                s_mov_corrente++;
                s_mov_attivo = false; s_mov_fermo_da = 0; s_n = 0; s_w = 0;
                s_mov_bias_pronto = false;

                if (s_mov_corrente >= 3) {
                    stampa_dinamica();
                    s_fase = Fase::VERDETTO_GYRO;
                } else {
                    tft.fillScreen(ArchColor::BG);
                    tft.setTextDatum(MC_DATUM);
                    tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
                    tft.drawString("REGISTRATO", ARCHBB_W/2, ARCHBB_H/2 - 12, 2);
                    tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
                    tft.drawString("rimetti l'arco in posizione", ARCHBB_W/2, ARCHBB_H/2 + 14, 1);
                    delay(2000);
                }
                return;
            }
        }
        if (ridisegna) {
            s_ultimo_disegno = ora;
            float v; asse_dominante(s_mov_acc, v);
            schermata_movimento(gmod, s_mov_attivo, fabsf(v));
        }
        return;
    }

    if (s_fase == Fase::VERDETTO_GYRO) {
        if (tocco) {                       // ricomincia tutto, taratura inclusa
            s_fase = Fase::TARATURA; s_taratura_da = 0;
            s_corrente = 0; s_n = 0; s_w = 0; s_fermo_da = 0;
            for (int i = 0; i < 3; i++) { s_posa[i].fatta = false; s_mov[i].fatto = false; }
            return;
        }
        if (ridisegna) { s_ultimo_disegno = ora; schermata_verdetto_gyro(); }
        return;
    }

    // ── FASE 2: POSE ────────────────────────────────────────────────────────
    bool fermo = s_ok_acc && s_ok_gyr;
    if (!fermo) s_fermo_da = 0;
    else if (s_fermo_da == 0) s_fermo_da = ora;
    uint32_t da = (s_fermo_da && fermo) ? (ora - s_fermo_da) : 0;

    // Cattura: automatica quando fermo abbastanza, oppure manuale dopo il
    // tempo di ripiego (su cavalletto toccare e' accettabile; restare
    // bloccati no). Il tocco PRIMA del ripiego resetta la finestra, che e'
    // il comportamento giusto se stai ancora sistemando la posa.
    bool ripiego_pronto = (ora - s_posa_da) > RIPIEGO_MS;
    // La cattura manuale richiede comunque la finestra PIENA: mx,my,mz sono la
    // media su quella finestra, e mediare su due campioni non e' una posa.
    bool cattura = (fermo && da >= FERMO_MS)
                || (tocco && ripiego_pronto && s_n >= N_FIN);

    if (tocco && !ripiego_pronto) { s_n = 0; s_w = 0; s_fermo_da = 0; return; }

    if (cattura) {
        s_posa[s_corrente].fatta = true;
        s_posa[s_corrente].ax    = mx;
        s_posa[s_corrente].ay    = my;
        s_posa[s_corrente].az    = mz;
        if ((bool)Serial && Serial.availableForWrite() > 0) {
            Serial.printf("posa %d %s: ax %+.3f ay %+.3f az %+.3f  (acc %.4f gyr %.3f)\n",
                          s_corrente + 1, (fermo && da >= FERMO_MS) ? "auto" : "MANUALE",
                          mx, my, mz, s_sd_acc, s_sd_gyr);
        }
        s_corrente++;
        s_n = 0; s_w = 0; s_fermo_da = 0; s_posa_da = ora;

        if (s_corrente >= 3) {
            calcola_verdetto();
            stampa_seriale();
            s_fase = Fase::VERDETTO;
        } else {
            tft.fillScreen(ArchColor::BG);
            tft.setTextDatum(MC_DATUM);
            tft.setTextColor(ArchColor::GOOD, ArchColor::BG);
            tft.drawString("POSA CATTURATA", ARCHBB_W / 2, ARCHBB_H / 2 - 14, 2);
            tft.setTextColor(ArchColor::TEXT, ArchColor::BG);
            tft.drawString("passa alla prossima", ARCHBB_W / 2, ARCHBB_H / 2 + 14, 2);
            delay(1800);
            s_posa_da = millis();
        }
        return;
    }

    if (ridisegna) {
        s_ultimo_disegno = ora;
        schermata_posa(mx, my, mz, fermo, da);
    }
}

#endif // ARCHBB_DIAG_ASSI
