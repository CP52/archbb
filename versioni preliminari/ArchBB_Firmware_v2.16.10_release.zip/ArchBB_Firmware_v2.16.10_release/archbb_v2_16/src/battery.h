// =============================================================================
// battery.h — ArchBB: monitoraggio batteria LiPo 1S  (v1.0, per firmware v2.5)
// =============================================================================
//
// SCOPO
//   Fornire una stima ATTENDIBILE della carica residua della batteria LiPo,
//   così da rendere VISIBILE lo stato energetico del dispositivo.
//   Fino alla v2.4 il campo batt_pct nei pacchetti BLE era hardcoded a 100:
//   "volavamo ciechi". Questo modulo lo alimenta con una misura reale.
//
// PERCHÉ È IMPORTANTE (contesto brownout)
//   Il sospetto principale sulla caduta BLE a metà sessione è un brownout
//   transitorio: durante la trasmissione BLE il picco di corrente fa scendere
//   la tensione sotto la soglia del modulo radio. Sapere la tensione reale è
//   il primo passo per distinguere "batteria che si sta scaricando" da
//   "picco transitorio su batteria ancora carica".
//
// HARDWARE (Waveshare ESP32-S3-Touch-LCD-1.69 — da schematico ufficiale)
//   - Nodo BAT_ADC collegato a GPIO1.
//   - Partitore resistivo: R3 = 200K (verso B+) e R7 = 100K (verso GND).
//   - Rapporto di partizione = (200K + 100K) / 100K = 3.0
//     → V_batt = V_pin × 3
//   - A batteria piena (4.20V) il pin vede 1.40V: ben dentro il range lineare
//     dell'ADC dell'ESP32-S3 con attenuazione 11 dB (0..~3.1V). Nessuna
//     saturazione, nessuna compressione ai bordi.
//
// PERCHÉ analogReadMilliVolts() E NON analogRead()
//   L'ADC SAR dell'ESP32-S3 ha non-linearità note (soprattutto sotto ~0.1V e
//   sopra ~2.5V). Espressif memorizza in eFuse una curva di calibrazione per
//   ogni singolo chip. analogReadMilliVolts() la applica automaticamente e
//   restituisce millivolt già corretti. Su una misura di batteria, dove 50 mV
//   di errore valgono ~10% di carica, questa non è un'opzione ma un obbligo.
//
// PERCHÉ UNA LUT E NON UNA FORMULA LINEARE
//   Una LiPo NON scarica linearmente. La curva ha una lunga "spalla" piatta
//   tra 3.70 e 3.90 V dove sta gran parte della capacità, poi crolla ripida
//   sotto 3.65 V. Una mappatura lineare 3.30→4.20 V mente proprio nella zona
//   critica: a 3.70 V (≈15% reale) direbbe 44%. Usiamo quindi una lookup table
//   tensione→% con interpolazione lineare tra i punti, derivata da curve di
//   scarica LiPo reali a basso carico.
//
// FILTRAGGIO
//   1. Ogni lettura è la media di BAT_ADC_SAMPLES conversioni consecutive
//      (abbatte il rumore bianco dell'ADC).
//   2. Sopra la conversione in percentuale applichiamo un filtro a MEDIANA
//      mobile su BAT_MEDIAN_WINDOW campioni: la mediana è immune agli spike
//      (es. il tuffo di tensione durante un burst BLE non fa "sobbalzare" la
//      percentuale mostrata).
//
// USO
//   battery_init();                       // una volta in setup()
//   uint8_t p = battery_read_pct();       // chiamare ogni pochi secondi
//   float    v = battery_last_voltage();  // ultima tensione batteria in Volt
//
// =============================================================================
#pragma once
#include <Arduino.h>

// -----------------------------------------------------------------------------
// GLOBALE CONDIVISA: percentuale batteria corrente (0..100).
//   Aggiornata da loop() (Core Arduino) via battery_read_pct() ogni pochi
//   secondi. Letta da ble_server.cpp (Core 1) per riempire i pacchetti BLE e
//   da display.cpp per l'icona batteria. volatile perché scritta e letta da
//   contesti/core diversi; uint8_t è atomico sull'ESP32 (nessun rischio di
//   valore "a metà").
// -----------------------------------------------------------------------------
extern volatile uint8_t g_batt_pct;

// Pin ADC della batteria. Definibile via build_flags (-DBAT_ADC_PIN=1).
// Default = 1 (GPIO1) come da schematico Waveshare 1.69.
#ifndef BAT_ADC_PIN
  #define BAT_ADC_PIN 1
#endif

// Rapporto del partitore resistivo: V_batt = V_pin × BAT_DIVIDER_RATIO.
// R3=200K (alto) + R7=100K (basso) → (200+100)/100 = 3.0
#ifndef BAT_DIVIDER_RATIO
  #define BAT_DIVIDER_RATIO 3.0f
#endif

// Numero di conversioni ADC mediate per ogni singola lettura di tensione.
#ifndef BAT_ADC_SAMPLES
  #define BAT_ADC_SAMPLES 16
#endif

// Ampiezza della finestra per il filtro a mediana mobile sulla percentuale.
// Dispari (3, 5, 7) per una mediana ben definita. La tensione è stabilissima
// (stdev ~6mV misurata sul campo), quindi una mediana leggera basta e avanza
// per il solo rumore ADC: nessun filtro più aggressivo è necessario.
#ifndef BAT_MEDIAN_WINDOW
  #define BAT_MEDIAN_WINDOW 5
#endif

// -----------------------------------------------------------------------------
// battery_init()
//   Configura l'ADC (risoluzione 12 bit, attenuazione 11 dB) e pre-carica la
//   finestra della mediana con una prima misura, così il primo valore mostrato
//   è già sensato e non uno zero transitorio.
// -----------------------------------------------------------------------------
void battery_init();

// -----------------------------------------------------------------------------
// battery_read_pct()
//   Esegue una nuova misura completa (media ADC → tensione → LUT → mediana) e
//   restituisce la percentuale di carica filtrata (0..100).
//   Chiamare a bassa frequenza (ogni 2-5 s): la batteria varia lentamente e
//   inutili letture frequenti aggiungono solo rumore e consumo.
// -----------------------------------------------------------------------------
uint8_t battery_read_pct();

// -----------------------------------------------------------------------------
// battery_read_pct_gated(radio_idle)
//   Variante "gated": misura la batteria SOLO se la radio BLE è a riposo
//   (radio_idle == true). Durante/subito dopo un burst la tensione crolla per
//   l'IR drop della resistenza interna della LiPo; misurare in quel momento
//   sottostima la carica di diversi punti percentuali. Saltando quelle finestre
//   otteniamo sempre la tensione a circuito aperto (OCV), che è quella
//   corretta. Ritorna true se ha misurato, false se ha saltato.
// -----------------------------------------------------------------------------
bool battery_read_pct_gated(bool radio_idle);

// -----------------------------------------------------------------------------
// battery_debug_read(raw_pct)  — SOLO DIAGNOSTICA
//   Lettura grezza della tensione (Volt) senza filtri, per osservare il
//   transitorio di accensione. Opzionalmente riempie *raw_pct con la % LUT
//   diretta. Attivata dal logger diagnostico se BATT_BOOT_DIAG è definito.
// -----------------------------------------------------------------------------
float battery_debug_read(uint8_t* raw_pct);

// -----------------------------------------------------------------------------
// battery_last_voltage()
//   Ultima tensione di batteria misurata, in Volt (già ricostruita ×3).
//   Utile per diagnostica brownout e log seriale.
// -----------------------------------------------------------------------------
float battery_last_voltage();

// -----------------------------------------------------------------------------
// battery_last_pct()
//   Ultima percentuale filtrata restituita, senza rieseguire una misura.
//   Usata dai task che vogliono solo leggere il valore corrente (es. display,
//   pacchetti BLE) senza forzare una nuova conversione ADC.
// -----------------------------------------------------------------------------
uint8_t battery_last_pct();
