// =============================================================================
// battery.cpp — ArchBB: monitoraggio batteria LiPo 1S  (v3.0, firmware v2.8)
// =============================================================================
// Vedi battery.h per hardware e algoritmo.
//
// STORIA E LEZIONE (importante):
//   v2.5 introdusse la lettura batteria (LUT + mediana): funzionava.
//   v2.6/2.7 aggiunsero "grace period" ed "EMA" per combattere un presunto
//   crollo 86%->65% all'accensione, attribuito prima alla surface charge, poi
//   a un transitorio hardware. La DIAGNOSTICA VIA BLE (firmware v2.7) ha
//   misurato il fenomeno e SMENTITO entrambe le ipotesi:
//     - la TENSIONE e' stabilissima all'accensione (drift 12mV in 4 min, stdev
//       ~6mV): l'hardware di misura e' perfetto;
//     - la percentuale GREZZA (LUT) e' corretta e stabile (~63-66%);
//     - il "crollo" era interamente un ARTEFATTO del filtro grace/EMA, che
//       partiva dal valore iniziale g_batt_pct=100 e ci metteva secondi a
//       riallinearsi, PRODUCENDO proprio il salto che doveva prevenire.
//
//   CONCLUSIONE: il fenomeno fisico non esisteva. La soluzione e' RIMUOVERE il
//   codice, non aggiungerne. La letteratura sui fuel gauge conferma: per una
//   applicazione A RIPOSO (nessun carico forte continuo) su chimica LiPo (curva
//   OCV-SOC non piatta), l'OCV lookup puro con filtro minimo e' l'approccio
//   corretto e sufficiente. Coulomb counting / EKF sarebbero over-engineering
//   (e comunque impossibili senza sensore di corrente).
//
//   v3.0 torna quindi a un gauge ONESTO: LUT empirica + mediana mobile leggera
//   per il solo rumore ADC. Niente grace period, niente EMA, niente smoothing
//   direzionale. Parte subito dal valore vero.
// =============================================================================

#include "battery.h"
#include "config.h"   // per la macro DBG()
#include <math.h>

// Globale condivisa. Inizializzata a 0: verra' sovrascritta dalla PRIMA lettura
// reale in battery_init(), quindi nessun consumatore vede mai lo zero (e nemmeno
// il vecchio "100" fittizio che innescava l'artefatto).
volatile uint8_t g_batt_pct = 0;

// -----------------------------------------------------------------------------
// LOOKUP TABLE tensione(mV cella) -> % carica  —  LiPo 1S (curva empirica)
// -----------------------------------------------------------------------------
// Basata su curve di scarica LiPo reali (letteratura RC), infittita nella zona
// centrale dove serve risoluzione. Ordinata dalla tensione piu' alta alla piu'
// bassa. Validata contro i dati di campo (batteria "ferma a 65%" -> ~3.95V ->
// 63-66%, coerente).
struct LipoPoint { uint16_t mv; uint8_t pct; };

static const LipoPoint LIPO_LUT[] = {
    { 4200, 100 }, { 4150,  92 }, { 4100,  85 }, { 4060,  80 },
    { 4030,  76 }, { 3990,  70 }, { 3950,  64 }, { 3910,  57 },
    { 3860,  52 }, { 3840,  47 }, { 3830,  42 }, { 3810,  36 },
    { 3790,  30 }, { 3770,  25 }, { 3750,  20 }, { 3730,  16 },
    { 3700,  11 }, { 3670,   8 }, { 3630,   4 }, { 3600,   0 },
};
static const int LIPO_LUT_N = sizeof(LIPO_LUT) / sizeof(LIPO_LUT[0]);

// -----------------------------------------------------------------------------
// STATO INTERNO (minimale)
// -----------------------------------------------------------------------------
static float   s_last_voltage = 0.0f;   // ultima tensione batteria (V)
static uint8_t s_last_pct      = 0;      // ultima percentuale (uscita)
static uint8_t s_median_buf[BAT_MEDIAN_WINDOW];
static int     s_median_idx    = 0;
static bool    s_median_full   = false;

// -----------------------------------------------------------------------------
// lipo_mv_to_pct() — interpolazione lineare nella LUT
// -----------------------------------------------------------------------------
static uint8_t lipo_mv_to_pct(uint16_t mv) {
    if (mv >= LIPO_LUT[0].mv)               return 100;
    if (mv <= LIPO_LUT[LIPO_LUT_N - 1].mv)  return 0;
    for (int i = 0; i < LIPO_LUT_N - 1; ++i) {
        uint16_t hi = LIPO_LUT[i].mv;
        uint16_t lo = LIPO_LUT[i + 1].mv;
        if (mv <= hi && mv >= lo) {
            float t = (float)(mv - lo) / (float)(hi - lo);
            float p = LIPO_LUT[i + 1].pct
                    + t * (LIPO_LUT[i].pct - LIPO_LUT[i + 1].pct);
            if (p < 0)   p = 0;
            if (p > 100) p = 100;
            return (uint8_t)lroundf(p);
        }
    }
    return 0;
}

// -----------------------------------------------------------------------------
// median_of() — mediana di n uint8_t (insertion sort su copia)
// -----------------------------------------------------------------------------
static uint8_t median_of(const uint8_t* src, int n) {
    uint8_t tmp[BAT_MEDIAN_WINDOW];
    for (int i = 0; i < n; ++i) tmp[i] = src[i];
    for (int i = 1; i < n; ++i) {
        uint8_t key = tmp[i];
        int j = i - 1;
        while (j >= 0 && tmp[j] > key) { tmp[j + 1] = tmp[j]; --j; }
        tmp[j + 1] = key;
    }
    return tmp[n / 2];
}

// -----------------------------------------------------------------------------
// read_voltage_mv() — lettura ADC mediata -> tensione CELLA in mV
// -----------------------------------------------------------------------------
static uint16_t read_voltage_mv() {
    uint32_t acc = 0;
    for (int i = 0; i < BAT_ADC_SAMPLES; ++i) {
        acc += analogReadMilliVolts(BAT_ADC_PIN);
    }
    float mv_pin  = (float)acc / (float)BAT_ADC_SAMPLES;
    float mv_batt = mv_pin * BAT_DIVIDER_RATIO;
    s_last_voltage = mv_batt / 1000.0f;
    return (uint16_t)lroundf(mv_batt);
}

// -----------------------------------------------------------------------------
// measure() — legge, converte, filtra con mediana leggera. Nient'altro.
// -----------------------------------------------------------------------------
static uint8_t measure() {
    uint16_t mv  = read_voltage_mv();
    uint8_t  pct = lipo_mv_to_pct(mv);

    s_median_buf[s_median_idx] = pct;
    s_median_idx = (s_median_idx + 1) % BAT_MEDIAN_WINDOW;
    if (s_median_idx == 0) s_median_full = true;
    int n = s_median_full ? BAT_MEDIAN_WINDOW : s_median_idx;
    if (n < 1) n = 1;

    s_last_pct = median_of(s_median_buf, n);
    g_batt_pct = s_last_pct;
    return s_last_pct;
}

// =============================================================================
// API PUBBLICA
// =============================================================================

void battery_init() {
    analogReadResolution(12);
    analogSetPinAttenuation(BAT_ADC_PIN, ADC_11db);

    // Pre-carica la finestra della mediana con la prima misura reale, cosi' il
    // valore iniziale e' gia' quello vero (nessun transitorio artificiale).
    uint16_t mv  = read_voltage_mv();
    uint8_t  pct = lipo_mv_to_pct(mv);
    for (int i = 0; i < BAT_MEDIAN_WINDOW; ++i) s_median_buf[i] = pct;
    s_median_idx  = 0;
    s_median_full = true;
    s_last_pct    = pct;
    g_batt_pct    = pct;

    DBG("Battery init: %.3fV -> %u%%", s_last_voltage, pct);
}

uint8_t battery_read_pct() {
    return measure();
}

// Variante gated: misura solo a radio a riposo (evita l'IR drop dei burst BLE).
// La tensione LiPo cala sotto carico per la resistenza interna; misurando a
// riposo si legge la OCV corretta. Ritorna true se ha misurato.
bool battery_read_pct_gated(bool radio_idle) {
    if (!radio_idle) return false;
    measure();
    return true;
}

float   battery_last_voltage() { return s_last_voltage; }
uint8_t battery_last_pct()     { return s_last_pct; }

// -----------------------------------------------------------------------------
// battery_debug_read() — SOLO DIAGNOSTICA: tensione grezza (V) senza filtri.
// -----------------------------------------------------------------------------
float battery_debug_read(uint8_t* raw_pct) {
    uint16_t mv = read_voltage_mv();
    if (raw_pct) *raw_pct = lipo_mv_to_pct(mv);
    return s_last_voltage;
}
