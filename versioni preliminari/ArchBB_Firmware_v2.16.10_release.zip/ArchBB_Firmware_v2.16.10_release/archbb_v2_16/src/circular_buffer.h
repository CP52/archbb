// =============================================================================
// circular_buffer.h — ArchBB: buffer circolare PSRAM thread-safe (v1.1)
// =============================================================================
#pragma once
#include <Arduino.h>
#include "config.h"

enum BufferState { BUFFER_RUNNING=0, BUFFER_FROZEN=1, BUFFER_READY=2 };

bool        circular_buffer_init();
void        circular_buffer_push(const ImuSample& sample);
void        circular_buffer_freeze(uint16_t pre_samples, uint16_t post_samples, uint16_t shot_id);
uint16_t    circular_buffer_get_burst(ImuSample* dst, uint16_t max_samples, uint16_t* trigger_idx_out);
void        circular_buffer_reset();
BufferState circular_buffer_state();
uint16_t    circular_buffer_post_count();
void        circular_buffer_print_stats();
