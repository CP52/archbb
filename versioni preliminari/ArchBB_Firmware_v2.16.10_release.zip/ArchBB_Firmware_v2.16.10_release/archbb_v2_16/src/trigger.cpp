// =============================================================================
// trigger.cpp — implementazione algoritmo trigger
// =============================================================================

#include "trigger.h"
#include "imu.h"
#include "circular_buffer.h"

extern volatile bool g_shutdown;  // definita in main.cpp

// =============================================================================
// VARIABILI GLOBALI
// =============================================================================
SemaphoreHandle_t g_trigger_fired_sem = nullptr;
volatile uint16_t g_shot_id           = 0;
volatile float    g_trigger_az_peak   = 0.0f;
volatile uint32_t g_trigger_ts_us     = 0;
volatile TriggerPhase g_trigger_phase = TRIG_PHASE_IDLE;

// Configurazione locale (copia dalla Config globale)
static TriggerMode  s_mode;
static float        s_threshold;
static uint8_t      s_confirm_n;
static uint16_t     s_rearm_ms;
static uint16_t     s_pre_samples;
static uint16_t     s_post_samples;

// Stato interno macchina a stati trigger
static uint8_t  s_confirm_count = 0;   // Campioni consecutivi sopra soglia
static float    s_az_prev       = 0.0f; // Az campione precedente (per jerk)
static volatile bool s_manual_trigger = false; // Flag trigger manuale (volatile: scritto da ble_task)
static uint16_t s_last_seq      = 0xFFFF; // v2.4: ultimo seq valutato (anti doppio conteggio)
static float    s_odr_hz        = 224.0f; // v2.4: ODR reale per il calcolo jerk

// =============================================================================
// trigger_init()
// =============================================================================
void trigger_init(const Config& cfg) {
    g_trigger_fired_sem = xSemaphoreCreateBinary();
    if (!g_trigger_fired_sem) {
        DBG("ERRORE: trigger semaforo fallito");
    }

    trigger_update_config(cfg);
    g_shot_id       = 0;
    g_trigger_phase = TRIG_PHASE_IDLE;
    s_confirm_count = 0;
    s_az_prev       = 0.0f;
    s_manual_trigger = false;
    s_last_seq       = 0xFFFF;

    DBG("Trigger init OK — mode=%d threshold=%.1f confirm_n=%d rearm=%dms",
        (int)cfg.trig_mode, cfg.trig_threshold_ms2,
        cfg.trig_confirm_n, cfg.rearm_ms);
}

// =============================================================================
// trigger_update_config()
// =============================================================================
void trigger_update_config(const Config& cfg) {
    s_mode        = cfg.trig_mode;
    s_threshold   = cfg.trig_threshold_ms2;
    s_confirm_n   = cfg.trig_confirm_n;
    s_rearm_ms    = cfg.rearm_ms;
    s_pre_samples = calcPreSamples(cfg);
    s_post_samples= calcPostSamples(cfg);
    s_odr_hz      = (float)odrToHz(cfg.odr);   // v2.4: ODR reale per jerk
    if (s_odr_hz < 1.0f) s_odr_hz = 224.0f;
}

// =============================================================================
// trigger_manual()
// =============================================================================
void trigger_manual() {
    s_manual_trigger = true;
}

// =============================================================================
// Funzione interna: abilita/disabilita registrazione
// Chiamata da trigger_task in risposta a comandi BLE
// Esposta esternamente tramite una variabile globale in main.cpp
// =============================================================================
extern volatile bool g_recording_enabled;  // definita in main.cpp

// =============================================================================
// trigger_task() — Core 1, priorità HIGH
// =============================================================================
//
// La macchina a stati del trigger opera su ogni campione IMU.
// Periodo: 4ms @250Hz.
//
// FLUSSO:
//   IDLE      → attende g_recording_enabled == true → ARMED
//   ARMED     → controlla condizione trigger su ogni campione
//               condizione vera → incrementa s_confirm_count
//               condizione falsa → s_confirm_count = 0
//               s_confirm_count >= s_confirm_n → FIRED
//   FIRED     → congela buffer, aggiorna shot_id, posta semaforo
//               avvia timer rearm → REARM
//   REARM     → attende rearm_ms → torna ARMED
//   (se g_recording_enabled == false → torna IDLE)
//
// =============================================================================
void trigger_task(void* param) {
    DBG("trigger_task avviato su Core %d", xPortGetCoreID());

    // Attende IMU ok
    while (!g_imu_ok) {
        vTaskDelay(pdMS_TO_TICKS(10));
    }

    uint32_t rearm_start_ms = 0;

    for (;;) {
        // Controlla flag shutdown
        if (g_shutdown) { DBG("trigger_task: shutdown"); vTaskDelete(nullptr); }

        // Legge campione più recente (con mutex)
        ImuSample sample;
        bool got_sample = false;
        if (xSemaphoreTake(g_imu_sample_mutex, pdMS_TO_TICKS(2)) == pdTRUE) {
            sample = (ImuSample&)g_latest_sample;
            got_sample = true;
            xSemaphoreGive(g_imu_sample_mutex);
        }

        if (!got_sample) {
            vTaskDelay(pdMS_TO_TICKS(1));
            continue;
        }

        // v2.4: la "freschezza" del campione (seq diverso dall'ultimo
        // valutato) gatekeepa SOLO la valutazione della condizione di trigger
        // in ARMED/CONFIRMING. Gli stati di transizione (FIRED, REARM, IDLE)
        // sono lavoro interno della macchina e devono sempre avanzare, anche
        // a IMU ferma (seq costante) — altrimenti un trigger manuale a board
        // immobile resterebbe bloccato in FIRED senza mai sparare.
        bool fresh = (sample.seq != s_last_seq);

        // --- Macchina a stati ---

        switch (g_trigger_phase) {

            // ---------------------------------------------------------------
            case TRIG_PHASE_IDLE:
                s_confirm_count = 0;
                s_az_prev       = sample.az;
                if (g_recording_enabled) {
                    g_trigger_phase = TRIG_PHASE_ARMED;
                    DBG("Trigger ARMED — threshold=%.1f mode=%d", s_threshold, (int)s_mode);
                }
                break;

            // ---------------------------------------------------------------
            case TRIG_PHASE_ARMED:
            case TRIG_PHASE_CONFIRMING:   // v2.4: stesso flusso — CONFIRMING è solo cosmetico per il display
                if (!g_recording_enabled) {
                    g_trigger_phase = TRIG_PHASE_IDLE;
                    s_confirm_count = 0;
                    break;
                }

                {
                    // --- Trigger manuale: fire IMMEDIATO, bypassa soglia e confirm_n ---
                    // v2.4 FIX: prima il manuale entrava in CONFIRMING e con
                    // confirm_n>=2 non scattava MAI (il flag veniva consumato
                    // al primo giro e CONFIRMING azzerava il progresso).
                    if (s_manual_trigger) {
                        s_manual_trigger  = false;
                        g_trigger_az_peak = sample.az;
                        g_trigger_phase   = TRIG_PHASE_FIRED;
                        DBG("Trigger MANUALE → FIRED");
                        break;
                    }

                    // Valutazione automatica solo su campione NUOVO (anti doppio
                    // conteggio: il task gira a ~3ms, i campioni arrivano a ~4ms).
                    if (!fresh) break;
                    s_last_seq = sample.seq;

                    bool condition = false;
                    if (s_mode == TRIG_AZ_THRESHOLD) {
                        condition = (fabsf(sample.az) > s_threshold);
                    } else if (s_mode == TRIG_JERK) {
                        // v2.4: dt = 1/ODR_reale (era hardcoded 1/250)
                        float dt   = 1.0f / s_odr_hz;
                        float jerk = fabsf((fabsf(sample.az) - fabsf(s_az_prev)) / dt);
                        condition  = (jerk > s_threshold);
                    }

                    if (condition) {
                        s_confirm_count++;
                        if (fabsf(sample.az) > fabsf(g_trigger_az_peak))
                            g_trigger_az_peak = sample.az;

                        if (s_confirm_count >= s_confirm_n) {
                            g_trigger_phase = TRIG_PHASE_FIRED;   // CONFERMATO
                        } else {
                            // resta in CONFIRMING SENZA perdere il campione
                            // successivo (prima un case dedicato bruciava un ciclo)
                            g_trigger_phase = TRIG_PHASE_CONFIRMING;
                        }
                    } else {
                        s_confirm_count   = 0;
                        g_trigger_az_peak = 0.0f;
                        g_trigger_phase   = TRIG_PHASE_ARMED;
                    }

                    s_az_prev = sample.az;
                }
                break;

            // ---------------------------------------------------------------
            case TRIG_PHASE_FIRED:
                // Registra timestamp e shot_id
                g_trigger_ts_us = sample.timestamp_us;
                g_shot_id++;

                DBG("TRIGGER! shot_id=%u az_peak=%.2f m/s² ts=%uµs",
                    g_shot_id, g_trigger_az_peak, g_trigger_ts_us);

                // Congela il buffer circolare
                circular_buffer_freeze(s_pre_samples, s_post_samples, g_shot_id);

                // Notifica ble_task che c'è un burst da inviare
                xSemaphoreGive(g_trigger_fired_sem);

                // Avvia timer rearm
                rearm_start_ms = millis();
                g_trigger_phase = TRIG_PHASE_REARM;
                break;

            // ---------------------------------------------------------------
            case TRIG_PHASE_REARM:
                if ((millis() - rearm_start_ms) >= s_rearm_ms) {
                    s_confirm_count = 0;
                    g_trigger_az_peak = 0.0f;
                    s_manual_trigger = false;   // v2.4: scarta eventuale manuale arrivato durante il rearm
                    g_trigger_phase = g_recording_enabled ? TRIG_PHASE_ARMED : TRIG_PHASE_IDLE;
                    DBG("Trigger REARMED");
                }
                break;
        }

        // Cede il controllo per 3ms (periodo campionamento ~4ms — lascia margine)
        // Non usare vTaskDelay(1) in tight loop: consuma CPU inutilmente.
        // imu_task legge dalla ISR (più responsivo), noi leggiamo g_latest_sample.
        vTaskDelay(pdMS_TO_TICKS(3));
    }

    vTaskDelete(nullptr);
}

