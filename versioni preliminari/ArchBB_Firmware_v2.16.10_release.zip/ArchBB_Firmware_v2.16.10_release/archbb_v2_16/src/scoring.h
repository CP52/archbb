// =============================================================================
// scoring.h — ArchBB: stato condiviso dello scoring del tiro (v1.0)
// Firmware 2.11.0 — Fase C
// =============================================================================
//
// SCOPO
//   Definisce la struttura PendingScore, il "ponte dati" fra due task:
//     - ble_server (ble_send_burst): a fine burst calcola gli ANGOLI (cant,alzo)
//       dal burst — finche' l'array e' ancora valido — e li deposita qui, poi
//       entra in STATE_SCORING.
//     - display_task: nello stato SCORING raccoglie l'ESITO col touch (colpito,
//       zona, distanza), lo scrive qui, e a completamento chiama ble_send_score()
//       che assembla e trasmette lo ScorePacket.
//
//   Perche' un ponte e non parametri di funzione: i campioni del burst NON
//   persistono dopo il ritorno di ble_send_burst, mentre lo scoring avviene
//   secondi dopo, in un altro task. Gli angoli vanno quindi calcolati subito
//   (array valido) e conservati; lo scoring li raggiunge qui piu' tardi.
//
// CONCORRENZA
//   L'accesso e' semplice e sicuro senza mutex complessi: ble_server SCRIVE
//   angoli+shot_id e imposta ready_for_input=true PRIMA di entrare in SCORING;
//   il display_task legge quei campi e scrive solo i campi di esito, che
//   ble_server non tocca. Non c'e' scrittura concorrente sullo stesso campo.
//   La variabile e' volatile per visibilita' cross-core (BLE su Core0,
//   display su Core0: stesso core, ma volatile per correttezza formale).
// =============================================================================

#pragma once
#include <stdint.h>

struct PendingScore {
    // --- Riempiti da ble_server a fine burst (input al display_task) ---
    uint16_t shot_id;          // id del tiro (lega allo ScorePacket e al burst)
    int16_t  cant_cdeg;        // cant  in centesimi di grado (gia' pronto per il packet)
    int16_t  alzo_cdeg;        // alzo  in centesimi di grado
    float    disp_ms2;         // dispersione |a| nella finestra (qualita' misura)
    bool     angles_valid;     // true se il calcolo angoli e' andato a buon fine

    // --- v2.14: metrica HOLD (follow-through), input al display_task ---
    // Calcolata a fine burst insieme a cant/alzo. Serve al display PRIMA dello
    // scoring: sapere se il braccio ha tenuto mentre si dichiara l'esito da' la
    // diagnosi (mancato+tenuto = errore di stima; mancato+abbassato = errore di
    // esecuzione). Vedi shot_angles.h per la validazione.
    int16_t  hold_cdeg;        // hold in centesimi di grado; NEGATIVO = abbassato
    uint8_t  hold_class;       // HoldClass: 0=TENUTO 1=LIEVE 2=ABBASSATO 3=ALZATO 4=N/D
    bool     hold_valid;       // true se il post-scocco era sufficiente a calcolarlo

    // --- v2.15: metrica RELEASE (pulizia del rilascio), input al display_task ---
    // Ortogonale a hold (rho=-0.024 su 42 tiri): hold guarda 900ms, release 40ms.
    // Servono entrambe a display: dicono DUE errori diversi dello stesso tiro.
    uint16_t release_jerk;     // max |d(ay)/dt| nei 40ms [m/s^3]; alto = strappo
    uint8_t  release_class;    // ReleaseClass: 0=PULITO 1=MEDIO 2=STRAPPO 3=N/D
    bool     release_valid;    // true se la finestra aveva abbastanza campioni

    // --- Riempiti dal display_task col touch (output dello scoring) ---
    bool     valutato;         // true se l'utente ha valutato; false se SKIP/timeout
    bool     colpito;          // esito
    uint8_t  zona;             // 0..8 (griglia 3x3)
    uint8_t  distanza_m;       // 0=ignota, 5..60 (distanza INCLINATA, line-of-sight)
    // v2.16: elevazione del bersaglio dal telemetro, gradi interi.
    //   -30..+30 = misurata (+ = bersaglio piu' in alto dell'arciere)
    //   ELEV_NOT_SET(-128) = non misurata (NON e' 0: 0 = tiro in piano)
    // Insieme a distanza_m forma la coppia (D, alpha) del telemetro: entrambe
    // GREZZE, mai pre-compensate. Vedi config.h per il perche'.
    int8_t   elev_deg;

    // --- Coordinamento ---
    volatile bool ready;       // ble_server -> display: c'e' un tiro da valutare
};

// Istanza globale condivisa (definita in ble_server.cpp).
extern volatile PendingScore g_pending_score;

// Trasmette lo ScorePacket all'app assemblandolo da g_pending_score.
// Chiamata dal display_task a scoring completato (o SKIP/timeout).
// Ritorna true se la notify e' stata accodata con successo.
bool ble_send_score();
