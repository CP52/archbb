// =============================================================================
// imu.h — ArchBB: interfaccia driver QMI8658C
// Versione corretta v1.1
// =============================================================================
//
// CORREZIONI v1.1 rispetto alla v1.0:
//
//   1. API SensorLib reale:
//      - begin(Wire, addr, sda, scl)  — firma corretta dalla classe base
//      - setPins(irq_pin)             — prima di begin(), abilita getDataReady()
//      - getDataReady()               — polling interno (NO attachInterrupt esterno)
//      - configINT() NON ESISTE       — si usa enableINT(INTERRUPT_PIN_1)
//      - GYR_ODR_250Hz NON ESISTE     — si usa GYR_ODR_224_2Hz
//      - GYR_ODR_500Hz NON ESISTE     — si usa GYR_ODR_448_4Hz
//      - GYR_ODR_100Hz NON ESISTE     — si usa GYR_ODR_112_1Hz
//      - GYR_RANGE_2048DPS NON ESISTE — max è GYR_RANGE_1024DPS
//
//   2. Strategia interrupt cambiata:
//      SensorLib gestisce internamente il pin IRQ (passato a setPins()).
//      getDataReady() legge il pin direttamente via hal->digitalRead().
//      Non usiamo attachInterrupt() esterno — imu_task() chiama getDataReady()
//      in polling con vTaskDelay(2ms) e usa un semaforo per notificare.
//      Latenza massima: 2ms (vs 4ms del periodo) — accettabile per 224Hz.
//
//   3. volatile ImuSample corretto:
//      Rimosso volatile da g_latest_sample — usiamo mutex FreeRTOS per
//      la sincronizzazione (più corretto e portabile).
//
// NOTA SensorQMI8658.hpp:
//   Il file SensorQMI8658.hpp è marcato DEPRECATED nella v0.2.x di SensorLib.
//   Il pragma message lo avvisa alla compilazione — non è un errore bloccante.
//   Per ora lo usiamo perché funziona; la migrazione al nuovo driver è futura.
// =============================================================================

#pragma once

#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include "config.h"

// =============================================================================
// HANDLE GLOBALI
// =============================================================================
extern SemaphoreHandle_t g_imu_sample_mutex;
extern ImuSample         g_latest_sample;    // NON volatile: protetto da mutex
extern volatile bool     g_imu_ok;

// =============================================================================
// API PUBBLICA
// =============================================================================

// Inizializza QMI8658C. Ritorna true se OK.
// irq_pin: GPIO collegato a INT1 del QMI8658C (IMU_INT_PIN = GPIO14 su Waveshare).
//          Passato a SensorLib per getDataReady() interno.
bool imu_init(OdrSetting odr           = ODR_250HZ,
              uint8_t    accel_range_g  = 8,
              uint16_t   gyro_range_dps = 512,
              int        irq_pin        = IMU_INT_PIN);

// Cambia ODR a runtime (fermare imu_task prima).
bool imu_set_odr(OdrSetting odr);

// Task FreeRTOS (Core 1, priorità HIGH).
// Polling getDataReady() ogni 2ms → legge IMU → aggiorna g_latest_sample
// → push in circular buffer. Non ritorna.
void imu_task(void* param);

// Temperatura on-chip [°C].
float imu_read_temperature();

// Debug Serial.
void imu_print_debug();

