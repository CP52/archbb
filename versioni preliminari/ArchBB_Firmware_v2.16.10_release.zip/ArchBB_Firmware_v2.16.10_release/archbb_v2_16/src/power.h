// =============================================================================
// power.h — ArchBB: gestione risparmio energetico  (v1.0, per firmware v2.6)
// =============================================================================
//
// SCOPO
//   Centralizzare la gestione del BACKLIGHT del display e del BUZZER per
//   ridurre il consumo durante le lunghe attese in mira, senza sacrificare il
//   feedback all'utente nei momenti che contano (scocco + trasmissione).
//
// IL PROBLEMA (misurato sul campo)
//   Con la lettura batteria reale introdotta in v2.5, una sessione di 5 frecce
//   ha mostrato un calo dall'85% al 65%. Il display acceso in permanenza è la
//   causa principale evitabile: sui piccoli TFT il solo backlight LED assorbe
//   ~15-25 mA, ed è acceso anche quando il telefono è in tasca e nessuno guarda
//   lo schermo (cioè per la maggior parte del tempo di sessione).
//
// LA STRATEGIA (guidata dalla macchina a stati)
//   Il backlight NON serve mentre il dispositivo è ARMATO in attesa dello
//   scocco (stato RECORDING): in quel momento l'arciere è in mira, il telefono
//   è in tasca. Serve invece:
//     - alla connessione e da fermi (IDLE/CONNECTED): l'utente configura/guarda
//     - allo scocco e durante la trasmissione (SENDING): conferma "colpo preso"
//     - in modalità LIVE: si sta guardando il mirino/telemetria
//   Quindi:
//     STATE_RECORDING           → backlight OFF   (attesa in mira, risparmio)
//     tutti gli altri stati      → backlight ON
//   La transizione RECORDING→SENDING (scocco riconosciuto) RIACCENDE il
//   backlight e produce un BEEP breve di conferma. Il ritorno SENDING→RECORDING
//   (pronto per il colpo dopo) lo rispegne.
//
// PERCHÉ NON IL LIGHT-SLEEP DELLA CPU (nota progettuale)
//   Spegnere il core farebbe risparmiare di più (~40 mA), ma è incompatibile
//   col modello di trigger attuale: le metriche pre-scocco richiedono il
//   campionamento IMU continuo. Il light-sleep con wake-on-interrupt è un
//   progetto a sé, rimandato alla piattaforma 1.83 (AXP2101). Qui agiamo solo
//   sul backlight: massimo beneficio a rischio zero.
//
// PERCHÉ NON UN BEEP PERIODICO A SCHERMO SPENTO
//   Un beep ricorrente "sono vivo" AUMENTEREBBE il consumo (il buzzer tira
//   corrente) e disturberebbe la concentrazione in mira. Preferiamo un singolo
//   beep di CONFERMA allo scocco. Se in futuro si vuole un "battito di
//   presenza", va reso opzionale, raro e spento di default.
//
// =============================================================================
#pragma once
#include <Arduino.h>

// -----------------------------------------------------------------------------
// power_init()
//   Configura i pin di backlight (TFT_BL) e buzzer (GPIO_BUZZER). Da chiamare
//   una volta in setup(), dopo display_init() (che già configura TFT_BL come
//   OUTPUT: qui ne prendiamo il controllo centralizzato).
// -----------------------------------------------------------------------------
void power_init();

// -----------------------------------------------------------------------------
// power_backlight(bool on)
//   Accende/spegne il backlight. Idempotente: se lo stato richiesto coincide
//   con quello attuale non fa nulla (evita scritture GPIO inutili).
// -----------------------------------------------------------------------------
void power_backlight(bool on);

// -----------------------------------------------------------------------------
// power_backlight_is_on()
//   Ritorna lo stato corrente del backlight (utile ad altri moduli).
// -----------------------------------------------------------------------------
bool power_backlight_is_on();

// -----------------------------------------------------------------------------
// power_update_for_state(uint8_t device_state)
//   Cuore della strategia: riceve lo stato corrente della macchina a stati e
//   imposta il backlight di conseguenza. Va chiamata a ogni ciclo del
//   display_task. Rileva internamente la transizione "ingresso in SENDING"
//   (cioè lo scocco appena riconosciuto) ed emette il beep di conferma UNA
//   sola volta per colpo.
// -----------------------------------------------------------------------------
void power_update_for_state(uint8_t device_state);

// -----------------------------------------------------------------------------
// power_beep(uint16_t freq_hz, uint16_t dur_ms)
//   Beep NON bloccante sul buzzer. Usa il canale LEDC (PWM hardware): avvia il
//   tono e programma lo spegnimento senza delay() bloccanti. Chiamabile da
//   qualsiasi task.
// -----------------------------------------------------------------------------
void power_beep(uint16_t freq_hz = 2200, uint16_t dur_ms = 60);

// -----------------------------------------------------------------------------
// power_tick()
//   Da chiamare frequentemente (es. nel display_task o nel loop): gestisce lo
//   spegnimento programmato del beep non bloccante. Leggerissima.
// -----------------------------------------------------------------------------
void power_tick();
