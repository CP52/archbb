// =============================================================================
// scoring_ui.cpp — ArchBB: UI dello scoring on-device (v3.0)
// Firmware 2.16.0 — Fase C + Backport UX 1.83 + ELEVAZIONE bersaglio
// =============================================================================
// Vedi scoring_ui.h per la panoramica. Struttura del file:
//   [1] Mini-driver touch CST816T (I2C raw, guard di plausibilità)
//   [2] Mappatura raw->zona con le soglie calibrate
//   [3] Rendering delle schermate (sprite): esito / zona / distanza / RIEPILOGO
//   [4] Sotto-macchina a stati dello scoring
//
// COSA CAMBIA nella v3.0 (v2.16 — ELEVAZIONE del bersaglio)
//   La schermata DISTANZA diventa DISTANZA + ELEVAZIONE: due slider sovrapposti
//   nella STESSA schermata, non una schermata in piu'.
//
//   PERCHE' NELLA STESSA SCHERMATA (e non una quarta consecutiva)
//     I due dati arrivano dallo STESSO gesto: il telemetro li mostra insieme,
//     nella stessa lettura, sullo stesso display. Separarli costringerebbe
//     l'arciere a memorizzare un numero mentre naviga fra schermate — che e'
//     esattamente il tipo di carico cognitivo che lo scoring on-device esiste
//     per evitare. La catena resta a 4 schermate:
//       ESITO -> ZONA -> DIST+ELEV -> RIEPILOGO
//
//   PERCHE' NON UN TASTIERINO NUMERICO CON CODICE CONCATENATO (es. 15.07)
//     Era l'alternativa considerata. Scartata: (a) il separatore e' ambiguo
//     (15.7 = 7 o 70 gradi?) e impone uno zero-padding da ricordare col guanto;
//     (b) l'elevazione e' BIPOLARE e un tastierino non ha un posto naturale per
//     il segno; (c) costa ~7 tocchi contro i 3 dei due slider, ed e' proprio
//     l'operazione che deve essere veloce. Il codice concatenato sarebbe
//     esistito solo nella testa dell'utente per 4 secondi: a valle (firmware,
//     BLE, CSV) i due campi restano comunque separati. Complessita' netta.
//
//   TRE SCELTE DI DESIGN NON OVVIE
//     [a] I tasti +/- sono CONTESTUALI: agiscono sull'ultimo slider toccato,
//         evidenziato dal colore del bordo. Due coppie di +/- (una per slider)
//         non ci stanno: servirebbero 4 tasti da 48px in una fascia alta 30.
//     [b] SNAP A ZERO entro +-2 gradi sullo slider elevazione. Il tiro in piano
//         e' il caso piu' frequente: un +1 spurio da tap impreciso inquinerebbe
//         l'analisi con rumore che non esiste nella realta'.
//     [c] L'elevazione NON ha il tasto "?" . Se non la tocchi resta NON IMPOSTATA
//         (sentinella), ma il default MOSTRATO e' 0 (in piano) perche' e' il
//         default fisico corretto. La distanza invece ha "?" perche' li' lo 0 non
//         significa "0 metri" ma "non lo so". Asimmetria voluta: le due grandezze
//         hanno un default naturale diverso.
//
// COSA CAMBIA rispetto alla v1.0 (backport delle migliorie mature sulla 1.83):
//   §1  RIEPILOGO come punto di controllo esplicito (OK cementa / CORREGGI
//       riapre lo stesso tiro senza reinviare). È il cuore del backport:
//       impedisce di fallare uno score con un tocco distratto.
//   §2  Debounce del tap + COOLDOWN uniforme post-azione (~200ms): elimina il
//       doppio-conteggio e l'ereditarietà del tocco fra schermate consecutive.
//       Sostituisce il vecchio delay(180) puntuale sulla sola schermata zona.
//   §3  Pulsante ‹ INDIETRO in ZONA e DISTANZA (torna alla schermata precedente).
//   §4  Breadcrumb (contesto delle scelte già fatte) in ZONA e DISTANZA.
//   §6  Pulsante ? (IGNOTA) esplicito per distanza=0 nella schermata distanza.
//
// COSA NON CAMBIA (era già corretto nella v1.0, riverificato):
//   §5  Semantica MANCATO: la schermata zona si mostra comunque; il centro
//       (indice 4) è disattivato nel mancato, SPOT nel colpito. Nessun zona=0
//       d'ufficio.
//   §7  Simboli +/- disegnati geometricamente (font 6 di TFT_eSPI è solo
//       numerico). Testo con lettere ("OK","CONFERMA") in font 4.
//
// COSA NON SI TOCCA (vincoli hardware/protocollo — vedi briefing 1.69):
//   - v2.16.2: le soglie THR_* empiriche sono state RIMOSSE, sostituite dalla
//     geometria vera della griglia + calibrazione affine nel driver.
//   - Pin touch SDA=11 SCL=10 RST=13 INT=14: INVARIATI.
//   - ScorePacket / ble_send_score(): il CORREGGI NON lo richiama; l'OK sì.
//     Lo shot_id resta quello scritto da ble_server all'ingresso: nessuno lo
//     tocca durante lo scoring, quindi CORREGGI lo preserva "per costruzione".
// =============================================================================

#include "scoring_ui.h"
#include "config.h"
#include "scoring.h"      // g_pending_score, ble_send_score()
#include "ble_server.h"   // g_device_state, g_shot_id
#include "display.h"      // palette COL_*, DISPLAY_W/H/OFFSET
#include "shot_angles.h"  // v2.14: HoldClass, hold_class_name() per la banda HOLD
#include <Wire.h>

// =============================================================================
// [1] MINI-DRIVER TOUCH CST816T
// =============================================================================
// Pinout (da schematico + briefing clinometro): SDA=11 SCL=10 RST=13 INT=14.
// Indirizzo 0x15. Il bus I2C è già inizializzato in main.cpp (Wire.begin),
// condiviso con IMU (0x6B) e RTC: qui NON reinizializziamo il bus, usiamo
// soltanto le transazioni. Lo scoring gira dopo il burst (IMU non campiona un
// tiro), quindi il bus è libero: coerente col vincolo del design doc.

#ifndef TP_RST
  #define TP_RST 13
#endif
#ifndef TP_INT
  #define TP_INT 14
#endif
#ifndef CST816_ADDR
  #define CST816_ADDR 0x15
#endif

static constexpr uint8_t  TP_REG_GESTURE   = 0x01;
static constexpr uint8_t  TP_REG_DIS_SLEEP  = 0xFE;
static constexpr uint16_t TP_COORD_SENTINEL = 4095;   // 0x0FFF: lettura sporca
// v2.16.4: era 320 ("controller 240x320"), ma quel filtro SCARTAVA
// SILENZIOSAMENTE ogni lettura oltre — e la calibrazione ha prodotto ry=317,
// a un pelo dal limite. Un fit che lavora su dati troncati senza saperlo e'
// esattamente come si ottengono due misure diverse dello stesso sistema.
// Il fondo scala reale del chip NON e' noto (e' il dato che DIAG deve
// misurare): finche' non lo e', l'unico valore da scartare e' la sentinella
// 4095 (0x0FFF = lettura sporca). 1023 = massimo su 10 bit: qualunque cosa il
// chip riporti ci sta dentro.
static constexpr uint16_t TP_COORD_MAX      = 1023;

// --- Soglie di calibrazione raw->zona (validate sul campo) — NON TOCCARE ---
// --- v2.16.2: geometria della griglia ZONA (era: soglie empiriche THR_*) ----
// COS'ERANO LE VECCHIE THR_*
//   THR_X_LC=89, THR_X_CR=164, THR_Y_TM=68, THR_Y_MB=198: quattro numeri tarati
//   sul campo "finche' funzionava", in coordinate GREZZE del chip. Funzionavano
//   perche' le celle sono 66px: bastava che il tocco cadesse dalla parte giusta,
//   e un errore di 20px non si vedeva. Erano la toppa su un disallineamento mai
//   diagnosticato — lo stesso che sui tasti da 32px della schermata DIST+ELEV
//   e' diventato palese ("tocco + e risponde OK").
//
// PERCHE' VANNO VIA ADESSO
//   [1] Ora tpRead() consegna coordinate-SPRITE. Confrontarle con soglie
//       espresse in coordinate-CHIP sarebbe sbagliato per costruzione.
//   [2[ Non erano nemmeno coerenti fra loro: provando a ricavarne la
//       trasformazione, un confine tornava a 4px e l'altro sbagliava di 64.
//       Un errore di scala da' scarti proporzionali, uno di offset li da'
//       uguali: quei numeri non descrivevano nessuna geometria: erano solo
//       "abbastanza giusti" per celle grandi.
//
// COSA C'E' AL LORO POSTO
//   La geometria VERA della griglia, derivata dalle stesse costanti con cui la
//   griglia viene DISEGNATA (gx=6, gy=44, cell=66, gap=4 in drawZona). I confini
//   cadono a meta' dei gap. Se un domani la griglia si sposta, i confini si
//   spostano con lei: e' impossibile che divergano, perche' sono la stessa cosa.
static constexpr int16_t ZG_X0   = 6;    // origine x della griglia (drawZona)
static constexpr int16_t ZG_Y0   = 44;   // origine y della griglia
static constexpr int16_t ZG_CELL = 66;   // lato cella
static constexpr int16_t ZG_GAP  = 4;    // spazio fra celle
// Confini = centro del gap fra una cella e la successiva.
//   fine della cella n = origine + n*cell + (n-1)*gap
//   confine dopo la cella n = fine + gap/2
// (Attenzione: NON e' origine + n*(cell+gap) + gap/2 — quello e' l'INIZIO della
// cella n+1, cioe' mezzo gap piu' in la'. Errore commesso e corretto: il test
// esaustivo sulle 9 celle l'ha stanato subito.)
static constexpr int16_t ZG_X_B1 = ZG_X0 + ZG_CELL + ZG_GAP/2;                  // 74
static constexpr int16_t ZG_X_B2 = ZG_X0 + 2*ZG_CELL + ZG_GAP + ZG_GAP/2;       // 144
static constexpr int16_t ZG_Y_B1 = ZG_Y0 + ZG_CELL + ZG_GAP/2;                  // 112
static constexpr int16_t ZG_Y_B2 = ZG_Y0 + 2*ZG_CELL + ZG_GAP + ZG_GAP/2;       // 182

// --- §2 COOLDOWN post-azione ------------------------------------------------
// Dopo OGNI azione touch che cambia stato, ignoriamo i tap per questo intervallo.
// A cosa serve: il CST816, allo stacco del dito, produce micro-rimbalzi, e con
// due schermate consecutive lo stesso dito può contare due volte (tap su ZONA
// che avanza a DISTANZA + residuo che conta come tap su DISTANZA). Un cooldown
// uniforme risolve il problema alla radice, in un colpo solo per tutte le
// schermate. Sostituisce il vecchio delay(180) puntuale (bloccante) sulla sola
// zona: qui è NON bloccante (confronto di millis) e vale ovunque.
// A 80ms/loop (~12Hz) 200ms sono ~2-3 giri: impercettibile per un tap
// intenzionale, sufficiente a mangiare il rimbalzo del rilascio precedente.
static constexpr uint32_t TOUCH_COOLDOWN_MS = 200;

struct TouchRaw {
    bool     valid;    // supera il guard di plausibilità
    bool     present;  // il chip riporta un dito (prima del guard)
    uint16_t x, y;
};

static bool tpReadRegs(uint8_t reg, uint8_t* buf, uint8_t len) {
    Wire.beginTransmission(CST816_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom((int)CST816_ADDR, (int)len) != len) return false;
    for (uint8_t i = 0; i < len; i++) buf[i] = Wire.read();
    return true;
}
static bool tpWriteReg(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(CST816_ADDR);
    Wire.write(reg);
    Wire.write(val);
    return (Wire.endTransmission() == 0);
}

void scoring_ui_init() {
    // Reset hardware del touch.
    pinMode(TP_RST, OUTPUT);
    digitalWrite(TP_RST, LOW);  delay(10);
    digitalWrite(TP_RST, HIGH); delay(50);
    pinMode(TP_INT, INPUT_PULLUP);
    // Disabilita auto-sleep per reattività (il chip altrimenti dorme e dà errori).
    tpWriteReg(TP_REG_DIS_SLEEP, 0x01);
}

// Legge un evento di tocco con guard di plausibilità (scarta gli spuri del chip:
// fingers!=1, coord sentinella 4095, fuori range fisico).
// v2.16.2 — LA CORREZIONE STA QUI, E SOLO QUI.
//   Le coordinate del CST816 non coincidono con quelle dello sprite (sintomo:
//   toccando "+" rispondeva "OK"; presente anche in ZONA, dove le celle da 66px
//   lo mascheravano). La trasformazione affine si applica UNA VOLTA nel driver:
//   da qui in poi tutto il firmware vede coordinate-sprite.
//
//   PERCHE' NEL DRIVER E NON NEGLI HANDLER
//     Correggere in ogni schermata avrebbe significato quattro punti da tenere
//     allineati a mano, piu' uno nuovo per ogni schermata futura. Ma il bug era
//     latente PROPRIO perche' ogni schermata aveva le sue soglie empiriche
//     scollegate: la cura non puo' essere aggiungerne altre. Un solo punto di
//     verita', il piu' a monte possibile.
//
//   NOTA sui clamp: si applicano DOPO la trasformazione, contro il fondo scala
//   dello SPRITE (non piu' TP_COORD_MAX, che e' il fondo scala del CHIP). Prima
//   della trasformazione un valore fuori range e' ancora legittimo; dopo, no.
static TouchRaw tpRead() {
    TouchRaw t = {false, false, 0, 0};
    uint8_t d[6] = {0};
    if (!tpReadRegs(TP_REG_GESTURE, d, 6)) return t;
    uint8_t fingers = d[1] & 0x0F;
    t.present = (fingers > 0);
    if (fingers != 1) return t;
    uint16_t rx = ((uint16_t)(d[2] & 0x0F) << 8) | d[3];
    uint16_t ry = ((uint16_t)(d[4] & 0x0F) << 8) | d[5];
    if (rx == TP_COORD_SENTINEL || ry == TP_COORD_SENTINEL) return t;
    if (rx > TP_COORD_MAX || ry > TP_COORD_MAX) return t;

    // grezzo -> sprite
    float fx = TOUCH_CAL_AX * (float)rx + TOUCH_CAL_BX;
    float fy = TOUCH_CAL_AY * (float)ry + TOUCH_CAL_BY;

    // Clamp ai bordi dello sprite invece di scartare: un tocco appena fuori per
    // arrotondamento e' un tocco sul bordo, non un errore. Scartarlo renderebbe
    // insensibili le fasce estreme (i tasti sono a 16px dal bordo).
    if (fx < 0) fx = 0; if (fx > DISPLAY_W - 1) fx = DISPLAY_W - 1;
    if (fy < 0) fy = 0; if (fy > DISPLAY_H - 1) fy = DISPLAY_H - 1;

    t.x = (uint16_t)(fx + 0.5f);
    t.y = (uint16_t)(fy + 0.5f);
    t.valid = true;
    return t;
}

// =============================================================================
// [2] MAPPATURA tocco -> zona (0..8)
// =============================================================================
// v2.16.2: le coordinate in ingresso sono gia' in spazio SPRITE (le converte
// tpRead), quindi qui si confrontano con la geometria della griglia disegnata.
// Prima si confrontavano coordinate-chip con soglie empiriche: funzionava per
// tolleranza, non per correttezza.
static uint8_t tpZoneFromRaw(uint16_t x, uint16_t y) {
    uint8_t col = (x < ZG_X_B1) ? 0 : ((x < ZG_X_B2) ? 1 : 2);
    uint8_t row = (y < ZG_Y_B1) ? 0 : ((y < ZG_Y_B2) ? 1 : 2);
    return row * 3 + col;
}

// Stato del rilevatore di tap, a livello di modulo (per poterlo azzerare dalle
// transizioni di fase). 'tp_seen' = un tocco valido è in corso; 'tp_armed_release'
// = dobbiamo attendere un rilascio PULITO prima di accettare il prossimo tap.
static bool     tp_seen = false;
static uint16_t tp_lx = 0, tp_ly = 0;
static bool     tp_require_release = false;

// --- v2.16: stato del tocco LIVE (per il ghost sotto il dito) ---------------
// PERCHE' NON UNA SECONDA LETTURA I2C: tpTapReleased() gia' interroga il chip a
// ogni giro e memorizza l'ultima posizione valida in tp_lx/tp_ly. Il ghost non
// ha bisogno di nient'altro: basta ESPORRE quello che il driver sa gia'. Una
// seconda tpRead() nello stesso giro raddoppierebbe il traffico sul bus I2C
// (condiviso con l'IMU) per zero informazione aggiuntiva.
static bool     tp_live_down = false;   // dito attualmente giu' (tocco valido)
static uint16_t tp_live_x = 0, tp_live_y = 0;

// Forza il rilevatore a scartare il tocco in corso e ad attendere un rilascio
// completo prima di validare un nuovo tap. Va chiamata a OGNI transizione di
// schermata: evita che un tocco ancora premuto su un pulsante venga "ereditato"
// dalla schermata successiva se le aree si sovrappongono (bug del riepilogo che
// spariva: CONFERMA distanza e OK riepilogo condividono l'area x[120..224]
// y[178..220], quindi il tocco di CONFERMA cadeva anche su OK).
static void tpResetTap() {
    tp_seen = false;
    tp_require_release = true;
    tp_live_down = false;   // v2.16: niente ghost fantasma dopo un cambio schermata
}

// Rileva un tocco COMPLETO (al rilascio) in modo non bloccante. Restituisce true
// una sola volta, al rilascio, con l'ultima posizione valida. Se è stato chiamato
// tpResetTap(), ignora il tocco finché non vede prima un rilascio pulito.
// v2.16: aggiorna anche lo stato live (tp_live_*) usato dal ghost.
static bool tpTapReleased(uint16_t& out_x, uint16_t& out_y) {
    TouchRaw t = tpRead();
    // Se stiamo aspettando un rilascio pulito: consuma le letture ma non validare
    // nulla finché il dito non si stacca del tutto.
    if (tp_require_release) {
        if (!t.present) tp_require_release = false;   // dito staccato: sblocca
        tp_seen = false;
        tp_live_down = false;
        return false;
    }
    if (t.valid) {
        tp_lx = t.x; tp_ly = t.y; tp_seen = true;
        tp_live_down = true; tp_live_x = t.x; tp_live_y = t.y;
        return false;
    }
    if (!t.present && tp_seen) {
        tp_seen = false; tp_live_down = false;
        out_x = tp_lx; out_y = tp_ly; return true;
    }
    if (!t.present) tp_live_down = false;
    return false;
}

// =============================================================================
// [3] RENDERING DELLE SCHERMATE (sprite anti-flicker)
// =============================================================================
// Tinte tenui simulate: il firmware non ha alpha, quindi per gli sfondi tenui
// usiamo colori scuri dedicati vicini alla palette (rosso/verde desaturati).
static constexpr uint16_t COL_RED_DIM   = 0x3000;  // rosso molto scuro
static constexpr uint16_t COL_GREEN_DIM = 0x0140;  // verde molto scuro
static constexpr uint16_t COL_AMBER_DIM = 0x2120;  // ambra molto scura
static constexpr uint16_t COL_CYAN_DIM  = 0x0110;  // ciano molto scuro

// Numerini tastierino per zona (mnemonica di presentazione).
static const uint8_t ZONE_KEYPAD[9] = { 7,8,9, 4,5,6, 1,2,3 };

// Etichette compatte delle 9 zone (allineate alla nomenclatura dell'app v1.22:
// alto-sx/alto/alto-dx / sx/centro/dx / basso-sx/basso/basso-dx). Il centro
// diventa "SPOT" se colpito.
static const char* const ZONE_ABBR[9] = {
    "alto-sx", "alto", "alto-dx",
    "sx",      "centro","dx",
    "basso-sx","basso", "basso-dx"
};
static const char* zoneLabel(bool colpito, uint8_t z) {
    if (colpito && z == 4) return "SPOT";
    return (z < 9) ? ZONE_ABBR[z] : "";
}

// --- Breadcrumb (§4): riga di contesto in cima a ZONA e DISTANZA ------------
// Mostra le scelte già fatte, col colore che richiama l'esito (verde COLPITO /
// rosso MANCATO). In ZONA mostra solo l'esito; in DISTANZA "esito > zona".
// stage: 0 = siamo in ZONA (mostra esito), 1 = siamo in DISTANZA (esito > zona).
static void drawBreadcrumb(TFT_eSprite& s, uint8_t stage) {
    bool colpito = g_pending_score.colpito;
    uint16_t col = colpito ? COL_GREEN : COL_RED;
    char line[40];
    if (stage == 0) {
        snprintf(line, sizeof(line), "%s", colpito ? "COLPITO" : "MANCATO");
    } else {
        // Il font 2 non ha un glifo affidabile per '›': uso ">" semplice.
        snprintf(line, sizeof(line), "%s > %s",
                 colpito ? "COLPITO" : "MANCATO",
                 zoneLabel(colpito, g_pending_score.zona));
    }
    s.setTextDatum(TL_DATUM);
    s.setTextColor(col, COL_BG);
    s.drawString(line, 6, 2, 2);
    s.drawFastHLine(0, 20, DISPLAY_W, COL_DARKGRAY);
    s.setTextDatum(MC_DATUM);   // ripristino il datum di default usato altrove
}

// --- Pulsante ‹ INDIETRO (§3): riquadro in basso a sinistra -----------------
// Disegnato come area tattile esplicita, coerente in ZONA e DISTANZA. La barra
// SKIP resta a destra; INDIETRO occupa il lato sinistro della fascia inferiore.
static void drawBackButton(TFT_eSprite& s) {
    const int16_t bx = 4, by = DISPLAY_H - 30, bw = 74, bh = 26;
    s.fillRect(bx, by, bw, bh, COL_BG);
    s.drawRect(bx, by, bw, bh, COL_DARKGRAY);
    s.setTextDatum(MC_DATUM);
    s.setTextColor(COL_GRAY, COL_BG);
    // Chevron '‹' disegnato geometricamente (due segmenti) + testo "indietro".
    int16_t chx = bx + 12, chy = by + bh/2;
    s.drawLine(chx + 4, chy - 6, chx - 3, chy,     COL_GRAY);
    s.drawLine(chx - 3, chy,     chx + 4, chy + 6, COL_GRAY);
    s.drawString("indietro", bx + bw/2 + 6, chy, 1);
}

// --- Schermata 1: esito rosso/verde ---
// --- Banda diagnostica RILASCIO | HOLD (v2.14, estesa v2.15) ----------------
// Mostra le due metriche del gesto PRIMA che l'arciere dichiari l'esito. Non e'
// un vezzo: l'ordine e' il punto. Vedere "STRAPPO" o "ABBASSATO" mentre si sta
// per premere MANCATO da' la diagnosi immediata. Se il dato arrivasse dopo, o
// solo nell'app a casa, il nesso col gesto appena compiuto andrebbe perso.
//
// PERCHE' DUE E NON UNA: misurano fasi diverse e sono statisticamente
// indipendenti (rho = -0.024 su 42 tiri). Un tiro puo' avere rilascio sporco e
// tenuta perfetta, o viceversa: sono due errori distinti e vanno letti insieme.
//
//   [ RILASCIO ]  |  [ HOLD ]
//    0..40ms          0..900ms
//    come rilasci     come tieni
//
// Colore: verde/ambra/rosso per entrambe. Stesso codice colore dell'esito, cosi'
// non c'e' un vocabolario nuovo da imparare.
//
// Occupa la fascia y=[0..HOLD_BAND_H), FUORI dai semicampi tattili: i tocchi
// sotto HOLD_BAND_H scelgono l'esito, quelli sopra sono ignorati (v. handler).
static constexpr int16_t HOLD_BAND_H = 30;

// Colore per classe (0=buono, 1=medio, 2+=cattivo) -> stessa mappa per entrambe.
static uint16_t classColor(uint8_t c, uint8_t na_val) {
    if (c == na_val) return COL_GRAY;
    switch (c) {
        case 0:  return COL_GREEN;
        case 1:  return COL_AMBER;
        default: return COL_RED;
    }
}

static void drawHoldBand(TFT_eSprite& s) {
    s.fillRect(0, 0, DISPLAY_W, HOLD_BAND_H, COL_BG);
    s.drawFastHLine(0, HOLD_BAND_H, DISPLAY_W, COL_DARKGRAY);
    // divisore verticale fra le due meta'
    s.drawFastVLine(DISPLAY_W/2, 2, HOLD_BAND_H - 4, COL_DARKGRAY);

    const int16_t yTop = 3;
    const int16_t yBot = HOLD_BAND_H - 11;

    // ---- meta' sinistra: RILASCIO ----
    s.setTextDatum(TC_DATUM);
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("RILASCIO", DISPLAY_W/4, yTop, 1);
    if (!g_pending_score.release_valid) {
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("N/D", DISPLAY_W/4, yBot, 2);
    } else {
        s.setTextColor(classColor(g_pending_score.release_class, RELEASE_NA), COL_BG);
        s.drawString(release_class_name(g_pending_score.release_class),
                     DISPLAY_W/4, yBot, 2);
    }

    // ---- meta' destra: HOLD ----
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("HOLD", DISPLAY_W*3/4, yTop, 1);
    if (!g_pending_score.hold_valid) {
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("N/D", DISPLAY_W*3/4, yBot, 2);
    } else {
        // Valore numerico: serve piu' dell'etichetta a chi confronta due tiri
        // della stessa classe. L'etichetta e' a colpo d'occhio nel colore.
        char buf[12];
        snprintf(buf, sizeof(buf), "%+.1f", g_pending_score.hold_cdeg / 100.0f);
        s.setTextColor(classColor(g_pending_score.hold_class, HOLD_NA), COL_BG);
        s.drawString(buf, DISPLAY_W*3/4, yBot, 2);
    }
    s.setTextDatum(MC_DATUM);   // ripristino il datum di default usato altrove
}

// --- Schermata 1: esito (MANCATO / COLPITO) ---------------------------------
// v2.14: la banda HOLD occupa la fascia alta; i semicampi tattili partono da
// HOLD_BAND_H+1 e la loro altezza si riduce di conseguenza. Le zone touch
// restano discriminate per X (~120px per lato: robusto), con in piu' il vincolo
// ty > HOLD_BAND_H che protegge la banda dai tocchi accidentali.
static void drawEsito(TFT_eSprite& s) {
    s.fillSprite(COL_BG);

    const int16_t top = HOLD_BAND_H + 1;
    const int16_t fh  = DISPLAY_H - 32 - top;    // altezza dei semicampi

    // semicampo sinistro (MANCATO, rosso)
    s.fillRect(0, top, DISPLAY_W/2, fh, COL_RED_DIM);
    // semicampo destro (COLPITO, verde)
    s.fillRect(DISPLAY_W/2, top, DISPLAY_W/2, fh, COL_GREEN_DIM);
    // divisore
    s.drawFastVLine(DISPLAY_W/2, top, fh, COL_DARKGRAY);

    s.setTextDatum(MC_DATUM);
    // Centri ricalcolati sulla nuova fascia utile: i glifi restano otticamente
    // centrati invece di scivolare in basso.
    const int16_t gy = top + fh/2 - 18;   // glifo grande
    const int16_t ly = top + fh/2 + 37;   // etichetta

    // MANCATO
    s.setTextColor(COL_RED, COL_RED_DIM);
    s.drawString("X", DISPLAY_W/4, gy, 6);
    s.drawString("MANCATO", DISPLAY_W/4, ly, 2);
    // COLPITO
    s.setTextColor(COL_GREEN, COL_GREEN_DIM);
    s.drawString("O", DISPLAY_W*3/4, gy, 6);
    s.drawString("COLPITO", DISPLAY_W*3/4, ly, 2);

    // banda HOLD in cima (v2.14)
    drawHoldBand(s);

    // barra SKIP (resta su esito, come richiesto)
    s.fillRect(0, DISPLAY_H - 32, DISPLAY_W, 32, COL_BG);
    s.drawFastHLine(0, DISPLAY_H - 32, DISPLAY_W, COL_DARKGRAY);
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("salta valutazione", DISPLAY_W/2, DISPLAY_H - 16, 2);

    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// Disegna una freccia direzionale dentro una cella (zona 0..8, escluso 4).
static void drawZoneGlyph(TFT_eSprite& s, uint8_t z, int16_t cx, int16_t cy, uint16_t col) {
    int col_i = z % 3, row_i = z / 3;
    int dx = col_i - 1, dy = row_i - 1;   // -1,0,+1
    int len = 11;
    int x2 = cx + dx*len, y2 = cy + dy*len;
    int x1 = cx - dx*len, y1 = cy - dy*len;
    s.drawLine(x1, y1, x2, y2, col);
    s.fillCircle(x2, y2, 3, col);   // punta di freccia al capo (x2,y2)
}

// --- Schermata 2: zona 3x3 (colpito=SPOT / mancato=centro disabilitato) ------
// §4 breadcrumb (esito) in cima; §3 INDIETRO in basso a sinistra.
static void drawZona(TFT_eSprite& s, bool colpito, int8_t sel_zone) {
    s.fillSprite(COL_BG);

    // §4 breadcrumb (esito) — sostituisce il vecchio titolo generico
    drawBreadcrumb(s, 0);

    s.setTextDatum(MC_DATUM);
    s.setTextColor(colpito ? COL_GREEN : COL_AMBER, COL_BG);
    s.drawString(colpito ? "DOVE HAI COLPITO" : "ZONA IMPATTO", DISPLAY_W/2, 30, 2);

    const int16_t gx = 6, gy = 44, cell = 66, gap = 4;   // 3*66+2*4 = 206
    for (uint8_t z = 0; z < 9; z++) {
        int cxi = z % 3, ryi = z / 3;
        int16_t x = gx + cxi * (cell + gap);
        int16_t y = gy + ryi * (cell + gap);
        int16_t ccx = x + cell/2, ccy = y + cell/2;

        bool is_center = (z == 4);
        bool selected  = (sel_zone == (int8_t)z);
        uint16_t border = COL_DARKGRAY, fill = COL_BG, fg = COL_GRAY;

        if (is_center && colpito) {          // SPOT
            border = COL_GREEN; fill = COL_GREEN_DIM; fg = COL_GREEN;
        } else if (is_center && !colpito) {  // centro disabilitato
            border = COL_DARKGRAY; fill = COL_BG; fg = COL_DARKGRAY;
        }
        if (selected) {
            border = colpito ? COL_GREEN : COL_RED;
            fill   = colpito ? COL_GREEN_DIM : COL_RED_DIM;
            fg     = colpito ? COL_GREEN : COL_RED;
        }

        s.fillRect(x, y, cell, cell, fill);
        s.drawRect(x, y, cell, cell, border);
        // numerino tastierino in alto a sx
        s.setTextDatum(TL_DATUM);
        s.setTextColor(fg, fill);
        char kb[2] = { (char)('0' + ZONE_KEYPAD[z]), 0 };
        s.drawString(kb, x + 5, y + 4, 1);
        s.setTextDatum(MC_DATUM);

        if (is_center && colpito) {
            s.drawCircle(ccx, ccy - 4, 10, COL_GREEN);
            s.fillCircle(ccx, ccy - 4, 4, COL_GREEN);
            s.setTextColor(COL_GREEN, fill);
            s.drawString("SPOT", ccx, ccy + 16, 1);
        } else if (is_center && !colpito) {
            s.drawFastHLine(ccx - 8, ccy, 16, COL_DARKGRAY);
        } else {
            drawZoneGlyph(s, z, ccx, ccy, fg);
        }
    }

    // §3 INDIETRO (torna a esito) + barra SKIP (destra) nella fascia inferiore
    drawBackButton(s);
    s.drawFastHLine(0, DISPLAY_H - 30, DISPLAY_W, COL_DARKGRAY);
    s.setTextDatum(MC_DATUM);
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("salta", DISPLAY_W - 44, DISPLAY_H - 15, 2);

    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// --- Schermata 3: distanza con SLIDER + tasti +/- + ? IGNOTA + INDIETRO/OK ---
// §4 breadcrumb (esito > zona); §6 pulsante ? per distanza=0; §3 INDIETRO.
// --- Schermata 3 (RIDISEGNO v2.13, criticita' campo #3): DISTANZA -----------
// Ergonomia: lo scoring va fatto veloce e col guanto. Il vecchio layout aveva
// tacche e CONFERMA orizzontali scomode. Nuovo schema (validato dall'uso: i
// tasti a tutta altezza sul bordo sono i piu' efficaci per il feedback tattile):
//   - SLIDER orizzontale grande a range fisso (DIST_MIN..DIST_MAX): un tocco
//     sulla barra imposta la distanza direttamente (tocco diretto);
//   - tasti +/- laterali grandi per l'aggiustamento fine;
//   - "?" per distanza IGNOTA (=0);
//   - in basso DUE tasti grandi verticali a tutta altezza: INDIETRO (sx) e
//     OK (dx), come nel riepilogo — discriminati per LATO, non per banda Y.
static constexpr uint8_t DIST_MIN = 5;
static constexpr uint8_t DIST_MAX = 60;

// --- Geometria comune ai due slider (coordinate sprite) ---------------------
static constexpr int16_t SLD_X0 = 24;                 // inizio barra
static constexpr int16_t SLD_X1 = DISPLAY_W - 24;     // fine barra (216)
static constexpr int16_t SLD_W  = SLD_X1 - SLD_X0;    // larghezza utile (192)

// --- Geometria verticale (v2.16.1, ricalcolata dopo la prova sul campo) -----
// I pulsanti INDIETRO/OK erano alti 90px: sproporzionati, mangiavano meta'
// schermo per due azioni che si fanno una volta per tiro. Dimezzati a 45px.
// I ~45px recuperati NON vanno in spazio vuoto: si redistribuiscono in
//   [1] separazione fra i due slider: 66 -> 79px fra gli assi. Due slider
//       vicini si toccano per sbaglio l'uno con l'altro; e' l'errore piu'
//       costoso qui, perche' silenzioso (sposti la distanza credendo di
//       spostare l'elevazione e te ne accorgi solo dal riepilogo).
//   [2] fascia tattile degli slider: +-14 -> +-16px (32px di bersaglio).
//   [3] BTN_GUARD: una zona morta di 12px sopra i pulsanti. Il tasto OK
//       CEMENTA lo score: un tap che scivola di 3px dal "+" non deve finirci
//       dentro. Meglio un tocco perso che uno score sbagliato.
static constexpr int16_t BTN_H     = 45;               // altezza INDIETRO/OK (era 90)
static constexpr int16_t BTN_TOP   = DISPLAY_H - BTN_H;   // 235
static constexpr int16_t BTN_GUARD = 12;               // zona morta di rispetto
static constexpr int16_t KEY_H     = 32;               // altezza tasti -/?/+
static constexpr int16_t KEY_Y     = BTN_TOP - BTN_GUARD - KEY_H;   // 191
// v2.16.10: anche le X dei tasti diventano costanti CONDIVISE fra disegno e
// handler. Erano letterali duplicati nei due punti: e' esattamente il modo in
// cui la fascia Y e' divergita (il disegno a 191, l'handler fermo a 150..180)
// e ha prodotto il bug "+ risponde OK". Coincidevano, ma per fortuna, non per
// costruzione. Una sola fonte, e la fortuna non serve piu'.
static constexpr int16_t KEY_MINUS_X0 = 16;
static constexpr int16_t KEY_MINUS_X1 = 64;
static constexpr int16_t KEY_IGN_X0   = DISPLAY_W/2 - 28;
static constexpr int16_t KEY_IGN_X1   = DISPLAY_W/2 + 28;
static constexpr int16_t KEY_PLUS_X0  = DISPLAY_W - 64;
static constexpr int16_t KEY_PLUS_X1  = DISPLAY_W - 16;

static constexpr int16_t SLD_Y_DIST = 69;
static constexpr int16_t SLD_Y_ELEV = 148;
static constexpr int16_t SLD_HIT    = 16;   // semi-altezza fascia tattile

// --- v2.16: quale slider ricevera' i tasti +/- ------------------------------
// I +/- sono contestuali: agiscono sull'ultimo slider toccato. Il focus e'
// mostrato dal bordo colorato del tasto, cosi' la regola si impara al primo uso
// invece che da un manuale.
enum SliderFocus : uint8_t { FOCUS_DIST = 0, FOCUS_ELEV = 1 };
static SliderFocus s_focus = FOCUS_DIST;

// --- mappa distanza <-> x ---------------------------------------------------
// v2.16 — CORREZIONE DI UN BUG PREESISTENTE (arrotondamento).
//   La barra e' larga 192px per 56 valori: 3.43 px/m. Le versioni <= 2.15
//   TRONCAVANO in entrambe le direzioni (divisione intera C), e i due
//   troncamenti si SOMMANO invece di annullarsi: il round-trip
//   distanza -> x -> distanza sbagliava su gran parte del range. Effetto sul
//   campo: premi "+" da 20 a 21, la tacca si muove, ma se poi tocchi la tacca
//   rileggi 20. Sintomo classico "lo slider scatta indietro da solo".
//   Fix: arrotondamento al PIU' VICINO (+meta' divisore prima di dividere) in
//   entrambe le mappe. Verificato: round-trip esatto su tutti i 56 valori.
static int16_t distToX(uint8_t d) {
    if (d < DIST_MIN) d = DIST_MIN; if (d > DIST_MAX) d = DIST_MAX;
    return SLD_X0 + (int16_t)(((int32_t)(d - DIST_MIN) * SLD_W
                               + (DIST_MAX - DIST_MIN) / 2) / (DIST_MAX - DIST_MIN));
}
static uint8_t xToDist(int16_t x) {
    if (x < SLD_X0) x = SLD_X0; if (x > SLD_X1) x = SLD_X1;
    int v = DIST_MIN + (int)(((int32_t)(x - SLD_X0) * (DIST_MAX - DIST_MIN)
                              + SLD_W / 2) / SLD_W);
    if (v < DIST_MIN) v = DIST_MIN; if (v > DIST_MAX) v = DIST_MAX;
    return (uint8_t)v;
}

// --- mappa elevazione <-> x (v2.16) -----------------------------------------
// Range simmetrico ELEV_MIN..ELEV_MAX con lo ZERO al centro esatto della barra.
// La sentinella ELEV_NOT_SET non ha una posizione: si disegna a 0 (default
// fisico) ma il valore resta "non impostato" finche' l'arciere non tocca.
static constexpr int16_t ELEV_X_ZERO = SLD_X0 + SLD_W / 2;   // 120

// Arrotondamento al PIU' VICINO in entrambe le direzioni: vedi la nota su
// distToX. Qui la densita' e' 3.15 px/grado, quindi il problema sarebbe stato
// anche peggiore: senza il fix, -2 non era nemmeno raggiungibile toccando la
// propria tacca (il round-trip lo mandava a -3, fuori dalla banda di snap).
static int16_t elevToX(int8_t e) {
    if (!elevIsSet(e)) e = 0;
    if (e < ELEV_MIN) e = ELEV_MIN; if (e > ELEV_MAX) e = ELEV_MAX;
    return SLD_X0 + (int16_t)(((int32_t)(e - ELEV_MIN) * SLD_W
                               + (ELEV_MAX - ELEV_MIN) / 2) / (ELEV_MAX - ELEV_MIN));
}
static int8_t xToElev(int16_t x) {
    if (x < SLD_X0) x = SLD_X0; if (x > SLD_X1) x = SLD_X1;
    int v = ELEV_MIN + (int)(((int32_t)(x - SLD_X0) * (ELEV_MAX - ELEV_MIN)
                              + SLD_W / 2) / SLD_W);
    if (v < ELEV_MIN) v = ELEV_MIN; if (v > ELEV_MAX) v = ELEV_MAX;
    // SNAP A ZERO (+-2 gradi): il tiro in piano e' il caso piu' frequente e deve
    // essere raggiungibile senza mira. Senza snap, un tap impreciso produrrebbe
    // +1 o -1 spuri: rumore che nel gesto reale non esiste, ma che finirebbe nel
    // CSV indistinguibile da una misura vera.
    if (v >= -2 && v <= 2) v = 0;
    return (int8_t)v;
}

// --- Helper: disegna un binario slider con la porzione attiva e la tacca -----
// Fattorizzato perche' i due slider differiscono solo per dove parte la porzione
// attiva: la distanza riempie da SINISTRA (grandezza monopolare, "quanto"),
// l'elevazione riempie DALLO ZERO CENTRALE (grandezza bipolare, "da che parte").
// Rendere questa differenza VISIBILE e' il punto: la barra comunica la natura
// della grandezza prima ancora che si legga il numero.
static void drawSliderTrack(TFT_eSprite& s, int16_t yAxis, int16_t xFrom,
                            int16_t xTo, uint16_t col, bool showKnob) {
    // binario grigio a tutta larghezza
    s.fillRoundRect(SLD_X0, yAxis - 3, SLD_W, 6, 3, COL_DARKGRAY);
    if (!showKnob) return;
    // porzione attiva: da xFrom a xTo (in qualunque ordine)
    int16_t a = (xFrom < xTo) ? xFrom : xTo;
    int16_t b = (xFrom < xTo) ? xTo   : xFrom;
    if (b > a) s.fillRoundRect(a, yAxis - 3, b - a, 6, 3, col);
    // tacca: cerchio pieno con foro (anello spesso, ben visibile col sole)
    s.fillCircle(xTo, yAxis, 10, col);
    s.fillCircle(xTo, yAxis, 5, COL_BG);
}

// =============================================================================
// GHOST DEL TOCCO (v2.16.1) — feedback visivo sotto il dito
// =============================================================================
// COSA FA
//   [a] ghost LIVE: un anello che segue il dito mentre e' premuto;
//   [b] cerchietto al RILASCIO: resta ~600ms dove hai staccato;
//   [c] COLORE = diagnosi: verde/ciano/ambra se il tocco cade in una zona
//       ATTIVA (e quale), ROSSO se cade in una zona morta.
//
// PERCHE' IL ROSSO E' LA PARTE IMPORTANTE
//   Non e' un vezzo estetico: e' uno STRUMENTO DI TARATURA. Le soglie touch
//   e le fasce Y sono calibrate, ma il CST816 puo'
//   derivare (temperatura, pellicola, guanto). Se tocchi lo slider e vedi
//   ROSSO, non hai sbagliato mira tu: e' il chip che riporta un'altra
//   coordinata. Senza feedback quel disallineamento e' invisibile e si
//   manifesta solo come "a volte non risponde" — la diagnosi piu' difficile da
//   fare a posteriori. Col ghost, il display DICE dove crede che sia il dito.
//
// PERCHE' UN REDRAW PARZIALE E NON s_need_redraw
//   Il display_task gira a 80ms (12.5Hz) e il modello di rendering ridisegna
//   SOLO al cambio di stato: e' il motivo per cui non c'e' flicker. Un ghost
//   che segue il dito deve invece aggiornarsi a ogni movimento — l'opposto.
//   Ridisegnare tutta la schermata (200+ primitive + pushSprite 240x280 via
//   SPI) a ogni giro sarebbe sia lento sia inutile. Qui si ridisegna solo il
//   RETTANGOLO attorno al ghost, e si ripristina il precedente cancellandolo
//   con lo stesso metodo. Costo: 2 push da ~44x44 invece di uno da 240x280,
//   cioe' ~1/37 dei pixel.
static constexpr int16_t GHOST_R      = 16;    // raggio anello
static constexpr uint32_t GHOST_HOLD_MS = 600; // durata cerchietto post-rilascio

// Ultima posizione disegnata (per cancellare il ghost precedente).
static int16_t  s_ghost_px = -1, s_ghost_py = -1;
// Cerchietto persistente al rilascio.
static int16_t  s_tapmark_x = -1, s_tapmark_y = -1;
static uint32_t s_tapmark_until = 0;

// Classifica un tocco: ritorna il colore della zona in cui cade, o COL_RED se
// la zona e' morta. E' l'UNICA fonte di verita' sul colore del ghost, e usa le
// STESSE costanti dell'handler: se le due divergessero, il ghost mentirebbe —
// che sarebbe peggio di non averlo.
static uint16_t ghostZoneColor(int16_t x, int16_t y) {
    if (y >= BTN_TOP)                       return (x >= DISPLAY_W/2) ? COL_GREEN : COL_GRAY;
    if (y >= KEY_Y && y <= KEY_Y + KEY_H) {
        if (x >= KEY_MINUS_X0 && x <= KEY_MINUS_X1) return COL_CYAN;
        if (x >= KEY_PLUS_X0  && x <= KEY_PLUS_X1)  return COL_CYAN;
        if (x >= KEY_IGN_X0   && x <= KEY_IGN_X1)   return COL_AMBER;
        return COL_RED;                     // fra i tasti: zona morta
    }
    if (y >= SLD_Y_DIST - SLD_HIT && y <= SLD_Y_DIST + SLD_HIT &&
        x >= SLD_X0 - 8 && x <= SLD_X1 + 8) return COL_CYAN;
    if (y >= SLD_Y_ELEV - SLD_HIT && y <= SLD_Y_ELEV + SLD_HIT &&
        x >= SLD_X0 - 8 && x <= SLD_X1 + 8) return COL_AMBER;
    return COL_RED;                         // tutto il resto: zona morta
}

// COME SI DISEGNA — e perche' NON serve toccare display.cpp
//   Prima idea (scartata): disegnare il ghost direttamente sul TFT. Richiedeva
//   di rendere globale l'istanza 'tft', che in display.cpp e' static — cioe'
//   modificare un modulo collaudato per una feature di UI. Rifiutato: e'
//   esattamente l'accoppiamento che l'architettura a moduli separati previene.
//   (E non era nemmeno possibile: TFT_eSprite tiene il puntatore al TFT nel
//   membro _tft, che e' PRIVATE.)
//
//   Soluzione adottata: il ghost si disegna SULLO SPRITE, e si spinge a schermo
//   solo il rettangolo che lo contiene con la pushSprite "a finestra"
//     pushSprite(tx, ty, sx, sy, sw, sh)
//   che copia la sola regione (sx,sy,sw,sh) dello sprite. Lo sprite ci arriva
//   gia' come parametro: zero righe aggiunte a display.cpp.
//
//   Il rovescio della medaglia: disegnare sullo sprite SPORCA il buffer pulito.
//   Da qui ghostRestore(), che ridisegna la porzione originale prima di
//   spostare il ghost altrove. Serve quindi un modo per rigenerare un pezzo di
//   schermata senza rifarla tutta -> s_redraw_fn (vedi sotto).
//
//   Costo: 2 finestre da ~44x44 invece di un push da 240x280 = ~1/37 dei pixel.

static void paintDistanza(TFT_eSprite& s, uint8_t dist, int8_t elev);  // fwd: disegna, NON pusha

// Callback di ridisegno della schermata corrente sullo sprite. Impostata da
// drawDistanza(): permette a ghostRestore() di rigenerare la porzione coperta
// senza sapere COSA c'e' sotto. Se un domani il ghost servisse anche in altre
// schermate, basta che anche quelle la impostino.
static void (*s_redraw_fn)(TFT_eSprite&) = nullptr;

// Spinge a schermo la sola finestra attorno a (x,y), con clipping ai bordi.
static void ghostPushWindow(TFT_eSprite& spr, int16_t x, int16_t y) {
    if (x < 0) return;
    const int16_t r = GHOST_R + 3;
    int16_t x0 = x - r, y0 = y - r, w = 2*r, h = 2*r;
    if (x0 < 0) { w += x0; x0 = 0; }
    if (y0 < 0) { h += y0; y0 = 0; }
    if (x0 + w > DISPLAY_W) w = DISPLAY_W - x0;
    if (y0 + h > DISPLAY_H) h = DISPLAY_H - y0;
    if (w <= 0 || h <= 0) return;
    spr.pushSprite(x0, y0 + DISPLAY_Y_OFFSET, x0, y0, w, h);
}

// Ripristina la porzione di sprite coperta dal ghost precedente e la ri-spinge.
static void ghostRestore(TFT_eSprite& spr, int16_t x, int16_t y) {
    if (x < 0 || !s_redraw_fn) return;
    s_redraw_fn(spr);              // rigenera lo sprite pulito (in RAM: non si vede)
    ghostPushWindow(spr, x, y);    // ...e ne spinge a schermo solo il pezzo sporco
}

static void ghostDraw(TFT_eSprite& spr, int16_t x, int16_t y, uint16_t col, bool filled) {
    if (x < 0) return;
    spr.drawCircle(x, y, GHOST_R,     col);
    spr.drawCircle(x, y, GHOST_R - 1, col);
    if (filled) spr.fillCircle(x, y, 4, col);
    else {
        // crosshair: dice il punto ESATTO, che l'anello da solo non da'
        spr.drawFastHLine(x - 5, y, 11, col);
        spr.drawFastVLine(x, y - 5, 11, col);
    }
    ghostPushWindow(spr, x, y);
}

// Chiamata a ogni giro dello scoring: gestisce ghost live + cerchietto.
static void ghostTick(TFT_eSprite& spr) {
    int16_t want_x = -1, want_y = -1;
    bool    filled = false;

    if (tp_live_down) {                       // [a] dito giu': ghost live
        want_x = (int16_t)tp_live_x; want_y = (int16_t)tp_live_y;
    } else if (millis() < s_tapmark_until) {  // [b] appena rilasciato: cerchietto
        want_x = s_tapmark_x; want_y = s_tapmark_y; filled = true;
    }

    if (want_x == s_ghost_px && want_y == s_ghost_py) return;   // niente da fare
    ghostRestore(spr, s_ghost_px, s_ghost_py);                  // via il vecchio
    if (want_x >= 0) ghostDraw(spr, want_x, want_y,
                               ghostZoneColor(want_x, want_y), filled);
    s_ghost_px = want_x; s_ghost_py = want_y;
}

// Azzera il ghost: da chiamare a ogni cambio schermata (lo sprite viene
// ripushato per intero, quindi non c'e' nulla da cancellare).
static void ghostReset() {
    s_ghost_px = s_ghost_py = -1;
    s_tapmark_until = 0;
}

// --- Schermata 3 (v2.16.1): DISTANZA + ELEVAZIONE, due slider ---------------
// Layout (coordinate sprite, display 240x280):
//   y   0.. 20  breadcrumb (esito > zona)
//   y  22.. 85  slider DISTANZA    (label+valore ~y30-50, asse y=69, scala y~80)
//   y  95.. 97  divisore
//   y 100..164  slider ELEVAZIONE  (label+valore ~y110-130, asse y=148, scala y~159)
//   y 191..223  tasti  -  /  ?  /  +
//   y 223..235  ZONA MORTA di rispetto (BTN_GUARD)
//   y 235..280  INDIETRO (sx) / OK (dx)   <- 45px, meta' dei 90 di prima
static void paintDistanza(TFT_eSprite& s, uint8_t dist, int8_t elev) {
    s.fillSprite(COL_BG);

    // breadcrumb (esito > zona)
    drawBreadcrumb(s, 1);

    s.setTextDatum(MC_DATUM);
    const bool ignota   = (dist == 0);
    const bool elev_set = elevIsSet(elev);
    // Valore da DISEGNARE per l'elevazione: se non impostata mostriamo 0 (il
    // default fisico: tiro in piano), ma in grigio invece che in ambra. Cosi'
    // "non toccato" e "toccato e messo a zero" restano distinguibili a colpo
    // d'occhio pur senza costringere l'arciere a un tocco in piu' sul caso piu'
    // frequente. Il valore TRASMESSO resta la sentinella finche' non tocca.
    const int8_t elev_shown = elev_set ? elev : 0;

    // ================= SLIDER 1: DISTANZA =================
    s.setTextDatum(TL_DATUM);
    s.setTextColor(s_focus == FOCUS_DIST ? COL_CYAN : COL_GRAY, COL_BG);
    s.drawString("DISTANZA", 12, 30, 2);
    s.setTextDatum(MC_DATUM);
    if (ignota) {
        s.setTextColor(COL_AMBER, COL_BG);
        s.drawString("IGN", 170, 40, 4);
    } else {
        s.setTextColor(COL_CYAN, COL_BG);
        char buf[8]; snprintf(buf, sizeof(buf), "%d", dist);
        s.drawString(buf, 165, 40, 6);
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("m", 200, 46, 2);
    }
    // binario: la distanza riempie da SINISTRA (monopolare)
    drawSliderTrack(s, SLD_Y_DIST, SLD_X0, distToX(dist), COL_CYAN, !ignota);
    s.setTextColor(COL_GRAY, COL_BG);
    s.setTextDatum(TL_DATUM);
    char lo[4]; snprintf(lo, sizeof(lo), "%d", DIST_MIN);
    s.drawString(lo, SLD_X0 - 4, SLD_Y_DIST + 10, 1);
    s.setTextDatum(TR_DATUM);
    char hi[4]; snprintf(hi, sizeof(hi), "%d", DIST_MAX);
    s.drawString(hi, SLD_X1 + 4, SLD_Y_DIST + 10, 1);
    s.setTextDatum(MC_DATUM);

    // divisore fra i due slider (ora ben staccati: 79px fra gli assi)
    s.drawFastHLine(12, 96, DISPLAY_W - 24, COL_DARKGRAY);

    // ================= SLIDER 2: ELEVAZIONE =================
    s.setTextDatum(TL_DATUM);
    s.setTextColor(s_focus == FOCUS_ELEV ? COL_AMBER : COL_GRAY, COL_BG);
    s.drawString("ELEVAZIONE", 12, 108, 2);
    s.setTextDatum(MC_DATUM);
    {
        // Il segno e' parte del dato, non un ornamento: "+12" e "-12" sono due
        // tiri opposti. Font 4 e NON font 6: il font 6 di TFT_eSPI e' numerico e
        // NON ha il glifo '+' (lezione gia' pagata, vedi intestazione §7).
        char buf[8]; snprintf(buf, sizeof(buf), "%+d", elev_shown);
        s.setTextColor(elev_set ? COL_AMBER : COL_GRAY, COL_BG);
        s.drawString(buf, 168, 118, 4);
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("o", 200, 112, 2);   // 'o' come simbolo di grado (font 2)
    }
    // binario: l'elevazione riempie DALLO ZERO CENTRALE (bipolare)
    drawSliderTrack(s, SLD_Y_ELEV, ELEV_X_ZERO, elevToX(elev_shown),
                    elev_set ? COL_AMBER : COL_DARKGRAY, true);
    // tacca dello ZERO: marcata SEMPRE, anche sotto la porzione attiva. Il tiro
    // in piano e' il caso piu' frequente: deve avere un riferimento visivo fisso.
    s.drawFastVLine(ELEV_X_ZERO, SLD_Y_ELEV - 9, 18, COL_GRAY);
    s.setTextColor(COL_GRAY, COL_BG);
    s.setTextDatum(TL_DATUM);
    s.drawString("-30", SLD_X0 - 6, SLD_Y_ELEV + 10, 1);
    s.setTextDatum(TC_DATUM);
    s.drawString("0", ELEV_X_ZERO, SLD_Y_ELEV + 10, 1);
    s.setTextDatum(TR_DATUM);
    s.drawString("+30", SLD_X1 + 6, SLD_Y_ELEV + 10, 1);
    s.setTextDatum(MC_DATUM);

    // ================= TASTI  -  /  ?  /  + =================
    // I +/- sono CONTESTUALI (agiscono sullo slider col focus). Il colore del
    // bordo dice su cosa agiranno: ciano = distanza, ambra = elevazione.
    const uint16_t fcol = (s_focus == FOCUS_DIST) ? COL_CYAN : COL_AMBER;
    const uint16_t fdim = (s_focus == FOCUS_DIST) ? COL_CYAN_DIM : COL_AMBER_DIM;
    // "-"
    s.fillRect(KEY_MINUS_X0, KEY_Y, KEY_MINUS_X1-KEY_MINUS_X0, KEY_H, fdim);
    s.drawRect(KEY_MINUS_X0, KEY_Y, KEY_MINUS_X1-KEY_MINUS_X0, KEY_H, fcol);
    { int16_t cx = (KEY_MINUS_X0+KEY_MINUS_X1)/2, cy = KEY_Y + KEY_H/2;
      s.fillRect(cx - 10, cy - 2, 20, 4, fcol); }
    // "+"
    s.fillRect(KEY_PLUS_X0, KEY_Y, KEY_PLUS_X1-KEY_PLUS_X0, KEY_H, fdim);
    s.drawRect(KEY_PLUS_X0, KEY_Y, KEY_PLUS_X1-KEY_PLUS_X0, KEY_H, fcol);
    { int16_t cx = (KEY_PLUS_X0+KEY_PLUS_X1)/2, cy = KEY_Y + KEY_H/2;
      s.fillRect(cx - 10, cy - 2, 20, 4, fcol);
      s.fillRect(cx - 2, cy - 10, 4, 20, fcol); }
    // "?" IGNOTA — agisce SOLO sulla distanza: l'elevazione non ne ha bisogno
    // (il suo default, "in piano", e' fisicamente sensato; "0 metri" non lo e').
    s.fillRect(KEY_IGN_X0, KEY_Y, KEY_IGN_X1-KEY_IGN_X0, KEY_H, ignota ? COL_AMBER_DIM : COL_BG);
    s.drawRect(KEY_IGN_X0, KEY_Y, KEY_IGN_X1-KEY_IGN_X0, KEY_H, COL_AMBER);
    s.setTextColor(COL_AMBER, ignota ? COL_AMBER_DIM : COL_BG);
    s.drawString("?", DISPLAY_W/2, KEY_Y + KEY_H/2, 4);

    // ================= INDIETRO (sx) / OK (dx) — 45px =================
    // Dimezzati (erano 90px): due azioni da una volta per tiro non meritano
    // meta' schermo. Restano discriminati per LATO (X), che e' cio' che li ha
    // sempre resi robusti — non l'altezza. 45px sono ~6mm: comodi anche col
    // guanto, e la zona morta sopra (BTN_GUARD) protegge dal tap che scivola.
    const int16_t midX = DISPLAY_W/2, gap = 4;
    s.fillRect(0, BTN_TOP, midX - gap, BTN_H, COL_BG);
    s.drawRect(0, BTN_TOP, midX - gap, BTN_H, COL_DARKGRAY);
    s.setTextColor(COL_GRAY, COL_BG);
    { int16_t ccx = 26, ccy = BTN_TOP + BTN_H/2;   // chevron piccolo a sinistra
      s.drawLine(ccx + 5, ccy - 8, ccx - 4, ccy, COL_GRAY);
      s.drawLine(ccx - 4, ccy, ccx + 5, ccy + 8, COL_GRAY); }
    s.drawString("INDIETRO", (midX - gap)/2 + 12, BTN_TOP + BTN_H/2, 2);
    s.fillRect(midX + gap, BTN_TOP, DISPLAY_W - (midX + gap), BTN_H, COL_GREEN);
    s.setTextColor(COL_BLACK, COL_GREEN);
    s.drawString("OK", midX + (DISPLAY_W - midX)/2, BTN_TOP + BTN_H/2, 4);

}

// Adattatore per s_redraw_fn: rigenera la schermata nel BUFFER leggendo i valori
// correnti dal ponte dati. Non prende parametri perche' ghostRestore() non puo'
// saperli: la fonte di verita' e' il ponte, non il chiamante.
static void redrawDistanzaToSprite(TFT_eSprite& spr) {
    paintDistanza(spr, g_pending_score.distanza_m, g_pending_score.elev_deg);
}

// Disegna E manda a schermo (schermata intera). E' quella che chiama la macchina
// a stati quando cambia qualcosa.
//
// PERCHE' PAINT E PUSH SONO SEPARATE
//   ghostRestore() deve rigenerare lo sprite pulito per cancellare il ghost, ma
//   NON deve mandarlo a schermo intero: se lo facesse, ogni movimento del dito
//   ridisegnerebbe 240x280px e il redraw parziale non servirebbe a niente (anzi:
//   flicker garantito a 12Hz). Separando le due fasi, ghostRestore ridipinge in
//   RAM e spinge a schermo la sola finestra sporca.
static void drawDistanza(TFT_eSprite& s, uint8_t dist, int8_t elev) {
    paintDistanza(s, dist, elev);
    s.pushSprite(0, DISPLAY_Y_OFFSET);
    s_redraw_fn = redrawDistanzaToSprite;   // da ora il ghost sa come ripulire
    ghostReset();   // schermata ripushata per intero: nessun ghost da cancellare
}

// --- Schermata 4 (NUOVA §1): RIEPILOGO — punto di controllo esplicito --------
// Mostra l'esito completo (colpito/mancato, zona, distanza, ARCS) e offre DUE
// sole azioni: OK (cementa e invia lo ScorePacket) e ‹ CORREGGI (riapre lo
// stesso tiro senza inviare nulla). Un tocco FUORI dai due pulsanti è ignorato:
// è questo che impedisce di cementare uno score per un tocco distratto.
//
// ARCS = ±(distanza*10 + (zona+1)), identico all'encoding app/1.83.
static int16_t arcsFromScore(bool colpito, uint8_t zona, uint8_t dist) {
    int16_t mag = (int16_t)dist * 10 + (zona + 1);   // zona+1 in [1..9]
    return colpito ? mag : -mag;
}

static void drawRiepilogo(TFT_eSprite& s) {
    bool colpito  = g_pending_score.colpito;
    uint8_t zona  = g_pending_score.zona;
    uint8_t dist  = g_pending_score.distanza_m;
    uint16_t esCol = colpito ? COL_GREEN : COL_RED;

    s.fillSprite(COL_BG);
    s.setTextDatum(MC_DATUM);

    // Intestazione
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("RIEPILOGO", DISPLAY_W/2, 12, 2);
    s.drawFastHLine(0, 24, DISPLAY_W, COL_DARKGRAY);

    // Esito grande
    s.setTextColor(esCol, COL_BG);
    s.drawString(colpito ? "COLPITO" : "MANCATO", DISPLAY_W/2, 52, 4);

    // Zona e distanza
    char line[40];
    s.setTextColor(COL_WHITE, COL_BG);
    snprintf(line, sizeof(line), "zona: %s", zoneLabel(colpito, zona));
    s.drawString(line, DISPLAY_W/2, 84, 2);
    if (dist == 0) snprintf(line, sizeof(line), "distanza: ignota");
    else           snprintf(line, sizeof(line), "distanza: %d m", dist);
    s.drawString(line, DISPLAY_W/2, 106, 2);

    // v2.16: elevazione. Il riepilogo e' il punto di controllo: se il dato NON
    // e' stato impostato deve DIRLO, non far finta che sia 0. Un "0" muto qui
    // sarebbe indistinguibile da un tiro in piano vero — e visto che il dato non
    // e' ricostruibile a posteriori (viene dal telemetro, non dall'IMU), l'unico
    // momento per accorgersi che manca e' ORA, prima dell'OK.
    int8_t elev = g_pending_score.elev_deg;
    if (!elevIsSet(elev)) {
        s.setTextColor(COL_GRAY, COL_BG);
        snprintf(line, sizeof(line), "elevazione: non impostata");
    } else {
        s.setTextColor(elev == 0 ? COL_WHITE : COL_AMBER, COL_BG);
        snprintf(line, sizeof(line), "elevazione: %+d gradi", (int)elev);
    }
    s.drawString(line, DISPLAY_W/2, 126, 2);
    s.setTextColor(COL_WHITE, COL_BG);

    // ARCS (intero-singolo che andrà nel CSV)
    s.setTextColor(COL_AMBER, COL_BG);
    snprintf(line, sizeof(line), "ARCS %d", arcsFromScore(colpito, zona, dist));
    s.drawString(line, DISPLAY_W/2, 148, 2);

    // --- Zona pulsanti: DUE QUADRONI AFFIANCATI che riempiono la fascia bassa --
    // Scelta di design: la discriminazione del tocco avviene sul LATO (X: sx vs
    // dx), non su una banda Y stretta. Così il tap può cadere ovunque nella metà
    // inferiore dello schermo — conta solo da che parte. È lo stesso principio
    // robusto della schermata esito (semicampo sx/dx), che non ha mai dato noie.
    // Altezza tattile ~126px per pulsante contro i 52 del vecchio OK a barra.
    // v2.16: btnTop 144 -> 166: la riga elevazione ha preso spazio in alto.
    // 104px di altezza tattile restano abbondanti (il vecchio OK a barra ne
    // aveva 52 ed era il problema che questo layout ha risolto).
    const int16_t btnTop = 166, btnBot = 270;   // fascia pulsanti nello sprite
    const int16_t btnH   = btnBot - btnTop;      // 104px
    const int16_t midX   = DISPLAY_W / 2;        // confine sx|dx = 120
    const int16_t gap    = 4;                    // fessura centrale

    // Sinistra: CORREGGI (ambra desaturata, bordo ambra, chevron '‹' grande)
    s.fillRect(0, btnTop, midX - gap, btnH, COL_AMBER_DIM);
    s.drawRect(0, btnTop, midX - gap, btnH, COL_AMBER);
    {
        int16_t ccx = (midX - gap) / 2, ccy = btnTop + btnH/2 - 12;
        int16_t r = 18;   // chevron '‹' geometrico grande
        s.drawLine(ccx + r/2, ccy - r, ccx - r/2, ccy,     COL_AMBER);
        s.drawLine(ccx - r/2, ccy,     ccx + r/2, ccy + r, COL_AMBER);
    }
    s.setTextColor(COL_AMBER, COL_AMBER_DIM);
    s.drawString("CORREGGI", (midX - gap)/2, btnTop + btnH/2 + 24, 2);

    // Destra: OK (verde pieno, nero sopra, font 4). L'UNICA azione che cementa.
    // NB: font 4, NON font 6 (font 6 è solo numerico: 'O'/'K' non esistono).
    s.fillRect(midX + gap, btnTop, DISPLAY_W - (midX + gap), btnH, COL_GREEN);
    s.setTextColor(COL_BLACK, COL_GREEN);
    s.drawString("OK", midX + (DISPLAY_W - midX)/2, btnTop + btnH/2, 4);

    // Niente barra SKIP qui: a valutazione conclusa le uscite sono OK o CORREGGI.
    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// =============================================================================
// [4] SOTTO-MACCHINA A STATI DELLO SCORING
// =============================================================================
enum ScoringPhase : uint8_t {
    SC_ESITO = 0,   // schermata 1
    SC_ZONA,        // schermata 2
    SC_DISTANZA,    // schermata 3
    SC_RIEPILOGO,   // schermata 4 (NUOVA §1): punto di controllo esplicito
    SC_DONE         // concluso (transizione in uscita)
};

static ScoringPhase s_phase       = SC_ESITO;
static bool         s_entered     = false;   // per inizializzare all'ingresso
static uint32_t     s_last_touch_ms = 0;     // per il timeout: si resetta a ogni tocco
static uint32_t     s_cooldown_until_ms = 0; // §2: fino a quando ignorare i tap
static bool         s_need_redraw = true;
static uint8_t      s_last_distance = 18;    // ultima distanza usata (default)
// v2.16: NON esiste un "s_last_elev". Scelta deliberata, ed e' l'opposto di
// quella fatta per la distanza. Perche':
//   - la distanza cambia poco fra tiri consecutivi (stessa piazzola, stessa
//     paglia): riproporre l'ultima fa risparmiare tocchi ed e' quasi sempre
//     giusta;
//   - l'elevazione e' una proprieta' del SINGOLO bersaglio. Riproporre i +12
//     del bersaglio precedente su un bersaglio nuovo significherebbe scrivere
//     nel CSV una misura mai fatta, indistinguibile da una vera. Meglio un
//     tocco in piu' che un dato inventato: i dati comandano.
// Ogni tiro riparte quindi da ELEV_NOT_SET.

static inline void touchCooldown() { s_cooldown_until_ms = millis() + TOUCH_COOLDOWN_MS; }
static inline bool inCooldown()    { return millis() < s_cooldown_until_ms; }

// Ingresso "pulito": azzera i campi di esito. Usato quando arriva un tiro NUOVO.
static void scoringEnter() {
    s_phase = SC_ESITO;
    s_last_touch_ms = millis();
    s_cooldown_until_ms = 0;
    s_need_redraw = true;
    tpResetTap();   // il primo tap deve seguire un rilascio pulito
    g_pending_score.valutato   = false;
    g_pending_score.colpito    = false;
    g_pending_score.zona       = 0;
    g_pending_score.distanza_m = 0;
    g_pending_score.elev_deg   = ELEV_NOT_SET;   // v2.16: mai ereditata dal tiro prima
    s_focus = FOCUS_DIST;   // il focus riparte sempre dalla distanza
}

// §1 Ripresa dal RIEPILOGO (CORREGGI): riapre lo STESSO tiro SENZA azzerare i
// valori. colpito/zona/distanza restano il punto di partenza, si riparte da
// esito. Non tocca shot_id né angoli (già nel ponte) e NON invia nulla: lo
// ScorePacket partirà solo con l'OK.
static void scoringResume() {
    s_phase = SC_ESITO;
    s_last_touch_ms = millis();
    touchCooldown();          // evita che il tap su CORREGGI conti anche su ESITO
    tpResetTap();             // e attende un rilascio pulito prima del prossimo tap
    s_need_redraw = true;
    // NB: g_pending_score.colpito/zona/distanza_m NON toccati -> valori conservati.
}

// Conclude lo scoring: invia il pacchetto e torna a CONNECTED/RECORDING.
static void scoringFinish(bool valutato) {
    s_redraw_fn = nullptr;   // v2.16.1: la schermata non esiste piu'
    g_pending_score.valutato = valutato;
    if (valutato) {
        if (g_pending_score.distanza_m >= 5) s_last_distance = g_pending_score.distanza_m;
    }
    g_pending_score.ready = false;
    ble_send_score();
    // Ripristina lo stato coerente con la modalita' reale.
    g_device_state = g_recording_enabled ? STATE_RECORDING : STATE_CONNECTED;
    s_entered = false;   // cosi' al prossimo ingresso si reinizializza
}

bool scoring_ui_tick(TFT_eSprite& sprite) {
    // Ingresso: inizializza una volta (tiro NUOVO -> partenza pulita).
    if (!s_entered) {
        s_entered = true;
        scoringEnter();
    }

    // Timeout di sicurezza: si misura dall'ULTIMO TOCCO, non dall'ingresso.
    if (millis() - s_last_touch_ms > SCORING_TIMEOUT_MS) {
        scoringFinish(false);
        return false;
    }

    // Redraw solo quando serve (evita flicker e spreco).
    if (s_need_redraw) {
        switch (s_phase) {
            case SC_ESITO:     drawEsito(sprite); break;
            case SC_ZONA:      drawZona(sprite, g_pending_score.colpito, -1); break;
            case SC_DISTANZA:  drawDistanza(sprite, g_pending_score.distanza_m,
                                            g_pending_score.elev_deg); break;
            case SC_RIEPILOGO: drawRiepilogo(sprite); break;
            default: break;
        }
        s_need_redraw = false;
    }

    // §2 COOLDOWN: leggiamo comunque il touch (per non lasciare "seen" appeso nel
    // driver) ma NON agiamo finché il cooldown è attivo.
    uint16_t tx, ty;
    bool tap = tpTapReleased(tx, ty);

    // v2.16.1: ghost del tocco. Solo in SC_DISTANZA — e' li' che serve (due
    // slider vicini + tasti piccoli). Le altre schermate hanno bersagli enormi
    // (semicampi, quadroni) e il ghost sarebbe rumore visivo senza scopo.
    // NB: sta PRIMA del check di cooldown, apposta. Durante il cooldown il tocco
    // non agisce ma il dito e' li': se il ghost sparisse, sembrerebbe che il
    // display si sia piantato proprio nel momento in cui l'utente insiste.
    if (s_phase == SC_DISTANZA) {
        if (tap) {   // registra il punto di rilascio per il cerchietto persistente
            s_tapmark_x = (int16_t)tx; s_tapmark_y = (int16_t)ty;
            s_tapmark_until = millis() + GHOST_HOLD_MS;
        }
        ghostTick(sprite);
    }

    if (inCooldown()) return true;
    if (!tap) return true;

    // Un tocco valido: resetta il timeout e apre un nuovo cooldown.
    s_last_touch_ms = millis();
    touchCooldown();

    // Fascia inferiore SKIP/INDIETRO su ESITO/ZONA. RIEPILOGO e DISTANZA hanno i
    // propri tasti verticali a tutta altezza e gestiscono i tap nel loro case.
    if (s_phase != SC_RIEPILOGO && s_phase != SC_DISTANZA && ty >= 248) {
        // In ESITO la fascia è tutta SKIP; in ZONA la parte sinistra (x < 82) è
        // INDIETRO, il resto è SKIP.
        if (s_phase != SC_ESITO && tx < 82) {
            s_phase = SC_ESITO;   // da ZONA si torna a ESITO
            s_need_redraw = true;
            tpResetTap();
            return true;
        }
        scoringFinish(false);   // SKIP immediato (non passa dal riepilogo)
        return false;
    }

    switch (s_phase) {
        case SC_ESITO: {
            // v2.14: la fascia alta e' la banda HOLD (informativa, non tattile).
            // Un tocco li' non deve scegliere l'esito: senza questo vincolo il
            // dito appoggiato sul valore di hold registrerebbe MANCATO/COLPITO
            // in base alla sola X, che e' esattamente il tipo di tocco
            // accidentale che il riepilogo serve a prevenire.
            if (ty <= HOLD_BAND_H) break;
            g_pending_score.colpito = (tx > (DISPLAY_W / 2));
            s_phase = SC_ZONA;
            s_need_redraw = true;
            tpResetTap();
            break;
        }
        case SC_ZONA: {
            uint8_t z = tpZoneFromRaw(tx, ty);
            if (!g_pending_score.colpito && z == 4) break;   // centro disabilitato nel mancato
            g_pending_score.zona = z;
            // feedback: ridisegna con la cella selezionata (il cooldown già armato
            // copre il rimbalzo del rilascio; niente delay bloccante).
            drawZona(sprite, g_pending_score.colpito, (int8_t)z);
            g_pending_score.distanza_m = s_last_distance;   // default = ultima usata
            s_phase = SC_DISTANZA;
            s_need_redraw = true;
            tpResetTap();
            break;
        }
        case SC_DISTANZA: {
            // =================================================================
            // v2.16.10 — BUG CORRETTO: l'handler aveva le costanti della v2.16.0
            // =================================================================
            // In v2.16.1 i pulsanti sono stati dimezzati (BTN_TOP 190 -> 235) e i
            // tasti +/-/? spostati (KEY_Y -> 191). Ho aggiornato il DISEGNO ma
            // NON questo handler, rimasto con i numeri vecchi scritti a mano:
            //     if (ty >= 190)          <- OK/INDIETRO, ma i tasti sono a 191!
            //     if (ty >= 150 && ty <= 180)  <- la vecchia fascia dei +/-
            //
            // Effetto: si tocca il "+" (disegnato a y 191..223), l'handler legge
            // y=209, valuta 209 >= 190 ed esegue OK. Il "-" a sinistra -> INDIETRO.
            // ESATTAMENTE il sintomo riportato dal campo, dalla 2.16.1 in poi.
            //
            // Il touch non c'entrava NIENTE: DIAG ha confermato che le coordinate
            // sono giuste (letture 36,207 / 112,208 / 205,209 = tutte dentro le
            // fasce corrette). Ho passato otto versioni a calibrare un sensore
            // che dopo la v2.16.9 era gia' a posto, mentre il bug era un numero
            // scritto a mano qui.
            //
            // LA CAUSA VERA: costanti DUPLICATE. Il disegno usava BTN_TOP/KEY_Y,
            // l'handler usava letterali. Due fonti per lo stesso fatto = una
            // certezza che prima o poi divergano. Ora l'handler usa le STESSE
            // costanti del disegno: non possono piu' separarsi, e spostare un
            // tasto e' una modifica sola.
            uint8_t d = g_pending_score.distanza_m;
            int8_t  e = g_pending_score.elev_deg;

            // --- INDIETRO (sx) / OK (dx): fascia bassa, lato = azione ---
            if (ty >= BTN_TOP) {
                if (tx >= DISPLAY_W/2) {
                    // OK -> RIEPILOGO. NB: NON forziamo elev a 0 se non impostata.
                    // Il riepilogo la mostrera' come "non impostata": e' li' che
                    // l'arciere se ne accorge, finche' e' ancora in tempo.
                    g_pending_score.valutato = true;
                    s_phase = SC_RIEPILOGO;
                    s_need_redraw = true;
                    tpResetTap();
                } else {
                    // INDIETRO -> torna a ZONA
                    s_phase = SC_ZONA;
                    s_need_redraw = true;
                    tpResetTap();
                }
                break;
            }

            // --- Fascia tasti  -  /  ?  /  +  ---
            if (ty >= KEY_Y && ty <= KEY_Y + KEY_H) {
                if (tx >= KEY_MINUS_X0 && tx <= KEY_MINUS_X1) {
                    // "-" CONTESTUALE: il focus decide su cosa agisce.
                    if (s_focus == FOCUS_DIST) {
                        if (d == 0) d = DIST_MIN; else if (d > DIST_MIN) d--;
                    } else {
                        // Il primo tocco su +/- con elevazione non impostata la
                        // IMPOSTA (partendo da 0): toccare i tasti E' la
                        // dichiarazione di aver misurato.
                        if (!elevIsSet(e)) e = 0;
                        else if (e > ELEV_MIN) e--;
                    }
                } else if (tx >= KEY_PLUS_X0 && tx <= KEY_PLUS_X1) {
                    // "+" CONTESTUALE
                    if (s_focus == FOCUS_DIST) {
                        if (d == 0) d = DIST_MIN; else if (d < DIST_MAX) d++;
                    } else {
                        if (!elevIsSet(e)) e = 0;
                        else if (e < ELEV_MAX) e++;
                    }
                } else if (tx >= KEY_IGN_X0 && tx <= KEY_IGN_X1) {
                    // "?" IGNOTA: agisce SOLO sulla distanza, e porta il focus li'
                    // (se hai appena detto "non so la distanza", il prossimo +/-
                    // quasi certamente serve a correggere la distanza).
                    d = 0;
                    s_focus = FOCUS_DIST;
                }
            }
            // --- Tocco diretto sullo slider DISTANZA (y [41..69]) ---
            else if (ty >= SLD_Y_DIST - SLD_HIT && ty <= SLD_Y_DIST + SLD_HIT &&
                     tx >= SLD_X0 - 8 && tx <= SLD_X1 + 8) {
                d = xToDist(tx);
                s_focus = FOCUS_DIST;    // toccare uno slider gli da' il focus
            }
            // --- Tocco diretto sullo slider ELEVAZIONE (y [107..135]) ---
            else if (ty >= SLD_Y_ELEV - SLD_HIT && ty <= SLD_Y_ELEV + SLD_HIT &&
                     tx >= SLD_X0 - 8 && tx <= SLD_X1 + 8) {
                // Toccare lo slider IMPOSTA l'elevazione (anche se il valore
                // risultante e' 0): il tocco e' la dichiarazione "l'ho misurata".
                // E' proprio qui che "in piano" smette di essere "non lo so".
                e = xToElev(tx);
                s_focus = FOCUS_ELEV;
            }

            g_pending_score.distanza_m = d;
            g_pending_score.elev_deg   = e;
            s_need_redraw = true;
            break;
        }
        case SC_RIEPILOGO: {
            // Due QUADRONI affiancati che riempiono la fascia bassa. La
            // discriminazione è sul LATO (X), non su una banda Y stretta: molto
            // meno sensibile alla coordinata Y del tocco (stesso principio della
            // schermata esito). Fascia attiva: y >= 166 (sotto le info/ARCS).
            //   sinistra (tx <  120) = CORREGGI
            //   destra   (tx >= 120) = OK
            // --- TARATURA (temporaneo): stampa il raw del tap sul riepilogo.
            //     Da rimuovere una volta validato sul campo.
            DBG("RIEPILOGO tap raw tx=%u ty=%u (attivo se ty>=166; sx=CORREGGI dx=OK)", tx, ty);
            if (ty < 166) break;                 // tocco sulle info in alto: ignora
            if (tx >= DISPLAY_W / 2) {
                scoringFinish(true);   // OK (lato destro): unico invio ScorePacket
                return false;
            } else {
                scoringResume();       // CORREGGI (lato sinistro): riapre, no invio
            }
            break;
        }
        default: break;
    }
    return true;
}
