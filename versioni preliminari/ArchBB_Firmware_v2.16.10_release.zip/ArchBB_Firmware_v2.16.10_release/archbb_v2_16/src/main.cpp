// =============================================================================
// main.cpp — ArchBB Black Box v2.3
// =============================================================================
//
// CHANGELOG v2.3 rispetto a v2.2e:
//
// FIX 1 — Boot standalone senza USB/monitor seriale
//   PROBLEMA: delay(5000) bloccava il boot aspettando il CDC host.
//   Senza monitor collegato: backlight acceso, firmware bloccato, nessuna risposta.
//   SOLUZIONE: attesa CDC condizionale, max 1.5s. Se il monitor non arriva,
//   il boot prosegue comunque. Serial0 (UART hardware) logga sempre.
//
// FIX 2 — Shutdown con tasto PWR (GPIO35/GPIO36)
//   PROBLEMA: GPIO36 non era monitorato → impossibile spegnere senza staccare LiPo.
//   SOLUZIONE: loop() monitora GPIO36 con debounce. Pressione >= 2s → shutdown.
//   Display mostra barra di countdown durante la pressione.
//
// =============================================================================
// CIRCUITO DI SHUTDOWN — da schematico Waveshare ESP32-S3-Touch-LCD-1.69
// =============================================================================
//
//   VBAT ──R21(10K)──┬── gate Q5(AO3401, P-MOS)
//                    │
//                   T2(SS8050, NPN)
//                    │  base ── R22(1K) ── GPIO35 (SYS_EN)
//                    └─ emitter ── GND
//
//   Q5 source = VBAT
//   Q5 drain  = rail di alimentazione sistema (VBAT_SYS)
//
//   GPIO35 HIGH → T2 ON → gate Q5 portato a GND → Q5 conduce → sistema ON
//   GPIO35 LOW  → T2 OFF → R21 porta gate Q5 a VBAT → Q5 interdetto → sistema OFF
//
//   GPIO36 (SYS_OUT): partitore R20/R24 sul drain Q5 + tasto PWR fisico.
//   Va LOW quando il tasto PWR è premuto → segnale letto dall'ESP32.
//
//   NOTA IMPORTANTE su vTaskSuspendAll():
//   Non serve e non aiuta. GPIO35 viene scritto solo in setup() e perform_shutdown().
//   Nessun task tocca GPIO35 dopo il boot. La sequenza di shutdown è:
//     1. Salva NVS
//     2. Display "Arrivederci"
//     3. digitalWrite(GPIO_SYS_EN, LOW)
//   Il rail crolla, l'ESP32 si spegne. Semplice come nel clinometro.
//
//   PERCHÉ FALLIVA IN PRECEDENZA:
//   Il problema NON era nei task FreeRTOS che rimettevano GPIO35 HIGH.
//   Il problema era il delay(5000) nel boot: dopo lo spegnimento, alla
//   pressione successiva di PWR il sistema si avviava ma sembrava bloccato
//   (backlight acceso, nessuna risposta) perché aspettava il CDC host.
//   Fix CDC + Fix shutdown risolvono entrambi i sintomi.
//
// =============================================================================

#include <Arduino.h>
#include <Wire.h>
#include <Preferences.h>
#include <NimBLEDevice.h>
#include "config.h"
#include "imu.h"
#include "circular_buffer.h"
#include "trigger.h"
#include "ble_server.h"
#include "display.h"
#include "battery.h"
#include "power.h"
#include "mount.h"   // v2.9: orientamento di montaggio

// =============================================================================
// VARIABILI GLOBALI
// =============================================================================
static Config       g_config;
static Preferences  g_prefs;
static char         s_adv_name[16];
static TaskHandle_t h_imu     = nullptr;
static TaskHandle_t h_trigger = nullptr;
static TaskHandle_t h_ble     = nullptr;
static TaskHandle_t h_display = nullptr;

volatile bool g_shutdown = false;

// =============================================================================
// MACRO LOG DI BOOT
// Serial0 = UART hardware, sempre disponibile anche senza USB.
// Serial  = CDC USB, disponibile solo con monitor collegato.
// =============================================================================
#define BLOG(fmt, ...) do { \
    Serial0.printf("[BOOT] " fmt "\n", ##__VA_ARGS__); \
    Serial0.flush(); \
    if (Serial) { \
        Serial.printf("[BOOT] " fmt "\n", ##__VA_ARGS__); \
        Serial.flush(); \
    } \
} while(0)

// =============================================================================
// NVS
// =============================================================================
static bool nvs_load_config(Config& cfg) {
    g_prefs.begin("archbb", true);
    size_t len = g_prefs.getBytesLength("cfg");
    bool ok = false;
    if (len == sizeof(Config)) {
        Config tmp;
        g_prefs.getBytes("cfg", &tmp, sizeof(Config));
        bool chk_ok  = (tmp.checksum == config_calc_checksum(tmp));
        bool ver_ok  = (tmp.config_version == configDefaults().config_version);
        if (chk_ok && ver_ok) {
            cfg = tmp;
            ok  = true;
        } else {
            // Versione o checksum non corrispondono → ricarica defaults
            // Questo avviene automaticamente ad ogni aggiornamento firmware
            // che incrementa config_version in configDefaults()
        }
    }
    g_prefs.end();
    return ok;
}

static void nvs_save_config(const Config& cfg) {
    g_prefs.begin("archbb", false);
    Config tmp   = cfg;
    tmp.checksum = config_calc_checksum(tmp);
    g_prefs.putBytes("cfg", &tmp, sizeof(Config));
    g_prefs.end();
}

// =============================================================================
// PERFORM SHUTDOWN
// =============================================================================
// Chiamata da loop() dopo countdown 2s su GPIO36.
// Sequenza minima verificata dallo schematico:
//   GPIO35 LOW → T2 OFF → Q5 interdetto → VBAT_SYS crolla → ESP32 spento.
// Niente vTaskSuspendAll(), niente esp_deep_sleep_start().
// L'ESP32 si spegne fisicamente prima che qualsiasi task possa interferire
// perché il rail VCC3V3 collassa in pochi ms.
// =============================================================================
static void perform_shutdown() {
    Serial0.println("[PWR] perform_shutdown()");

    // 1. Salva config in NVS
    nvs_save_config(g_config);
    Serial0.println("[PWR] NVS salvato");

    // 2. Backlight off — feedback visivo immediato
    digitalWrite(TFT_BL, LOW);

    // 3. SYS_EN LOW → T2 OFF → Q5 interdetto → sistema spento
    //    Da questo punto l'ESP32 ha i ms contati prima che VCC3V3 crolli.
    //    Non eseguiamo altro codice deliberatamente.
    digitalWrite(GPIO_SYS_EN, LOW);

    // 4. Loop di sicurezza — raggiunto solo se alimentati da sola USB
    //    (senza LiPo il MOSFET Q5 non comanda nulla).
    //    In questo caso il dispositivo resta bloccato qui — comportamento corretto.
    while (true) { delay(100); }
}

// =============================================================================
// SETUP
// =============================================================================
void setup() {
    // SYS_EN HIGH: priorità assoluta — va fatto nei primissimi ms.
    // GPIO35 LOW = Q5 interdetto = sistema non alimentato da LiPo.
    // Se questa riga non viene eseguita subito, il sistema crolla.
    pinMode(GPIO_SYS_EN,  OUTPUT);
    digitalWrite(GPIO_SYS_EN, HIGH);

    // GPIO36: input con pullup interno.
    // Va LOW quando il tasto PWR fisico è premuto.
    // INPUT_PULLUP evita flottamento se la LiPo non è collegata.
    pinMode(GPIO_SYS_OUT, INPUT_PULLUP);

    // Backlight ON subito = feedback visivo "sono vivo"
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, HIGH);

    // Serial0 (UART hardware TX/RX fisici) — sempre disponibile
    Serial0.begin(115200);
    Serial0.println("\n[BOOT] ArchBB v" FW_VERSION_STR " — Serial0 OK");

    // Serial (CDC USB) — attesa CONDIZIONALE, max 1.5s
    // FIX v2.3: il boot NON si blocca ad aspettare il monitor USB.
    // Questo permette l'avvio autonomo standalone (solo LiPo, senza PC).
    Serial.begin(115200);

    // FIX v2.11: protezione RUNTIME contro il blocco USB CDC.
    // Con ARDUINO_USB_CDC_ON_BOOT, se il buffer di trasmissione USB si riempie e
    // NESSUNO legge (monitor seriale chiuso), Serial.printf() BLOCCA il task che
    // la chiama, in attesa che si liberi spazio. Sintomo osservato: lo scoring (e
    // il trigger) funzionavano solo col monitor aperto, si congelavano chiudendolo.
    // setTxTimeoutMs(0) rende le scritture NON bloccanti: se il buffer e' pieno,
    // i byte in eccesso vengono scartati e il codice prosegue. I DBG diventano
    // fire-and-forget: visibili se qualcuno ascolta, scartati altrimenti, MAI
    // bloccanti. Indispensabile per il funzionamento standalone (solo LiPo).
    Serial.setTxTimeoutMs(0);

    {
        const uint32_t CDC_WAIT_MS = 1500;
        uint32_t t0 = millis();
        while (!Serial && (millis() - t0 < CDC_WAIT_MS)) { delay(10); }
        if (Serial) {
            BLOG("CDC USB connesso");
        } else {
            Serial0.println("[BOOT] Standalone — CDC non connesso, boot continua");
        }
    }
    delay(100);

    BLOG("ArchBB v" FW_VERSION_STR "  heap=%u", ESP.getFreeHeap());

    // -------------------------------------------------------------------------
    // v2.10.5 — DIAGNOSTICA RESET: perché si è riavviato l'ULTIMA volta?
    // -------------------------------------------------------------------------
    // Invece di decodificare il "Saved PC" (che cattura un core magari in idle
    // e depista), chiediamo al sistema la CAUSA già categorizzata del reset.
    // esp_reset_reason() è il dato diagnostico diretto: al prossimo crash, il
    // boot successivo scriverà a lettere quale watchdog/causa ha resettato.
    {
        esp_reset_reason_t rr = esp_reset_reason();
        const char* rr_str;
        switch (rr) {
            case ESP_RST_POWERON:   rr_str = "POWERON (accensione normale)";     break;
            case ESP_RST_SW:        rr_str = "SW (esp_restart esplicito)";        break;
            case ESP_RST_PANIC:     rr_str = "PANIC (crash software/exception)";  break;
            case ESP_RST_INT_WDT:   rr_str = "INT_WDT (Interrupt Watchdog!)";     break;
            case ESP_RST_TASK_WDT:  rr_str = "TASK_WDT (Task Watchdog!)";         break;
            case ESP_RST_WDT:       rr_str = "WDT (altro watchdog)";              break;
            case ESP_RST_BROWNOUT:  rr_str = "BROWNOUT (calo di tensione!)";      break;
            case ESP_RST_DEEPSLEEP: rr_str = "DEEPSLEEP (risveglio)";             break;
            case ESP_RST_EXT:       rr_str = "EXT (reset esterno/pin)";           break;
            case ESP_RST_SDIO:      rr_str = "SDIO";                              break;
            default:                rr_str = "UNKNOWN";                           break;
        }
        BLOG("*** RESET REASON: %s ***", rr_str);
        BLOG("*** CPU freq: %u MHz (se <240, il PM sta scalando) ***",
             (unsigned)getCpuFrequencyMhz());
    }

    Wire.begin(I2C_SDA, I2C_SCL);
    Wire.setClock(400000);
    BLOG("I2C OK");

    circular_buffer_init();
    BLOG("Buffer OK  heap=%u", ESP.getFreeHeap());

    esp_log_level_set("Preferences", ESP_LOG_NONE);
    if (!nvs_load_config(g_config)) {
        g_config            = configDefaults();
        g_config.session_id = 1;
        nvs_save_config(g_config);
        BLOG("Config: defaults");
    } else {
        g_config.session_id++;
        g_config.shot_counter = 0;
        BLOG("Config: NVS OK  session=%d", g_config.session_id);
    }
    esp_log_level_set("Preferences", ESP_LOG_WARN);

    // v2.9: imposta l'orientamento di montaggio dalla Config PRIMA che
    // l'imu_task parta, cosi' il primo campione e' gia' nel frame corretto.
    if (!mount_is_valid(g_config.mount_orientation)) g_config.mount_orientation = MOUNT_0;
    g_mount_orientation = g_config.mount_orientation;
    BLOG("Montaggio: %s", mount_name(g_mount_orientation));

    BLOG("IMU init...");
    imu_init(g_config.odr, g_config.accel_range_g, g_config.gyro_range_dps);
    BLOG("IMU OK  heap=%u", ESP.getFreeHeap());

    trigger_init(g_config);
    BLOG("Trigger OK");

    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_BT);
    snprintf(s_adv_name, sizeof(s_adv_name), "%s%02X%02X",
             BLE_DEVICE_NAME_PREFIX, mac[4], mac[5]);
    BLOG("BLE init  %s  heap=%u", s_adv_name, ESP.getFreeHeap());
    ble_server_init(s_adv_name, &g_config);
    BLOG("BLE OK  heap=%u", ESP.getFreeHeap());

    BLOG("Display init...");
    display_init();
    display_show_boot();
    BLOG("Display OK");

    // Monitoraggio batteria: ADC su GPIO1, partitore ×3 (schematico 1.69).
    // Deve avvenire dopo Serial (per il log DBG) e prima dei task, così il
    // primo StatusPacket BLE riporta già una carica reale.
    battery_init();
    BLOG("Battery OK  %.2fV -> %u%%", battery_last_voltage(), g_batt_pct);

    // Gestione risparmio energetico: backlight state-driven + beep di conferma.
    // Dopo display_init() e battery_init(): prende il controllo di TFT_BL e
    // configura il buzzer su GPIO33.
    power_init();
    BLOG("Power OK");

    // Tutti i task applicativi su Core 1.
    // v2.10.3: ble_task RIPORTATO su Core 1. Lo spostamento su Core 0 (v2.10.1)
    // è stato un ERRORE: metteva ble_task sullo stesso core dell'host NimBLE, e
    // la contesa sulle sezioni critiche interne di NimBLE (spinlock che
    // disabilitano gli interrupt) teneva gli interrupt bloccati oltre il timeout
    // dell'INTERRUPT watchdog (IWDT) -> reset via esp_restart_noos (confermato
    // dal decode del Saved PC 0x40377ae4). Su Core 1 la contesa non blocca gli
    // interrupt dello stesso core così a lungo. Il vero fix del residuo è alzare
    // il timeout IWDT (vedi sdkconfig.defaults), non spostare il core.
    xTaskCreatePinnedToCore(imu_task,     "imu",     IMU_TASK_STACK,     nullptr, 5, &h_imu,     1);
    xTaskCreatePinnedToCore(trigger_task, "trigger", TRIGGER_TASK_STACK, nullptr, 4, &h_trigger, 1);
    xTaskCreatePinnedToCore(ble_task,     "ble",     BLE_TASK_STACK,     nullptr, 3, &h_ble,     1);
    xTaskCreatePinnedToCore(display_task, "display", DISPLAY_TASK_STACK, nullptr, 1, &h_display, 1);

    BLOG("Tasks OK  heap=%u", ESP.getFreeHeap());
    BLOG("===== BOOT COMPLETATO =====");
}

// =============================================================================
// LOOP — monitoraggio GPIO36 + salvataggio NVS periodico
// =============================================================================
//
// LOGICA TASTO PWR (GPIO36):
//   loop() gira a ~50Hz (delay 20ms). Campiona GPIO36 ad ogni ciclo.
//   GPIO36 va LOW quando il tasto PWR fisico è tenuto premuto.
//
//   Stato          Condizione              Azione
//   ─────────────────────────────────────────────────────
//   IDLE           GPIO36 HIGH             nessuna
//   DEBOUNCE       GPIO36 LOW < 50ms       ignora (anti-rimbalzo)
//   COUNTDOWN      GPIO36 LOW 50ms..2000ms display barra proporzionale
//   SHUTDOWN       GPIO36 LOW >= 2000ms    perform_shutdown()
//   ANNULLATO      GPIO36 torna HIGH       reset stato, display normale
//
// =============================================================================

#ifndef SHUTDOWN_HOLD_MS
  #define SHUTDOWN_HOLD_MS     2000   // ms pressione per confermare
#endif
#ifndef SHUTDOWN_DEBOUNCE_MS
  #define SHUTDOWN_DEBOUNCE_MS   50   // ms debounce iniziale
#endif
#ifndef NVS_SAVE_INTERVAL_MS
  #define NVS_SAVE_INTERVAL_MS 60000
#endif
#ifndef NVS_SAVE_SHOT_INTERVAL
  #define NVS_SAVE_SHOT_INTERVAL 10
#endif
#ifndef BATT_SAMPLE_INTERVAL_MS
  #define BATT_SAMPLE_INTERVAL_MS 3000   // campiona la batteria ogni 3 s
#endif
#ifndef BATT_RADIO_SETTLE_MS
  #define BATT_RADIO_SETTLE_MS 1500      // attesa dopo un burst prima di misurare
                                         // (la tensione LiPo risale dall'IR drop)
#endif

void loop() {
    static uint32_t last_nvs_ms    = 0;
    static uint16_t last_nvs_shots = 0;
    static uint32_t last_batt_ms   = 0;

    static bool     pwr_was_low        = false;
    static uint32_t pwr_low_since_ms   = 0;
    static bool     shutdown_countdown = false;

    uint32_t now = millis();

    // ── Lettura GPIO36 ──────────────────────────────────────────────────────
    bool pwr_low = (digitalRead(GPIO_SYS_OUT) == LOW);

    if (pwr_low && !pwr_was_low) {
        // Fronte discendente: tasto appena premuto
        pwr_low_since_ms   = now;
        shutdown_countdown = false;
        pwr_was_low        = true;
        Serial0.println("[PWR] premuto");
    }
    else if (pwr_low && pwr_was_low) {
        uint32_t held_ms = now - pwr_low_since_ms;

        if (held_ms >= SHUTDOWN_DEBOUNCE_MS) {
            // Debounce superato: sospendi display_task e mostra countdown
            g_display_suspended = true;
            shutdown_countdown  = true;

            uint32_t cd_ms = held_ms - SHUTDOWN_DEBOUNCE_MS;
            uint8_t  pct   = (uint8_t)min((uint32_t)100,
                              cd_ms * 100 / SHUTDOWN_HOLD_MS);

            display_show_shutdown_countdown(pct);

            if (cd_ms >= SHUTDOWN_HOLD_MS) {
                Serial0.println("[PWR] shutdown confermato");
                display_show_shutdown_complete();
                delay(300);
                perform_shutdown();
                // Non ritorna
            }
        }
    }
    else if (!pwr_low && pwr_was_low) {
        // Tasto rilasciato prima del timeout: ripristina display_task
        if (shutdown_countdown) {
            Serial0.println("[PWR] annullato");
        }
        g_display_suspended = false;   // display_task riprende
        pwr_was_low         = false;
        shutdown_countdown  = false;
    }
    // ────────────────────────────────────────────────────────────────────────

    // ── NVS periodico ───────────────────────────────────────────────────────
    if ((g_config.shot_counter != last_nvs_shots &&
         g_config.shot_counter % NVS_SAVE_SHOT_INTERVAL == 0) ||
        (now - last_nvs_ms > NVS_SAVE_INTERVAL_MS)) {
        nvs_save_config(g_config);
        last_nvs_ms    = now;
        last_nvs_shots = g_config.shot_counter;
    }
    // ────────────────────────────────────────────────────────────────────────

    // ── DIAGNOSTICA BOOT BATTERIA (temporanea) ───────────────────────────────
    // Attiva solo se in platformio.ini è presente -DBATT_BOOT_DIAG.
    // Stampa la tensione GREZZA (senza filtri) a 1 Hz per i primi
    // BATT_BOOT_DIAG_MS millisecondi, per osservare il transitorio di
    // accensione. Formato CSV-friendly: "DIAG,<ms>,<volt>,<raw_pct>".
    #ifdef BATT_BOOT_DIAG
    {
        static uint32_t diag_last = 0;
        static bool     diag_done = false;
        if (!diag_done && (now - diag_last >= 1000)) {
            diag_last = now;
            if (now <= BATT_BOOT_DIAG_MS) {
                uint8_t rp = 0;
                float v = battery_debug_read(&rp);
                Serial.printf("DIAG,%lu,%.3f,%u\n", (unsigned long)now, v, rp);
            } else {
                diag_done = true;
                Serial.println("DIAG,END");
            }
        }
    }
    #endif
    // ────────────────────────────────────────────────────────────────────────

    // ── Campionamento batteria (v2.6: gated + anti IR-drop) ──────────────────
    // La batteria varia lentamente: una lettura ogni 3s basta. MA la misura è
    // valida solo a radio a riposo: durante/subito dopo un burst BLE la tensione
    // crolla per l'IR drop della LiPo e sottostima la carica. Consideriamo la
    // radio "a riposo" se NON siamo in SENDING e se è passato almeno
    // BATT_RADIO_SETTLE_MS dall'ultimo burst.
    if (now - last_batt_ms > BATT_SAMPLE_INTERVAL_MS) {
        bool radio_idle = (g_device_state != STATE_SENDING) &&
                          (now - g_last_burst_end_ms > BATT_RADIO_SETTLE_MS);
        if (battery_read_pct_gated(radio_idle)) {
            last_batt_ms = now;
            DBG("Batt %.2fV -> %u%% (OCV)", battery_last_voltage(), g_batt_pct);
        }
        // se non idle, riproviamo al giro dopo senza aggiornare last_batt_ms
    }
    // ────────────────────────────────────────────────────────────────────────

    delay(20);  // 50Hz — sufficiente per rilevare debounce 50ms
}
