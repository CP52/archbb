// =============================================================================
// power.cpp — ArchBB: gestione risparmio energetico  (v1.0, firmware v2.6)
// =============================================================================
// Vedi power.h per la documentazione completa della strategia.
// =============================================================================

#include "power.h"
#include "config.h"    // DeviceState, macro DBG(), GPIO_BUZZER, TFT_BL via User_Setup

// TFT_BL è definito in include/User_Setup.h (=15). Lo includiamo indirettamente
// tramite i moduli display; qui lo ridichiariamo con guardia per sicurezza.
#ifndef TFT_BL
  #define TFT_BL 15
#endif
#ifndef GPIO_BUZZER
  #define GPIO_BUZZER 33
#endif

// Canale LEDC dedicato al buzzer (0..15). Ne scegliamo uno alto per non
// collidere con eventuali PWM del backlight/display.
#ifndef BUZZER_LEDC_CH
  #define BUZZER_LEDC_CH 7
#endif

// -----------------------------------------------------------------------------
// STATO INTERNO
// -----------------------------------------------------------------------------
static bool     s_bl_on          = true;    // stato corrente backlight
static uint8_t  s_prev_state     = 0xFF;    // stato precedente (per rilevare transizioni)
static bool     s_shot_beeped    = false;   // beep di scocco gia' emesso per il tiro corrente
static bool     s_beep_active    = false;   // true se un beep è in corso
static uint32_t s_beep_off_ms    = 0;       // millis() a cui spegnere il beep

// =============================================================================
// BACKLIGHT
// =============================================================================

void power_backlight(bool on) {
    if (on == s_bl_on) return;              // idempotente: niente scritture inutili
    s_bl_on = on;
    digitalWrite(TFT_BL, on ? HIGH : LOW);
    DBG("Backlight %s", on ? "ON" : "OFF");
}

bool power_backlight_is_on() { return s_bl_on; }

// -----------------------------------------------------------------------------
// power_update_for_state()
//   Mappa stato → backlight ed emette il beep di conferma allo scocco.
//   La regola è semplice: backlight OFF solo in RECORDING (attesa in mira),
//   ON in tutti gli altri stati.
// -----------------------------------------------------------------------------
void power_update_for_state(uint8_t device_state) {
    // 1) Beep di conferma "colpo riconosciuto" — UNA VOLTA SOLA per tiro.
    //    La sequenza reale di stati e' RECORDING -> SENDING -> SCORING. A seconda
    //    di quanto spesso gira il display_task, questo puo' vedere SOLO SCORING
    //    (SENDING troppo veloce) oppure ENTRAMBI SENDING e SCORING. La v2.12.1
    //    aveva DUE agganci (SCORING e la "rete di sicurezza" su SENDING): quando
    //    il display vedeva entrambe le transizioni, scattavano DUE beep — il
    //    doppio-beep udito sul primo tiro.
    //    FIX: un flag di ciclo. Emettiamo il beep alla PRIMA transizione utile
    //    (RECORDING -> SENDING oppure ingresso in SCORING), poi lo inibiamo fino
    //    a quando si torna armati in RECORDING (nuovo tiro). Cosi' il numero di
    //    beep non dipende piu' da quali stati intermedi il display riesce a
    //    osservare.
    bool shot_event = (device_state == STATE_SENDING && s_prev_state == STATE_RECORDING)
                   || (device_state == STATE_SCORING && s_prev_state != STATE_SCORING);
    if (shot_event && !s_shot_beeped) {
        power_backlight(true);
        power_beep(2200, 60);               // beep breve di conferma "colpo preso"
        s_shot_beeped = true;               // inibisce ulteriori beep per questo tiro
    }
    // Ri-arma il beep quando si torna in uno stato "a riposo" (non si sta
    // valutando un tiro): RECORDING (armato), CONNECTED o IDLE. Copre anche il
    // caso in cui dopo lo scoring si torni a CONNECTED (recording disattivato)
    // invece che a RECORDING.
    if (device_state == STATE_RECORDING || device_state == STATE_CONNECTED
        || device_state == STATE_IDLE) {
        s_shot_beeped = false;
    }

    // 2) Regola generale di backlight in funzione dello stato.
    //    OFF solo mentre si è armati in attesa del colpo.
    switch (device_state) {
        case STATE_RECORDING:
            power_backlight(false);         // attesa in mira → risparmio
            break;
        case STATE_IDLE:
        case STATE_CONNECTED:
        case STATE_TRIGGERED:
        case STATE_SENDING:
        case STATE_LIVE:
        case STATE_SCORING:                 // v2.11: serve vedere e toccare
        default:
            power_backlight(true);          // schermo utile → acceso
            break;
    }

    s_prev_state = device_state;
}

// =============================================================================
// BUZZER (beep non bloccante via LEDC)
// =============================================================================

void power_beep(uint16_t freq_hz, uint16_t dur_ms) {
    // Avvia il tono sul canale LEDC. ledcWriteTone imposta la frequenza; il
    // duty di default (~50%) genera il suono. Lo spegnimento è programmato in
    // power_tick(), così NON blocchiamo il task chiamante con un delay().
    ledcWriteTone(BUZZER_LEDC_CH, freq_hz);
    s_beep_active = true;
    s_beep_off_ms = millis() + dur_ms;
}

void power_tick() {
    if (s_beep_active && (int32_t)(millis() - s_beep_off_ms) >= 0) {
        ledcWriteTone(BUZZER_LEDC_CH, 0);   // silenzia
        s_beep_active = false;
    }
}

// =============================================================================
// INIT
// =============================================================================

void power_init() {
    // Backlight: prendiamo il controllo del pin (display_init lo ha già messo
    // OUTPUT+HIGH; qui allineiamo lo stato interno).
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, HIGH);
    s_bl_on = true;

    // Buzzer: PWM hardware LEDC. 2 kHz base, risoluzione 8 bit; la frequenza
    // effettiva viene poi imposta da ledcWriteTone ad ogni beep.
    ledcSetup(BUZZER_LEDC_CH, 2000, 8);
    ledcAttachPin(GPIO_BUZZER, BUZZER_LEDC_CH);
    ledcWriteTone(BUZZER_LEDC_CH, 0);       // silenzio iniziale

    s_prev_state  = 0xFF;
    s_beep_active = false;
    s_shot_beeped = false;

    DBG("Power init: backlight ON, buzzer su GPIO%d (LEDC ch %d)",
        GPIO_BUZZER, BUZZER_LEDC_CH);
}
