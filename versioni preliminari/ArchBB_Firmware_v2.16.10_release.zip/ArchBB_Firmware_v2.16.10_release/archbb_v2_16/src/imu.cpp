// =============================================================================
// imu.cpp — implementazione driver QMI8658C (v1.1 corretta)
// =============================================================================
//
// STRATEGIA POLLING vs INTERRUPT:
//   SensorLib gestisce il pin IRQ internamente tramite setPins(irq_pin) e
//   hal->digitalRead() dentro getDataReady(). Non usiamo attachInterrupt()
//   esterno perché SensorLib non espone una callback ISR, e fare attachInterrupt
//   + read I2C nella stessa ISR causerebbe crash (I2C non è ISR-safe).
//
//   Il task gira con vTaskDelay(2ms) tra i poll di getDataReady().
//   A 224Hz il periodo è ~4.5ms — con 2ms di delay il worst-case di latenza
//   è 2ms (metà periodo), accettabile per analisi trigger e FFT.
//   Il task usa una NOTIFICA FreeRTOS per segnalare al circular buffer.
//
// ATTENZIONE PRAGMA:
//   SensorQMI8658.hpp emette un #pragma message di deprecazione a compile time.
//   Non è un errore — è un warning del preprocessore. Ignorare.
// =============================================================================

#include "imu.h"
#include "circular_buffer.h"
#include "mount.h"   // v2.9: trasformazione orientamento di montaggio

// Sopprime il warning di deprecazione di SensorLib durante la compilazione
// (il pragma message non è un errore, ma può confondere nel log)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcpp"
#include <SensorQMI8658.hpp>

extern volatile bool g_shutdown;  // definita in main.cpp
#pragma GCC diagnostic pop

// v2.9: SensorLib (SensorCommDebug.hpp) ridefinisce DBG come macro VUOTA,
// sovrascrivendo la nostra e sopprimendo silenziosamente i log ArchBB di questo
// file. Ripristiniamo la definizione ArchBB DOPO l'include cosi' il debug di
// imu.cpp funziona di nuovo quando ARCHBB_DEBUG e' attivo.
#undef DBG
#ifdef ARCHBB_DEBUG
  #define DBG(fmt, ...)     Serial.printf("[ARCHBB] " fmt "\n", ##__VA_ARGS__)
#else
  #define DBG(fmt, ...)
#endif

// =============================================================================
// VARIABILI GLOBALI
// =============================================================================
SemaphoreHandle_t g_imu_sample_mutex = nullptr;
ImuSample         g_latest_sample    = {};
volatile bool     g_imu_ok           = false;

static SensorQMI8658* s_imu    = nullptr;
static volatile uint16_t s_seq = 0;

// =============================================================================
// imu_init()
// =============================================================================
bool imu_init(OdrSetting odr_setting, uint8_t accel_range_g,
              uint16_t gyro_range_dps, int irq_pin) {

    DBG("IMU init — I2C SDA=%d SCL=%d IRQ=%d", I2C_SDA, I2C_SCL, irq_pin);

    // I2C già inizializzato in main.cpp — Wire.begin() idempotente
    // Wire.begin già chiamato in main.cpp — non ripetere
    Wire.setClock(400000);  // solo setClock è ok ripetere

    // Scan I2C preventivo
    Wire.beginTransmission(QMI8658_L_SLAVE_ADDRESS);  // 0x6B
    if (Wire.endTransmission() != 0) {
        DBG("ERRORE: QMI8658C non trovato su 0x6B");
        g_imu_ok = false;
        return false;
    }
    DBG("QMI8658C trovato su I2C 0x6B");

    // Alloca driver
    s_imu = new SensorQMI8658();
    if (!s_imu) { DBG("ERRORE: malloc SensorQMI8658"); return false; }

    // Inizializza: begin(Wire, address, sda, scl, irq_pin)
    // Il pin IRQ viene passato a begin() — NON usare setPins() separatamente
    // perché causa "bus already initialized" se Wire è già stato avviato.
    if (!s_imu->begin(Wire, QMI8658_L_SLAVE_ADDRESS, I2C_SDA, I2C_SCL)) {
        DBG("ERRORE: SensorLib begin() fallito — chip non risponde");
        delete s_imu; s_imu = nullptr;
        g_imu_ok = false;
        return false;
    }
    DBG("SensorLib begin() OK — chipID=0x%02X", s_imu->getChipID());

    // --- Configura accelerometro ---
    SensorQMI8658::AccelRange acc_range;
    SensorQMI8658::AccelODR   acc_odr;
    switch (accel_range_g) {
        case 2:  acc_range = SensorQMI8658::ACC_RANGE_2G;  break;
        case 4:  acc_range = SensorQMI8658::ACC_RANGE_4G;  break;
        case 16: acc_range = SensorQMI8658::ACC_RANGE_16G; break;
        default: acc_range = SensorQMI8658::ACC_RANGE_8G;  break;  // 8g
    }
    switch (odr_setting) {
        case ODR_100HZ: acc_odr = SensorQMI8658::ACC_ODR_125Hz; break;
        case ODR_500HZ: acc_odr = SensorQMI8658::ACC_ODR_500Hz; break;
        default:        acc_odr = SensorQMI8658::ACC_ODR_250Hz; break;  // 250Hz
    }
    s_imu->configAccelerometer(acc_range, acc_odr, SensorQMI8658::LPF_MODE_2);

    // --- Configura giroscopio ---
    // NOTA: QMI8658 non ha ODR esatti 100/250/500Hz per il giroscopio.
    // ODR disponibili: 28, 56, 112, 224, 448, 896, 1793, 3587, 7174 Hz
    // Mappiamo ai più vicini (vedere odrToHz() in config.h per i valori nominali).
    SensorQMI8658::GyroRange gyr_range;
    SensorQMI8658::GyroODR   gyr_odr;

    switch (gyro_range_dps) {
        case 16:   gyr_range = SensorQMI8658::GYR_RANGE_16DPS;   break;
        case 32:   gyr_range = SensorQMI8658::GYR_RANGE_32DPS;   break;
        case 64:   gyr_range = SensorQMI8658::GYR_RANGE_64DPS;   break;
        case 128:  gyr_range = SensorQMI8658::GYR_RANGE_128DPS;  break;
        case 256:  gyr_range = SensorQMI8658::GYR_RANGE_256DPS;  break;
        case 1024: gyr_range = SensorQMI8658::GYR_RANGE_1024DPS; break;
        default:   gyr_range = SensorQMI8658::GYR_RANGE_512DPS;  break;  // 512dps
    }
    switch (odr_setting) {
        case ODR_100HZ: gyr_odr = SensorQMI8658::GYR_ODR_112_1Hz; break;
        case ODR_500HZ: gyr_odr = SensorQMI8658::GYR_ODR_448_4Hz; break;
        default:        gyr_odr = SensorQMI8658::GYR_ODR_224_2Hz; break;
    }
    s_imu->configGyroscope(gyr_range, gyr_odr, SensorQMI8658::LPF_MODE_2);

    // --- Abilita sensori ---
    s_imu->enableAccelerometer();
    s_imu->enableGyroscope();

    // --- Abilita interrupt INT1 ---
    // getDataReady() usa polling sul registro STATUS — non richiede pin IRQ.
    // enableINT è opzionale e viene saltato per evitare conflitti con Wire.
    // s_imu->enableINT(SensorQMI8658::INTERRUPT_PIN_1);  // disabilitato v1.9b

    // --- Mutex FreeRTOS per g_latest_sample ---
    g_imu_sample_mutex = xSemaphoreCreateMutex();
    if (!g_imu_sample_mutex) {
        DBG("ERRORE: mutex IMU fallito");
        return false;
    }

    g_imu_ok = true;
    DBG("IMU OK — accel=±%dg gyro=±%ddps odr_idx=%d (acc~%dHz gyr~%dHz)",
        accel_range_g, gyro_range_dps, (int)odr_setting,
        (odr_setting == ODR_100HZ ? 125 : odr_setting == ODR_500HZ ? 500 : 250),
        odrToHz(odr_setting));
    return true;
}

// =============================================================================
// imu_set_odr()
// =============================================================================
bool imu_set_odr(OdrSetting odr_setting) {
    if (!s_imu) return false;
    s_imu->disableAccelerometer();
    s_imu->disableGyroscope();

    SensorQMI8658::AccelODR acc_odr;
    SensorQMI8658::GyroODR  gyr_odr;
    switch (odr_setting) {
        case ODR_100HZ: acc_odr = SensorQMI8658::ACC_ODR_125Hz; gyr_odr = SensorQMI8658::GYR_ODR_112_1Hz; break;
        case ODR_500HZ: acc_odr = SensorQMI8658::ACC_ODR_500Hz; gyr_odr = SensorQMI8658::GYR_ODR_448_4Hz; break;
        default:        acc_odr = SensorQMI8658::ACC_ODR_250Hz; gyr_odr = SensorQMI8658::GYR_ODR_224_2Hz; break;
    }
    // Riconfigurazione con range invariati (default 8g/512dps)
    s_imu->configAccelerometer(SensorQMI8658::ACC_RANGE_8G, acc_odr, SensorQMI8658::LPF_MODE_2);
    s_imu->configGyroscope(SensorQMI8658::GYR_RANGE_512DPS, gyr_odr, SensorQMI8658::LPF_MODE_2);
    s_imu->enableAccelerometer();
    s_imu->enableGyroscope();
    DBG("ODR cambiato → gyr~%dHz", odrToHz(odr_setting));
    return true;
}

// =============================================================================
// imu_task() — polling getDataReady(), Core 1, priorità HIGH
// =============================================================================
void imu_task(void* param) {
    DBG("imu_task avviato su Core %d", xPortGetCoreID());

    while (!g_imu_ok) { vTaskDelay(pdMS_TO_TICKS(10)); }

    float ax_g, ay_g, az_g;
    float gx_dps, gy_dps, gz_dps;
    uint32_t last_debug_ms = 0;

    for (;;) {
        // Controlla flag shutdown (inizio loop)
        if (g_shutdown) { DBG("imu_task: shutdown"); vTaskDelete(nullptr); }

        // Polling DATA_READY ogni 1ms con check shutdown
        if (!s_imu->getDataReady()) {
            vTaskDelay(pdMS_TO_TICKS(1));
            if (g_shutdown) { DBG("imu_task: shutdown"); vTaskDelete(nullptr); }
            continue;
        }

        // Leggi dati dal QMI8658C
        if (!s_imu->getAccelerometer(ax_g, ay_g, az_g)) {
            vTaskDelay(pdMS_TO_TICKS(1));
            continue;
        }
        if (!s_imu->getGyroscope(gx_dps, gy_dps, gz_dps)) {
            vTaskDelay(pdMS_TO_TICKS(1));
            continue;
        }

        // Converti g → m/s² in variabili LOCALI (allineate a 4 byte).
        float ax = ax_g * 9.80665f;
        float ay = ay_g * 9.80665f;
        float az = az_g * 9.80665f;
        float gx = gx_dps;
        float gy = gy_dps;
        float gz = gz_dps;

        // --- v2.9: TRASFORMAZIONE ORIENTAMENTO DI MONTAGGIO -----------------
        // Applicata QUI, a monte di tutto: g_latest_sample, circular buffer,
        // trigger, burst BLE e metriche app vedono gia' dati nel frame CANONICO
        // 0 gradi. Nessun altro modulo va toccato. Per MOUNT_0 e' un no-op
        // (comportamento identico a v2.8). Costo: permutazione di segni, nullo.
        //
        // NOTA (packed): la trasformazione lavora su queste variabili LOCALI e
        // NON sui campi di ImuSample. ImuSample e' __attribute__((packed)) e i
        // suoi float possono cadere ad indirizzi non allineati: legarli a
        // 'float&' e' vietato dal compilatore (errore "cannot bind packed field
        // to float&") perche' Xtensa richiede accessi allineati. Trasformando le
        // locali e assegnandole DOPO, l'accesso alla struct e' una semplice
        // copia byte-wise sicura.
        mount_apply(g_mount_orientation, ax, ay, az, gx, gy, gz);
        // -------------------------------------------------------------------

        // Compila campione con i valori GIA' nel frame canonico
        ImuSample sample;
        sample.seq          = s_seq++;
        sample.timestamp_us = (uint32_t)esp_timer_get_time();
        sample.ax           = ax;
        sample.ay           = ay;
        sample.az           = az;
        sample.gx           = gx;
        sample.gy           = gy;
        sample.gz           = gz;

        // Aggiorna g_latest_sample con mutex
        if (xSemaphoreTake(g_imu_sample_mutex, pdMS_TO_TICKS(1)) == pdTRUE) {
            g_latest_sample = sample;
            xSemaphoreGive(g_imu_sample_mutex);
        }

        // Push nel circular buffer
        circular_buffer_push(sample);

        // Debug ogni ~1s (224 campioni)
#ifdef ARCHBB_DEBUG
        if (millis() - last_debug_ms > 1000) {
            last_debug_ms = millis();
            DBG_RAW("[IMU] seq=%u t=%uµs ax=%.2f ay=%.2f az=%.2f gx=%.1f gy=%.1f gz=%.1f\n",
                    sample.seq, sample.timestamp_us,
                    sample.ax, sample.ay, sample.az,
                    sample.gx, sample.gy, sample.gz);
        }
#endif

        // Breve yield dopo lettura riuscita
        vTaskDelay(pdMS_TO_TICKS(1));
    }
    vTaskDelete(nullptr);
}

// =============================================================================
float imu_read_temperature() {
    if (!s_imu) return -273.0f;
    return s_imu->getTemperature_C();
}

void imu_print_debug() {
    if (!s_imu) { Serial.println("IMU non inizializzato"); return; }
    float ax, ay, az, gx, gy, gz;
    s_imu->getAccelerometer(ax, ay, az);
    s_imu->getGyroscope(gx, gy, gz);
    Serial.printf("  ax=%.3fg ay=%.3fg az=%.3fg | gx=%.1f gy=%.1f gz=%.1f | T=%.1f°C\n",
                  ax, ay, az, gx, gy, gz, s_imu->getTemperature_C());
}

