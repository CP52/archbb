// =============================================================================
// display.h — ArchBB: interfaccia display TFT ST7789V2 (v1.1)
// =============================================================================
#pragma once
#include <Arduino.h>
#include <TFT_eSPI.h>
#include "config.h"

// Palette (RGB565)
#define COL_BG       0x1A1E
#define COL_CYAN     0x07FF
#define COL_GREEN    0x07E8
#define COL_AMBER    0xFD40
#define COL_RED      0xF98B
#define COL_WHITE    0xF7BE
#define COL_GRAY     0x7BEF
#define COL_DARKGRAY 0x4208
#define COL_BLACK    0x0000

void display_init();
void display_task(void* param);
void display_show_boot();
void display_screen_idle(bool ble_connected, uint16_t shot_count, uint8_t batt_pct);
void display_screen_recording(uint16_t shot_count, float az_live, bool rec_blink);
void display_screen_triggered(uint16_t shot_id, float az_peak, uint8_t send_progress_pct);
void display_screen_live(float ax, float ay, float az, float gx, float gy, float gz);

// Shutdown UI — chiamate da loop() durante pressione tasto PWR.
//
// ANTI-FLICKERING: flag g_display_suspended.
//   loop() lo alza prima di chiamare display_show_shutdown_countdown().
//   display_task lo controlla e se true salta il render.
//   loop() lo abbassa se l'utente rilascia prima del timeout.
//   volatile: visibilità immediata cross-core FreeRTOS.
extern volatile bool g_display_suspended;

void display_show_shutdown_countdown(uint8_t pct);   // pct 0..100
void display_show_shutdown_complete();
