// =============================================================================
// scoring_ui.h — ArchBB: interfaccia UI dello scoring on-device (v2.0)
// Firmware 2.12.0 — Fase C + Backport UX dalla 1.83
// =============================================================================
//
// SCOPO
//   Contiene tutto ciò che serve allo stato STATE_SCORING:
//     - un mini-driver touch CST816T (init + lettura, con guard di plausibilità
//       e soglie di calibrazione raw->zona validate sul campo);
//     - il rendering delle schermate (esito / zona 3x3+SPOT / distanza ± /
//       RIEPILOGO di conferma);
//     - la sotto-macchina a stati che le orchestra e, SOLO all'OK del riepilogo,
//       scrive l'esito in g_pending_score e chiama ble_send_score().
//
// v2.0 — backport UX dalla 1.83 (l'interfaccia pubblica NON cambia: stesse due
//   funzioni, stesso aggancio dal display_task). Le migliorie sono tutte interne
//   a scoring_ui.cpp: RIEPILOGO OK/CORREGGI (anti-fallo score), debounce+cooldown
//   del touch, INDIETRO, breadcrumb, pulsante ? IGNOTA. Vedi l'intestazione del
//   .cpp per il dettaglio §1..§7.
//
//   Vive in un modulo separato per NON gonfiare il display.cpp collaudato:
//   display_task aggiunge un solo 'case STATE_SCORING' che delega a
//   scoring_ui_tick(). Architettura conservativa: la logica nuova è isolata.
//
// SOGLIE DI CALIBRAZIONE (dai dati reali della sessione di calibrazione)
//   THR_X_LC=89  THR_X_CR=164  (colonne: sx | centro | dx)
//   THR_Y_TM=68  THR_Y_MB=198  (righe:   alto | mezzo | basso)
//   zona = colonna + 3*riga, con colonna/riga in {0,1,2}.
// =============================================================================

#pragma once
#include <Arduino.h>
#include <TFT_eSPI.h>

// Inizializza il touch CST816T (reset, disabilita auto-sleep). Idempotente:
// può essere chiamata più volte senza danni. Va chiamata una volta a boot.
void scoring_ui_init();

// Da chiamare dal display_task quando g_device_state == STATE_SCORING.
// Gestisce internamente la sotto-macchina (esito->zona->distanza), il touch,
// il timeout, e a completamento scrive l'esito + chiama ble_send_score() e
// riporta g_device_state a STATE_CONNECTED.
//   sprite : lo sprite condiviso del display (per il rendering anti-flicker)
// Ritorna true se lo scoring è ancora in corso, false se è concluso (l'uscita
// di stato la fa comunque internamente).
bool scoring_ui_tick(TFT_eSprite& sprite);
