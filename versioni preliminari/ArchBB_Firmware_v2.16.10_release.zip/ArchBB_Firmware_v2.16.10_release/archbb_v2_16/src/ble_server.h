// =============================================================================
// ble_server.h — ArchBB: server GATT NimBLE v2.2
// =============================================================================
#pragma once

#include <Arduino.h>
#include <NimBLEDevice.h>
#include "config.h"
#include "imu.h"

void ble_server_init(const char* advertising_name, Config* cfg_ptr);
void ble_task(void* param);
void ble_notify_status(DeviceState state, uint16_t shot_count, uint8_t batt_pct);
void ble_send_burst(const ImuSample* samples, uint16_t total,
                    uint16_t trigger_idx, uint8_t batt_pct);
bool ble_is_connected();
bool ble_is_burst_subscribed();
bool ble_is_live_subscribed();

extern volatile DeviceState g_device_state;
extern volatile bool        g_live_streaming;
extern volatile bool        g_recording_enabled;
extern volatile uint32_t    g_last_burst_end_ms;   // v2.6: gating batteria
extern volatile bool        g_batt_diag_active;    // diagnostica batteria via BLE
extern volatile uint32_t    g_batt_diag_until_ms;

