// =============================================================================
// trigger.h — ArchBB: algoritmo di rilevazione trigger rilascio dita
// =============================================================================
//
// RAZIONALE FISICO:
//   Quando l'arciere apre le dita (rilascio), la corda trasmette un impulso
//   di accelerazione al riser/stabilizzatore attraverso il punto di ancoraggio.
//   La componente Az (asse di trazione della freccia) mostra un picco negativo
//   (decompressione) seguito da oscillazioni smorzate (frequenza flettente).
//
//   Il trigger deve rilevare questo evento in modo affidabile e distinguerlo
//   da:
//     a) vibrazioni ambientali (passo, vento, movimenti del corpo)
//     b) ricerca della finestra di mira (movimenti lenti, <2 m/s²)
//     c) respiro (0.2–0.5 m/s², <1Hz)
//
// DUE MODALITÀ:
//
//   1. AZ_THRESHOLD (default):
//      Condizione: |Az| > threshold per N campioni consecutivi.
//      Semplice, robusto, bassa latenza (<8ms).
//      Threshold default: 20 m/s² (aspettato 30–80 m/s² su barebow reale).
//
//   2. JERK (derivata):
//      Condizione: |d|Az|/dt| > threshold_jerk per N campioni consecutivi.
//      Jerk = variazione di accelerazione nel tempo [m/s³].
//      Più selettivo: un movimento lento ma ampio (es. bow arm drop) ha Az alto
//      ma jerk basso; il rilascio ha jerk molto alto (salita ripida del picco).
//      Threshold jerk default: 500 m/s³ (=50 m/s² in 100ms).
//
// REARM:
//   Dopo il trigger, il sistema attende rearm_ms prima di accettare un nuovo
//   trigger. Questo previene trigger multipli sulla stessa onda di vibrazione.
//   Default: 2000ms (consente ~30 colpi/min).
//
// CONFIRM_N:
//   Il trigger scatta solo se la condizione è vera per N campioni consecutivi.
//   Con N=2 @250Hz → conferma in 8ms → latenza accettabile.
//   Aumentare N riduce falsi positivi ma aumenta latenza.
// =============================================================================

#pragma once

#include <Arduino.h>
#include "config.h"

// =============================================================================
// HANDLE GLOBALI
// =============================================================================

// Semaforo: postato da trigger_task quando trigger confermato.
// ble_task fa xSemaphoreTake su questo semaforo per iniziare l'invio.
extern SemaphoreHandle_t g_trigger_fired_sem;

// Shot ID dell'ultimo trigger (incrementato a ogni trigger)
extern volatile uint16_t g_shot_id;

// Valore Az al momento del trigger (debug / metrica Trigger Sharpness)
extern volatile float g_trigger_az_peak;

// Timestamp µs del trigger
extern volatile uint32_t g_trigger_ts_us;

// =============================================================================
// API PUBBLICA
// =============================================================================

// Inizializza il modulo trigger: crea semafori, carica config.
void trigger_init(const Config& cfg);

// Aggiorna la configurazione trigger a runtime (dopo CMD BLE).
void trigger_update_config(const Config& cfg);

// Task FreeRTOS (Core 1, priorità HIGH).
// Loop: legge g_latest_sample → applica algoritmo trigger
//       → se trigger: congela buffer, incrementa shot_id, posta g_trigger_fired_sem.
void trigger_task(void* param);

// Forza trigger manuale (da CMD_MANUAL_TRIGGER).
// Thread-safe, può essere chiamato da qualsiasi task.
void trigger_manual();

// Stato interno del trigger (per display e debug)
enum TriggerPhase {
    TRIG_PHASE_IDLE,       // In attesa, registrazione non attiva
    TRIG_PHASE_ARMED,      // Registrazione attiva, attende evento
    TRIG_PHASE_CONFIRMING, // Condizione verificata per K/N campioni
    TRIG_PHASE_FIRED,      // Trigger confermato, in rearm
    TRIG_PHASE_REARM,      // In attesa di rearm_ms
};

extern volatile TriggerPhase g_trigger_phase;

