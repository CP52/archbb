// =============================================================================
// mount.h — ArchBB: trasformazione assi per orientamento di montaggio
// Versione 1.0 (introdotta in firmware v2.9)
// =============================================================================
//
// SCOPO
//   La scheda Waveshare puo' essere montata sul riser in 4 orientamenti, per
//   adattarsi ai fori liberi dei riser moderni (olimpici o compound):
//     - 0 gradi  : frontale, schermo verso l'arciere (montaggio di riferimento)
//     - -90 gradi: lato DESTRO del riser
//     - +90 gradi: lato SINISTRO del riser
//     - 180 gradi: lato OPPOSTO
//   I 4 montaggi sono rotazioni attorno all'ASSE GRAVITA' (ax): "l'alto resta
//   l'alto". Cio' che cambia e' come l'asse FRECCIA (az) e l'asse LATERALE (ay)
//   si distribuiscono sugli assi elettronici del sensore.
//
// PRINCIPIO: TRASFORMAZIONE A MONTE
//   La trasformazione viene applicata in imu.cpp SUBITO dopo la lettura del
//   sensore e PRIMA di ogni elaborazione a valle (trigger, circular buffer,
//   burst BLE, metriche app). Cosi' l'INTERO sistema a valle vede sempre dati
//   nel frame CANONICO 0 gradi, e NESSUN altro codice va modificato: il trigger
//   continua a cercare lo spike su az, il cant continua a usare atan2(ay,ax),
//   ecc. Questo e' l'approccio raccomandato in letteratura per il problema
//   "sensor-to-body alignment" (cfr. AllAboutCircuits, "How to Interpret IMU
//   Sensor Data for Dead-Reckoning: Rotation Matrix Creation", 2019; brevetto
//   US11886245 "runtime-frame velocity of wearable device", trasformazione dal
//   frame di montaggio a un frame di training/canonico).
//
// FRAME CANONICO (0 gradi) — ANCORATO A TIRI VERI (sessione 02JUL, 5 scocchi)
//   ax = asse verticale / GRAVITA'  (+ax ad arco verticale, gravita' media +10.2)
//   ay = asse laterale (dx/sx)      (base del cant)
//   az = asse FRECCIA / SCOCCO      (spike +az allo scocco, media +34 m/s^2)
//
// MATRICI DI ROTAZIONE R  (v_canonico = R . v_sensore)
//   Determinate empiricamente e validate (ortonormali, det=+1). Poiche' sono
//   rotazioni di multipli di 90 gradi attorno ad ax, R contiene solo 0 e +-1:
//   la trasformazione e' una semplice permutazione con cambi di segno, ZERO
//   trigonometria, ZERO errori di arrotondamento, costo computazionale nullo.
//
//     0 gradi  (MOUNT_0)      : identita'
//                cax= ax  cay= ay  caz= az      cgx= gx  cgy= gy  cgz= gz
//     -90 (MOUNT_DX_M90)      :
//                cax= ax  cay=-az  caz= ay      cgx= gx  cgy=-gz  cgz= gy
//     +90 (MOUNT_SX_P90)      :
//                cax= ax  cay= az  caz=-ay      cgx= gx  cgy= gz  cgz=-gy
//     180 (MOUNT_180)         :
//                cax= ax  cay=-ay  caz=-az      cgx= gx  cgy=-gy  cgz=-gz
//
//   NOTA FISICA: in tutti i montaggi cax=ax (gravita' invariante) e caz
//   ricostruisce sempre l'asse freccia canonico -> il trigger vede lo spike
//   su az qualunque sia il montaggio. Il giroscopio usa la STESSA matrice
//   dell'accelerometro: sono rigidamente solidali sullo stesso PCB, quindi
//   condividono un'unica trasformazione rigida (cfr. Frosio et al., calibrazione
//   MEMS: basta l'allineamento dell'accelerometro, il gyro segue).
// =============================================================================

#pragma once

#include <Arduino.h>
#include <stdint.h>
#include "config.h"

// -----------------------------------------------------------------------------
// ENUM ORIENTAMENTO DI MONTAGGIO
//   Valori STABILI (persistiti in NVS nel byte Config::mount_orientation).
//   NON riordinare: cambierebbe il significato dei dati gia' salvati.
// -----------------------------------------------------------------------------
enum MountOrientation : uint8_t {
    MOUNT_0       = 0,   // frontale (riferimento) — nessuna trasformazione
    MOUNT_DX_M90  = 1,   // lato destro  (-90 gradi)
    MOUNT_SX_P90  = 2,   // lato sinistro (+90 gradi)
    MOUNT_180     = 3,   // lato opposto (180 gradi)
    MOUNT_COUNT   = 4,   // sentinella (numero di orientamenti validi)
};

// -----------------------------------------------------------------------------
// Nomi leggibili (per debug / display). Indicizzati da MountOrientation.
// -----------------------------------------------------------------------------
inline const char* mount_name(uint8_t m) {
    switch (m) {
        case MOUNT_0:      return "0 (frontale)";
        case MOUNT_DX_M90: return "-90 (destro)";
        case MOUNT_SX_P90: return "+90 (sinistro)";
        case MOUNT_180:    return "180 (opposto)";
        default:           return "?";
    }
}

// -----------------------------------------------------------------------------
// Variabile globale con l'orientamento corrente.
//   Aggiornata da main.cpp all'avvio (da Config NVS) e ad ogni scrittura Config
//   via BLE. Letta dall'imu_task nel suo hot-loop.
//   'volatile' perche' scritta da un task (BLE/main, Core 0) e letta da un altro
//   (imu_task, Core 1). Un uint8_t e' letto/scritto atomicamente su Xtensa, quindi
//   non serve mutex: la lettura vede sempre un valore intero coerente (vecchio o
//   nuovo), mai una via di mezzo. Il cambio di montaggio non e' time-critical.
// -----------------------------------------------------------------------------
extern volatile uint8_t g_mount_orientation;

// -----------------------------------------------------------------------------
// mount_apply() — trasforma un campione dal frame SENSORE al frame CANONICO.
//
//   Applica in-place la matrice R corrispondente a 'orient' ai sei assi del
//   campione (ax,ay,az,gx,gy,gz). Implementata come switch con permutazioni
//   dirette: nessuna moltiplicazione di matrice, massima efficienza.
//
//   Parametri passati per riferimento e modificati in-place.
//
//   ATTENZIONE (packed): passare VARIABILI LOCALI (float allineati a 4 byte),
//   NON campi di una struct __attribute__((packed)) come ImuSample. Su Xtensa
//   (ESP32) legare un campo packed non allineato a 'float&' e' un errore di
//   compilazione ("cannot bind packed field to float&"). In imu.cpp la
//   trasformazione avviene infatti sulle locali, prima di riempire ImuSample.
// -----------------------------------------------------------------------------
inline void mount_apply(uint8_t orient,
                        float& ax, float& ay, float& az,
                        float& gx, float& gy, float& gz)
{
    // ax e gx (asse gravita'/rollio) sono INVARIANTI in ogni montaggio: la
    // rotazione avviene attorno ad ax. Li marchiamo come volutamente inutilizzati
    // per evitare warning -Wunused-parameter senza perdere la simmetria della firma.
    (void)ax; (void)gx;

    switch (orient) {

        case MOUNT_0:
            // Identita': nessuna trasformazione. Caso piu' frequente -> primo.
            break;

        case MOUNT_DX_M90: {
            // cax=ax; cay=-az; caz=ay   |   cgx=gx; cgy=-gz; cgz=gy
            float t_ay = -az,  t_az = ay;
            float t_gy = -gz,  t_gz = gy;
            ay = t_ay;  az = t_az;
            gy = t_gy;  gz = t_gz;
            break;
        }

        case MOUNT_SX_P90: {
            // cax=ax; cay=az; caz=-ay   |   cgx=gx; cgy=gz; cgz=-gy
            float t_ay = az,   t_az = -ay;
            float t_gy = gz,   t_gz = -gy;
            ay = t_ay;  az = t_az;
            gy = t_gy;  gz = t_gz;
            break;
        }

        case MOUNT_180:
            // cax=ax; cay=-ay; caz=-az   |   cgx=gx; cgy=-gy; cgz=-gz
            ay = -ay;  az = -az;
            gy = -gy;  gz = -gz;
            break;

        default:
            // Valore sconosciuto (NVS corrotta?): tratta come 0 gradi (sicuro).
            break;
    }
}

// -----------------------------------------------------------------------------
// mount_is_valid() — true se il valore e' un orientamento riconosciuto.
// -----------------------------------------------------------------------------
inline bool mount_is_valid(uint8_t m) {
    return m < MOUNT_COUNT;
}
