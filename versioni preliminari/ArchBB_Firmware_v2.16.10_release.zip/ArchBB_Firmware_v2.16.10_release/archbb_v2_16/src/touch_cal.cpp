// =============================================================================
// touch_cal.cpp — ArchBB: strumento di calibrazione del touch (v2.16.2)
// =============================================================================
// Vedi touch_cal.h per il PERCHE' di questo modulo (in breve: le coordinate del
// CST816 non coincidono con quelle dello sprite, il disallineamento era
// mascherato dai bersagli grandi, e non e' ricavabile a tavolino dai dati
// esistenti — va misurato).
// =============================================================================

#include "touch_cal.h"
#include "config.h"
#include "display.h"
#include <Arduino.h>
#include <Wire.h>
#include <esp_task_wdt.h>

// -----------------------------------------------------------------------------
// Watchdog: pascolo difensivo nei loop bloccanti
// -----------------------------------------------------------------------------
// Questo modulo e' bloccante per costruzione: DIAG ci si sta anche minuti, la
// calibrazione una decina di secondi. Se il task che ci ospita fosse registrato
// al Task Watchdog, scatterebbe un reset — ed e' esattamente quello che e'
// successo quando l'aggancio stava in display_init() (contesto loopTask di
// Arduino, sorvegliato): "DIAG mi fa toccare una sola volta e poi resetta".
//
// Adesso l'aggancio e' in display_task (non sorvegliato), quindi in teoria non
// serve. Lo mettiamo lo stesso, difensivamente: costa una chiamata che se il
// task non e' registrato ritorna un errore innocuo, e protegge dal caso in cui
// un domani qualcuno registri display_task al TWDT senza ricordarsi di qui.
// esp_task_wdt_reset() su un task non registrato NON e' un errore fatale.
// -----------------------------------------------------------------------------
// Formattazione dei float SENZA snprintf("%f")
// -----------------------------------------------------------------------------
// PERCHE': la formattazione float di newlib (dtoa) alloca buffer temporanei
// sullo STACK — tipicamente 1-2 KB PER CHIAMATA. display_task ne ha 6144 (era
// 3072), e questo modulo faceva 14 snprintf con %f: stack overflow -> reset.
//
// E' la causa del bug "DIAG mi fa toccare una sola volta e poi resetta": il
// primo tocco attiva il ramo che stampa i valori — cioe' il primo che esegue
// gli snprintf float. Prima del tocco si passa solo dal ramo "tocca lo
// schermo...", che di float non ne formatta nessuno. Il reset arrivava quindi
// esattamente al primo tocco, e mai prima.
//
// Alzare lo stack da solo sarebbe bastato, ma resta una toppa: qui i float li
// formattiamo con l'aritmetica intera, che di stack non ne usa. Due difese
// indipendenti per un modulo diagnostico che DEVE funzionare quando il resto
// non funziona.
//
// fmtFixed(buf, len, val, dec): scrive val con 'dec' decimali (max 5).
static void fmtFixed(char* out, size_t n, float v, uint8_t dec) {
    static const int32_t P[6] = {1, 10, 100, 1000, 10000, 100000};
    if (dec > 5) dec = 5;
    bool neg = (v < 0);
    if (neg) v = -v;
    // +0.5f sull'ultima cifra = arrotondamento al piu' vicino
    int32_t scaled = (int32_t)(v * (float)P[dec] + 0.5f);
    int32_t ip = scaled / P[dec];
    int32_t fp = scaled % P[dec];
    if (dec == 0) snprintf(out, n, "%s%ld", neg ? "-" : "", (long)ip);
    else          snprintf(out, n, "%s%ld.%0*ld", neg ? "-" : "",
                           (long)ip, (int)dec, (long)fp);
}

static inline void wdtFeed() {
#if CONFIG_ESP_TASK_WDT
    esp_task_wdt_reset();
#endif
}

// -----------------------------------------------------------------------------
// Accesso al touch — duplicato minimo e VOLUTO
// -----------------------------------------------------------------------------
// Le funzioni del CST816 vivono in scoring_ui.cpp come static (invisibili da
// qui). Le ri-dichiariamo invece di esportarle per un motivo preciso: questo
// modulo deve leggere il touch GREZZO, senza filtri, debounce o cooldown.
// Quelli servono alla UI di scoring (dove un tocco doppio e' un bug), ma qui
// sarebbero dannosi: falserebbero la misura che stiamo facendo.
// La duplicazione e' ~15 righe e ha una ragione semantica, non e' pigrizia.
static constexpr uint8_t  TPC_ADDR           = 0x15;
static constexpr uint8_t  TPC_REG_GESTURE    = 0x01;
static constexpr uint16_t TPC_COORD_SENTINEL = 4095;
// v2.16.4: vedi TP_COORD_MAX in scoring_ui.cpp. Qui e' anche peggio: questo e'
// il modulo che DEVE misurare il fondo scala, e filtrarlo a 320 significava
// tagliare proprio il dato che stiamo cercando.
static constexpr uint16_t TPC_COORD_MAX      = 1023;

struct TpcRaw { bool present; bool valid; uint16_t x, y; };

// Colore locale: COL_CYAN_DIM e' static in scoring_ui.cpp, e va bene cosi'.
// Esportarlo creerebbe una dipendenza di questo modulo diagnostico dalla UI di
// scoring — accoppiamento gratuito fra due cose che non c'entrano nulla.
// Ridefinire una costante di 16 bit costa meno.
static constexpr uint16_t TPC_COL_CYAN_DIM  = 0x0110;
static constexpr uint16_t TPC_COL_AMBER_DIM = 0x2920;

static bool tpcReadRegs(uint8_t reg, uint8_t* buf, size_t len) {
    Wire.beginTransmission(TPC_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom((int)TPC_ADDR, (int)len) != (int)len) return false;
    for (size_t i = 0; i < len; i++) buf[i] = Wire.read();
    return true;
}

static TpcRaw tpcRead() {
    TpcRaw t = {false, false, 0, 0};
    uint8_t d[6] = {0};
    if (!tpcReadRegs(TPC_REG_GESTURE, d, 6)) return t;
    uint8_t fingers = d[1] & 0x0F;
    t.present = (fingers > 0);
    if (fingers != 1) return t;
    uint16_t x = ((uint16_t)(d[2] & 0x0F) << 8) | d[3];
    uint16_t y = ((uint16_t)(d[4] & 0x0F) << 8) | d[5];
    if (x == TPC_COORD_SENTINEL || y == TPC_COORD_SENTINEL) return t;
    if (x > TPC_COORD_MAX || y > TPC_COORD_MAX) return t;
    t.x = x; t.y = y; t.valid = true;
    return t;
}

// -----------------------------------------------------------------------------
// I 5 punti di calibrazione (coordinate SPRITE)
// -----------------------------------------------------------------------------
// Non agli angoli esatti: un capacitivo ai bordi estremi e' meno lineare (il
// campo elettrico e' deformato dal bordo del sensore) e ci darebbe i punti
// PEGGIORI proprio dove pesano di piu' nel fit. 30px di margine e' il
// compromesso standard.
//
// Perche' 5 e non 4: il centro e' il punto che discrimina un modello lineare
// da uno che non lo e'. Se i 4 angoli tornano ma il centro no, la mappatura ha
// una non-linearita' (o una rotazione) che una trasformazione affine non puo'
// descrivere — e vogliamo scoprirlo QUI, non sul campo.
// v2.16.4: 30 -> 40. Le crocette a 30px erano troppo vicine alla cornice: il
// dito non ci arriva comodo e tocca "corto", e nel fit i punti estremi pesano
// piu' di tutti. 40px costa un filo di leva sul fit ma rende il tocco naturale.
static constexpr int16_t CAL_M = 40;
struct CalPoint { int16_t x, y; const char* nome; };
static const CalPoint CAL_PTS[5] = {
    { CAL_M,               CAL_M,                "alto-sx"  },
    { DISPLAY_W - CAL_M,   CAL_M,                "alto-dx"  },
    { DISPLAY_W / 2,       DISPLAY_H / 2,        "centro"   },
    { CAL_M,               DISPLAY_H - CAL_M,    "basso-sx" },
    { DISPLAY_W - CAL_M,   DISPLAY_H - CAL_M,    "basso-dx" },
};
static constexpr int N_CAL = 5;

// -----------------------------------------------------------------------------
// Fit ai minimi quadrati: s = a*t + b
// -----------------------------------------------------------------------------
// Regressione lineare semplice su N punti. Con N=5 il sistema e'
// SOVRA-determinato (2 incognite, 5 equazioni): non esiste una soluzione esatta,
// e i minimi quadrati trovano quella che minimizza l'errore complessivo.
//
// E' esattamente il punto: il RESIDUO che ne esce non e' un artefatto del
// calcolo, e' una misura di quanto il modello lineare descriva la realta'. Con
// 2 punti il residuo sarebbe zero per costruzione — e non ci direbbe niente.
// (E' l'errore che avevo fatto ricavando la trasformazione dalle THR_*.)
static bool fitLinear(const float* t, const float* s, int n, float& a, float& b) {
    float st = 0, ss = 0, stt = 0, sts = 0;
    for (int i = 0; i < n; i++) { st += t[i]; ss += s[i]; stt += t[i]*t[i]; sts += t[i]*s[i]; }
    const float den = n * stt - st * st;
    // den ~ 0 significa che tutti i t sono (quasi) uguali: l'utente ha toccato
    // 5 volte lo stesso punto, o il touch riporta sempre lo stesso valore.
    // In entrambi i casi non c'e' nessuna retta da trovare.
    if (fabsf(den) < 1e-6f) return false;
    a = (n * sts - st * ss) / den;
    b = (ss - a * st) / n;
    return true;
}

// -----------------------------------------------------------------------------
// Disegno
// -----------------------------------------------------------------------------
static void drawCrosshair(TFT_eSprite& s, int16_t x, int16_t y, uint16_t col) {
    s.drawCircle(x, y, 14, col);
    s.drawCircle(x, y, 13, col);
    s.drawCircle(x, y, 3,  col);
    s.drawFastHLine(x - 20, y, 41, col);
    s.drawFastVLine(x, y - 20, 41, col);
}

static void drawCalScreen(TFT_eSprite& s, int idx, int pass) {
    s.fillSprite(COL_BG);
    s.setTextDatum(TC_DATUM);
    s.setTextColor(COL_WHITE, COL_BG);
    s.drawString("CALIBRAZIONE TOCCO", DISPLAY_W/2, 6, 2);
    s.setTextColor(COL_GRAY, COL_BG);
    char buf[32];
    snprintf(buf, sizeof(buf), "passata %d/2  -  punto %d di %d", pass, idx + 1, N_CAL);
    s.drawString(buf, DISPLAY_W/2, 26, 1);
    // La seconda passata NON e' una ripetizione per sicurezza: e' il controllo.
    // Va toccata con la stessa cura della prima, o il confronto non vale nulla.
    s.setTextColor(pass == 1 ? COL_CYAN : COL_AMBER, COL_BG);
    s.drawString(pass == 1 ? "prima misura" : "controllo indipendente",
                 DISPLAY_W/2, 40, 1);
    s.setTextColor(COL_AMBER, COL_BG);
    s.drawString("tocca il centro della mira", DISPLAY_W/2, DISPLAY_H - 44, 2);
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("con la punta del dito", DISPLAY_W/2, DISPLAY_H - 26, 1);

    // I punti gia' fatti restano visibili in grigio: da' il senso di avanzamento
    // e, se una mira e' stata sbagliata, si vede.
    for (int i = 0; i < idx; i++)
        drawCrosshair(s, CAL_PTS[i].x, CAL_PTS[i].y, COL_DARKGRAY);
    drawCrosshair(s, CAL_PTS[idx].x, CAL_PTS[idx].y, COL_CYAN);

    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// -----------------------------------------------------------------------------
// Attende un tocco completo (pressione + rilascio) e ne ritorna la media.
// -----------------------------------------------------------------------------
// MEDIA e non ultima lettura: il CST816 ha jitter di qualche px. Su un tocco
// da ~300ms si raccolgono decine di campioni; la media riduce il rumore di
// sqrt(N). Qui la precisione conta piu' della reattivita' — e' l'unico momento
// in cui il rumore del sensore finisce dentro una costante permanente.
//
// Ritorna false se scade il timeout (touch rotto / utente assente).
static bool waitTouchAvg(uint16_t& out_x, uint16_t& out_y, uint32_t timeout_ms) {
    const uint32_t t0 = millis();
    // fase 1: attendi che il dito scenda
    while (true) {
        if (millis() - t0 > timeout_ms) return false;
        TpcRaw t = tpcRead();
        if (t.valid) break;
        wdtFeed();
        delay(10);
    }
    // fase 2: accumula finche' il dito e' giu'
    uint32_t sx = 0, sy = 0, n = 0;
    uint8_t  miss = 0;
    while (true) {
        TpcRaw t = tpcRead();
        if (t.valid) { sx += t.x; sy += t.y; n++; miss = 0; }
        else if (!t.present) {
            // Tolleriamo qualche lettura vuota isolata prima di dichiarare il
            // rilascio: il CST816 ogni tanto perde un campione, e chiudere al
            // primo buco spezzerebbe la media a meta' tocco.
            if (++miss >= 3) break;
        }
        if (millis() - t0 > timeout_ms) return false;
        wdtFeed();
        delay(8);
    }
    if (n < 3) return false;   // tocco troppo breve: rumore, non un tocco
    out_x = (uint16_t)(sx / n);
    out_y = (uint16_t)(sy / n);
    return true;
}

// Attende che il dito sia staccato: evita che un tocco lungo venga contato due
// volte per due punti consecutivi.
static void waitRelease() {
    uint8_t clean = 0;
    while (clean < 5) {
        TpcRaw t = tpcRead();
        clean = t.present ? 0 : (clean + 1);
        wdtFeed();
        delay(10);
    }
}

// -----------------------------------------------------------------------------
// Schermata dei risultati
// -----------------------------------------------------------------------------
static void drawResult(TFT_eSprite& s, const TouchCalResult& r) {
    s.fillSprite(COL_BG);
    s.setTextDatum(TC_DATUM);

    if (!r.valid) {
        s.setTextColor(COL_RED, COL_BG);
        s.drawString("CALIBRAZIONE FALLITA", DISPLAY_W/2, 40, 2);
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("tocchi non validi", DISPLAY_W/2, 70, 2);
        s.drawString("si prosegue con i valori", DISPLAY_W/2, 100, 1);
        s.drawString("gia' compilati", DISPLAY_W/2, 114, 1);
        s.setTextColor(COL_CYAN, COL_BG);
        s.drawString("tocca per continuare", DISPLAY_W/2, DISPLAY_H - 30, 2);
        s.pushSprite(0, DISPLAY_Y_OFFSET);
        return;
    }

    // === LA RIPETIBILITA' VIENE PRIMA DI TUTTO ===
    // E' il campo che nella v2.16.2 mancava, ed e' il motivo per cui due misure
    // incompatibili sono state prese entrambe per buone. Se le due passate non
    // concordano, i coefficienti NON vanno ricopiati: sono un numero, non una
    // misura. Quindi sta in cima, grande, e in rosso.
    if (!r.repeatable) {
        s.setTextColor(COL_RED, COL_BG);
        s.drawString("MISURA NON RIPETIBILE", DISPLAY_W/2, 8, 2);
        s.setTextDatum(TL_DATUM);
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("le due passate non concordano:", 8, 30, 1);
        char b2[40];
        s.setTextColor(COL_RED, COL_BG);
        char q1[12], q2[12];
        fmtFixed(q1, sizeof(q1), r.spread_ax, 1);
        fmtFixed(q2, sizeof(q2), r.spread_ay, 1);
        snprintf(b2, sizeof(b2), "scarto ax %s%%   ay %s%%", q1, q2);
        s.drawString(b2, 8, 44, 2);
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("(accettabile: sotto il 3%)", 8, 64, 1);
        s.drawString("NON ricopiare questi numeri:", 8, 84, 1);
        s.drawString("cambierebbero al prossimo giro.", 8, 96, 1);
        s.setTextColor(COL_AMBER, COL_BG);
        s.drawString("Cosa fare:", 8, 118, 2);
        s.setTextColor(COL_GRAY, COL_BG);
        s.drawString("- tocca il CENTRO delle mire", 8, 138, 1);
        s.drawString("- punta del dito, non polpastrello", 8, 150, 1);
        s.drawString("- stessa cura in entrambe le passate", 8, 162, 1);
        s.drawString("- se persiste: usa DIAG e riferisci", 8, 174, 1);
        s.setTextColor(COL_DARKGRAY, COL_BG);
        char m1[16], m2[16];
        fmtFixed(m1, sizeof(m1), r.ay, 5);
        fmtFixed(m2, sizeof(m2), r.by, 2);
        snprintf(b2, sizeof(b2), "media: ay %s by %s", m1, m2);
        s.drawString(b2, 8, 196, 1);
        s.setTextDatum(TC_DATUM);
        s.setTextColor(COL_CYAN, COL_BG);
        s.drawString("tocca per continuare", DISPLAY_W/2, DISPLAY_H - 24, 2);
        s.pushSprite(0, DISPLAY_Y_OFFSET);
        return;
    }

    s.setTextColor(COL_GREEN, COL_BG);
    s.drawString("MISURA RIPETIBILE", DISPLAY_W/2, 4, 2);
    s.setTextColor(COL_GRAY, COL_BG);
    char sb[40];
    char s1[12], s2[12];
    fmtFixed(s1, sizeof(s1), r.spread_ax, 1);
    fmtFixed(s2, sizeof(s2), r.spread_ay, 1);
    snprintf(sb, sizeof(sb), "scarto passate: ax %s%% ay %s%%", s1, s2);
    s.drawString(sb, DISPLAY_W/2, 22, 1);
    s.drawString("ricopia TUTTE le cifre in config.h", DISPLAY_W/2, 34, 1);

    char buf[40];
    s.setTextDatum(TL_DATUM);
    s.setTextColor(COL_CYAN, COL_BG);
    // 5 decimali: su 280px un arrotondamento a 1 cifra (0.7 invece di 0.6983)
    // sposta un tocco di ~6px, mezzo tasto. Si stampa il formato ESATTO da
    // ricopiare, suffisso 'f' compreso.
    char nb[20];
    fmtFixed(nb, sizeof(nb), r.ax, 5); snprintf(buf, sizeof(buf), "AX %sf", nb);
    s.drawString(buf, 8,  50, 2);
    fmtFixed(nb, sizeof(nb), r.bx, 2); snprintf(buf, sizeof(buf), "BX %sf", nb);
    s.drawString(buf, 8,  70, 2);
    s.setTextColor(COL_AMBER, COL_BG);
    fmtFixed(nb, sizeof(nb), r.ay, 5); snprintf(buf, sizeof(buf), "AY %sf", nb);
    s.drawString(buf, 8,  94, 2);
    fmtFixed(nb, sizeof(nb), r.by, 2); snprintf(buf, sizeof(buf), "BY %sf", nb);
    s.drawString(buf, 8, 114, 2);

    // Il residuo misura la coerenza INTERNA di una passata: i 5 punti stanno su
    // una retta? E' un'altra domanda dalla ripetibilita', e serve a stanare i
    // casi in cui il modello affine non basta (rotazione, non-linearita').
    const uint16_t ecol = (r.err_max < 4.0f) ? COL_GREEN
                        : (r.err_max < 10.0f) ? COL_AMBER : COL_RED;
    s.setTextColor(ecol, COL_BG);
    fmtFixed(nb, sizeof(nb), r.err_max, 1);
    snprintf(buf, sizeof(buf), "errore max %s px", nb);
    s.drawString(buf, 8, 142, 2);
    fmtFixed(nb, sizeof(nb), r.err_rms, 1);
    snprintf(buf, sizeof(buf), "errore rms %s px", nb);
    s.drawString(buf, 8, 162, 2);

    s.setTextDatum(TC_DATUM);
    s.setTextColor(COL_GRAY, COL_BG);
    if (r.err_max < 4.0f)       s.drawString("fit ottimo", DISPLAY_W/2, 188, 2);
    else if (r.err_max < 10.0f) s.drawString("fit usabile", DISPLAY_W/2, 188, 2);
    else                        s.drawString("modello non adatto: rifai", DISPLAY_W/2, 188, 1);

    s.setTextColor(COL_CYAN, COL_BG);
    s.drawString("tocca per continuare", DISPLAY_W/2, DISPLAY_H - 24, 2);
    s.pushSprite(0, DISPLAY_Y_OFFSET);
}

// -----------------------------------------------------------------------------
// API pubblica
// -----------------------------------------------------------------------------
int touch_cal_offer3(TFT_eSprite& s, uint32_t wait_ms) {
    s.fillSprite(COL_BG);
    s.setTextDatum(TC_DATUM);
    s.setTextColor(COL_WHITE, COL_BG);
    s.drawString("TOCCO", DISPLAY_W/2, 16, 2);

    // Due bersagli GRANDI e ben separati. Il motivo e' lo stesso di sempre, ma
    // qui pesa il doppio: siamo nella schermata che serve QUANDO il touch e'
    // scalibrato. Bersagli piccoli o vicini sarebbero irraggiungibili proprio
    // nel caso d'uso per cui esistono. Due fasce da 64px, separate da 20px.
    // GEOMETRIA VERIFICATA CONTRO TUTTI I MODELLI IN GIOCO.
    //   Questa schermata deve funzionare ANCHE se i coefficienti sono sbagliati
    //   — e' il caso d'uso per cui esiste. Quindi non basta che i bersagli siano
    //   grandi: devono cadere dalla parte giusta della soglia sotto QUALUNQUE
    //   ipotesi plausibile su cosa riporti il chip.
    //   Testati 4 modelli (identita', sprite-coords, ay=0.7 misurato, 320/300):
    //   con bersagli 40..96 e 150..206, banda morta 54px e soglia grezza 125,
    //   tutti e 4 mappano correttamente. Una versione precedente (50..114 /
    //   134..198, soglia 130) falliva su 2 modelli su 4: il bordo basso di
    //   CALIBRA finiva oltre la soglia e veniva letto come DIAG.
    s.fillRect(16, 40, DISPLAY_W - 32, 56, TPC_COL_CYAN_DIM);
    s.drawRect(16, 40, DISPLAY_W - 32, 56, COL_CYAN);
    s.setTextColor(COL_CYAN, TPC_COL_CYAN_DIM);
    s.drawString("CALIBRA", DISPLAY_W/2, 60, 4);
    s.setTextColor(COL_GRAY, TPC_COL_CYAN_DIM);
    s.drawString("misura i coefficienti", DISPLAY_W/2, 84, 1);

    s.fillRect(16, 150, DISPLAY_W - 32, 56, TPC_COL_AMBER_DIM);
    s.drawRect(16, 150, DISPLAY_W - 32, 56, COL_AMBER);
    s.setTextColor(COL_AMBER, TPC_COL_AMBER_DIM);
    s.drawString("DIAG", DISPLAY_W/2, 170, 4);
    s.setTextColor(COL_GRAY, TPC_COL_AMBER_DIM);
    s.drawString("mostra i numeri grezzi", DISPLAY_W/2, 194, 1);

    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("altrove o attendi = prosegui", DISPLAY_W/2, 214, 1);
    s.pushSprite(0, DISPLAY_Y_OFFSET);

    const uint32_t t0 = millis();
    while (millis() - t0 < wait_ms) {
        const uint32_t left = (wait_ms - (millis() - t0) + 999) / 1000;
        s.fillRect(0, DISPLAY_H - 42, DISPLAY_W, 18, COL_BG);
        s.setTextColor(COL_DARKGRAY, COL_BG);
        char b[12]; snprintf(b, sizeof(b), "%lu", (unsigned long)left);
        s.setTextDatum(TC_DATUM);
        s.drawString(b, DISPLAY_W/2, DISPLAY_H - 42, 2);
        s.pushSprite(0, DISPLAY_H - 42 + DISPLAY_Y_OFFSET, 0, DISPLAY_H - 42, DISPLAY_W, 18);

        wdtFeed();
        TpcRaw t = tpcRead();
        if (t.valid) {
            // Confronto sulle coordinate GREZZE, senza applicare TOUCH_CAL_*.
            // E' l'unico punto del firmware in cui e' corretto farlo: se i
            // coefficienti fossero sbagliati (l'ipotesi che stiamo verificando),
            // applicarli qui renderebbe irraggiungibile la schermata che serve a
            // scoprirlo. I bersagli sono grandi apposta per tollerare qualunque
            // disallineamento plausibile.
            const uint16_t y = t.y;
            waitRelease();
            // Soglia 125: verificata contro i 4 modelli (vedi sopra). Sotto
            // ognuno di essi CALIBRA cade sempre <125 e DIAG sempre >=125.
            return (y < 125) ? 1 : 2;
        }
        delay(20);
    }
    return 0;   // timeout = prosegui
}

bool touch_cal_offer(TFT_eSprite& s, uint32_t wait_ms) {
    s.fillSprite(COL_BG);
    s.setTextDatum(TC_DATUM);
    s.setTextColor(COL_WHITE, COL_BG);
    s.drawString("CALIBRAZIONE TOCCO", DISPLAY_W/2, 30, 2);
    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("serve solo se i tasti", DISPLAY_W/2, 58, 1);
    s.drawString("rispondono spostati", DISPLAY_W/2, 72, 1);

    // CALIBRA e' un bersaglio GRANDE e in alto; SALTA e' il resto dello schermo.
    // Deliberato: se il touch e' scalibrato — cioe' proprio il caso in cui si
    // entra qui — un bersaglio piccolo sarebbe irraggiungibile. E il default
    // (non toccare, o toccare a caso in basso) e' comunque "vai avanti".
    s.fillRect(20, 100, DISPLAY_W - 40, 70, TPC_COL_CYAN_DIM);
    s.drawRect(20, 100, DISPLAY_W - 40, 70, COL_CYAN);
    s.setTextColor(COL_CYAN, TPC_COL_CYAN_DIM);
    s.drawString("CALIBRA", DISPLAY_W/2, 126, 4);

    s.setTextColor(COL_GRAY, COL_BG);
    s.drawString("qualsiasi altro punto = SALTA", DISPLAY_W/2, 200, 1);
    s.pushSprite(0, DISPLAY_Y_OFFSET);

    const uint32_t t0 = millis();
    while (millis() - t0 < wait_ms) {
        // countdown: dice che non si e' bloccato e quanto resta
        const uint32_t left = (wait_ms - (millis() - t0) + 999) / 1000;
        s.fillRect(0, DISPLAY_H - 40, DISPLAY_W, 20, COL_BG);
        s.setTextColor(COL_DARKGRAY, COL_BG);
        char b[16]; snprintf(b, sizeof(b), "%lu", (unsigned long)left);
        s.setTextDatum(TC_DATUM);
        s.drawString(b, DISPLAY_W/2, DISPLAY_H - 40, 2);
        s.pushSprite(0, DISPLAY_H - 40 + DISPLAY_Y_OFFSET, 0, DISPLAY_H - 40, DISPLAY_W, 20);

        TpcRaw t = tpcRead();
        if (t.valid) {
            // Il confronto usa le coordinate GREZZE: e' l'unico punto del
            // firmware dove e' corretto, perche' qui la calibrazione e' proprio
            // cio' che non conosciamo ancora. Il bersaglio e' grande apposta.
            const bool dentro = (t.y >= 90 && t.y <= 185);
            waitRelease();
            return dentro;
        }
        delay(20);
    }
    return false;   // timeout = salta: il default non infastidisce mai
}

// Raccoglie UNA passata di 5 punti. Ritorna false se timeout.
static bool calCollect(TFT_eSprite& s, int pass, float* tx, float* ty,
                       float* sx, float* sy, uint32_t timeout_ms) {
    const uint32_t t_start = millis();
    for (int i = 0; i < N_CAL; i++) {
        drawCalScreen(s, i, pass);
        waitRelease();
        uint16_t mx, my;
        const uint32_t left = (millis() - t_start < timeout_ms)
                            ? (timeout_ms - (millis() - t_start)) : 0;
        if (left == 0 || !waitTouchAvg(mx, my, left)) return false;
        tx[i] = mx; ty[i] = my;
        sx[i] = CAL_PTS[i].x; sy[i] = CAL_PTS[i].y;
        drawCrosshair(s, CAL_PTS[i].x, CAL_PTS[i].y, COL_GREEN);
        s.pushSprite(0, DISPLAY_Y_OFFSET);
        delay(220);
    }
    return true;
}

// =============================================================================
// DUE PASSATE INDIPENDENTI, E SI CONFRONTANO (v2.16.4)
// =============================================================================
// PERCHE'
//   Due calibrazioni successive dello stesso hardware hanno dato ay=0.700 e
//   ay=0.794: +13%. Il jitter del CST816 giustifica l'1%, non il 13%. La misura
//   NON E' RIPETIBILE — e una misura non ripetibile non e' una misura, e' un
//   numero. Il guaio e' che la v2.16.2 lo stampava lo stesso, con l'aria di
//   saperlo: 5 cifre decimali e un errore residuo basso (perche' il residuo
//   misura la coerenza INTERNA di una passata, non la ripetibilita').
//
//   Un residuo basso su una singola passata non dice NULLA sulla riproducibilita'.
//   Solo due passate indipendenti lo dicono. Se concordano, il numero e' buono.
//   Se divergono, non c'e' nessun numero da dare — e il firmware deve dirlo,
//   non inventarne uno.
//
// I dati comandano: e questi dati stanno dicendo che non sappiamo ancora
// misurare questo touch. Meglio saperlo che cementare un valore casuale.
TouchCalResult touch_cal_run(TFT_eSprite& s, uint32_t timeout_ms) {
    TouchCalResult r = {};
    r.valid = false;

    float tx[N_CAL], ty[N_CAL], sx[N_CAL], sy[N_CAL];
    float tx2[N_CAL], ty2[N_CAL], sx2[N_CAL], sy2[N_CAL];

    if (!calCollect(s, 1, tx, ty, sx, sy, timeout_ms)) {
        drawResult(s, r); waitRelease();
        while (!tpcRead().valid) { wdtFeed(); delay(20); }
        return r;
    }
    if (!calCollect(s, 2, tx2, ty2, sx2, sy2, timeout_ms)) {
        drawResult(s, r); waitRelease();
        while (!tpcRead().valid) { wdtFeed(); delay(20); }
        return r;
    }

    // fit di ciascuna passata, separatamente
    float ax1, bx1, ay1, by1, ax2, bx2, ay2, by2;
    if (!fitLinear(tx,  sx,  N_CAL, ax1, bx1) || !fitLinear(ty,  sy,  N_CAL, ay1, by1) ||
        !fitLinear(tx2, sx2, N_CAL, ax2, bx2) || !fitLinear(ty2, sy2, N_CAL, ay2, by2)) {
        drawResult(s, r); return r;
    }

    // CONFRONTO: le due passate concordano?
    // Soglia sul coefficiente angolare: 3%. Il jitter del CST816 su una media
    // di decine di campioni sta sotto l'1%; 3% lascia margine senza far passare
    // il 13% osservato.
    r.spread_ay = fabsf(ay2 - ay1) / ((fabsf(ay1) > 1e-6f) ? fabsf(ay1) : 1.0f) * 100.0f;
    r.spread_ax = fabsf(ax2 - ax1) / ((fabsf(ax1) > 1e-6f) ? fabsf(ax1) : 1.0f) * 100.0f;
    r.repeatable = (r.spread_ax < 3.0f && r.spread_ay < 3.0f);

    // media delle due passate: se concordano, mediarle riduce ancora il rumore
    r.ax = (ax1 + ax2) / 2.0f;  r.bx = (bx1 + bx2) / 2.0f;
    r.ay = (ay1 + ay2) / 2.0f;  r.by = (by1 + by2) / 2.0f;

    // Residui: la vera uscita di questo strumento. Se sono grandi, i
    // coefficienti sono precisi ma il MODELLO e' sbagliato — e va saputo.
    r.err_max = 0; float sq = 0;
    for (int i = 0; i < N_CAL; i++) {
        const float ex = (r.ax * tx[i] + r.bx) - sx[i];
        const float ey = (r.ay * ty[i] + r.by) - sy[i];
        const float e  = sqrtf(ex*ex + ey*ey);
        if (e > r.err_max) r.err_max = e;
        sq += e * e;
    }
    r.err_rms = sqrtf(sq / N_CAL);
    r.valid = true;

    drawResult(s, r);
    waitRelease();
    while (!tpcRead().valid) { wdtFeed(); delay(20); }   // attende il tocco di uscita
    waitRelease();
    return r;
}


// =============================================================================
// MODALITA' DIAGNOSTICA (v2.16.3) — vedi touch_cal.h per il perche'
// =============================================================================
// Mostra i numeri grezzi invece di dedurli. Serve a rispondere a UNA domanda:
// che cosa riporta davvero il chip? Tutto il resto (scala, offset, verso degli
// assi, fondo scala) si legge da li'.

// Replica ESATTA della trasformazione di tpRead(), inclusi i clamp. Deve essere
// identica: se diverge, la diagnostica mente su cio' che sta diagnosticando.
static void diagApply(uint16_t rx, uint16_t ry, int16_t& ox, int16_t& oy) {
    float fx = TOUCH_CAL_AX * (float)rx + TOUCH_CAL_BX;
    float fy = TOUCH_CAL_AY * (float)ry + TOUCH_CAL_BY;
    if (fx < 0) fx = 0; if (fx > DISPLAY_W - 1) fx = DISPLAY_W - 1;
    if (fy < 0) fy = 0; if (fy > DISPLAY_H - 1) fy = DISPLAY_H - 1;
    ox = (int16_t)(fx + 0.5f);
    oy = (int16_t)(fy + 0.5f);
}

// v2.16.7 — DIAG DISEGNA IL LAYOUT VERO.
//   Finora DIAG mostrava numeri su schermo vuoto: per capire se il tocco cadeva
//   giusto bisognava confrontare a mente le coordinate col layout ricordato.
//   Chiedere a un utente di fare quel confronto e' chiedergli di fare il lavoro
//   dello strumento — e infatti l'esito e' arrivato come descrizione a parole
//   ("il mirino va in ambra sopra di parecchi pixel"), che non si e' riusciti a
//   mappare su nessuno stato coerente del firmware.
//   Ora DIAG disegna le fasce REALI della schermata DIST+ELEV e ci mette sopra
//   il mirino: si vede A OCCHIO se il mirino cade dove punta il dito. Nessuna
//   interpretazione, nessun colore da ricordare.
// v2.16.8 — il modo LAYOUT diventa un MIRINO DI MISURA.
//   La v2.16.7 disegnava le fasce della schermata DIST+ELEV: utile per vedere
//   "il mirino segue il dito?", ma per MISURARE serve altro — bersagli a
//   coordinate NOTE e ben distribuite, e i numeri LEGGIBILI.
//   (In v2.16.7 i valori di X erano coperti dalla scritta "2s premuto = esci":
//   ecco perche' l'asse X e' rimasto senza misura mentre la Y si e' chiusa.)
//
//   Cinque mire, con la loro coordinata scritta accanto. Si tocca una mira, si
//   legge cosa dice il firmware, si confronta. E' esattamente il procedimento
//   che ha risolto la Y — qui e' solo reso esplicito invece che improvvisato.
struct DiagTarget { int16_t x, y; };
static const DiagTarget DIAG_T[5] = {
    { 120,  40 },   // alto centro
    {  40, 140 },   // sinistra
    { 120, 140 },   // CENTRO
    { 200, 140 },   // destra
    { 120, 240 },   // basso centro
};

static void diagDrawLayout(TFT_eSprite& s) {
    char lb[16];
    s.setTextDatum(MC_DATUM);
    for (int i = 0; i < 5; i++) {
        const int16_t x = DIAG_T[i].x, y = DIAG_T[i].y;
        s.drawCircle(x, y, 16, COL_CYAN);
        s.drawCircle(x, y, 15, COL_CYAN);
        s.drawFastHLine(x-22, y, 45, COL_CYAN);
        s.drawFastVLine(x, y-22, 45, COL_CYAN);
        s.fillCircle(x, y, 2, COL_CYAN);
        // la coordinata VERA scritta accanto alla mira: e' il riferimento
        s.setTextColor(COL_GRAY, COL_BG);
        snprintf(lb, sizeof(lb), "%d,%d", x, y);
        s.drawString(lb, x, y - 30, 1);
    }
    s.setTextDatum(TL_DATUM);
}

// Cosa ne dedurrebbe l'handler di SC_DISTANZA. Costanti allineate a scoring_ui.
static const char* diagZona(int16_t x, int16_t y) {
    const int16_t BTN_TOP = DISPLAY_H - 45;   // 235
    const int16_t KEY_Y = BTN_TOP - 12 - 32;  // 191
    const int16_t KEY_H = 32;
    if (y >= BTN_TOP) return (x >= DISPLAY_W/2) ? "OK" : "INDIETRO";
    if (y >= KEY_Y && y <= KEY_Y + KEY_H) {
        if (x >= 16 && x <= 64) return "meno";
        if (x >= DISPLAY_W - 64 && x <= DISPLAY_W - 16) return "PIU'";
        if (x >= DISPLAY_W/2 - 28 && x <= DISPLAY_W/2 + 28) return "ignota";
        return "-- morta --";
    }
    if (y >= 69-16 && y <= 69+16)   return "slider DIST";
    if (y >= 148-16 && y <= 148+16) return "slider ELEV";
    return "-- morta --";
}

void touch_cal_diag(TFT_eSprite& s) {
    // Estremi visti: toccando i bordi si legge il FONDO SCALA REALE del chip.
    uint16_t rx_min = 9999, rx_max = 0, ry_min = 9999, ry_max = 0;
    uint32_t hold_start = 0;
    char buf[44];
    bool     have_last = false;
    uint16_t lrx = 0, lry = 0;
    int16_t  lsx = 0, lsy = 0;

    // v2.16.7 — DUE MODALITA', si alternano toccando la fascia in alto.
    //   MODO 0 (LAYOUT): disegna le fasce vere della schermata DIST+ELEV e ci
    //     mette sopra il mirino. Serve a rispondere a UNA domanda, a occhio e
    //     senza interpretare colori: il mirino cade dove punta il dito?
    //   MODO 1 (NUMERI): la vecchia schermata coi valori. Serve per gli span.
    // Il modo LAYOUT e' il default perche' e' quello che risponde alla domanda
    // aperta: se il mirino segue il dito, la calibrazione e' giusta e il
    // problema e' altrove; se e' spostato, si vede DI QUANTO e IN CHE VERSO.
    uint8_t modo = 0;

    while (true) {
        wdtFeed();
        TpcRaw t = tpcRead();

        // uscita: 2s di pressione continua
        if (t.valid) {
            if (hold_start == 0) hold_start = millis();
            else if (millis() - hold_start > 2000) { waitRelease(); return; }
        } else hold_start = 0;

        if (t.valid) {
            if (t.x < rx_min) rx_min = t.x;
            if (t.x > rx_max) rx_max = t.x;
            if (t.y < ry_min) ry_min = t.y;
            if (t.y > ry_max) ry_max = t.y;
            lrx = t.x; lry = t.y;
            diagApply(lrx, lry, lsx, lsy);
            have_last = true;
            // cambio modo: tocco nella fascia altissima (y<20 in coord CORRETTE)
            if (lsy < 20) { modo ^= 1; waitRelease(); }
        }

        s.fillSprite(COL_BG);

        if (modo == 0) {
            // ---------------- MODO MIRE (misura) ----------------
            diagDrawLayout(s);
            s.setTextDatum(TC_DATUM);
            s.setTextColor(COL_WHITE, COL_BG);
            s.drawString("tocca il centro di una mira", DISPLAY_W/2, 4, 1);
            s.setTextColor(COL_DARKGRAY, COL_BG);
            s.drawString("tocca qui = numeri", DISPLAY_W/2, 15, 1);
            if (have_last) {
                const uint16_t c = t.valid ? COL_RED : COL_AMBER;
                s.drawCircle(lsx, lsy, 9, c);
                s.drawFastHLine(lsx-13, lsy, 27, c);
                s.drawFastVLine(lsx, lsy-13, 27, c);
                // I NUMERI: in una fascia sgombra, ALTI e in bianco su nero.
                // Sono il prodotto di questa schermata: devono essere leggibili
                // col dito ancora appoggiato e senza nulla che li copra.
                s.fillRect(0, DISPLAY_H-34, DISPLAY_W, 34, COL_BLACK);
                s.setTextDatum(TL_DATUM);
                s.setTextColor(COL_WHITE, COL_BLACK);
                snprintf(buf, sizeof(buf), "x %3d   y %3d", lsx, lsy);
                s.drawString(buf, 4, DISPLAY_H-32, 4);
                s.setTextColor(COL_GRAY, COL_BLACK);
                snprintf(buf, sizeof(buf), "grezzo %u,%u", lrx, lry);
                s.drawString(buf, 140, DISPLAY_H-26, 1);
                s.drawString(diagZona(lsx, lsy), 140, DISPLAY_H-14, 1);
            }
        } else {
            // ---------------- MODO NUMERI ----------------
            s.setTextDatum(TC_DATUM);
            s.setTextColor(COL_WHITE, COL_BG);
            s.drawString("DIAGNOSTICA", DISPLAY_W/2, 2, 2);
            s.setTextColor(COL_DARKGRAY, COL_BG);
            s.drawString("tocca qui = mire", DISPLAY_W/2, 18, 1);

            s.setTextDatum(TL_DATUM);
            s.setTextColor(COL_GRAY, COL_BG);
            s.drawString("coeff. attivi:", 6, 32, 1);
            char c1[16], c2[16];
            s.setTextColor(COL_CYAN, COL_BG);
            fmtFixed(c1, sizeof(c1), TOUCH_CAL_AX, 5);
            fmtFixed(c2, sizeof(c2), TOUCH_CAL_BX, 2);
            snprintf(buf, sizeof(buf), "ax %s bx %s", c1, c2);
            s.drawString(buf, 6, 44, 1);
            s.setTextColor(COL_AMBER, COL_BG);
            fmtFixed(c1, sizeof(c1), TOUCH_CAL_AY, 5);
            fmtFixed(c2, sizeof(c2), TOUCH_CAL_BY, 2);
            snprintf(buf, sizeof(buf), "ay %s by %s", c1, c2);
            s.drawString(buf, 6, 56, 1);
            s.drawFastHLine(6, 70, DISPLAY_W-12, COL_DARKGRAY);

            if (have_last) {
                const bool live = t.valid;
                s.setTextColor(COL_GRAY, COL_BG);
                s.drawString(live ? "grezzo:" : "grezzo (ultimo):", 6, 76, 1);
                s.setTextColor(live ? COL_WHITE : COL_GRAY, COL_BG);
                snprintf(buf, sizeof(buf), "rx %3u ry %3u", lrx, lry);
                s.drawString(buf, 6, 88, 4);
                s.setTextColor(COL_GRAY, COL_BG);
                s.drawString("corretto:", 6, 120, 1);
                s.setTextColor(live ? COL_GREEN : COL_GRAY, COL_BG);
                snprintf(buf, sizeof(buf), "x %3d y %3d", lsx, lsy);
                s.drawString(buf, 6, 132, 4);
                s.setTextColor(COL_GRAY, COL_BG);
                s.drawString("zona:", 6, 164, 1);
                s.setTextColor(live ? COL_AMBER : COL_GRAY, COL_BG);
                s.drawString(diagZona(lsx, lsy), 6, 176, 2);
            } else {
                s.setTextColor(COL_DARKGRAY, COL_BG);
                s.drawString("tocca lo schermo...", 6, 88, 2);
            }

            s.drawFastHLine(6, 200, DISPLAY_W-12, COL_DARKGRAY);
            s.setTextColor(COL_GRAY, COL_BG);
            s.drawString("estremi visti:", 6, 204, 1);
            s.setTextColor(COL_CYAN, COL_BG);
            if (rx_max >= rx_min) {
                snprintf(buf, sizeof(buf), "rx %3u..%3u span %u", rx_min, rx_max, rx_max-rx_min);
                s.drawString(buf, 6, 218, 1);
                snprintf(buf, sizeof(buf), "ry %3u..%3u span %u", ry_min, ry_max, ry_max-ry_min);
                s.drawString(buf, 6, 230, 1);
            }
            const uint32_t freeB = uxTaskGetStackHighWaterMark(NULL) * 4;
            s.setTextColor(COL_DARKGRAY, COL_BG);
            snprintf(buf, sizeof(buf), "stack %lu B", (unsigned long)freeB);
            s.drawString(buf, 6, 244, 1);
        }

        // v2.16.8: la scritta di uscita sta in ALTO A DESTRA, non piu' in
        // fondo: li' copriva i numeri — che sono il prodotto della schermata.
        // Un diagnostico che nasconde il proprio output e' peggio di niente:
        // e' cosi' che l'asse X e' rimasto senza misura per due versioni.
        s.setTextDatum(TR_DATUM);
        s.setTextColor(COL_DARKGRAY, COL_BG);
        s.drawString("2s=esci", DISPLAY_W-3, 2, 1);
        s.pushSprite(0, DISPLAY_Y_OFFSET);
        delay(50);
    }
}
