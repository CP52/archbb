// =============================================================================
// circular_buffer.cpp — buffer circolare (heap interno o PSRAM)
// =============================================================================
//
// ARCHBB_NO_PSRAM: se definito, usa malloc() su heap interno invece di
// ps_malloc(). Buffer ridotto a 300 campioni (9KB) per stare in DRAM.
// RAM interna disponibile: ~296KB → 9KB = 3% → abbondante.
//
// Quando PSRAM sarà risolta: rimuovere -DARCHBB_NO_PSRAM=1 da platformio.ini
// e riportare CIRCULAR_BUFFER_SIZE a 750.
// =============================================================================

#include "circular_buffer.h"

// Dimensione buffer: 750 con PSRAM, 300 senza
#ifdef ARCHBB_NO_PSRAM
  static constexpr uint16_t BUF_SIZE = 750;  // 750×30B=22KB — heap interno ok
#else
  static constexpr uint16_t BUF_SIZE = CIRCULAR_BUFFER_SIZE;
#endif

static ImuSample* s_buf      = nullptr;
static volatile uint16_t s_write_idx   = 0;
static volatile BufferState s_state    = BUFFER_RUNNING;
static uint16_t s_pre_samples          = 0;
static uint16_t s_post_samples         = 0;
static uint16_t s_shot_id              = 0;
static uint16_t s_trigger_write_idx    = 0;
static volatile uint16_t s_post_count  = 0;
static SemaphoreHandle_t s_mutex       = nullptr;

// =============================================================================
bool circular_buffer_init() {
#ifdef ARCHBB_NO_PSRAM
    // Heap interno — malloc standard
    s_buf = (ImuSample*)malloc(sizeof(ImuSample) * BUF_SIZE);
    DBG("Buffer in heap interno — %u campioni × %u byte = %u byte",
        BUF_SIZE, (unsigned)sizeof(ImuSample),
        (unsigned)(BUF_SIZE * sizeof(ImuSample)));
#else
    // PSRAM
    if (!psramFound()) {
        DBG("ERRORE: PSRAM non trovata — fallback heap interno");
        s_buf = (ImuSample*)malloc(sizeof(ImuSample) * BUF_SIZE);
    } else {
        s_buf = (ImuSample*)ps_malloc(sizeof(ImuSample) * BUF_SIZE);
        DBG("Buffer in PSRAM — %u campioni × %u byte = %u byte",
            BUF_SIZE, (unsigned)sizeof(ImuSample),
            (unsigned)(BUF_SIZE * sizeof(ImuSample)));
    }
#endif

    if (!s_buf) {
        DBG("ERRORE: malloc buffer circolare fallito");
        return false;
    }
    memset(s_buf, 0, sizeof(ImuSample) * BUF_SIZE);

    s_mutex = xSemaphoreCreateMutex();
    if (!s_mutex) { free(s_buf); s_buf = nullptr; return false; }

    s_write_idx  = 0;
    s_state      = BUFFER_RUNNING;
    s_post_count = 0;

    DBG("Circular buffer OK — free heap: %u byte", ESP.getFreeHeap());
    return true;
}

// =============================================================================
void circular_buffer_push(const ImuSample& sample) {
    if (!s_buf) return;
    if (xSemaphoreTake(s_mutex, pdMS_TO_TICKS(1)) != pdTRUE) return;

    switch (s_state) {
        case BUFFER_RUNNING:
            s_buf[s_write_idx] = sample;
            s_write_idx = (s_write_idx + 1) % BUF_SIZE;
            break;
        case BUFFER_FROZEN:
            if (s_post_count < s_post_samples) {
                uint16_t idx = (s_trigger_write_idx + s_post_count) % BUF_SIZE;
                s_buf[idx] = sample;
                s_post_count++;
                if (s_post_count >= s_post_samples) {
                    s_state = BUFFER_READY;
                    DBG("Buffer READY: pre=%u post=%u tot=%u",
                        s_pre_samples, s_post_samples,
                        s_pre_samples + s_post_samples);
                }
            }
            break;
        case BUFFER_READY:
            break;
    }
    xSemaphoreGive(s_mutex);
}

// =============================================================================
void circular_buffer_freeze(uint16_t pre, uint16_t post, uint16_t shot_id) {
    if (!s_buf) return;
    if (xSemaphoreTake(s_mutex, pdMS_TO_TICKS(5)) != pdTRUE) return;
    s_pre_samples       = pre;
    s_post_samples      = post;
    s_shot_id           = shot_id;
    s_post_count        = 0;
    s_trigger_write_idx = s_write_idx;
    s_state             = BUFFER_FROZEN;
    DBG("Buffer FROZEN: shot=%u pre=%u post=%u", shot_id, pre, post);
    xSemaphoreGive(s_mutex);
}

// =============================================================================
uint16_t circular_buffer_get_burst(ImuSample* dst, uint16_t max_samples,
                                   uint16_t* trigger_idx_out) {
    if (!s_buf || !dst) return 0;
    if (xSemaphoreTake(s_mutex, pdMS_TO_TICKS(10)) != pdTRUE) return 0;

    uint16_t total = s_pre_samples + s_post_samples;
    if (total > max_samples) total = max_samples;

    uint16_t start = (s_trigger_write_idx - s_pre_samples + BUF_SIZE) % BUF_SIZE;
    for (uint16_t i = 0; i < total; i++) {
        dst[i] = s_buf[(start + i) % BUF_SIZE];
    }
    if (trigger_idx_out) *trigger_idx_out = s_pre_samples;

    xSemaphoreGive(s_mutex);
    return total;
}

// =============================================================================
void circular_buffer_reset() {
    if (!s_buf) return;
    if (xSemaphoreTake(s_mutex, pdMS_TO_TICKS(5)) != pdTRUE) return;
    s_state      = BUFFER_RUNNING;
    s_post_count = 0;
    xSemaphoreGive(s_mutex);
    DBG("Buffer RESET → RUNNING");
}

BufferState circular_buffer_state()    { return s_state; }
uint16_t    circular_buffer_post_count(){ return s_post_count; }
void        circular_buffer_print_stats() {
    DBG("Buffer: state=%d write=%u post=%u/%u",
        (int)s_state, s_write_idx, s_post_count, s_post_samples);
}

