// =============================================================================
// touch_cal.h — ArchBB: strumento di calibrazione del touch (v2.16.2)
// =============================================================================
//
// PERCHE' ESISTE QUESTO MODULO
//   Sintomo osservato sul campo (v2.16.1): toccando i tasti "+"/"-" la UI
//   reagisce come se si fosse toccato "OK"/"INDIETRO"; lo stesso disallineamento
//   e' presente anche nella schermata ZONA (codice mai modificato), dove pero'
//   non si notava perche' le celle sono enormi (66px) e bastava che il tocco
//   cadesse "dalla parte giusta".
//
//   Quindi: NON e' un bug della geometria nuova. E' una discrepanza fra il
//   sistema di coordinate riportato dal CST816 e quello dello sprite, che
//   esisteva da sempre ed era mascherata dai bersagli grandi. I tasti da 32px
//   della schermata DIST+ELEV l'hanno solo resa visibile.
//
// PERCHE' NON SI E' RICAVATA LA CALIBRAZIONE "A TAVOLINO"
//   Ci ho provato, e va documentato perche' non si ripeta il tentativo:
//
//   [1] Fit sulle soglie THR_* esistenti (THR_Y_TM=68, THR_Y_MB=198):
//       da' y_sprite = 0.538*y_touch + 75.4. Implicherebbe che toccando il
//       BORDO SUPERIORE del pannello lo sprite legga y=75, cioe' un terzo di
//       schermo piu' in basso: fisicamente implausibile per un capacitivo
//       allineato. E il fit e' su DUE punti: due punti danno SEMPRE una retta,
//       ma e' quella vera solo se i punti sono confini geometrici esatti.
//
//   [2] Ipotesi "il touch copre il pannello fisico, lo sprite ha offset 20":
//       prevede y_sprite = y_touch - 20. Verificata contro le THR_*: una soglia
//       torna quasi perfetta (202 vs 198, scarto 4px), l'altra e' fuori di 64px
//       (132 vs 68). Un errore di scala darebbe scarti PROPORZIONALI, uno di
//       offset li darebbe UGUALI: qui non e' ne' l'uno ne' l'altro.
//
//   Conclusione: le THR_* non sono confini geometrici, sono soglie empiriche
//   tarate "finche' funzionava". Non contengono l'informazione che serve.
//   Con due ipotesi incompatibili e zero misure dirette, l'unica cosa onesta e'
//   MISURARE. I dati comandano: non si tara un sistema di coordinate a occhio.
//
// COSA FA
//   Mostra 5 crocette in posizioni note (4 angoli + centro), raccoglie il touch
//   grezzo per ciascuna, calcola la trasformazione affine ai minimi quadrati
//     x_sprite = ax * x_touch + bx
//     y_sprite = ay * y_touch + by
//   e la STAMPA a display, insieme all'errore residuo. I coefficienti si
//   ricopiano a mano in config.h (TOUCH_CAL_*).
//
//   Perche' 5 punti e non 2: con 5 punti il fit e' SOVRA-determinato, quindi
//   l'errore residuo e' una misura della BONTA' del modello, non un numero
//   inventato. Se il residuo e' alto, il modello lineare non basta (rotazione,
//   specchiatura, non-linearita') e lo si scopre SUBITO invece che sul campo.
//
// SI PUO' SEMPRE SALTARE
//   La calibrazione non e' obbligatoria e non blocca mai il dispositivo: c'e'
//   un tasto SALTA sempre visibile, e un timeout automatico. Se si salta, il
//   firmware usa i coefficienti compilati in config.h e funziona esattamente
//   come prima.
//
#pragma once

#include <TFT_eSPI.h>
#include <stdint.h>

// Esito di una sessione di calibrazione.
struct TouchCalResult {
    bool  valid;        // true se i 5 punti sono stati raccolti e il fit e' riuscito
    float ax, bx;       // x_sprite = ax * x_touch + bx
    float ay, by;       // y_sprite = ay * y_touch + by
    float err_max;      // errore massimo residuo (px sprite): coerenza INTERNA
    float err_rms;      // errore RMS residuo (px sprite)
    // v2.16.4 — RIPETIBILITA', che e' un'altra cosa dal residuo.
    //   err_max dice se i 5 punti di UNA passata stanno su una retta.
    //   spread_* dice se DUE passate indipendenti danno la stessa retta.
    //   Un residuo basso con spread alto = "misuro con precisione una cosa
    //   diversa ogni volta": e' esattamente il caso osservato (ay 0.700 vs
    //   0.794, +13%, con residui bassi in entrambe).
    bool  repeatable;   // true se le due passate concordano entro il 3%
    float spread_ax;    // scarto % fra le due passate su ax
    float spread_ay;    // scarto % fra le due passate su ay
};

// Esegue l'intera procedura in modo BLOCCANTE (siamo in boot, nessun task
// concorrente da servire) e ritorna l'esito. Mostra i risultati a display e
// attende un tocco per uscire.
//
// timeout_ms: se l'utente non tocca nulla entro questo tempo, esce con
//             valid=false (comportamento identico a SALTA). Serve a non
//             lasciare mai il dispositivo bloccato in calibrazione, per esempio
//             se il touch e' rotto: sarebbe l'unico caso in cui l'utente non
//             puo' nemmeno premere SALTA.
TouchCalResult touch_cal_run(TFT_eSprite& spr, uint32_t timeout_ms = 60000);

// Mostra la schermata d'ingresso "CALIBRA / SALTA" per qualche secondo.
// Ritorna true se l'utente ha scelto CALIBRA. Se non tocca nulla entro
// wait_ms, ritorna false (= salta) senza infastidire nessuno.
//
// PERCHE' OPT-IN E NON OPT-OUT: la calibrazione e' un'operazione da fare una
// volta, non a ogni accensione. Il default (non toccare nulla) DEVE essere
// "vai avanti come sempre".
bool touch_cal_offer(TFT_eSprite& spr, uint32_t wait_ms = 3000);

// =============================================================================
// MODALITA' DIAGNOSTICA (v2.16.3)
// =============================================================================
// PERCHE' ESISTE
//   Dopo la prima calibrazione i coefficienti misurati (ay=0.700, by=28.08)
//   producono fatti INCOMPATIBILI fra loro:
//     [1] ay=0.7 implica che il touch copra ~400 px per 280 di sprite;
//     [2] ma tpRead() scarta ry>320, quindi y_sprite>252 sarebbe irraggiungibile;
//     [3] eppure OK (y>=235) risponde, mentre "+" (y 191..223, che richiede
//         y_touch 233..278 — ben dentro il range valido) NON risponde.
//   Tre fatti, nessun modello che li spieghi tutti. Vuol dire che una delle
//   assunzioni e' sbagliata, e a tavolino non si scopre quale: le candidate
//   (asse Y invertito, coefficienti non attivi nel binario, ay arrotondato male,
//   ghost e handler che leggono cose diverse) sono tutte compatibili con i
//   sintomi riportati.
//
//   Continuare a costruire modelli sarebbe indovinare. Questa schermata mostra
//   i NUMERI: coordinate grezze del chip, coordinate trasformate, e cosa ne
//   concluderebbe l'handler. Un giro di 30 secondi qui vale piu' di dieci
//   ipotesi.
//
// COSA MOSTRA
//   - rx, ry     : quello che il CST816 riporta, PRIMA di qualunque conversione
//   - x, y       : dopo la trasformazione con i TOUCH_CAL_* compilati
//   - i coefficienti effettivamente attivi nel binario (smaschera il caso in cui
//     non siano stati ricompilati)
//   - la zona che l'handler dedurrebbe da (x,y)
//   - min/max di rx,ry visti finora: tocca i 4 angoli e leggi il fondo scala
//     REALE del chip, che e' il dato che manca a tutti i modelli.
//
// Bloccante, si esce tenendo premuto 2s. Nessun effetto sul resto: e' solo
// lettura.
void touch_cal_diag(TFT_eSprite& spr);

// Schermata d'ingresso a tre esiti (v2.16.3):
//   0 = salta (default: timeout o tocco fuori dai due bersagli)
//   1 = CALIBRA  -> touch_cal_run()
//   2 = DIAG     -> touch_cal_diag()
// Sostituisce touch_cal_offer(), che ne aveva due.
int touch_cal_offer3(TFT_eSprite& spr, uint32_t wait_ms = 3000);
