# ArchBB Firmware — Note di sviluppo e test

## Struttura file

```
archbb_firmware/
├── platformio.ini          # Configurazione build
└── src/
    ├── config.h            # Costanti, UUID, struct, enum
    ├── imu.h / imu.cpp     # Driver QMI8658C 250Hz interrupt
    ├── circular_buffer.h/.cpp  # Buffer PSRAM thread-safe
    ├── trigger.h / trigger.cpp # Algoritmo trigger
    ├── ble_server.h/.cpp   # GATT NimBLE 5 caratteristiche
    ├── display.h / display.cpp # UI TFT ST7789V2
    └── main.cpp            # Setup, FreeRTOS tasks, NVS
```

## Test sequenziale raccomandato (primo flash)

### Step 1 — Verifica alimentazione e I2C
Flash `main.cpp` con tutto disabilitato tranne Serial e I2C scan.
Output atteso su Serial:
```
I2C scan:
  Dispositivo trovato: 0x15  (CST816T touch)
  Dispositivo trovato: 0x51  (PCF85063 RTC)
  Dispositivo trovato: 0x6B  (QMI8658C IMU)
```
Se 0x6B non appare: verificare GPIO35 HIGH e connessioni I2C.

### Step 2 — Verifica IMU a 250Hz
Abilitare solo `imu_task`. Output Serial ogni 1s:
```
IMU seq=250 t=1000120µs ax=0.12 ay=-0.03 az=9.82 gx=0.1 gy=0.0 gz=0.0
```
Az a riposo ≈ ±9.81 m/s² (gravity). Jitter timestamp <200µs.

### Step 3 — Verifica circular buffer
Aggiungere `circular_buffer_init()` e `circular_buffer_print_stats()` ogni 5s.
Output atteso:
```
PSRAM libera: 8323072 byte
Circular buffer OK — 750 campioni × 28 byte = 21000 byte in PSRAM
Buffer stats: state=0 write_idx=1250 post_count=0/0 pre=0
```

### Step 4 — Verifica trigger (senza BLE)
Abilitare `trigger_task`. Colpire il riser o agitare il device.
Output atteso:
```
TRIGGER! shot_id=1 az_peak=-42.15 m/s² ts=15234567µs
Buffer FROZEN — shot_id=1 pre=125 post=62 trigger_idx=...
Buffer READY — burst completo: pre=125 post=62 tot=187
```

### Step 5 — Verifica BLE
Usare nRF Connect (Android) o Web BLE Tester.
Service UUID: `bbarc000-0001-0000-0000-000000000001`
Inviare CMD 0x01 (START_REC), osservare STATUS notify.

## Parametri da calibrare su barebow reale

| Parametro | Default | Range atteso barebow |
|-----------|---------|---------------------|
| trig_threshold_ms2 | 20.0 | 30–80 m/s² |
| trig_confirm_n | 2 | 2–4 campioni |
| rearm_ms | 2000 | 1500–3000 ms |

## Colori display

| Elemento | Colore | RGB565 |
|----------|--------|--------|
| Sfondo | Blu notte | 0x1A1E |
| Primario | Ciano | 0x07FF |
| OK/Armato | Verde lime | 0x07E8 |
| Warning | Ambra | 0xFD40 |
| Errore/SHOT | Rosso | 0xF98B |

