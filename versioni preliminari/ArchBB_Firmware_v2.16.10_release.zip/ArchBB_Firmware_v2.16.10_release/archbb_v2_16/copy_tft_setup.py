# =============================================================================
# copy_tft_setup.py — Pre-build script PlatformIO per TFT_eSPI
# =============================================================================
#
# PROBLEMA:
#   TFT_eSPI cerca User_Setup.h nella propria cartella di libreria
#   (.pio/libdeps/<env>/TFT_eSPI/). Nessun meccanismo basato su percorsi
#   o build_flags funziona in modo cross-platform con PlatformIO, perché
#   la libreria compila nel proprio include context, non in quello del progetto.
#
# SOLUZIONE:
#   Questo script viene eseguito da PlatformIO PRIMA della compilazione
#   (dichiarato come extra_scripts = pre:copy_tft_setup.py in platformio.ini).
#   Copia il nostro User_Setup.h dentro la cartella della libreria TFT_eSPI.
#
# EFFETTO:
#   .pio/libdeps/<env>/TFT_eSPI/User_Setup.h  ← il nostro file
#   Quando TFT_eSPI.h fa #include <User_Setup_Select.h> → #include <User_Setup.h>
#   trova il nostro file perché è nella stessa cartella → tutto risolto.
#
# IDEMPOTENTE: sovrascrive sempre il file (safe per rebuild pulite).
# =============================================================================

Import("env")
import shutil
import os

def copy_user_setup(source, target, env):
    # Percorso del nostro User_Setup.h (nella cartella include/ del progetto)
    project_dir  = env.subst("$PROJECT_DIR")
    src_file     = os.path.join(project_dir, "include", "User_Setup.h")

    # Percorso della libreria TFT_eSPI installata da PlatformIO
    libdeps_dir  = env.subst("$PROJECT_LIBDEPS_DIR")
    env_name     = env.subst("$PIOENV")
    dst_file     = os.path.join(libdeps_dir, env_name, "TFT_eSPI", "User_Setup.h")

    if not os.path.isfile(src_file):
        print(f"[copy_tft_setup] ERRORE: {src_file} non trovato!")
        return

    if not os.path.isdir(os.path.dirname(dst_file)):
        print(f"[copy_tft_setup] WARN: cartella TFT_eSPI non ancora esistente ({dst_file})")
        print("[copy_tft_setup] Verrà copiato al prossimo build dopo download librerie.")
        return

    shutil.copy2(src_file, dst_file)
    print(f"[copy_tft_setup] User_Setup.h copiato in TFT_eSPI/")
    print(f"  src: {src_file}")
    print(f"  dst: {dst_file}")

# Registra la callback: eseguita PRIMA di ogni build
env.AddPreAction("buildprog", copy_user_setup)
# Eseguila anche subito (per il primo build dove buildprog non è ancora schedulato)
copy_user_setup(None, None, env)

