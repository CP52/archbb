# ArchBB v2.11.0 — Fase C: Scoring on-device

## Cosa contiene questa versione
Integrazione completa dello scoring del tiro (esito + zona 3x3 + distanza)
con calcolo degli angoli biomeccanici (cant + alzo) dal burst.

## File NUOVI (Fase C)
- `src/scoring.h`       — struct PendingScore (ponte dati BLE<->display), ble_send_score()
- `src/shot_angles.h/.cpp` — calcolo cant/alzo dalla finestra pre-scocco
- `src/scoring_ui.h/.cpp`  — driver touch CST816T + 3 schermate + sotto-macchina

## File MODIFICATI
- `src/config.h`      — STATE_SCORING, ScorePacket (10 byte), helper flag
- `src/ble_server.cpp`— calcolo angoli a fine burst + ingresso SCORING + ble_send_score()
- `src/display.cpp`   — case STATE_SCORING (delega a scoring_ui_tick) + init touch
- `src/power.cpp`     — STATE_SCORING mantiene backlight ON
- `platformio.ini`    — pin touch TP_RST=13, TP_INT=14, CST816_ADDR=0x15

## Build
```
pio run -t upload
pio device monitor -b 115200
```

## Soglie touch calibrate (già nel codice)
THR_X_LC=89  THR_X_CR=164  THR_Y_TM=68  THR_Y_MB=198

## Cosa testare sul campo
1. Tira → burst normale → dopo BurstEnd deve apparire la schermata ESITO.
2. Tocca MANCATO/COLPITO → griglia zona (SPOT verde al centro se colpito).
3. Tocca una zona → schermata distanza (pulsanti +/-, tacche 18/30/50).
4. CONFERMA → ritorno a CONNECTED, ScorePacket inviato all'app.
5. SKIP in qualsiasi schermata → tiro non valutato, ritorno a CONNECTED.
6. Timeout 30s senza toccare → tiro non valutato, prosegue.

## Note su cosa potrebbe richiedere ritocco (solo estetica)
- Le tinte tenui (COL_RED_DIM ecc.) sono calcolate a mano in RGB565:
  verificare la resa sul display reale, eventualmente ritoccare i valori.
- Celle zona 74px: verificare che stiano bene nei 240px di larghezza.
- Le frecce direzionali sono disegnate con drawLine: valutare la leggibilità.

## Angoli cant/alzo: DA VALIDARE
Sono una stima dalla finestra di stabilita' pre-scocco. Vanno incrociati con lo
scoring reale (dispersione) per verificarne il potere predittivo. I dati comandano.

## v2.11.1 — Fix dopo primo test sul campo (09JUL)
Tre bug corretti dopo la sessione di test:

1. **Blocco USB CDC** (main.cpp): `Serial.setTxTimeoutMs(0)` dopo Serial.begin.
   SINTOMO: scoring e trigger funzionavano solo col monitor seriale aperto, si
   congelavano chiudendolo (Ctrl-C). CAUSA: Serial.printf() su USB CDC blocca il
   task se il buffer TX si riempie e nessuno legge. FIX: scritture non bloccanti
   (i DBG diventano fire-and-forget). Indispensabile per il funzionamento
   standalone a batteria.

2. **Ritorno stato dopo scoring** (scoring_ui.cpp): a fine scoring lo stato
   tornava sempre a CONNECTED, lasciando il device incoerente (REC logicamente
   attivo ma display CONNESSO). FIX: ripristina STATE_RECORDING se il recording
   era abilitato, come faceva la fine burst originale.

3. **Inibizione trigger durante scoring** (ble_server.cpp): un nuovo scuotimento
   durante lo scoring avviava un altro burst (sovrapposizione). FIX: in
   STATE_SCORING il trigger viene scartato (un tiro si valuta prima del
   successivo, coerente col design doc).

## v2.11.2 — Fix bug visivo "+" (10JUL)
Il simbolo "+" del pulsante distanza non appariva (il "-" si': il font 6 di
TFT_eSPI e' solo numerico e non contiene il glifo '+'). FIX: "+" e "-" disegnati
come forme geometriche (fillRect), nitidi e simmetrici, indipendenti dal font.

## v2.11.3 — Timeout scoring resettabile (10JUL)
Il timeout SCORING ora si RESETTA a ogni tocco (non parte dall'ingresso):
finche' l'utente interagisce non scade, cosi' binocolo/telemetro tra un tocco e
l'altro non fanno sparire lo scoring. Portato da 30s a 60s dall'ultimo tocco.
Il firmware invia SEMPRE lo ScorePacket a fine scoring (conferma/SKIP/timeout),
quindi l'app riceve sempre lo score: il suo timeout (ora 180s, v1.22) e' solo
una rete di sicurezza per il caso BLE caduto, non un'attesa attiva.

- config.h: SCORING_TIMEOUT_MS 30000 -> 60000
- scoring_ui.cpp: timeout misurato da s_last_touch_ms, resettato a ogni tap
- app v1.22: SCORE_WAIT_TIMEOUT_MS 35000 -> 180000
