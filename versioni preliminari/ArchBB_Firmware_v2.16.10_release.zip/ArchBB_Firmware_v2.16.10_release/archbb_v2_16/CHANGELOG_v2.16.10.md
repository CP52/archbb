# ArchBB — Firmware v2.16.10 (WS-1.69)

**Tema: ELEVAZIONE del bersaglio nello scoring on-device.**

> **v2.16.1** — revisione ergonomica: pulsanti dimezzati, slider distanziati,
> **ghost del tocco**. Vedi § 11.
>
> **v2.16.2** — il ghost ha fatto il suo lavoro: ha rivelato un **disallineamento
> del touch preesistente**, latente da sempre e mascherato dai bersagli grandi.
> Vedi § 12.
>
> **v2.16.3** — i coefficienti misurati non spiegano i sintomi: modalità
> **DIAG**. Vedi § 13.
>
> **v2.16.4** — la seconda calibrazione ha dato numeri diversi del 13%: **la
> misura non è ripetibile**. Torno all'identità e rendo la calibrazione
> auto-verificante. Vedi § 14.
>
> **v2.16.5** — DIAG resettava al primo tocco: **girava nel posto sbagliato**.
> Vedi § 15.
>
> **v2.16.6** — DIAG ha dato i numeri: il touch è più stretto del display del
> 28%. Vedi § 16.
>
> **v2.16.7** — DIAG disegna il layout vero. Vedi § 17.
>
> **v2.16.8** — asse Y risolto misurando l'errore. Vedi § 18.
>
> **v2.16.9** — anche la X, con lo stesso metodo. Vedi § 19.
>
> **v2.16.10** — **il bug non era il touch.** L'handler aveva le costanti della
> v2.16.0. Vedi § 20.

Accompagna l'app **v1.28**. Firmware e app vanno aggiornati insieme (nuovo
formato ScorePacket), ma le combinazioni miste degradano in modo pulito — vedi
§ Compatibilità.

---

## 1. Cosa cambia per l'arciere

La schermata DISTANZA diventa **DISTANZA + ELEVAZIONE**: due slider sovrapposti
nella stessa schermata. La catena di scoring resta a 4 schermate:

```
ESITO  →  ZONA  →  DIST + ELEV  →  RIEPILOGO
```

Sequenza tipica dopo una lettura al telemetro (es. 27 m, +12°):

1. tap sullo slider distanza a ~27 → `27 m`
2. tap sullo slider elevazione a ~+12 → `+12°`
3. `OK` → riepilogo → `OK`

Tre tocchi per i due dati. Se serve l'aggiustamento fine, i tasti `−` / `+`
agiscono sull'**ultimo slider toccato** (il colore del bordo dice quale:
ciano = distanza, ambra = elevazione).

---

## 2. Perché in una schermata sola (e non una quarta)

I due dati arrivano dallo **stesso gesto**: il telemetro li mostra insieme,
nella stessa lettura, sullo stesso display. Separarli costringerebbe l'arciere a
memorizzare un numero mentre naviga — esattamente il carico cognitivo che lo
scoring on-device esiste per evitare.

### Perché NON il tastierino numerico con codice concatenato (es. `15.07`)

Era l'alternativa in valutazione. Scartata per tre ragioni indipendenti:

| Problema | Dettaglio |
|---|---|
| **Separatore ambiguo** | `15.7` = 7° o 70°? Serve zero-padding obbligatorio, da ricordare col guanto |
| **Segno senza posto** | L'elevazione è bipolare (±30°); un tastierino non ha una casa naturale per il `±` |
| **Costo in tocchi** | `22.02` = 7 tocchi (`2`,`2`,`.`,`0`,`2`, segno, OK) contro i **3** dei due slider |

E il risparmio sarebbe stato illusorio: a valle (firmware, BLE, CSV) i due campi
restano comunque separati. Il codice concatenato sarebbe esistito solo nella
testa dell'utente per 4 secondi — complessità netta senza contropartita.

---

## 3. Perché l'angolo GREZZO e non la distanza compensata

Molti telemetri offrono una modalità *angle compensated* che restituisce
`D·cos α` al posto della distanza inclinata. Archiviare quella sarebbe un
errore, per due ragioni indipendenti.

### [1] La regola del coseno è approssimata per le frecce

La regola classica ("*mira come se il bersaglio fosse a D·cos α*") nasce per la
balistica del **fucile**: tempo di volo ~50 ms, drop trascurabile. Lì
l'approssimazione è ottima.

Per una freccia no. Il drop è `½·g·t²` con `t` misurato lungo la **corda
inclinata** (`t ≈ D/v₀`), non lungo la proiezione orizzontale. La regola del
coseno assume implicitamente `t ≈ D·cos α/v₀` — un tempo di volo più corto di
quello vero — e quindi **sotto-corregge**.

A **30 m / 30°**, con v₀ = 55 m/s:

| Metodo | Drop |
|---|---|
| Nessuna correzione | 145.9 cm |
| Regola del coseno | 109.4 cm |
| Corretta (`t = D/v₀`) | **126.3 cm** |

La regola del coseno sbaglia di **~17 cm**. Su un 3D è la differenza fra il
polmone e la pancia.

Salvando α grezzo, la correzione giusta si può fare — e **ri**-fare — a valle,
nell'app e nel simulatore balistico, senza riflashare il firmware.

### [2] Con α si ottiene una metrica altrimenti impossibile

```
errore di alzo = alzo_cdeg (IMU) − elev_deg (telemetro)
```

Cioè: **di quanto l'arciere ha sbagliato l'inclinazione rispetto al bersaglio
vero**. È l'unica validazione indipendente dell'alzo calcolato dall'IMU. Con la
distanza già compensata questo confronto è impossibile: l'informazione angolare
è stata bruciata dentro un coseno.

Questo, da solo, giustifica la feature più di ogni considerazione balistica.

---

## 4. La sentinella: 0 ≠ "non misurata"

`elev_deg = 0` significa **tiro in piano** — un valore legittimo e
frequentissimo. Non può quindi fare da "non misurato". Stessa lezione già
pagata con `hold_class` / `release_class`, ma qui è **più grave**:

| Metrica | Origine | Se manca nel CSV |
|---|---|---|
| hold, release | IMU | l'app la **ricalcola** dai campioni grezzi |
| **elevazione** | **telemetro + dito dell'arciere** | **persa per sempre** |

Non c'è nessun dato da cui dedurla. Da qui:

- **BLE**: `ELEV_NOT_SET = -128` (unico `int8` fuori dal range ±127: non può mai
  collidere con una misura vera)
- **CSV**: cella **vuota** = mai misurata; `0` = misurata, in piano
- **App**: `elev_fw = null` → badge `∅ elev` nella lista tiri

### `int8` e non `int16`

Range utile ±30° (oltre non si tira sui 3D), risoluzione del telemetro 1°. Un
`int16` spenderebbe un byte per decimali che **lo strumento non produce**.

---

## 5. Protocollo — ScorePacket v4

**16 → 17 byte.** La lunghezza 17 è libera (occupate: 6/8/9/15/16/24/30), quindi
la discriminazione per lunghezza esatta continua a funzionare.
`SCORE_FORMAT_VERSION` 3 → **4**.

```c
struct __attribute__((packed)) ScorePacket {
    uint8_t  pkt_type;      // 0x06
    uint16_t shot_id;
    uint8_t  score_flags;   // bit0 valutato, bit1 colpito, bit2..5 zona
    uint8_t  distanza_m;    // 0 = ignota; 5..60 = metri (INCLINATA, line-of-sight)
    int16_t  cant_cdeg;
    int16_t  alzo_cdeg;
    int16_t  hold_cdeg;     // v2.14
    uint8_t  hold_class;    // v2.14
    uint16_t release_jerk;  // v2.15
    uint8_t  release_class; // v2.15
    int8_t   elev_deg;      // v2.16 ◄── offset 15
    uint8_t  score_ver;     // = 4    ◄── offset 16
};
static_assert(sizeof(ScorePacket) == 17);
```

Verificato con `static_assert` + test C++ sugli offset.

---

## 6. Bug corretto: arrotondamento degli slider (preesistente)

Trovato mentre verificavo la geometria del nuovo slider. **Affliggeva anche la
distanza, da sempre.**

La barra è larga 192 px per 56 valori di distanza (3.43 px/m). Le versioni
≤ 2.15 **troncavano** in entrambe le direzioni (divisione intera C), e i due
troncamenti si **sommano** invece di annullarsi:

> Premi `+` da 20 a 21, la tacca si muove. Tocchi la tacca: rileggi 20.

Sintomo sul campo: *"lo slider scatta indietro da solo"*.

Sull'elevazione sarebbe stato peggio (3.15 px/°): `-2` non era nemmeno
raggiungibile toccando la propria tacca — il round-trip lo mandava a `-3`, fuori
dalla banda di snap.

**Fix**: arrotondamento al più vicino (`+ mezzo divisore` prima di dividere) in
tutte e quattro le mappe. Verificato: round-trip esatto su **tutti** i valori di
entrambi gli slider.

---

## 7. Tre scelte di design non ovvie

| Scelta | Perché |
|---|---|
| **`±` contestuali** | Due coppie di `±` (una per slider) non ci stanno: servirebbero 4 tasti da 48 px in una fascia alta 30. Il focus è mostrato dal colore del bordo: la regola si impara al primo uso |
| **Snap a zero (±2°)** | Il tiro in piano è il caso più frequente. Senza snap un tap impreciso produrrebbe `+1` spuri: rumore che nel gesto reale non esiste, ma che finirebbe nel CSV indistinguibile da una misura vera |
| **Nessun "?" sull'elevazione** | Il suo default ("in piano") è fisicamente sensato; "0 metri" non lo è. Asimmetria voluta: le due grandezze hanno un default naturale diverso |

### E una quarta: nessun `s_last_elev`

La distanza ricorda l'ultimo valore usato (`s_last_distance`), l'elevazione
**no**. Deliberato:

- la **distanza** cambia poco fra tiri consecutivi (stessa piazzola, stessa
  paglia): riproporre l'ultima fa risparmiare tocchi ed è quasi sempre giusta;
- l'**elevazione** è una proprietà del *singolo bersaglio*. Riproporre i `+12`
  del bersaglio precedente su un bersaglio nuovo significherebbe scrivere nel
  CSV una misura mai fatta, indistinguibile da una vera.

Meglio un tocco in più che un dato inventato. *I dati comandano.*

---

## 8. Compatibilità

| Firmware | App | Risultato |
|---|---|---|
| 2.16 | 1.28 | ✅ tutto |
| 2.16 | ≤ 1.27 | pacchetto da 17 byte **ignorato** (lunghezza sconosciuta) → nessuno score. **Aggiornare l'app.** |
| ≤ 2.15 | 1.28 | ✅ score completo, `elev_fw = null` (l'app sa che il fw non lo manda) |

---

## 9. File toccati

| File | Modifica |
|---|---|
| `config.h` | `FW_VERSION_STR` → 2.16.0; `ScorePacket` +`elev_deg` (17 B); `ELEV_MIN/MAX/NOT_SET`; `elevIsSet()`; `SCORE_FORMAT_VERSION` = 4 |
| `scoring.h` | `PendingScore` + `elev_deg` |
| `ble_server.cpp` | init a `ELEV_NOT_SET`; assemblaggio pacchetto; log |
| `scoring_ui.cpp` | schermata a due slider; mappe `elevToX`/`xToElev`; focus contestuale; **fix arrotondamento**; riepilogo con elevazione |

Nessun'altra modifica: `Config`, `ImuSample`, IMU, trigger, burst, batteria,
power — **invariati**.

---

## 10. Da verificare sul campo

1. **Zone tattili dei due slider**: i +14 px attorno all'asse sono comodi col
   guanto? Se no, il gap fra i due slider (38 px) permette di allargare a ±18.
2. **`±` contestuali**: il colore del bordo basta a capire su cosa agiscono, o
   serve un'etichetta esplicita?
3. **Snap a ±2°**: troppo aggressivo? Se i tiri a `+2°` reali sono frequenti,
   scendere a ±1.
4. **Riepilogo**: la riga "elevazione: non impostata" si nota abbastanza da
   accorgersi della dimenticanza *prima* dell'OK?
5. **Il fix di arrotondamento**: verificare che gli slider non "scattino" più.


---

## 11. v2.16.1 — revisione ergonomica

### 11.1 Pulsanti dimezzati e spazio redistribuito

`INDIETRO` / `OK` erano alti **90 px**: mezzo schermo per due azioni che si
fanno una volta per tiro. Portati a **45 px** (~6 mm: comodi anche col guanto).
Restano discriminati per **lato X** — è questo che li ha sempre resi robusti,
non l'altezza.

I ~45 px recuperati **non** diventano spazio vuoto:

| Destinazione | Prima | Dopo |
|---|---|---|
| Separazione fra gli assi degli slider | 66 px | **79 px** |
| Fascia tattile di ogni slider | ±14 px | **±16 px** |
| Zona morta sopra i pulsanti (`BTN_GUARD`) | — | **12 px** |

**Perché distanziare gli slider era la priorità.** Due slider vicini si toccano
per sbaglio l'uno con l'altro, ed è l'errore più costoso qui perché
**silenzioso**: sposti la distanza credendo di spostare l'elevazione, e te ne
accorgi solo al riepilogo — o mai.

**Perché la zona morta.** `OK` cementa lo score. Un tap che scivola di 3 px dal
`+` non deve finirci dentro. Meglio un tocco perso che uno score sbagliato.

### 11.2 Ghost del tocco

Tre comportamenti in uno:

| | Cosa |
|---|---|
| **Live** | anello + crosshair che segue il dito mentre è premuto |
| **Rilascio** | cerchietto pieno, resta 600 ms dove hai staccato |
| **Colore** | ciano/ambra/verde = zona attiva · **rosso = zona morta** |

**Il rosso è la parte importante, ed è uno strumento di taratura, non un
vezzo.** Le soglie touch (`THR_*`) e le fasce Y sono calibrate sul campo, ma il
CST816 può derivare (temperatura, pellicola, guanto). Se tocchi lo slider e vedi
**rosso**, non hai sbagliato mira: è il chip che riporta un'altra coordinata.
Senza feedback quel disallineamento è invisibile e si manifesta solo come *"a
volte non risponde"* — la diagnosi più difficile da fare a posteriori. Col
ghost, il display **dice** dove crede che sia il dito.

> Sul layout attuale il **55.8%** dello schermo è zona morta (verificato pixel
> per pixel). È voluto — è l'effetto di `BTN_GUARD` e delle fasce separate — ma
> senza il ghost quel 56% è invisibile.

### 11.3 Implementazione: due problemi non ovvi

**[a] Il ghost contraddice il modello di rendering.** Il display task gira a
80 ms e ridisegna **solo al cambio di stato** (è il motivo per cui non c'è
flicker). Un ghost che segue il dito deve aggiornarsi a ogni movimento —
l'opposto. Ridisegnare 240×280 via SPI a ogni giro sarebbe lento *e*
flickerante.

**Soluzione: redraw parziale.** Il ghost si disegna sullo sprite, e a schermo va
solo la finestra ~44×44 che lo contiene, con `pushSprite(tx,ty,sx,sy,sw,sh)`.
Per cancellarlo, `ghostRestore()` rigenera lo sprite pulito **in RAM** (invisibile)
e ne spinge la sola porzione sporca. Da qui la separazione
`paintDistanza()` (disegna) / `drawDistanza()` (disegna **e** pusha).

> Misurato su un tap con trascinamento: **34.848 px** spinti via SPI contro
> 1.209.600 del redraw completo — **97.1% risparmiato**.

**[b] Il TFT non è raggiungibile.** Prima idea: disegnare direttamente sul TFT.
Impossibile — `tft` è `static` in `display.cpp`, e `TFT_eSprite::_tft` è
`private`. Renderla globale avrebbe significato **modificare un modulo
collaudato per una feature di UI**: esattamente l'accoppiamento che
l'architettura a moduli separati previene. Disegnando sullo sprite (che arriva
già come parametro) il problema non si pone: **zero righe aggiunte a
display.cpp**.

### 11.4 Il ghost non deve mentire

`ghostZoneColor()` e l'handler `SC_DISTANZA` sono due funzioni separate che
devono concordare: se divergessero, il ghost mostrerebbe verde dove l'handler
non fa nulla — **peggio che non avere il ghost**.

Verificato per costruzione (stesse costanti) e per test: **0 divergenze su
67.200 pixel**.

### 11.5 Da verificare sul campo

1. **Il ghost segue il dito o arranca?** A 12.5 Hz il ritardo è ~80 ms. Se
   risulta scattoso, l'unica leva vera è abbassare il periodo del display task
   in `SC_DISTANZA` (es. 40 ms): il ghost è già a costo quasi nullo.
2. **Il rosso appare dove non te lo aspetti?** → le soglie touch sono da
   ritarare. È il ghost che sta facendo il suo lavoro.
3. **45 px bastano per OK/INDIETRO col guanto?**
4. **Il cerchietto da 600 ms**: troppo persistente durante la regolazione fine
   col `±`?


---

## 12. v2.16.2 — il disallineamento del touch

### 12.1 La diagnosi che il ghost ha permesso

Sintomo riportato: *«tocco su + o su − e salta come avessi toccato OK o
INDIETRO, e lo fa anche nella schermata precedente, mentre colpito/mancato è
così grande che non ce se ne accorge»*.

Quella frase **è** la diagnosi completa:

- **"lo fa anche nella schermata precedente"** → non è un bug della geometria
  nuova. La griglia ZONA non l'ha toccata nessuno.
- **"colpito/mancato è così grande che non ce se ne accorge"** → il difetto è
  **proporzionale alla dimensione del bersaglio**: invisibile su semicampi da
  140 px, tollerabile su celle da 66 px, fatale su tasti da 32 px.

Conclusione: le coordinate del CST816 **non coincidono con quelle dello sprite**,
e non ci coincidevano da sempre. I tasti piccoli l'hanno solo reso visibile.

> Il ghost non ha causato il problema: l'ha **rivelato**. È esattamente il
> motivo per cui era stato messo.

### 12.2 Perché NON ho ricavato la calibrazione a tavolino

Ci ho provato, e va documentato perché non si ripeta il tentativo.

**Tentativo 1 — fit sulle soglie `THR_*` esistenti.** Le quattro soglie
(`THR_Y_TM=68`, `THR_Y_MB=198`, …) sono l'unico dato "misurato" nel file.
Ricavandone la trasformazione:

```
y_sprite = 0.538 × y_touch + 75.4
```

Implicherebbe che toccando il **bordo superiore** del pannello lo sprite legga
y=75 — un terzo di schermo più in basso. Fisicamente implausibile per un
capacitivo allineato. E il fit era su **due punti**: due punti danno *sempre*
una retta, ma è quella vera solo se sono confini geometrici esatti.

**Tentativo 2 — ipotesi "il touch copre il pannello, lo sprite ha offset 20".**
Prevede `y_sprite = y_touch − 20`. Verificata contro le `THR_*`:

| Confine | Previsto | Misurato | Scarto |
|---|---|---|---|
| riga 1/2 | 202 | 198 | **4 px** |
| riga 0/1 | 132 | 68 | **64 px** |

Un errore di **scala** darebbe scarti proporzionali. Un errore di **offset** li
darebbe uguali. Qui non è né l'uno né l'altro: **nessun modello lineare spiega
entrambe le soglie**.

**Conclusione.** Le `THR_*` non sono confini geometrici: sono numeri tarati
*«finché funzionava»*. Con celle da 66 px bastava cadere dalla parte giusta, e
un errore di 20 px non si vedeva. **Non contengono l'informazione che serve.**

Due ipotesi incompatibili e zero misure dirette → non si indovina. **I dati
comandano.**

### 12.3 Lo strumento: calibrazione a 5 punti

Nuovo modulo `touch_cal.h/.cpp`. Al boot, schermata di 3 s:

```
        CALIBRAZIONE TOCCO
   serve solo se i tasti
   rispondono spostati
   ┌───────────────────────┐
   │       CALIBRA         │   ← bersaglio grande, in alto
   └───────────────────────┘
   qualsiasi altro punto = SALTA
```

**Sempre saltabile**: chi non tocca nulla prosegue come sempre. Il default deve
essere *«vai avanti»* — la calibrazione si fa una volta, non a ogni accensione.

> Il tasto CALIBRA è volutamente **enorme e in alto**: se il touch è scalibrato
> — cioè proprio il caso in cui si entra qui — un bersaglio piccolo sarebbe
> irraggiungibile.

Poi 5 crocette (4 angoli + centro), fit ai minimi quadrati, e i coefficienti a
display da ricopiare in `config.h`.

**Perché 5 punti e non 2.** Con 5 il sistema è *sovra-determinato* (2 incognite,
5 equazioni): il residuo che ne esce misura **quanto il modello lineare descriva
la realtà**. Con 2 punti il residuo sarebbe zero *per costruzione* — ed è
esattamente l'errore che avevo fatto al tentativo 1.

Verificato in simulazione:

| Scenario | errmax |
|---|---|
| offset / scala / entrambi | 0.00 px (ricostruzione esatta) |
| jitter CST816 2 px | 2.24 px (degrada in proporzione) |
| **assi scambiati** | **142 px** → *«modello non adatto: rifai»* |

L'ultimo è il punto: se la mappatura avesse una rotazione, la schermata lo
**direbbe**. Un fit a 2 punti no.

**Perché i coefficienti non finiscono in NVS.** NVS+Config arriva in Fase 5 come
store unico; infilarci ora una scrittura separata creerebbe una seconda fonte di
verità da riconciliare dopo. Meglio un ricopiaggio manuale una tantum che un
debito architetturale permanente.

### 12.4 La correzione: un solo punto, il più a monte possibile

La trasformazione si applica **dentro `tpRead()`, una volta sola**. Da lì in poi
tutto il firmware vede coordinate-sprite.

```c
float fx = TOUCH_CAL_AX * rx + TOUCH_CAL_BX;
float fy = TOUCH_CAL_AY * ry + TOUCH_CAL_BY;
```

**Perché nel driver e non negli handler.** Correggere in ogni schermata avrebbe
significato quattro punti da allineare a mano, più uno nuovo per ogni schermata
futura. Ma il bug era latente **proprio perché** ogni schermata aveva le sue
soglie empiriche scollegate: la cura non può essere aggiungerne altre.

**Default = identità** (`ax=1, bx=0, ay=1, by=0`): finché non hai misurato, il
firmware si comporta *esattamente* come la 2.16.1. Meglio il bug noto di una
correzione inventata da noi.

### 12.5 Le soglie `THR_*` sono state rimosse

Sostituite dalla **geometria vera della griglia**, derivata dalle stesse costanti
con cui la griglia viene *disegnata* (`gx=6, gy=44, cell=66, gap=4`). Se un
domani la griglia si sposta, i confini si spostano con lei: non possono
divergere, perché sono la stessa cosa.

Quanto erano sbagliate le vecchie soglie — verificato pixel per pixel:

| | Celle con errori |
|---|---|
| Soglie `THR_*` empiriche | **8 / 9** (fino al **74%** dei pixel di una cella) |
| Geometria derivata | **0 / 9** |

Questo è, misurato, il *«lo fa anche nella schermata precedente»*.

> **Un bug trovato dal test.** La prima formula per i confini
> (`gx + n*(cell+gap) + gap/2`) dava l'**inizio** della cella successiva, non il
> confine: mezzo gap più in là, 5 celle su 9 sbagliate. Corretta in
> `gx + n*cell + (n-1)*gap + gap/2`. Il test esaustivo sulle 9 celle l'ha
> stanata subito — la stessa verifica che sulle vecchie `THR_*` non era mai
> stata fatta.

### 12.6 Procedura consigliata

1. Flasha la **2.16.2** (si comporta come la 2.16.1: default = identità).
2. Al boot tocca **CALIBRA**, fai le 5 crocette.
3. Leggi `AX / BX / AY / BY` e l'**errore max**:
   - **< 4 px** → ottimo;
   - **< 10 px** → usabile (i bersagli più piccoli sono 32 px);
   - **oltre** → il modello affine non basta: rifai, e se persiste **fermati e
     dimmelo** (vorrebbe dire rotazione o non-linearità, e serve un modello
     diverso).
4. Ricopia i 4 numeri in `config.h` → `TOUCH_CAL_*`, riflasha.
5. Verifica col **ghost**: i tocchi devono cadere dove punti, e il rosso apparire
   solo nelle zone morte vere.

Mandami i coefficienti: dicono anche *quale* dei due modelli era giusto — cioè
cosa stava succedendo davvero.


---

## 13. v2.16.3 — quando il modello non regge, si guardano i numeri

### 13.1 I coefficienti misurati

```c
TOUCH_CAL_AX = 1.00598f;   TOUCH_CAL_BX = -13.96f;
TOUCH_CAL_AY = 0.7f;       TOUCH_CAL_BY = 28.08f;
```

**Asse X: plausibile.** `ax ≈ 1.006` (scala giusta), `bx = -14` (offset di
14 px). Un disallineamento semplice.

**Asse Y: due cose non tornano.**

### 13.2 Anomalia 1 — `ay = 0.7` è troppo tondo

Un fit ai minimi quadrati su 5 tocchi reali, col jitter del CST816, produce
`0.6983` o `0.7021`. **Non `0.7000` esatto.** E il sospetto cresce guardandolo
accanto a `ax = 1.00598`, che di cifre ne ha sei.

Sa di valore **troncato o letto male** nel ricopiaggio. Quanto costerebbe: su
280 px, `0.7` invece di `0.6983` sposta un tocco di **~6 px** — mezzo tasto.

> **Corretto in questa versione**: la schermata dei risultati ora stampa **5
> decimali** e il formato esatto da ricopiare, suffisso `f` compreso
> (`AY 0.69831f`). Con 4 decimali l'errore sarebbe 0.03 px — irrilevante. Con 1
> è mezzo tasto.

### 13.3 Anomalia 2 — tre fatti che non stanno insieme

| | Fatto |
|---|---|
| **[1]** | `ay = 0.7` implica che il touch copra ~400 px per 280 di sprite |
| **[2]** | ma `tpRead()` scarta `ry > 320` → `y_sprite > 252` sarebbe **irraggiungibile** |
| **[3]** | eppure **OK** (y≥235) risponde, mentre **"+"** (y 191..223, che richiede `y_touch` 233..278 — *dentro* il range valido) **non** risponde |

Tre fatti, **nessun modello che li spieghi tutti**. Ho provato: ogni ipotesi ne
spiega due su tre.

Le candidate rimaste sono tutte compatibili coi sintomi:

- asse Y invertito (il chip conta dal basso);
- coefficienti non attivi nel binario flashato;
- `ay` arrotondato male (§ 13.2);
- ghost e handler che leggono cose diverse.

**Non si distinguono a tavolino.** Continuare a costruire modelli sarebbe
indovinare — e i dati comandano.

### 13.4 DIAG: i numeri invece delle ipotesi

Nuova schermata al boot (`DIAG`, accanto a `CALIBRA`). Mostra:

| Campo | A cosa serve |
|---|---|
| `rx`, `ry` **grezzi** | cosa riporta il CST816 *prima* di ogni conversione |
| `x`, `y` trasformati | dopo i `TOUCH_CAL_*` |
| **coefficienti attivi** | smaschera il caso "non ho ricompilato" |
| zona dedotta | cosa ne concluderebbe l'handler |
| **min/max di `rx`,`ry`** | tocca i 4 angoli → **il fondo scala vero del chip** |

L'ultima riga è la più importante: **nessun modello sapeva** se questo CST816
riporti 0..240/0..280, 0..320, o altro. Trenta secondi in DIAG valgono più di
dieci ipotesi.

### 13.5 La schermata deve funzionare col touch rotto

`offer3` ha due bersagli, e la sua geometria è **verificata contro tutti e
quattro i modelli in gioco** — perché è la schermata che serve *quando* i
coefficienti sono sbagliati.

> **Bug trovato dal test.** La prima geometria (CALIBRA 50..114, DIAG 134..198,
> soglia 130) falliva su **2 modelli su 4**: il bordo basso di CALIBRA finiva
> oltre la soglia e veniva letto come DIAG. Corretta in 40..96 / 150..206, banda
> morta 54 px, soglia 125 — verificata OK su tutti e quattro.

Il confronto in `offer3` usa le coordinate **grezze**, senza applicare
`TOUCH_CAL_*`: è l'unico punto del firmware dove è corretto, perché applicare
coefficienti sospetti renderebbe irraggiungibile la schermata che serve a
scoprirli.

### 13.6 Cosa fare adesso

1. Flasha la **2.16.3** (i tuoi coefficienti sono già dentro come default).
2. Al boot → **DIAG**.
3. **Controlla i coefficienti attivi** in cima: se non sono `1.00598 / -13.96 /
   0.7 / 28.08`, il binario non è quello che credi → ricompila.
4. **Tocca i 4 angoli estremi** e leggi `rx`/`ry` min/max in fondo. Questo è il
   fondo scala vero.
5. **Tocca il "+"** e leggi le tre righe: `ry` grezzo, `y` trasformato, zona
   dedotta.

Mandami: **span di rx/ry ai 4 angoli**, e la terna `ry` / `y` / zona quando
tocchi il `+`. Con quei numeri il modello si chiude in un colpo — senza più
ipotesi.

> **Sul "mirino bianco"**: `ghostZoneColor()` non restituisce mai bianco (solo
> ciano, ambra, verde, grigio, rosso). `COL_AMBER = 0xFD40` è però molto chiaro:
> un anello sottile può leggersi bianco. Se in DIAG il crosshair rosso cade dove
> punti il dito, il ghost è a posto e il problema è a valle.


---

## 14. v2.16.4 — una misura che non si ripete non è una misura

### 14.1 Il dato che chiude la questione

Due calibrazioni dello **stesso hardware**:

| | giro 1 | giro 2 | scarto |
|---|---|---|---|
| `ax` | 1.00598 | 1.09105 | **+8.5%** |
| `ay` | 0.70000 | 0.79412 | **+13.4%** |
| `by` | 28.08 | 29.78 | +6.1% |

Un fit ripetuto sullo stesso sistema deve dare quasi lo stesso risultato: il
jitter del CST816 produce variazioni dell'**1%**, non del **13%**.

**La misura non è ripetibile.** Nessuno dei due valori è affidabile, e
metterne uno in produzione significherebbe cementare un numero casuale.

> Il primo `0.7` non era nemmeno un troncamento del secondo: `0.79412` troncato
> a una cifra dà `0.8`, non `0.7`. Erano due misure genuinamente diverse.

### 14.2 Cosa aveva riportato il chip

Invertendo i due fit (`ry = (y_sprite − by) / ay`):

| crocetta | giro 1 | giro 2 |
|---|---|---|
| y=30 | ry ≈ 3 | ry ≈ 0 |
| y=250 | ry ≈ **317** | ry ≈ 277 |
| **span** | **314** | **277** |

Due span diversi per gli stessi due punti fisici: **impossibile**, a meno che
qualcosa non falsi la lettura.

### 14.3 Il colpevole: un filtro che scartava in silenzio

```c
static constexpr uint16_t TP_COORD_MAX = 320;   // "controller 240x320"
if (rx > TP_COORD_MAX || ry > TP_COORD_MAX) return t;   // scarta
```

Il giro 1 ha prodotto **ry = 317** — a tre pixel dal limite. Le letture appena
oltre venivano **buttate senza dirlo**, e il fit lavorava su dati troncati senza
saperlo. È esattamente così che si ottengono due misure diverse dello stesso
sistema.

**Corretto**: il limite sale a 1023 (fondo scala 10 bit). Il fondo scala vero del
chip **non è noto** — è il dato che DIAG deve misurare. Finché non lo è, l'unico
valore da scartare è la sentinella `4095` (lettura sporca).

### 14.4 Perché il residuo non aveva protetto da niente

La v2.16.2 stampava 5 decimali e un errore residuo basso. Sembrava una misura
solida. Non lo era, e il motivo è concettuale:

| | Domanda a cui risponde |
|---|---|
| `err_max` (residuo) | i 5 punti di **una** passata stanno su una retta? |
| `spread` (nuovo) | **due** passate danno la **stessa** retta? |

Sono domande diverse. Entrambi i giri avevano residuo basso: **misuravano con
precisione una cosa diversa ogni volta**.

> Avevo costruito uno strumento che misurava la propria coerenza interna e la
> spacciava per affidabilità. Il residuo basso mi aveva convinto — ed è il
> motivo per cui ho preso per buono `ay=0.7` abbastanza da suggerirti di
> ricopiarlo.

### 14.5 La calibrazione ora si verifica da sola

**Due passate indipendenti**, poi confronto:

- **concordano entro il 3%** → `MISURA RIPETIBILE`, coefficienti mediati (il
  che riduce ulteriormente il rumore);
- **divergono** → `MISURA NON RIPETIBILE` in rosso, con lo scarto misurato e
  **l'istruzione esplicita di non ricopiare i numeri**.

Verificato: il criterio **boccia** i due giri reali (8.5% / 13.4%) e **passa** il
jitter normale (1–2%).

Altre correzioni:

- **crocette da 30 → 40 px dal bordo**: a 30 px erano troppo vicine alla
  cornice, il dito non ci arriva comodo. Nel fit i punti estremi pesano più di
  tutti.
- **DIAG mostra `ay` atteso**: dallo span di `ry` misurato ai bordi calcola
  quanto *dovrebbe* venire. Se lo span arriva a ~320 → `ay ≈ 0.875`; se a ~280 →
  `ay ≈ 1.0`.

### 14.6 Torno all'identità

```c
TOUCH_CAL_AX = 1.0f;  TOUCH_CAL_BX = 0.0f;
TOUCH_CAL_AY = 1.0f;  TOUCH_CAL_BY = 0.0f;
```

Il firmware si comporta come la 2.16.1: il bug del touch torna, **prevedibile**.
È preferibile a una correzione basata su un numero che cambia a ogni giro.

### 14.7 Cosa serve adesso

Il dato che manca a **tutti** i modelli è uno solo: **il fondo scala vero del
chip**.

1. Flasha la **2.16.4** (identità: nessuna correzione attiva, nessuna
   retroazione possibile).
2. Boot → **DIAG**.
3. Tocca **il bordo più in alto** e **il bordo più in basso** che riesci a
   raggiungere, poi **sinistra** e **destra**.
4. Leggi le due righe in fondo:
   ```
   rx  ___..___  span ___
   ry  ___..___  span ___
   -> ay atteso _____
   ```

Mandami quei sei numeri. Con lo span reale il modello si chiude senza più
ipotesi — e sapremo se `ay` deve essere 0.875, 1.0, o altro ancora.

> Se poi vuoi ritentare la calibrazione, ora ti dirà lei se la misura tiene.


---

## 15. v2.16.5 — DIAG resettava al primo tocco

### 15.1 L'errore

Avevo agganciato la calibrazione dentro **`display_init()`**, chiamata da
`setup()` in `main.cpp`. Quel codice gira nel contesto del **loopTask di
Arduino**; DIAG è bloccante per costruzione (ci si sta anche minuti).

**Spostata dentro `display_task`**, che per progetto vive già in un loop infinito
ed è il task che *possiede* display e touch. È il posto naturale — averlo messo
altrove era una svista.

### 15.2 Il sintomo diceva "primo tocco", e quello indirizza

Il reset arrivava **al primo tocco**, mai prima. Non è casuale: il primo tocco è
l'unico momento in cui si esegue il ramo che **formatta e stampa i valori** —
la parte più profonda della catena di chiamate. Prima del tocco gira solo il
ramo *"tocca lo schermo..."*, che non formatta nulla.

Questo punta allo **stack**. Il budget di `display_task`:

```
DISPLAY_TASK_STACK = 3072 byte   (platformio.ini)
```

Stima di quanto aggiunge `touch_cal`: ~1360 B sopra il baseline di ~1500 B →
**~212 B di margine**. Dentro l'incertezza delle stime (TFT_eSPI è imprevedibile).

> **Onestà: non l'ho provato.** `display.cpp` usa `snprintf("%f")` da sempre
> (righe 191, 244, 277, 532) e non è mai crashato — quindi `%f` *da solo* non
> sfonda 3072 B, e la mia prima stima (1400 B per chiamata) era gonfiata:
> newlib-nano su ESP32 è molto più parsimonioso. Lo stack resta però l'unica
> risorsa che il mio codice consuma più del resto.

### 15.3 Tre difese, invece di una scommessa

| | |
|---|---|
| **Stack 3072 → 6144** | costa 3 KB di RAM su ~300 KB liberi: niente |
| **Niente `snprintf("%f")`** | 14 chiamate sostituite da `fmtFixed()`, aritmetica intera, zero stack |
| **Watermark a schermo** | DIAG mostra `stack libero NNNN B` |

L'ultima è la più importante: **trasforma l'ipotesi in misura**.
`uxTaskGetStackHighWaterMark()` ritorna il minimo spazio libero mai visto dal
task. Se compare un numero basso (<512 B, mostrato in rosso), lo stack *era*
davvero il collo di bottiglia. Se resta alto, il reset ha un'altra causa e la
cerchiamo altrove — con un dato, non con un'ipotesi.

### 15.4 Sul watchdog: non era lui

Verificato nel tuo `sdkconfig.defaults`:

```
CONFIG_ESP_TASK_WDT_PANIC=n        <- il TWDT logga, non resetta
CONFIG_ESP_INT_WDT_TIMEOUT_MS=800  <- l'IWDT sorveglia le sezioni critiche
```

Il TWDT non poteva resettare (panic già disabilitato in v2.10.x), e l'IWDT
sorveglia gli interrupt disabilitati — cosa che `delay(50)` non fa. Ho comunque
aggiunto `wdtFeed()` nei loop bloccanti, difensivamente: costa una chiamata
innocua e protegge dal caso in cui un domani qualcuno registri `display_task` al
TWDT senza ricordarsi di questo modulo.

### 15.5 Anche: i numeri restano a schermo

Difetto ovvio a posteriori, invisibile finché non lo usi: DIAG mostrava i valori
**solo mentre il dito era premuto** — cioè mentre il dito copriva lo schermo. Per
leggerli bisognava staccare, e staccando sparivano.

Ora l'ultima lettura **resta**, in grigio (dato congelato) invece che acceso
(live). Tocchi il bordo, alzi il dito, leggi.

### 15.6 Cosa fare

1. Flasha la **2.16.5**.
2. Boot → **DIAG**.
3. **Guarda `stack libero`** in basso: se è rosso o sotto ~500 B, lo stack era il
   problema — dimmelo.
4. Tocca i **4 bordi estremi**, alza il dito, leggi:
   ```
   rx  ___..___  span ___
   ry  ___..___  span ___
   -> ay atteso _____
   ```

Quei sei numeri chiudono il modello del touch. `ay atteso` è calcolato dallo span
reale: dice quanto *dovrebbe* venire la calibrazione.


---

## 16. v2.16.6 — caso chiuso: era l'asse X

### 16.1 I numeri di DIAG

```
rx:  31..203   span 172      <- lo schermo è largo 240
ry:   1..278   span 277      <- lo schermo è alto  280
stack libero: 16496 B
```

Tre risposte in tre righe.

### 16.2 L'asse Y era già perfetto

`ry 1..278` su 280 px: **il chip riporta già coordinate-sprite, 1:1**, senza
offset.

Tutti i modelli tentati a tavolino erano sbagliati:

| Ipotesi | Verdetto |
|---|---|
| offset 20 (`by = −20`) | ✗ |
| scala 320/280 (`ay = 0.875`) | ✗ |
| `ay = 0.70` (giro 1) | ✗ |
| `ay = 0.79` (giro 2) | ✗ |

**Su Y non c'era niente da correggere.** Le due calibrazioni che davano 0.70 e
0.79 misuravano rumore — ed è per questo che non erano ripetibili. Il criterio
introdotto in v2.16.4 le avrebbe bocciate entrambe.

### 16.3 L'asse X è compresso del 28% — ed era lui

`rx 31..203` su 240 px: **il sensore capacitivo è fisicamente più stretto del
display**. Copre ~172 px dei 240 del vetro, centrato (margini 31 px a sinistra,
37 a destra).

**Il bug, finalmente:**

> Il tasto `+` è disegnato a **x 176..224**. Toccandolo al centro (x≈200 sul
> vetro), il chip riportava **rx ≈ 175**. La fascia parte da 176.
> **Fuori per un pixel.**

Stessa sorte per il `-`. Ecco il *«tocco + e non fa quello che deve»*.

E spiega anche perché è rimasto invisibile per versioni e versioni: con
bersagli da 140 px (semicampi ESITO) o 66 px (celle ZONA), il 28% di
compressione non bastava a mancarli. Serviva un tasto da 48 px per rivelarlo.

### 16.4 Perché questi numeri sono affidabili

Non vengono da un fit su 5 tocchi: vengono dagli **estremi misurati**, che sono
un dato fisico del sensore. Tre controprove indipendenti:

1. **Su Y hai raggiunto `ry=1` e `ry=278`** — i bordi veri. Sai toccare i bordi,
   quindi i margini in X non sono errori di mira.
2. **I margini X (31 e 37) sono quasi simmetrici** — è la firma di un sensore
   centrato. Errori di mira darebbero margini casuali.
3. **Con i coefficienti tutti i tasti rientrano**: `-` serve rx 42..77, `?`
   97..137, `+` 158..192 — tutti dentro 31..203.

### 16.5 I coefficienti

```c
static constexpr float TOUCH_CAL_AX = 1.38953f;   // X: espande del 28%
static constexpr float TOUCH_CAL_BX = -43.08f;
static constexpr float TOUCH_CAL_AY = 1.00722f;   // Y: praticamente identità
static constexpr float TOUCH_CAL_BY = -1.01f;
```

Già dentro il firmware. Verifica della raggiungibilità dopo la correzione:

| Elemento | Raggiungibile |
|---|---|
| `−` / `?` / `+` | 100% |
| slider | 100% |
| INDIETRO / OK | 100% / 99% |
| celle ZONA | 100% |

**Il layout non va toccato.**

### 16.6 Il vincolo hardware da ricordare

> **I ~30 px ai bordi sinistro e destro del display non sono fisicamente
> sensibili.** Stirare con `ax=1.39` li rende indirizzabili in teoria, ma il
> vetro lì non sente.

Non mettere mai bersagli a meno di ~30 px dai bordi laterali. È un vincolo
**hardware**, non software — e nessuna calibrazione lo può aggirare. (In Y il
problema non esiste: il sensore copre tutto.)

### 16.7 Lo stack non era il problema

`stack libero: 16496 B`. Ipotesi **smentita** — e va bene così: era un'ipotesi
dichiarata tale, e la misura l'ha chiusa in un secondo. Il reset di DIAG era
solo la posizione sbagliata (`display_init` invece di `display_task`), corretta
in v2.16.5.

Le difese aggiunte (stack 6144, niente `%f`) restano: non fanno danno e
irrobustiscono un modulo diagnostico che deve funzionare quando il resto non
funziona.

### 16.8 (superata dalla v2.16.7 — vedi § 17)

### 16.8bis La lezione

Cinque versioni per un bug che i numeri hanno risolto in tre righe. Ho costruito
quattro modelli a tavolino — **tutti sbagliati**, e tutti su Y, mentre il
problema era su X.

Il metodo ha funzionato solo quando ha smesso di dedurre e ha misurato: prima il
ghost (che ha rivelato il difetto), poi DIAG (che l'ha quantificato). *I dati
comandano* non è uno slogan: è ciò che ha chiuso la questione dopo che il
ragionamento aveva fallito quattro volte.

### 16.9 Cosa fare

1. Flasha la **2.16.6**.
2. Vai in scoring, schermata DIST+ELEV.
3. **Premi `+` e `-`**: devono rispondere.
4. **Guarda il ghost**: il crosshair deve cadere sotto il dito, e il rosso
   apparire solo nelle zone morte vere.
5. Riprova anche **ZONA** — era rotta pure lei (8 celle su 9), ora la griglia usa
   la geometria vera *e* la correzione.


---

## 17. v2.16.7 — il modello dice che funziona, l'hardware dice di no

### 17.1 Lo stato

Confermato: la **2.16.6 è flashata** e i coefficienti sono **attivi**
(`1.38953 / -43.08 / 1.00722 / -1.01`, letti in DIAG).

E il tocco sbaglia ancora: `+` → OK, `-` → INDIETRO.

Sulla carta non è possibile. Rifacendo i conti con i coefficienti attivi:

| tocco | chip riporta | dopo correzione | zona |
|---|---|---|---|
| `+` (x≈200, y≈207) | rx=175, ry=207 | x=200, y=207 | **`+` ✓** |

**Il modello dice che funziona. L'hardware dice di no.** Quando modello e realtà
divergono, è il modello a essere sbagliato — e il mio si regge su un'assunzione
mai verificata: che gli span `rx 31..203 / ry 1..278` corrispondano ai bordi
fisici del vetro.

### 17.2 Perché non deduco oltre

La descrizione più precisa che ho è: *«tocco lo slider distanza e il mirino va
in ambra sopra di parecchi pixel»*.

Non riesco a mapparla su nessuno stato coerente del firmware:

- **ambra** = slider ELEVAZIONE, che sta **sotto** la distanza (y 148 vs 69).
  Se il firmware leggesse 148 col dito a 69, il mirino apparirebbe **più in
  basso**, non sopra.
- se il mirino fosse davvero **sopra** (y 20..50), quella è zona morta → sarebbe
  **rosso**, non ambra.

Le due cose non stanno insieme. Sto interpretando parole invece di leggere
numeri — l'errore che ho già fatto **quattro volte** in questa vicenda, sempre
con lo stesso esito.

Un fatto però è solido: `ghostZoneColor()` e l'handler sono verificati coincidere
su **67.200 pixel su 67.200**. Il ghost **non mente**: se il mirino è ambra,
l'handler *sta davvero leggendo* lo slider elevazione. Quindi sono le coordinate
a essere sbagliate — e i dati DIAG dicono di no.

### 17.3 DIAG ora disegna il layout vero

L'errore di progettazione di DIAG: mostrava numeri su **schermo vuoto**. Per
capire se il tocco cadeva giusto bisognava confrontare a mente le coordinate col
layout ricordato — cioè **chiedere all'utente di fare il lavoro dello
strumento**. Ed è per questo che l'esito è arrivato come descrizione a parole,
non come misura.

Ora DIAG ha **due modalità**, si alternano toccando la fascia in alto:

| Modo | Cosa mostra |
|---|---|
| **LAYOUT** (default) | le fasce **vere** della schermata DIST+ELEV, col mirino sopra |
| **NUMERI** | `rx/ry` grezzi, `x/y` corretti, zona, span, stack |

Il modo LAYOUT risponde a una domanda sola, **a occhio, senza interpretare
colori**: *il mirino cade dove punta il dito?*

- **sì** → la calibrazione è giusta e il problema è a valle (nell'handler o nel
  layout);
- **no** → si vede **di quanto** e **in che verso**, e quello è il dato che
  chiude il modello.

In basso, una riga sola: `ry NNN -> y NNN : zona`.

### 17.4 Cosa serve

1. Flasha la **2.16.7**.
2. Boot → **DIAG** (si apre già in modo LAYOUT).
3. **Tocca il rettangolo `+`** in basso a destra, poi lo **slider `dist`** in
   alto.
4. Guarda **dove appare il mirino rispetto al dito**.

Dimmi solo questo:

- il mirino è **sotto il dito** o **spostato**? Se spostato: **in che verso** e
  **di quanto** (metà schermo? un dito?);
- la riga in basso, quando tocchi il `+`: `ry ___ -> y ___ : ______`.

Con quella riga il caso si chiude. Se il mirino segue il dito ma il `+` non
risponde, il problema non è mai stato il touch — ed è un'altra indagine, molto
più corta.


---

## 18. v2.16.8 — l'asse Y è risolto (misurando l'errore, non deducendolo)

### 18.1 I numeri che hanno chiuso la Y

Bersagli a coordinata **nota**, letture riportate da DIAG:

| bersaglio | y vero | y letto | errore |
|---|---|---|---|
| slider distanza | 69 | 40 | **−29** |
| slider elevazione | 148 | 153 | **+5** |
| tasto `?` | 207 | 227 | **+20** |
| tasto `+` | 207 | 233 | +26 |
| tasto `−` | 207 | 222 | +15 |

Il pattern è inequivocabile: **negativo in alto, ~zero a metà, positivo in
basso**. Non è un offset (darebbe errore costante), non è uno specchiamento: è
un **guadagno eccessivo** attorno a un punto fisso.

> L'hai detto guardando lo schermo, prima che i conti lo confermassero:
> *«c'è troppo guadagno»*. E *«al centro tocco e mirino coincidono, ai bordi
> divergono»* — è la definizione stessa del fenomeno.

### 18.2 La correzione

Fit sui tre punti:

```
y_letto = 1.3592 · y_vero − 52.10
```

Invertito e composto coi coefficienti allora attivi (`AY=1.00722`):

```c
TOUCH_CAL_AY = 0.74103f;   // era 1.00722
TOUCH_CAL_BY = 37.59f;     // era -1.01
```

Verifica sui punti misurati:

| bersaglio | prima | dopo | errore |
|---|---|---|---|
| 69 | 40 | **68** | −1.2 |
| 148 | 153 | **151** | +2.9 |
| 207 | 227 | **205** | −1.7 |

**±3 px** — il bersaglio più piccolo è alto 32. E il `+`, che finiva su
`OK/INDIETRO`, torna nella propria fascia.

### 18.3 Quello che non spiego

`1.359` è quasi identico ad `AX = 1.38953` (2% di scarto). **Non ho una
spiegazione** del perché il guadagno in Y somigli tanto al coefficiente X — il
codice applica `AX` a `rx` e `AY` a `ry`, verificato, nessuno scambio.

**E non ne invento una.** Ogni volta che in questa vicenda ho spiegato prima di
misurare ho sbagliato: sei modelli, sei smentite. Questi valori riproducono i
punti misurati, e tanto basta finché una misura non li smentisce.

### 18.4 L'asse X è ancora da misurare

Il sintomo c'è — *«tocco la fine dello slider e il mirino va sul bordo»* — ma è
una **descrizione, non un numero**. E il motivo è un difetto mio:

> *«i numerini bianchi della X non si vedono perché coperti da "2s premuto =
> esci"»*

**Un diagnostico che nasconde il proprio output è peggio di niente.** È così che
l'asse X è rimasto senza misura per due versioni intere, mentre la Y si chiudeva.

`AX` resta a `1.38953`: quasi certamente **sbagliato per eccesso**, ma non lo
cambio a occhio su una stima. Serve la stessa misura fatta per la Y.

### 18.5 DIAG ora è un mirino di misura

- **cinque mire** a coordinate note (`120,40` · `40,140` · `120,140` · `200,140`
  · `120,240`), con la coordinata **scritta accanto**;
- i numeri in **fascia sgombra**, font grande, su nero;
- `2s=esci` spostato **in alto a destra**: non copre più niente.

Tocchi una mira, leggi cosa dice il firmware, confronti. È il procedimento che ha
risolto la Y — qui reso esplicito invece che improvvisato.

### 18.6 Cosa serve

1. Flasha la **2.16.8**.
2. Boot → **DIAG** (parte in modo MIRE).
3. Tocca il **centro** di queste tre, e riporta la riga `x ___ y ___`:

| mira | atteso |
|---|---|
| `40,140` (sinistra) | x=40 |
| `120,140` (centro) | x=120 |
| `200,140` (destra) | x=200 |

Tre numeri e l'asse X si chiude come si è chiusa la Y.

> **Nota**: la Y dovrebbe già essere giusta — se toccando `120,140` leggi
> `y≈140`, la correzione ha funzionato. Se leggi `y` sbagliato, dimmelo: vuol
> dire che il fit va rifatto.


---

## 19. v2.16.9 — caso chiuso, e l'errore che è costato sei versioni

### 19.1 La Y è confermata sul campo

| mira | y letto | errore |
|---|---|---|
| `120,40` | 40 | **0** |
| `40,140` | 137 | −3 |
| `120,140` | 143 | +3 |
| `200,140` | 140 | **0** |
| `120,240` | 240 | **0** |

Errori `0 / −3 / +3 / 0 / 0`: **rumore del tocco**. La correzione della v2.16.8
(`AY=0.74103, BY=37.59`) è giusta e non si tocca.

### 19.2 La X, con lo stesso metodo

| mira | x letto | errore |
|---|---|---|
| `40,140` | 18 | **−22** |
| `120,140` | 129 | **+9** |
| `200,140` | 239 | **+39** |

Errore che cresce da sinistra a destra: eccesso di guadagno, identico al caso Y.

```
fit:  x_letto = 1.3813 · x_vero − 37.08
```

Invertito e composto con `AX=1.38953`:

```c
TOUCH_CAL_AX = 1.00599f;   // era 1.38953
TOUCH_CAL_BX = -4.34f;     // era -43.08
```

Verifica sui tre punti: **−0.1 / +0.2 / −0.1 px**.

### 19.3 L'errore che è costato sei versioni

> **`AX_new ≈ 1.0` significa che l'asse X era GIÀ ALLINEATO.**

Il famoso *«sensore più stretto del display del 28%»* — la conclusione trionfale
della v2.16.6, § 16 — **non è mai esistito**.

Gli span `rx 31..203` letti in DIAG non erano i bordi del sensore: erano
**semplicemente dove avevi toccato**. Ho costruito `AX=1.38953` su un dato che
misurava il gesto invece dell'hardware — e quel coefficiente **ha causato** il
disallineamento in X che poi passavo le versioni a inseguire.

Anche le "tre controprove indipendenti" del § 16.4 erano circolari: verificavano
la coerenza interna del modello, non la sua aderenza alla realtà. Lo stesso
errore del residuo contro la ripetibilità (§ 14.4), commesso una seconda volta
senza riconoscerlo.

**Gli span sono inaffidabili per principio: misurano l'utente, non il chip.** I
bersagli a coordinata nota no — perché il riferimento è disegnato dal firmware,
non scelto dal dito.

### 19.4 Il metodo, per la prossima volta

| ✗ Non funziona | ✓ Funziona |
|---|---|
| dedurre cosa riporta il chip | misurare **di quanto sbaglia** la catena completa |
| span dei bordi (dipendono dal gesto) | bersagli a **coordinata nota** |
| residuo di una passata | ripetibilità fra passate |
| spiegare, poi verificare | misurare, poi (forse) spiegare |

Sei modelli, sei smentite. Ha funzionato solo quando ho smesso di chiedermi
*perché* e ho misurato *quanto*.

### 19.5 Quello che resta senza spiegazione

Il guadagno in Y era `1.359`, cioè quasi esattamente `AX=1.38953`. **Non so
perché.** Il codice applica `AX` a `rx` e `AY` a `ry` — verificato, nessuno
scambio.

**E non invento una spiegazione.** I coefficienti riproducono i punti misurati
con errore ±3 px, ed è l'unica cosa che conta finché una misura non li smentisce.
Se un domani il touch tornasse storto, la risposta è la stessa: **DIAG, mire,
numeri.**

### 19.6 Verifica finale

1. Flasha la **2.16.9**.
2. **DIAG → mire**: tocca i centri, gli scarti devono stare entro ±5 px.
3. **Scoring → DIST+ELEV**: `+` e `−` devono rispondere, il ghost cadere sotto il
   dito, il rosso solo nelle zone morte vere.
4. **ZONA**: prova tutte e 9 le celle — era rotta anche lei (8 su 9), ora ha
   geometria vera *e* calibrazione giusta.

Se il `+` risponde, siamo alla fine: torna l'**elevazione del bersaglio**, che era
il punto di partenza di tutto questo.


---

## 20. v2.16.10 — il bug era un numero scritto a mano

### 20.1 Il dato che ha chiuso tutto

Da DIAG, toccando il centro dei tre tasti:

| tasto | letto | fascia attesa | esito |
|---|---|---|---|
| `-` | **36, 207** | x 16..64, y 191..223 | **dentro ✓** |
| `?` | **112, 208** | x 92..148, y 191..223 | **dentro ✓** |
| `+` | **205, 209** | x 176..224, y 191..223 | **dentro ✓** |

**Le coordinate erano giuste.** Tutte e tre, dentro le rispettive fasce, con
scarti di 4–8 px su bersagli larghi 48.

Il touch era a posto. Il bug era altrove.

### 20.2 L'handler aveva i numeri della v2.16.0

```c
case SC_DISTANZA: {
    if (ty >= 190) {                    // ← OK/INDIETRO
    if (ty >= 150 && ty <= 180) {       // ← tasti +/-/?
```

In **v2.16.1** i pulsanti sono stati dimezzati (`BTN_TOP` 190 → 235) e i tasti
spostati (`KEY_Y` → 191). Ho aggiornato il **disegno** e non l'**handler**,
rimasto con i letterali vecchi.

Il conto:

> Tocchi il `+`, disegnato a y 191..223. L'handler legge y=209, valuta
> `209 >= 190` → **esegue OK**. Il `-`, a sinistra → **INDIETRO**.

Riprodotto sui tuoi numeri reali:

| tasto | tocco | v2.16.9 | v2.16.10 |
|---|---|---|---|
| `-` | 36,207 | **INDIETRO** | `-` ✓ |
| `?` | 112,208 | **INDIETRO** | `?` ✓ |
| `+` | 205,209 | **OK** | `+` ✓ |

Esattamente il sintomo, dalla 2.16.1 in poi.

### 20.3 La causa vera: costanti duplicate

Il disegno usava `BTN_TOP` / `KEY_Y`. L'handler usava letterali. **Due fonti per
lo stesso fatto** — e prima o poi divergono. Sono divergute nel momento esatto in
cui ho cambiato il layout.

Le X dei tasti erano nella stessa condizione: letterali duplicati in disegno e
handler. **Coincidevano per fortuna, non per costruzione.** Ora tutte le zone —
disegno, handler e `ghostZoneColor()` — leggono le **stesse costanti**:
`BTN_TOP`, `KEY_Y`, `KEY_H`, `KEY_MINUS_X0/X1`, `KEY_IGN_X0/X1`,
`KEY_PLUS_X0/X1`. Spostare un tasto è ora una modifica sola.

### 20.4 Otto versioni sul sensore sbagliato

Ho passato **otto versioni** a calibrare un touch che, dopo la 2.16.9, era già a
posto. Il bug era un numero scritto a mano in una riga che avevo scritto io.

Cosa avrebbe dovuto insospettirmi, e non l'ha fatto:

- **«lo fa anche nella schermata precedente»** → ZONA aveva davvero un problema
  suo (le soglie `THR_*`), e questo ha reso credibile la pista "touch" per tutte
  le versioni successive. Due bug diversi con un sintomo simile.
- **il sintomo era *specifico dei tasti***, mai degli slider. Un touch scalibrato
  sbaglia **tutto**, non solo tre rettangoli. Ci ho messo dieci versioni a
  chiedermi perché gli slider funzionassero.
- **«DIAG funziona perfettamente, ma i tasti no»** → questa frase *era* la
  diagnosi. Se lo strumento che legge il touch è perfetto e chi lo usa no, il
  problema non è il touch.

### 20.5 Il metodo, aggiornato

| ✗ | ✓ |
|---|---|
| dedurre cosa riporta il chip | misurare **di quanto sbaglia** la catena |
| span dei bordi (dipendono dal gesto) | bersagli a **coordinata nota** |
| costanti duplicate fra disegno e handler | **una sola fonte** |
| «il sintomo assomiglia a X» | *quali* elementi sbagliano, e quali no |

Il lascito di tutta questa vicenda non sono i coefficienti: sono il **ghost**
(che ha rivelato il difetto), **DIAG con le mire** (che l'ha quantificato) e
questa regola — quando lo strumento funziona e l'applicazione no, guardare
l'applicazione.

### 20.6 Verifica

1. Flasha la **2.16.10**.
2. **DIST+ELEV**: `+`, `-`, `?` devono rispondere.
3. Il ghost deve restare **ciano/ambra** sui tasti (rosso solo fra un tasto e
   l'altro).
4. **ZONA**: tutte e 9 le celle.
5. **OK / INDIETRO**: continuano a funzionare (ora sono la fascia y ≥ 235).

Se rispondono, siamo alla fine: torna l'**elevazione del bersaglio** — il punto
di partenza, undici versioni fa.
