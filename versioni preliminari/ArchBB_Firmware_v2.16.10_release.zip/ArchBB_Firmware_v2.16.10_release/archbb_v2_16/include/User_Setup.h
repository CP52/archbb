// =============================================================================
// User_Setup.h — TFT_eSPI per Waveshare ESP32-S3-Touch-LCD-1.69
// =============================================================================
//
// Questo file viene copiato da copy_tft_setup.py dentro la cartella
// .pio/libdeps/<env>/TFT_eSPI/ prima di ogni compilazione.
// In questo modo TFT_eSPI lo trova tramite il proprio include path.
//
// CONTROLLER ST7789V2 vs PANNELLO FISICO:
//   Controller: 240×320 pixel (registri hardware)
//   Pannello fisico 1.69": 240×280 pixel
//   → TFT_WIDTH=240, TFT_HEIGHT=320 (controller)
//   → Nel codice applicativo: pushSprite(0, 20) per l'offset y
//
// USER_SETUP_LOADED:
//   Definito qui per impedire a User_Setup_Select.h di caricare altri setup.
//   DEVE essere la prima definizione del file.
// =============================================================================

#define USER_SETUP_LOADED   // PRIMA DI TUTTO — blocca altri setup

// Driver
#define ST7789_DRIVER

// Dimensioni CONTROLLER (non pannello fisico)
#define TFT_WIDTH  240
#define TFT_HEIGHT 320

// Pin SPI — Waveshare ESP32-S3-Touch-LCD-1.69
#define TFT_MISO  -1    // non usato (write-only)
#define TFT_MOSI   7
#define TFT_SCLK   6
#define TFT_CS     5
#define TFT_DC     4
#define TFT_RST    8
#define TFT_BL    15    // backlight (PWM o digital)

// SPI frequency
#define SPI_FREQUENCY       40000000
#define SPI_READ_FREQUENCY   6000000
#define SPI_TOUCH_FREQUENCY  2500000

// Ordine colori RGB per ST7789V2 su questa board
#define TFT_RGB_ORDER TFT_RGB

// Font built-in (Font 2, 4, 6, 7 usati in display.cpp)
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define LOAD_FONT6
#define LOAD_FONT7
#define LOAD_FONT8
#define LOAD_GFXFF
#define SMOOTH_FONT

