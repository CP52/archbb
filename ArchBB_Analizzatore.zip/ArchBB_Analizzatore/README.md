# ArchBB — Analizzatore

**Strumento da scrivania, per ogni sistema operativo · luglio 2026**

Legge la microSD e analizza i burst grezzi. Non usa il Bluetooth: per quello
c'è l'app HTML, che sta sul telefono e serve al campo.

---

## Perché due strumenti e non uno

| | app HTML (`ArchBB_183_App_v0_2.html`) | questo Streamlit |
|---|---|---|
| dove gira | telefono e PC, nel browser | ovunque ci sia Python |
| come prende i dati | BLE dal dispositivo | microSD |
| cosa mostra | quadro della seduta, tabella tiri | dentro i tiri, tutta la card |
| quando lo usi | a fine seduta, sul campo | dopo, quando qualcosa non torna |

L'app HTML deve stare in tasca e non dipendere da niente. Questo strumento non
ha quel vincolo, e in cambio può usare `numpy` e `scipy`.

---

## Avvio

**Windows** — doppio clic su `avvia.bat`, oppure:

```
py -m pip install -r requirements.txt ; py -m streamlit run app.py
```

**macOS / Linux** — `./avvia.sh`, oppure:

```
python3 -m pip install -r requirements.txt
python3 -m streamlit run app.py
```

Si apre nel browser. Nella barra a sinistra indica dove sono i dati: va bene la
radice della card (`E:\`, `/Volumes/ARCHBB`), la cartella `ARCHBB`, o una
singola `SESS_…`. Le tre forme sono riconosciute da sole — costringerti a
indovinare quale livello scegliere sarebbe un modo gratuito di farti sbagliare.

In alternativa, un `.zip` che contenga cartelle `SESS_…`.

La cache si invalida da sola quando i file cambiano: dopo aver tirato altre
frecce non devi ricordarti di premere niente.

---

## Struttura

```
archbb_dsp.py       le convenzioni di analisi — IMPLEMENTAZIONE DI RIFERIMENTO
archbb_io.py        lettura della card: sessioni, shots.csv, burst
archbb_metrics.py   replica degli algoritmi di bordo (per verificare il CSV)
converti_1_69.py    importa le esportazioni piatte della 1.69
app.py              interfaccia Streamlit
```

### `archbb_dsp.py` è la specifica

Dalla Fase 10 gli strumenti che analizzano i burst sono due, in due linguaggi.
Due implementazioni della stessa fisica sono la regola §4.1 travestita: il
giorno in cui il JavaScript dice 8,8 Hz e Python 9,4 Hz sullo stesso tiro,
nessuno dei due è credibile.

La cura non è «scrivere lo stesso codice due volte con attenzione»: è dichiarare
**una specifica** e implementarla due volte sapendo di farlo. Quel file è la
specifica, con i numeri che l'hanno stabilita. Il JavaScript la cita nei
commenti.

Le cinque convenzioni:

1. **fs misurata dallo span**, non dalla mediana dei Δt
2. **fs nominale (224 Hz)** per replicare il firmware
3. **finestra spettrale 300 ms** di default
4. sotto **f_min = 2/T** si legge deriva, non frequenza
5. sopra il **5,39 % dell'ODR** c'è il filtro dell'IMU, non l'arco

---

## Le sei schede

### Panoramica
Tutta la card in una tabella, e **le tre fasi del tiro seduta per seduta**.

La struttura viene dai 42 tiri del 14/07: PCA con PC1 al 32 % — non esiste un
indice unico di bravura — e tre gruppi statisticamente indipendenti (ρ fra loro
−0,24 / +0,25 / −0,04, tutte con p > 0,1).

```
1 · MIRA        fermezza · angolo di mira · cant
2 · RILASCIO    pulizia rilascio · torsione
3 · TENUTA      hold
```

Qui non si guarda il singolo tiro ma come ciascuna fase si muove **fra le
sedute**: è la domanda a cui il singolo tiro non può rispondere. Per il tiro
per tiro c'è l'app HTML.

Le nove metriche ci sono tutte. `ξ consistenza`, `nettezza scocco` e
`follow-through` sono state portate dal sorgente della 1.29 con le costanti
originali — cambiarne una renderebbe i numeri non più confrontabili con la 1.69,
che è l'unico motivo per cui vale la pena portarle. Valori misurati sulla seduta
del 27/07, accanto a quelli della schermata 1.69 di riferimento:

| | 1.83 (27/07) | 1.69 (schermata) |
|---|---|---|
| nettezza scocco | 961–2700 m/s³ | 1054 |
| follow-through | 9–15 | 16 |
| ξ consistenza | 0,76–0,80 | 0,86–0,89 |

**`angolo di mira` non è una metrica di fase** e non sta più nei gruppi: dipende
dalla distanza e dal bersaglio, non dall'esecuzione. In una seduta a distanze
diverse la sua media non significa nulla. Al suo posto, nella fase MIRA, c'è lo
**scostamento in mira**: quanto la mano d'arco si muove *mentre* mira. Sui 20
tiri del 27/07 vale 0,04–0,15°.

### L'assetto, e perché a volte va dedotto

Le colonne del CSV si chiamano `cant_cdeg` / `alzo_cdeg`, ma cosa contengono
dipende dal montaggio con cui la seduta è stata registrata:

| | colonne | forme d'onda |
|---|---|---|
| sedute F11+ (`mount` dichiarato) | già giuste | già giuste |
| sedute precedenti | invertite | frame di `mount = 0` |

Lo strumento **applica la corrispondenza** e usa i nomi veri. Non è un'ipotesi:
è il verdetto del DIAG ASSI del 26/07 (montaggio destro, margine 36 su soglia
5), confermato dai numeri — nella seduta del 25/07 la colonna «cant» segna
17,0° con σ 0,72°, cioè una mira tenuta, non un rollio del braccio d'arco.

I burst vengono **raddrizzati** applicando M2 ai campioni salvati:

```
salvato = (x,  y, -z_grezzo)          M0 + flip
voluto  = (x, -z_grezzo, -y)          M2 + flip
voluto in funzione del salvato = (x, z_salv, -y_salv)
```

Dopo il raddrizzamento il cant sta fra −2,4 e +1,7° e l'alzo a −17° (punta in
basso, sagoma 3D a terra). L'`hold` viene **ricalcolato** dai campioni, perché
quello nel CSV il dispositivo l'ha integrato sull'asse sbagliato.

Resta indeterminato solo il valore **assoluto** dell'alzo: senza taratura del
montaggio contiene anche l'inclinazione della staffa. Le variazioni sono
affidabili.

### Il controllo di allineamento fra i due strumenti

Fermezza e torsione le calcolano sia questo Streamlit sia l'app HTML, in due
linguaggi. Verificato sui nove tiri del 25/07 che diano **gli stessi numeri**:

```
fermezza  67 · 45 · 35 · 10 · 70 · 37 · 66 · 39 · 43
torsione  -1,33 · -0,57 · -2,10 · -0,42 · +0,09 · -0,63 · -2,96 · -0,94 · -1,21
hold      +1,59 · +2,40 · +0,69 · +3,17 · -1,10 · +3,84 · -2,86 · +0,35 · -2,64
```

È il controllo che impedisce alla stessa fisica, scritta due volte, di
divergere senza che nessuno se ne accorga.

### Tiro per tiro
Il dettaglio completo di **un tiro**: le tre fasi con tutte le metriche e il
riferimento di seduta accanto a ciascuna, la **traccia 2D**, le forme d'onda di
accelerometro e giroscopio, e la tabella completa della seduta.

La traccia è disegnata a **scala 1:1** fra i due assi: con scale diverse un
movimento circolare sembrerebbe un'ellisse e si leggerebbe una tendenza che non
c'è. Il tratto ambra va dallo scocco a +15 ms — l'unico che ha deviato *questa*
freccia; il rosso dopo racconta le tendenze, non il colpo.

Il bias del giroscopio è stimato via ZUPT sui campioni fermi prima dello scocco
(300–430 campioni sui dati reali). **Il verso dello yaw non è validato sulla
1.83**: il parametro è esposto invece che nascosto in una costante, e finché non
c'è il test statico a rotazione nota conviene fidarsi della forma, non del verso.

### Progressione
Le metriche nel tempo, con due assi orizzontali possibili:

- **tiro nella seduta** — le curve si sovrappongono e si confronta l'andamento
  *interno*: se la fermezza cala verso la fine di ogni seduta è stanchezza, non
  caso;
- **progressivo su tutta la card** — la storia in ordine cronologico.

La banda è media ± 1σ su tutte le sedute selezionate: si vede al volo quale tiro
esce dal branco senza cercarlo nella tabella.

### Sovrapposizione
Tutti i tiri allineati sullo scocco, con **mediana e banda interquartile**.

Mediana e quartili, non media e deviazione standard: con nove tiri un solo gesto
anomalo sposta la media e gonfia la σ, e la banda finisce per non descrivere
nessun tiro. La mediana lo ignora; i quartili dicono dove sta la metà centrale —
che è esattamente la domanda «come tiro di solito».

L'allineamento è **per tempo**, non per indice: un burst troncato o un ODR
diverso romperebbero l'allineamento per campione.

### Spettro e smorzamento
Spettro, spettrogramma e — la parte nuova — la **misura del decadimento**.

Il filtro interno dell'IMU chiude la banda dei flettenti, quindi la vibrazione
dell'attrezzo non è misurabile (vedi sotto). Ma il modo dominante misurato,
8–11 Hz, sta comodamente dentro la banda passante, e il suo decadimento si
misura bene: quanto in fretta l'insieme arciere+arco torna fermo. Un
follow-through che si assesta in 150 ms e uno che oscilla per mezzo secondo sono
due gesti diversi.

Metodo: passa-banda attorno al modo dominante, inviluppo analitico con la
trasformata di Hilbert, retta ai minimi quadrati sul logaritmo. **L'R² viene
mostrato accanto al risultato**: se l'inviluppo non è esponenziale, ζ non
significa niente e va detto, non nascosto.

> **Questa metrica non è validata.** Prima di finire in una dashboard deve
> passare dallo split-half della scheda Statistica. Finché non lo fa, è
> un'osservazione, non un indicatore.

### Verifica del dispositivo
Il dispositivo calcola le metriche a bordo e ne scrive il risultato nel CSV; il
burst grezzo resta accanto. Quindi il CSV è **falsificabile**: si rifanno i
conti dai campioni e si controlla che tornino.

Serve anche a **ritarare senza ri-tirare**: cambi le soglie in
`archbb_metrics.py`, ricarichi, e vedi l'effetto sui tiri veri di tutte le
sedute della card.

### Statistica
ρ di Spearman con **n e p sempre accanto al coefficiente**, split-half con
correzione di Spearman-Brown, distanza di Mahalanobis diagonale.

Un ρ senza il suo p è un'opinione con i decimali. Sulla 1.69 il costo di non
mostrarli era già stato pagato: alcune metriche correlavano con l'alzo, cioè
misuravano l'inclinazione del bersaglio invece del gesto.

---

## Cosa è emerso costruendolo

### La replica del firmware coincide — dopo due correzioni

Il confronto CSV-vs-ricalcolo, alla prima esecuzione, dava 2 tiri su 9
coincidenti. Il jerk tornava al centesimo, ma cant, alzo e hold no — e tutti e
tre dipendono dalla finestra calma. Due differenze, entrambe nella mia replica:

1. **Troncamento contro arrotondamento.** Il firmware scrive
   `(uint16_t)(0.200f * 224)` e il cast in C **tronca**: 44,8 → 44 campioni.
   Arrotondando "per fare meglio" viene 45, la finestra scorre su un insieme
   diverso di candidate e ne può vincere un'altra.
2. **Deviazione standard campionaria.** `windowStats()` usa `sqrt(var/(n-1))`;
   `numpy.std()` per difetto usa `n`. Su 44 campioni è l'1,2 %: irrilevante come
   numero, decisivo come **criterio** — fra ~400 finestre con punteggi vicini,
   l'1,2 % basta a farne vincere un'altra, e da lì cambiano cant, alzo e hold
   insieme.

Corrette queste, restava solo l'hold, con scarti fino a 0,13°. Terza differenza:

3. **L'ultimo trapezio.** `integrate_gy()` include ogni trapezio il cui estremo
   **sinistro** cade entro i 900 ms — l'ultimo sconfina un po' oltre
   l'orizzonte. Prendere solo i trapezi interamente dentro la finestra è la
   scelta "pulita", e ne perde uno.

Risultato finale sulla sessione del 25/07:

```
cant   scarto massimo  0,0040°     (quantizzazione del CSV: 0,005°)
alzo   scarto massimo  0,0045°
hold   scarto massimo  0,0040°
jerk   scarto massimo  0,44 m/s³   (arrotondamento a intero: 0,5)
```

Tutti e nove i tiri coincidono col dispositivo entro la quantizzazione. Da qui
in avanti il CSV è verificato, e questo strumento è affidabile per ritarare le
soglie.

### Il filtro dell'IMU

`imu.cpp` configura il QMI8658 con `LPF_MODE_2` = **5,39 % dell'ODR** (registro
CTRL5). Ai 217,7 Hz effettivi il taglio cade a ~11,7 Hz. Misura sui nove burst,
energia per banda, finestra 300 ms:

```
  3– 8 Hz   61.7  61.9  74.1  41.5 238.4  29.0  72.5  29.3  30.8
  8–15 Hz   84.1  69.0  76.5  90.7 262.6  22.5 155.7  21.4  29.8
 15–30 Hz    4.5   1.5   1.3   1.8   3.8   1.0   0.7   1.0   0.9
 30–60 Hz    0.0   0.0   0.0   0.0   0.0   0.0   0.0   0.0   0.0
```

Zero esatto sopra i 30 Hz. La banda 15–80 Hz che la 1.69 chiamava «vibrazione
dei flettenti», con questa configurazione, **non esiste**.

Per aprirla servirebbe `LPF_MODE_3` (13,37 % dell'ODR) o l'`aLPF` disabilitato,
con ODR più alto — ma cambierebbe la risposta del sensore su cui la soglia del
trigger è stata tarata sul campo. Va provato in un ambiente PlatformIO dedicato
(`archbb_183_spectro`, sul modello di `shotrec`), confrontando gli spettri dello
stesso gesto nelle due configurazioni. **Prima la prova, poi eventualmente il
campo.**

### La finestra spettrale

Frequenza di picco sui nove tiri, per larghezza di finestra:

| finestra | media | σ |
|---|---|---|
| **300 ms** | 8,87 Hz | **1,31** |
| 500 ms | 7,43 Hz | 2,13 |
| 1000 ms | si sfilaccia al limite dei 2 Hz | — |

Si sceglie la finestra con σ minima: è dove la misura si ripete. Le altre
restano selezionabili perché vedere il confronto insegna più che leggerlo.

---

## Importare le sedute della 1.69

La 1.69 esportava un CSV solo, con **una riga per campione**: i sei assi, e
accanto le metriche del tiro ripetute su ogni riga. Sono gli stessi dati della
1.83 con un'organizzazione diversa.

```
python3 converti_1_69.py BBarch_14JUL.csv -o /dove/mettere --data 2026-07-14 --ricalcola
```

Produce una cartella `SESS_…` standard: `session.txt`, `shots.csv`,
`burst_NNNN.bin`. Da quel momento quei dati sono dati come tutti gli altri,
leggibili anche dall'app HTML — che di questo formato non sa nulla e non deve
saperne.

### Perché un convertitore e non un secondo lettore

La tentazione era aggiungere all'analizzatore un ramo «se il CSV è piatto,
leggilo così». Sarebbe stata la scelta peggiore: due formati interni da tenere
vivi per sempre, ogni analisi nuova da scrivere due volte, e il giorno in cui
divergono nessuno se ne accorge. La regola sana è l'opposto: **un solo formato
dentro, adattatori sottili al bordo.**

### La verifica preliminare

Prima di convertire c'era una domanda sola: i campioni della 1.69 sono nello
stesso **frame canonico** della 1.83? Le due schede hanno il chip montato
specchiato, e la 1.83 lo compensa con `MOUNT_0_FLIPZ`.

Ricalcolando cant e alzo dai campioni con l'algoritmo attuale si ritrovano
**esattamente** i valori che il firmware 1.69 aveva scritto in
`cant_fw_deg`/`alzo_fw_deg` — scarto 0,00 su tutti i tiri, incluso uno a
−75,93°. I due mount portano allo stesso frame canonico, che è esattamente il
loro scopo. Nessun rimappaggio di assi nel convertitore.

### Le tre insidie del formato piatto

Nessuna si vede leggendo le prime righe.

1. **L'intestazione si ripete.** Il file è la concatenazione di più
   esportazioni (in `BBarch_14JUL.csv` sono tre).
2. **`shot_id` non identifica un tiro.** Si ripete dentro lo stesso blocco, e i
   blocchi si sovrappongono nel tempo. L'unico riferimento univoco è il
   timestamp.
3. **`sample_idx` si avvolge a 65536.** È un contatore a 16 bit. Un tiro a
   cavallo dell'avvolgimento sembra spezzato in due (nel file: 544 campioni da
   idx 64992, poi 128 da idx 0 — un burst solo). Senza il modulo nel test di
   contiguità quel tiro viene diviso e altri vengono fusi: si passa da **44
   tiri veri a 30 sbagliati**.

### Cosa viene portato e cosa no

| campo | origine |
|---|---|
| punteggio (`colpito`, `zona`, `dist_m`, `arcs`) | portato tale e quale |
| `cant_cdeg`, `alzo_cdeg` | i valori che il **dispositivo 1.69** aveva scritto |
| `hold_cdeg`, `release_jerk` | vuoti, oppure ricalcolati con `--ricalcola` |
| `stability`, `xi`, `sharpness`, `follow_through`, `vib_hz`, `torque_deg`, `drift_*`, `recoil` | conservati in `metriche_1_69.csv` |

Cant e alzo **non** vengono ricalcolati di proposito: così la scheda Verifica fa
un confronto vero fra generazioni, invece di confrontare l'algoritmo attuale con
sé stesso — che tornerebbe sempre e non direbbe niente.

Hold e release restano vuoti perché l'esportazione 1.69 ha `follow_through` e
`sharpness` in unità che **non** corrispondono. Inventare un fattore di
conversione sarebbe peggio di un vuoto: un numero sbagliato entra nelle
statistiche, un vuoto no. Con `--ricalcola` si riempiono con gli algoritmi
attuali, e `session.txt` lo dichiara (`hold_release=ricalcolato`).

### Il filtro «solo tiri con punteggio»

Nel file del 14 luglio, **33 catture su 44 non hanno punteggio**: arco
maneggiato, falsi scocchi, prove. Due hanno cant −76° e −92°, assetti che un
arco in mira non può avere.

Lasciarli dentro non falsa «un po'» le statistiche, le distrugge:

```
solo tiri con punteggio (11)   cant σ =  3,74°     alzo σ =  8,16°
tutte le catture       (44)    cant σ = 19,44°     alzo σ = 25,45°
```

La spunta nella barra a sinistra è attiva per difetto. Il criterio è quello del
dispositivo: se non è stato assegnato un punteggio, per l'arciere quel gesto non
era un tiro.

### Confronto spettrale fra le due generazioni

Energia per banda, mediana sui tiri, finestra 300 ms post-scocco:

| banda | 1.69 (11 tiri) | 1.83 (9 tiri) |
|---|---|---|
| 3–8 Hz | 304,7 | 126,5 |
| 8–15 Hz | 452,7 | 149,7 |
| **15–30 Hz** | **246,5** | **2,5** |
| 30–60 Hz | 0,01 | 0,00 |
| 60–105 Hz | 0,00 | 0,00 |

Due letture, di peso molto diverso.

**Confermato:** sopra i 30 Hz l'energia è nulla su **entrambe** le schede. Il
muro del filtro dell'IMU non è una particolarità della 1.83 — la banda
«vibrazione dei flettenti» non è mai esistita su nessuna delle due.

**Da capire:** fra 15 e 30 Hz la 1.69 vede **cento volte** più energia, con lo
stesso taglio nominale (12,1 contro 11,7 Hz). Le spiegazioni possibili sono
almeno tre — montaggio più rigido sulla 1.69, attrezzo o giornata diversi,
configurazione del sensore diversa — e i dati a disposizione non permettono di
sceglierne una. È un'ipotesi da verificare, non una conclusione.

La prova che discriminerebbe è semplice e da banco: un **colpetto secco sul
riser** con le due schede montate, e confronto degli spettri di risposta. Se la
differenza resta senza l'arciere in mezzo, è il montaggio — e allora la 1.83 sta
smorzando meccanicamente informazione prima che arrivi al sensore, il che
conterebbe più di qualunque impostazione software.

---

## Limiti dichiarati

- **Lo split-half non è calcolabile con una sola seduta.** Servono almeno 3
  sedute con 6+ tiri. Non è un limite dello strumento: l'affidabilità *fra*
  sedute richiede più sedute.
- **Sotto ~15 tiri le correlazioni non sono interpretabili.** Vengono mostrate
  col loro n e p, e marcate come non leggibili.
- **Lo smorzamento è una metrica nuova.** Nessuna validazione, nessuna soglia.
- **Nessuna scrittura sulla card.** Lo strumento è in sola lettura, di
  proposito: un analizzatore che modifica il dato che analizza è un modo di
  perdere il dato.

---

## Se l'app si lamenta di «moduli disallineati»

I quattro `.py` sono un insieme e vanno aggiornati **insieme**. Estrarre lo zip
*sopra* una cartella esistente senza sostituire tutti i file lascia un
miscuglio, e il sintomo arriva lontano dalla causa: un `AttributeError` dentro
una scheda, dieci schermate più in là.

Ogni modulo porta una marca `VERSIONE`, e `app.py` la controlla all'avvio: se
qualcosa è rimasto indietro lo dice subito, dicendo **quale file**. La cura è
sempre la stessa — cancellare la cartella e riestrarre l'archivio per intero.

Controllo manuale, dalla cartella:

```
python -c "import archbb_dsp, archbb_io, archbb_metrics as m; print(archbb_dsp.VERSIONE, archbb_io.VERSIONE, m.VERSIONE)"
```

---

## Correggere distanza ed elevazione

Il selettore di distanza sul dispositivo resta sull'ultimo valore usato: nella
seduta del 27/07 diciotto tiri su venti risultano a 18 m mentre erano a 6.

Nella scheda **Tiro per tiro**, in fondo, c'è `Correggi distanza ed elevazione
della seduta`. È **l'unica scrittura** che questo strumento fa, e ha tre
precauzioni:

1. **Copia di sicurezza.** Alla prima modifica `shots.csv` viene copiato in
   `shots.csv.orig`, che non viene mai sovrascritto: la prima versione resta
   recuperabile anche dopo dieci correzioni.
2. **Modifica chirurgica, non rigenerazione.** Le righe si rileggono come testo
   e si sostituiscono solo i campi indicati — terminatori di riga, spazi e
   colonne sconosciute restano byte per byte. Verificato: 21 CRLF prima, 21
   dopo; commento e intestazione intatti.
3. **`arcs` viene ricalcolato.** Il punteggio codifica la distanza
   (`arcs = ±(dist_m·10 + zona + 1)`): cambiarne una senza l'altro lascerebbe il
   file in contraddizione con sé stesso.

Con una sorgente `.zip` la correzione è disabilitata: non c'è un file su disco
da riscrivere.
