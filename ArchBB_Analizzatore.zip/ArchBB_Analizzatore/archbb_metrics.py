#!/usr/bin/env python3
# ============================================================================
#  ArchBB — archbb_metrics.py
#  Replica in Python degli algoritmi di bordo, per VERIFICARE il CSV.
#  Cesare Pagura · Padova/Noale IT · luglio 2026
# ----------------------------------------------------------------------------
#  A COSA SERVE
#    Il dispositivo calcola cant, alzo, hold e release a bordo e ne scrive il
#    risultato nel CSV. Il burst grezzo resta accanto. Quindi il CSV e'
#    FALSIFICABILE: si rifanno i conti dai campioni e si controlla che tornino.
#    Se un giorno non tornassero, si scoprirebbe subito quale delle due cose e'
#    cambiata — e non sei mesi dopo, guardando una statistica che non torna.
#
#    Serve anche per RITARARE senza ri-tirare: cambi HOLD_SOGLIE o TAU qui,
#    rilanci su tutte le sessioni della card e vedi l'effetto sui tiri veri.
#
#  DERIVA DA analisi_firmware.py (Fase 5), con DUE correzioni:
#
#    1. LA FREQUENZA GIUSTA PER LO SCOPO GIUSTO.
#       Il firmware dimensiona le sue finestre con odrToHz(), cioe' 224 Hz
#       NOMINALI (shot_angles.cpp riga 216). Per replicarlo bisogna usare quel
#       numero, non la frequenza misurata: con 217,7 Hz le finestre verrebbero
#       lunghe un campione in meno e i numeri non coinciderebbero mai
#       esattamente. analisi_firmware.py usava la MEDIANA dei Δt (200 Hz), che
#       non e' ne' l'una ne' l'altra.
#       Regola: fs NOMINALE per replicare il firmware, fs MISURATA per il
#       segnale. Vedi §fs in archbb_dsp.py.
#
#    2. VETTORIALE.
#       find_calm_window scorreva ~400 finestre da 44 campioni in Python puro:
#       ~20 000 operazioni per tiro. Con le somme cumulate e' la stessa
#       identica matematica in una manciata di operazioni su array. Serve
#       perche' qui si lavora su tutta la card, non su una sessione.
#
#  I SEGNI (frame canonico, dopo mount_apply con MOUNT_0_FLIPZ)
#    cant = atan2(ay, ax)   + = destra
#    alzo = atan2(az, ax)   + = punta in alto
#    I burst salvati sono GIA' nel frame canonico: nessun rimappaggio qui.
# ============================================================================
from __future__ import annotations

# VERSIONE DEL MODULO — deve coincidere con quella attesa da app.py.
#  Serve perche' i quattro file sono un insieme: estrarre lo zip sopra una
#  cartella esistente e sostituirne solo alcuni lascia un miscuglio che si
#  manifesta come AttributeError dentro una scheda, dieci schermate piu' in la'
#  rispetto alla causa. Con la marca, l'app lo dice subito e dice quale file.
VERSIONE = "2026.07.27-11"

import math
from dataclasses import dataclass

import numpy as np
import pandas as pd

from archbb_dsp import Burst

# --- Costanti degli algoritmi di bordo -------------------------------------
#  Sono qui, in un punto solo, perche' il senso di questo modulo e' poterle
#  cambiare e rilanciare. Devono restare allineate a shot_angles.h del
#  firmware: se divergono, il confronto CSV-vs-ricalcolo smette di essere una
#  verifica e diventa un confronto fra due cose diverse.
GUARD_S = 0.050          # distanza minima della finestra calma dal trigger
WIN_S = 0.200            # ampiezza della finestra calma
GRAVITA = 9.81
TAU_DPS = 5.0            # stability: RMS a cui il punteggio vale 37
HOLD_MS = 900
REL_MS = 40
DT_MAX_US = 50000
HOLD_SOGLIE = (4.0, 8.0)        # gradi
RELEASE_SOGLIE = (330.0, 510.0)  # m/s^3

# --- Torsione (Release Torque), definizione della 1.69 ---------------------
#  Integrale di -(gz - bias) sulla finestra [trigger-100ms, trigger+15ms].
#  SOLO GIROSCOPIO: nell'impatto del rilascio l'accelerometro e' inservibile.
#  La finestra finisce a +15 ms perche' li' la freccia lascia la corda: dopo,
#  la torsione della mano non la devia piu'.
#  Segno: positivo = antiorario/sinistra, negativo = orario/destra (banco).
TORSIONE_PRE_MS = 100
TORSIONE_POST_MS = 15

HOLD_NOMI = {0: "tenuto", 1: "lieve", 2: "abbassato", 3: "alzato", 4: "n/d"}
REL_NOMI = {0: "pulito", 1: "medio", 2: "strappo", 3: "n/d"}


@dataclass
class MetricheRicalcolate:
    cant: float | None = None
    alzo: float | None = None
    stabile: bool | None = None
    g_medio: float | None = None
    g_sd: float | None = None
    stability: float | None = None
    rms_dps: float | None = None
    torsione: float | None = None
    hold: float | None = None
    hold_class: int = 4
    release_jerk: float | None = None
    release_class: int = 3
    finestra_calma: tuple[int, int] | None = None
    motivo: str = ""


def finestra_calma(b: Burst) -> tuple[int, int] | None:
    """La finestra pre-scocco piu' ferma. Stessa logica di shot_angles_compute.

    Punteggio da minimizzare: |media(|a|) - g| + sd(|a|). Premia le finestre in
    cui l'accelerometro vede solo gravita' e la vede stabile — cioe' l'arciere
    in mira, fermo. Il guard di 50 ms tiene fuori la fase dinamica del rilascio,
    che altrimenti vincerebbe per motivi sbagliati.
    """
    fs = b.fs_nominale
    # TRONCAMENTO, non arrotondamento. Il firmware scrive:
    #     const uint16_t win = (uint16_t)((float)200/1000.0f * hz);
    # e il cast a intero in C TRONCA: 0,200 x 224 = 44,8 -> 44 campioni.
    # Arrotondando "per fare meglio" verrebbe 45, la finestra scorrerebbe su un
    # insieme diverso di candidate e potrebbe vincerne un'altra. Replicare
    # significa replicare anche le troncature.
    guard = int(GUARD_S * fs)      # 0,050 x 224 = 11,2 -> 11
    win = int(WIN_S * fs)          # 0,200 x 224 = 44,8 -> 44
    we_max = b.trig - guard
    if we_max < win or win < 2:
        return None

    mag = np.sqrt(b.ax ** 2 + b.ay ** 2 + b.az ** 2)
    c1 = np.concatenate([[0.0], np.cumsum(mag)])
    c2 = np.concatenate([[0.0], np.cumsum(mag ** 2)])

    we = np.arange(win, we_max + 1)
    ws = we - win
    somma = c1[we] - c1[ws]
    somma2 = c2[we] - c2[ws]
    media = somma / win
    # sd CAMPIONARIA (denominatore n-1), come windowStats() del firmware:
    #     gsd = sqrt(var/(n-1))
    # numpy con std() userebbe n. Su una finestra da 44 campioni la differenza
    # e' l'1,2 %: irrilevante come numero, decisiva come CRITERIO — fra ~400
    # finestre candidate con punteggi vicini, l'1,2 % basta a farne vincere
    # un'altra, e da li' cambiano cant, alzo e hold tutti insieme.
    var = np.maximum(0.0, (somma2 - win * media ** 2) / (win - 1))
    punteggio = np.abs(media - GRAVITA) + np.sqrt(var)

    k = int(np.argmin(punteggio))
    return int(ws[k]), int(we[k])


def ricalcola(b: Burst) -> MetricheRicalcolate:
    """Rifa' tutti i conti del dispositivo a partire dai campioni grezzi."""
    r = MetricheRicalcolate()
    cw = finestra_calma(b)
    if cw is None:
        r.motivo = "pre-scocco troppo corto per la finestra calma"
        return r
    r.finestra_calma = cw
    a, z = cw

    ax, ay, az = b.ax[a:z], b.ay[a:z], b.az[a:z]
    gx, gy, gz = b.gx[a:z], b.gy[a:z], b.gz[a:z]

    # --- assetto -----------------------------------------------------------
    mx, my, mz = ax.mean(), ay.mean(), az.mean()
    mag = np.sqrt(ax ** 2 + ay ** 2 + az ** 2)
    r.g_medio = float(mag.mean())
    r.g_sd = float(mag.std(ddof=1))   # campionaria, come windowStats() del firmware
    r.cant = math.degrees(math.atan2(my, mx))
    r.alzo = math.degrees(math.atan2(mz, mx))
    r.stabile = bool(abs(r.g_medio - GRAVITA) < 1.5 and r.g_sd < 1.0)

    # --- stability (non finisce nel CSV, ma serve al confronto storico) -----
    bgx, bgy, bgz = gx.mean(), gy.mean(), gz.mean()
    rms = float(np.sqrt(np.mean((gx - bgx) ** 2 + (gy - bgy) ** 2 + (gz - bgz) ** 2)))
    r.rms_dps = rms
    r.stability = float(round(100 * math.exp(-rms / TAU_DPS)))

    # --- torsione: integrale di -(gz - bias) su [-100ms, +15ms] -------------
    t0 = b.ts[b.trig]
    sin_t = np.arange(0, b.n - 1)
    el = b.ts[sin_t] - t0
    sin_t = sin_t[(el >= -TORSIONE_PRE_MS * 1000) & (el <= TORSIONE_POST_MS * 1000)]
    if len(sin_t) >= 10:
        dt = (b.ts[sin_t + 1] - b.ts[sin_t]) / 1e6
        ok = (dt > 0) & (dt <= DT_MAX_US / 1e6)
        if ok.sum() >= 10:
            w0 = b.gz[sin_t] - bgz
            w1 = b.gz[sin_t + 1] - bgz
            r.torsione = float(np.sum((-0.5 * (w0 + w1) * dt)[ok]))

    # --- hold: integrale di (gy - bias) per 900 ms, a dt REALE --------------
    #  Il dt reale e' obbligatorio: con il tick di FreeRTOS che alterna 4 e 5 ms
    #  un dt costante sbaglierebbe l'integrale in modo sistematico, non casuale.
    #
    #  IL DETTAGLIO CHE CAMBIA IL RISULTATO — integrate_gy() del firmware fa:
    #      for (i = start; i < end-1; i++) {
    #          if (ts[i] - t0 > span_us) break;      <-- test sull'estremo SINISTRO
    #          ...somma il trapezio (i, i+1)...
    #      }
    #  cioe' include OGNI trapezio il cui estremo sinistro cade entro i 900 ms:
    #  l'ultimo sconfina un po' oltre l'orizzonte. Prendere solo i trapezi
    #  interamente dentro la finestra — la scelta "pulita", che avevo fatto —
    #  ne perde uno e lascia uno scarto fino a 0,13° sull'hold. Piccolo, ma
    #  sistematico: esattamente il tipo di divergenza che questo strumento
    #  esiste per stanare.
    sinistri = np.arange(b.trig, b.n - 1)
    sinistri = sinistri[(b.ts[sinistri] - t0) <= HOLD_MS * 1000]
    if len(sinistri) > 0:
        dt = (b.ts[sinistri + 1] - b.ts[sinistri]) / 1e6
        ok = (dt > 0) & (dt <= DT_MAX_US / 1e6)
        if ok.sum() >= 20:
            w0 = b.gy[sinistri] - bgy
            w1 = b.gy[sinistri + 1] - bgy
            r.hold = float(np.sum((0.5 * (w0 + w1) * dt)[ok]))
            am = abs(r.hold)
            r.hold_class = (0 if am <= HOLD_SOGLIE[0]
                            else 1 if am <= HOLD_SOGLIE[1]
                            else 2 if r.hold < 0 else 3)

    # --- release: max |d(ay)/dt| nei primi 40 ms, derivata centrata ---------
    dentro_r = (b.ts >= t0) & (b.ts - t0 <= REL_MS * 1000)
    idr = np.where(dentro_r)[0]
    idr = idr[(idr > b.trig) & (idr < b.n - 1)]
    if len(idr) >= 5:
        dt2 = (b.ts[idr + 1] - b.ts[idr - 1]) / 1e6
        ok = (dt2 > 0) & (dt2 <= 2 * DT_MAX_US / 1e6)
        if ok.sum() >= 5:
            j = np.abs((b.ay[idr + 1] - b.ay[idr - 1]) / dt2)
            r.release_jerk = float(np.max(j[ok]))
            r.release_class = (0 if r.release_jerk <= RELEASE_SOGLIE[0]
                               else 1 if r.release_jerk <= RELEASE_SOGLIE[1] else 2)
    return r


# ============================================================================
#  Le tre metriche che mancavano — portate dalla 1.29 (app v1.4)
# ============================================================================
#  Erano rimaste fuori perche' avevo la descrizione ma non la normalizzazione.
#  Con il sorgente della 1.29 sotto mano le definizioni ci sono per intero, e
#  vanno riprodotte COSI' COME SONO: se cambiassi una costante, i numeri non
#  sarebbero piu' confrontabili con quelli della 1.69 — che e' l'unico motivo
#  per cui vale la pena portarle.

def nettezza_scocco(b: Burst) -> float | None:
    """Ripidita' del fronte di rilascio: picco |az| diviso il tempo di salita.

    Finestra [trigger-5, trigger+5). Si cerca il picco, il primo campione sopra
    la meta' del picco, e si divide per i campioni fra i due. L'ODR e' quello
    NOMINALE, come nella 1.29 (parametro odr, default 224).
    """
    a = max(0, b.trig - 5)
    z = min(b.n, b.trig + 5)
    if z - a < 3:
        return None
    seg = np.abs(b.az[a:z])
    picco = float(seg.max())
    if picco <= 0:
        return None
    sopra = np.where(seg > picco * 0.5)[0]
    i_picco = int(np.argmax(seg))
    if len(sopra) == 0:
        return None
    campioni_salita = max(1, i_picco - int(sopra[0]))
    return float(picco / campioni_salita * b.fs_nominale)      # m/s^3


def follow_through(b: Burst) -> float | None:
    """Quiete post-scocco: 100*exp(-3*rms), con ax normalizzato al picco.

    Finestra [trigger+3, trigger+52) — circa 220 ms dopo lo scocco.
    La normalizzazione al picco e' il fix della v1.2: con ax in m/s^2 assoluti
    l'esponenziale saturava a zero. Cosi' il punteggio misura il movimento
    post-scocco RELATIVO all'impulso di rilascio, che e' la grandezza sensata.
    """
    a, z = b.trig + 3, min(b.n, b.trig + 52)
    if z - a < 3:
        return None
    picco = float(np.max(np.abs(b.ax))) or 1e-6
    rms = float(np.sqrt(np.mean((b.ax[a:z] / picco) ** 2)))
    return float(round(max(0.0, 100 * math.exp(-3 * rms))))


# --- xi consistenza: DTW sulla finestra di rilascio -------------------------
XI_PRE, XI_POST = 25, 79      # finestra [trig-25, trig+79) ~ 460 ms a 224 Hz
XI_BANDA = 0.10               # banda di Sakoe-Chiba, 10%
XI_SCALA = 0.05               # fattore di conversione distanza -> punteggio
XI_MAX_RIF = 10               # quanti tiri precedenti usare come riferimento


def _finestra_rilascio(b: Burst) -> np.ndarray:
    """|az| attorno al rilascio, normalizzato al picco: confronta la FORMA."""
    a = max(0, b.trig - XI_PRE)
    z = min(b.n, b.trig + XI_POST)
    seg = np.abs(b.az[a:z]).astype(np.float64)
    return seg / max(float(seg.max()), 1e-6)


def _dtw(a: np.ndarray, c: np.ndarray) -> float:
    """DTW con banda di Sakoe-Chiba.

    La banda vieta gli allineamenti patologici (un campione mappato su decine
    dell'altro segnale) e taglia il costo da O(N^2) pieno a O(N*banda).
    """
    la, lb = len(a), len(c)
    if la < 2 or lb < 2:
        return float("inf")
    banda = max(5, math.ceil(max(la, lb) * XI_BANDA))
    d = np.full((la, lb), np.inf)
    d[0, 0] = abs(a[0] - c[0])
    for i in range(1, min(la, banda + 1)):
        d[i, 0] = d[i - 1, 0] + abs(a[i] - c[0])
    for j in range(1, min(lb, banda + 1)):
        d[0, j] = d[0, j - 1] + abs(a[0] - c[j])
    for i in range(1, la):
        j0, j1 = max(1, i - banda), min(lb - 1, i + banda)
        if j1 < j0:
            continue
        for j in range(j0, j1 + 1):
            d[i, j] = abs(a[i] - c[j]) + min(d[i - 1, j], d[i, j - 1], d[i - 1, j - 1])
    return float(d[la - 1, lb - 1])


def consistenza_xi(b: Burst, precedenti: list) -> float | None:
    """Somiglianza della forma del rilascio coi tiri precedenti (0..1).

    Perche' solo i PRECEDENTI e non tutta la seduta: xi risponde a "questo tiro
    somiglia a come tiravo finora", che e' una domanda con una direzione nel
    tempo. Confrontarlo anche coi successivi lo renderebbe una misura di
    coerenza globale — un'altra cosa, e non quella che la 1.69 mostrava.
    """
    if not precedenti:
        return None
    rif = precedenti[-XI_MAX_RIF:]
    cur = _finestra_rilascio(b)
    dist = [_dtw(cur, _finestra_rilascio(r)) for r in rif]
    dist = [x for x in dist if math.isfinite(x)]
    if not dist:
        return None
    media = sum(dist) / len(dist)
    return round(1.0 / (1.0 + media * XI_SCALA), 2)


def scostamento_mira(b: Burst, tr) -> float | None:
    """Quanto si muove la mano d'arco MENTRE MIRA, in gradi.

    Media quadratica di sqrt(dyaw^2 + dpitch^2) rispetto alla MEDIA della
    finestra, calcolata sulla FINESTRA CALMA.

    PERCHE' QUESTA E NON "l'angolo di mira"
      L'angolo di mira assoluto dipende dalla distanza: in una seduta a
      distanze diverse la sua media non significa nulla e la sua deviazione
      misura il bersaglio, non l'arciere. Quello che conta e' quanto la mano
      d'arco si MUOVE mentre e' in mira.

    PERCHE' LA FINESTRA CALMA E NON GLI ULTIMI 50 CAMPIONI
      Il rilascio comincia PRIMA che il trigger scatti. Misurato sulla seduta
      del 27/07: lo yaw resta piatto a -5,7 gradi fino a -25 ms, poi ruota di
      5,7 gradi in 23 ms mentre il modulo del giroscopio passa da 20 a 174 dps.
      Una finestra che arriva fino allo scocco inghiotte quella rotazione e
      restituisce 4-7 gradi di "scostamento in mira" che non e' mira: e' il
      rilascio. La finestra calma finisce prima, ed e' lo stesso criterio di
      "fermo" che usa il firmware per cant, alzo e hold.

    PERCHE' RISPETTO ALLA MEDIA DELLA FINESTRA E NON ALLO SCOCCO
      Serve il MOVIMENTO, non la distanza dal punto di rilascio: quella e' una
      grandezza diversa, ed e' gia' leggibile sulla traccia.
    """
    from archbb_dsp import finestra_calma
    cw = finestra_calma(b)
    if cw is None:
        return None
    a, z = cw
    if z - a < 5:
        return None
    dy = tr.yaw[a:z] - tr.yaw[a:z].mean()
    dp = tr.pitch[a:z] - tr.pitch[a:z].mean()
    return float(np.sqrt(np.mean(dy ** 2 + dp ** 2)))


# ============================================================================
#  Confronto CSV (dispositivo) vs ricalcolo (qui)
# ============================================================================
#  TOLLERANZE — quanto scarto e' fisiologico e quanto e' un problema.
#    Il CSV porta cant/alzo/hold in CENTESIMI di grado interi: la sola
#    quantizzazione vale gia' 0,005°. Il jerk e' un intero in m/s^3.
#    Sopra queste soglie non c'e' arrotondamento che tenga: e' un algoritmo
#    diverso, e va guardato.
TOLL_GRADI = 0.05
TOLL_JERK = 2.0


def confronta(sessione) -> pd.DataFrame:
    """Per ogni tiro con burst: valore del CSV, valore ricalcolato, scarto."""
    righe = []
    if sessione.tiri.empty:
        return pd.DataFrame()

    for _, t in sessione.tiri.iterrows():
        f = str(t.get("burst_file") or "")
        b = sessione.bursts.get(f)
        if b is None:
            righe.append({"shot": t.get("shot"), "esito": "nessuna forma d'onda"})
            continue
        r = ricalcola(b)
        riga = {"shot": int(t.get("shot")) if pd.notna(t.get("shot")) else None}

        def coppia(nome, csv_val, calc_val, toll):
            riga[f"{nome}_csv"] = csv_val
            riga[f"{nome}_ric"] = calc_val
            if csv_val is None or calc_val is None or pd.isna(csv_val):
                riga[f"{nome}_d"] = np.nan
            else:
                riga[f"{nome}_d"] = float(calc_val) - float(csv_val)

        coppia("cant", t.get("cant"), r.cant, TOLL_GRADI)
        coppia("alzo", t.get("alzo"), r.alzo, TOLL_GRADI)
        coppia("hold", t.get("hold"), r.hold, TOLL_GRADI)
        coppia("jerk", t.get("release_jerk"), r.release_jerk, TOLL_JERK)

        scarti = [
            (abs(riga.get("cant_d", np.nan)), TOLL_GRADI),
            (abs(riga.get("alzo_d", np.nan)), TOLL_GRADI),
            (abs(riga.get("hold_d", np.nan)), TOLL_GRADI),
            (abs(riga.get("jerk_d", np.nan)), TOLL_JERK),
        ]
        fuori = [s > tl for s, tl in scarti if not np.isnan(s)]
        riga["esito"] = ("nessun confronto possibile" if not fuori
                         else "divergente" if any(fuori) else "coincide")
        righe.append(riga)
    return pd.DataFrame(righe)


def riepilogo_confronto(df: pd.DataFrame) -> str:
    if df.empty or "esito" not in df.columns:
        return "nessun tiro confrontabile"
    n = len(df)
    ok = int((df["esito"] == "coincide").sum())
    ko = int((df["esito"] == "divergente").sum())
    if ko == 0 and ok == n:
        return f"tutti i {n} tiri coincidono col dispositivo"
    return f"{ok}/{n} coincidono · {ko} divergenti"
