#!/usr/bin/env python3
# ============================================================================
#  ArchBB — converti_1_69.py
#  Porta le esportazioni PIATTE della 1.69 nel formato standard della card.
#  Cesare Pagura · Padova/Noale IT · luglio 2026
# ----------------------------------------------------------------------------
#  IL PROBLEMA
#    La 1.69 esportava un CSV solo, con UNA RIGA PER CAMPIONE: i 6 assi, e
#    accanto le metriche del tiro ripetute su ogni riga. La 1.83 separa le due
#    cose: shots.csv (una riga per tiro) e burst_NNNN.bin (i campioni). Sono
#    gli stessi dati con un'organizzazione diversa.
#
#  PERCHE' UN CONVERTITORE E NON UN SECONDO LETTORE NELL'ANALIZZATORE
#    La tentazione era aggiungere allo Streamlit un ramo "se il CSV e' piatto,
#    leggilo cosi'". Sarebbe stata la scelta peggiore: due formati interni da
#    tenere vivi per sempre, ogni analisi nuova da scrivere due volte, e il
#    giorno in cui divergono nessuno se ne accorge.
#    La regola sana e' l'opposto: UN SOLO formato dentro, adattatori sottili al
#    bordo. Il convertitore sta qui, si usa una volta, e da quel momento i dati
#    del 2026-07-14 sono dati come tutti gli altri — leggibili anche dall'app
#    HTML, che di questo formato non sa e non deve sapere nulla.
#
#  LA VERIFICA CHE HA RESO POSSIBILE TUTTO QUESTO
#    Prima di convertire va risposta una domanda sola: i campioni della 1.69
#    sono nello STESSO frame canonico della 1.83? Le due schede hanno il chip
#    montato specchiato, e la 1.83 lo compensa con MOUNT_0_FLIPZ.
#    Risposta, misurata: ricalcolando cant e alzo dai campioni con l'algoritmo
#    attuale si ritrovano ESATTAMENTE i valori che il firmware 1.69 aveva
#    scritto in cant_fw_deg/alzo_fw_deg — scarto 0,00 su tutti i tiri, incluso
#    uno a -75,93°. I due mount portano allo stesso frame canonico, che e'
#    esattamente il loro scopo. Nessun rimappaggio di assi qui dentro.
#
#  USO
#    python3 converti_1_69.py BBarch_14JUL.csv -o /dove/mettere --data 2026-07-14
#    python3 converti_1_69.py BBarch_14JUL.csv -o . --ricalcola
# ============================================================================
from __future__ import annotations

import argparse
import csv as csvmod
import math
import struct
import sys
from datetime import datetime
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from archbb_dsp import BURST_HDR_FMT, BURST_MAGIC, IMU_FMT, Burst, frequenza_misurata
import archbb_metrics as MET

# ── Mappa delle zone ───────────────────────────────────────────────────────
#  La 1.69 scriveva il nome, la 1.83 l'indice della griglia 3x3.
#  La corrispondenza NON e' stata indovinata: e' stata ricavata dall'aritmetica
#  del punteggio, che vale in entrambe le generazioni:
#      arcs = ±(distanza_m * 10 + zona_indice + 1)      (negativo = mancato)
#  Verificata su tutte le combinazioni presenti nel file: SPOT -> 4,
#  alto-dx -> 2, sx -> 3. Coerente con la griglia letta per righe.
ZONE = {
    "alto-sx": 0, "alto": 1, "alto-dx": 2,
    "sx": 3, "SPOT": 4, "centro": 4, "dx": 5,
    "basso-sx": 6, "basso": 7, "basso-dx": 8,
}

# Colonne della 1.69 che NON hanno un corrispondente nella 1.83. Non si
# buttano: finiscono in un file a parte dentro la stessa cartella. L'analizzatore
# le ignora (legge solo i nomi standard), ma il dato resta.
COLONNE_STORICHE = ("stability", "xi", "sharpness", "follow_through", "cant_deg",
                    "vib_hz", "pressure_hpa", "torque_deg", "drift_lat",
                    "drift_vert", "recoil")

INTESTAZIONE_CSV = ("shot,ts_ms,colpito,zona,dist_m,elev_deg,arcs,"
                    "cant_cdeg,alzo_cdeg,angoli_stabili,hold_cdeg,hold_class,"
                    "release_jerk,release_class,burst_file")


def leggi_esportazione(percorso: Path):
    """Legge il CSV piatto e ne ricava i singoli tiri.

    QUI STA TUTTA LA DIFFICOLTA' DEL FORMATO, e nessuna delle tre insidie si
    vede leggendo le prime righe del file.

    1) L'INTESTAZIONE SI RIPETE. Il file e' la concatenazione di piu'
       esportazioni (in BBarch_14JUL.csv sono tre). Vanno separate.

    2) shot_id NON IDENTIFICA UN TIRO. Si ripete dentro lo stesso blocco: in
       quel file b3/8 compare a 774,0 s e di nuovo a 789,1 s, b3/9 a 812,7 e
       820,2. Sono tiri fisicamente diversi con la stessa etichetta. Ed e'
       peggio: i blocchi si SOVRAPPONGONO nel tempo (b3/1 sta a 83,4 s, prima
       di b1/1 a 171,8 s), quindi non sono nemmeno sedute consecutive.
       L'unico riferimento davvero univoco e' il TIMESTAMP.

    3) sample_idx SI AVVOLGE a 65536. E' un contatore a 16 bit: dopo 65535
       riparte da 0. Un tiro a cavallo dell'avvolgimento sembra spezzato in due
       (nel file: 544 campioni da idx 64992, poi 128 da idx 0 — un burst solo).
       Se il test di contiguita' non prevede l'avvolgimento, quel tiro viene
       diviso in due e altri vengono fusi: si passa da 44 tiri veri a 30
       sbagliati. E' esattamente l'errore che questo commento esiste per
       impedire alla prossima persona.

    Quindi: si spezza in TRATTE CONTIGUE di sample_idx (modulo 16 bit), si
    ordina per timestamp, si rinumera da capo.
    """
    with open(percorso, newline="", encoding="utf-8-sig") as f:
        righe = list(csvmod.reader(f))
    if not righe:
        raise ValueError("file vuoto")

    intest = righe[0]
    ci = {c: i for i, c in enumerate(intest)}
    for obbl in ("shot_id", "sample_idx", "ts_us", "ax", "ay", "az", "gx", "gy", "gz"):
        if obbl not in ci:
            raise ValueError(f"colonna obbligatoria assente: {obbl}")

    inizi = [i for i, r in enumerate(righe) if r and r[0] == "shot_id"]
    blocchi = []
    for k, i in enumerate(inizi):
        fine = inizi[k + 1] if k + 1 < len(inizi) else len(righe)
        blocchi.append(righe[i + 1:fine])

    MIN_CAMPIONI = 32          # sotto questa soglia e' un frammento, non un tiro
    tiri = []
    for nb, b in enumerate(blocchi):
        gruppi: dict[str, list] = {}
        for r in b:
            if r and r[0]:
                gruppi.setdefault(r[0], []).append(r)

        for sid, rs in gruppi.items():
            idx = [int(float(r[ci["sample_idx"]])) for r in rs]
            inizio = 0
            for i in range(1, len(rs) + 1):
                contigua = (i < len(rs)) and (idx[i] == (idx[i - 1] + 1) & 0xFFFF)
                if contigua:
                    continue
                seg = rs[inizio:i]
                if len(seg) >= MIN_CAMPIONI:
                    tiri.append(dict(blocco=nb, id_orig=sid, righe=seg,
                                     t0=float(seg[0][ci["ts_us"]])))
                inizio = i

    tiri.sort(key=lambda t: t["t0"])
    return ci, tiri, len(inizi)


def costruisci_burst(ci, rs, shot_num) -> tuple[Burst, bytes]:
    """Dai campioni della riga piatta al Burst e ai byte del .bin."""
    n = len(rs)
    trig = int(float(rs[0][ci["trigger_idx"]])) if rs[0][ci["trigger_idx"]] else n // 2
    trig = max(0, min(trig, n - 1))

    idx = np.array([int(float(r[ci["sample_idx"]])) for r in rs], dtype=np.int64)
    seq = (idx - idx[0]) % 65536          # riporta a 0 e rispetta i 16 bit
    ts = np.array([float(r[ci["ts_us"]]) for r in rs], dtype=np.float64)
    assi = {a: np.array([float(r[ci[a]]) for r in rs], dtype=np.float64)
            for a in ("ax", "ay", "az", "gx", "gy", "gz")}

    fs, continua = frequenza_misurata(seq, ts)
    b = Burst(ver=1, odr_code=1, n=n, trig=trig, shot=shot_num,
              seq=seq, ts=ts, **assi,
              fs=fs, fs_nominale=224.0, seq_continua=continua,
              nome=f"burst_{shot_num:04d}.bin")

    # Byte del file, layout identico a writeBurstBin() del firmware.
    # ts_us diventa uint32: e' un contatore da boot, con il modulo si comporta
    # come sul dispositivo (l'aritmetica modulare e' voluta, non un troncamento).
    testa = struct.pack(BURST_HDR_FMT, BURST_MAGIC, 1, 1, n, trig, shot_num, b"\0\0\0\0")
    corpo = bytearray()
    for i in range(n):
        corpo += struct.pack(IMU_FMT, int(seq[i]), int(ts[i]) & 0xFFFFFFFF,
                             assi["ax"][i], assi["ay"][i], assi["az"][i],
                             assi["gx"][i], assi["gy"][i], assi["gz"][i])
    return b, bytes(testa) + bytes(corpo)


def cd(v) -> str:
    """Gradi -> centesimi interi, come il firmware. Vuoto = NON CALCOLATO."""
    if v is None or (isinstance(v, float) and not math.isfinite(v)):
        return ""
    return str(int(round(v * 100)))


def converti(sorgente: Path, destinazione: Path, data: str | None,
             ricalcola: bool, verbose: bool = True):
    ci, tiri, n_blocchi = leggi_esportazione(sorgente)
    if not tiri:
        raise ValueError("nessun tiro riconoscibile nel file")

    quando = data or _data_dal_nome(sorgente.name)
    dt = datetime.fromisoformat(quando) if "T" in quando else datetime.fromisoformat(quando + "T00:00:00")
    nome_sess = f"SESS_{dt:%Y%m%d_%H%M}"
    cartella = destinazione / nome_sess
    cartella.mkdir(parents=True, exist_ok=True)

    righe_csv = []
    righe_storiche = []
    fs_viste = []

    for k, t in enumerate(tiri, start=1):
        rs = t["righe"]
        b, byte_bin = costruisci_burst(ci, rs, k)
        (cartella / f"burst_{k:04d}.bin").write_bytes(byte_bin)
        fs_viste.append(b.fs)

        p = rs[0]                                   # metriche: costanti sul tiro

        def g(col):
            return p[ci[col]].strip() if col in ci else ""

        # --- punteggio: si porta com'e' -----------------------------------
        esito = g("esito")
        colpito = 1 if esito == "colpito" else 0
        zona = ZONE.get(g("zona"), None)
        dist = g("distanza_m")
        arcs = g("arcs") or "0"

        # --- assetto: i valori che il DISPOSITIVO 1.69 aveva scritto -------
        # Non ricalcolati di proposito: cosi' la scheda "Verifica" fa un
        # confronto VERO fra generazioni invece di confrontare l'algoritmo
        # attuale con se' stesso (che tornerebbe sempre, e non direbbe niente).
        cant = g("cant_fw_deg")
        alzo = g("alzo_fw_deg")

        # --- hold e release ------------------------------------------------
        # L'esportazione 1.69 ha follow_through e sharpness, ma in unita' che
        # NON corrispondono a hold_cdeg e release_jerk. Inventare un fattore di
        # conversione sarebbe peggio di lasciare vuoto: un numero sbagliato
        # entra nelle statistiche, un vuoto no. Con --ricalcola si riempiono
        # con gli algoritmi ATTUALI, e session.txt lo dichiara.
        hold_s = hold_c = jerk_s = rel_c = ""
        if ricalcola:
            m = MET.ricalcola(b)
            hold_s = cd(m.hold)
            hold_c = str(m.hold_class)
            jerk_s = str(int(round(m.release_jerk))) if m.release_jerk is not None else ""
            rel_c = str(m.release_class)

        righe_csv.append(",".join([
            str(k), str(int(t["t0"] / 1000)), str(colpito),
            "" if zona is None else str(zona), dist, "", arcs,
            cd(float(cant)) if cant else "", cd(float(alzo)) if alzo else "",
            "1", hold_s, hold_c, jerk_s, rel_c, f"burst_{k:04d}.bin",
        ]))

        st = {"shot": k, "id_originale": f"b{t['blocco']+1}-{t['id_orig']}"}
        for c in COLONNE_STORICHE:
            if c in ci:
                st[c] = g(c)
        righe_storiche.append(st)

    # --- shots.csv ---------------------------------------------------------
    fw = "1.69-import" + ("-ric" if ricalcola else "")
    with open(cartella / "shots.csv", "w", newline="", encoding="utf-8") as f:
        f.write(f"# ArchBB CSV v1  fw={fw}\n")
        f.write(INTESTAZIONE_CSV + "\n")
        f.write("\n".join(righe_csv) + "\n")

    # --- session.txt -------------------------------------------------------
    fs_med = float(np.mean(fs_viste))
    fine = dt.replace(second=0)
    with open(cartella / "session.txt", "w", encoding="utf-8") as f:
        f.write("ArchBB session 1\n")
        f.write(f"fw={fw}\n")
        f.write("csv_format=1\nburst_format=1\n")
        f.write(f"odr_hz={fs_med:.0f}\n")
        # ASSETTO DICHIARATO. Senza questa riga l'analizzatore considera la
        # seduta "a corrispondenza dedotta" e scambia cant e alzo — su dati
        # 1.69, dove sono GIA' giusti. Verificato: ricalcolando gli angoli dai
        # campioni con l'algoritmo attuale si ritrovano esattamente i valori
        # che il firmware 1.69 aveva scritto (scarto 0,00 su 44 tiri), e l'alzo
        # cresce con la distanza mentre il cant no (rho +0,53 contro -0,09).
        f.write("mount=0\n")
        f.write("mount_lato=frontale (1.69)\n")
        f.write("off_cant_deg=0.00\noff_alzo_deg=0.00\n")
        f.write(f"ended_datetime={fine.isoformat()}\n")
        f.write(f"shots={len(tiri)}\n")
        # Tracciabilita': da dove viene questo dato e cosa gli e' stato fatto.
        f.write(f"origine={sorgente.name}\n")
        f.write(f"origine_blocchi={n_blocchi}\n")
        f.write(f"hold_release={'ricalcolato' if ricalcola else 'assente'}\n")

    # --- metriche storiche (nessun dato buttato) ---------------------------
    if righe_storiche:
        campi = list(righe_storiche[0].keys())
        with open(cartella / "metriche_1_69.csv", "w", newline="", encoding="utf-8") as f:
            w = csvmod.DictWriter(f, fieldnames=campi)
            w.writeheader()
            w.writerows(righe_storiche)

    if verbose:
        print(f"Convertito  {sorgente.name}")
        print(f"  -> {cartella}")
        print(f"     {len(tiri)} tiri da {n_blocchi} blocchi, fs media {fs_med:.2f} Hz")
        print(f"     hold/release: {'ricalcolati con gli algoritmi attuali' if ricalcola else 'lasciati vuoti'}")
        print(f"     metriche 1.69 conservate in metriche_1_69.csv")
    return cartella


def _data_dal_nome(nome: str) -> str:
    """Prova a ricavare la data da nomi tipo BBarch_14JUL.csv."""
    mesi = dict(JAN="01", FEB="02", MAR="03", APR="04", MAY="05", JUN="06",
                JUL="07", AUG="08", SEP="09", OCT="10", NOV="11", DEC="12")
    import re
    m = re.search(r"(\d{1,2})([A-Z]{3})", nome.upper())
    if m and m.group(2) in mesi:
        return f"{datetime.now().year}-{mesi[m.group(2)]}-{int(m.group(1)):02d}"
    return datetime.now().date().isoformat()


def main():
    ap = argparse.ArgumentParser(
        description="Converte le esportazioni piatte della 1.69 nel formato card 1.83")
    ap.add_argument("sorgente", type=Path, help="il CSV esportato dalla 1.69")
    ap.add_argument("-o", "--destinazione", type=Path, default=Path("."),
                    help="dove creare la cartella SESS_… (default: qui)")
    ap.add_argument("--data", default=None,
                    help="data della seduta, es. 2026-07-14 o 2026-07-14T18:30. "
                         "Se omessa si prova a ricavarla dal nome del file.")
    ap.add_argument("--ricalcola", action="store_true",
                    help="riempie hold e release con gli algoritmi ATTUALI "
                         "(dichiarato in session.txt: non sono valori del dispositivo)")
    a = ap.parse_args()
    converti(a.sorgente, a.destinazione, a.data, a.ricalcola)


if __name__ == "__main__":
    main()
