#!/usr/bin/env python3
# ============================================================================
#  ArchBB — archbb_io.py
#  Lettura della microSD: albero /ARCHBB, sessioni, shots.csv, burst.
#  Cesare Pagura · Padova/Noale IT · luglio 2026
# ----------------------------------------------------------------------------
#  PRINCIPIO EREDITATO DAL FIRMWARE: la card *e'* lo stato.
#    sd_storage.cpp non tiene un indice delle sessioni da nessuna parte: le
#    enumera dal filesystem ogni volta. Qui si fa lo stesso. Nessun database,
#    nessuna cache da tenere allineata: si guarda la card e si vede la verita'.
#
#  DUE SCHEMI DI NOME, ENTRAMBI DA GESTIRE (Fase 6)
#    SESS_20260725_1648  quando l'RTC e' impostato (ora di INIZIO)
#    SESS_0001           quando non lo e'
#    I nomi ordinano bene come stringhe in entrambi gli schemi, ma NON fra
#    schemi diversi: SESS_0001 viene prima di SESS_2026... alfabeticamente, il
#    che e' cronologicamente giusto solo per caso. Per l'ordinamento vero si
#    usa, quando c'e', ended_datetime da session.txt.
#
#  ATTENZIONE ai burst SENZA riga CSV e viceversa
#    Il firmware scrive prima il .bin e poi la riga CSV (il CSV e' il dato
#    prezioso, il burst e' sacrificabile). Un crash fra i due lascia un burst
#    orfano. Non e' un errore da nascondere: e' un tiro di cui restano i
#    campioni ma non lo scoring, e va mostrato come tale.
# ============================================================================
from __future__ import annotations

# VERSIONE DEL MODULO — deve coincidere con quella attesa da app.py.
#  Serve perche' i quattro file sono un insieme: estrarre lo zip sopra una
#  cartella esistente e sostituirne solo alcuni lascia un miscuglio che si
#  manifesta come AttributeError dentro una scheda, dieci schermate piu' in la'
#  rispetto alla causa. Con la marca, l'app lo dice subito e dice quale file.
VERSIONE = "2026.07.27-11"

import csv as csvmod
import io
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from archbb_dsp import Burst, leggi_burst, raddrizza

RE_SESSIONE = re.compile(r"^SESS_", re.IGNORECASE)
RE_BURST = re.compile(r"^burst_(\d+)\.bin$", re.IGNORECASE)

# Colonne di shots.csv (csv_format = 1). Si mappa per NOME, mai per posizione:
# il firmware documenta che i campi nuovi vanno SEMPRE in coda, cosi' i file
# vecchi restano leggibili. Un parser posizionale butterebbe questa proprieta'.
COL_INTERE = ("shot", "ts_ms", "colpito", "zona", "dist_m", "elev_deg", "arcs",
              "angoli_stabili", "hold_class", "release_jerk", "release_class")
COL_CENTESIMI = ("cant_cdeg", "alzo_cdeg", "hold_cdeg")   # -> gradi


@dataclass
class Sessione:
    nome: str
    percorso: str                      # descrittivo (path o "zip:...")
    meta: dict = field(default_factory=dict)
    tiri: pd.DataFrame = field(default_factory=pd.DataFrame)
    bursts: dict = field(default_factory=dict)     # nome file -> Burst
    avvisi: list = field(default_factory=list)

    @property
    def n_tiri(self) -> int:
        return len(self.tiri)

    @property
    def n_onde(self) -> int:
        return len(self.bursts)

    @property
    def quando(self) -> str:
        """Chiave di ordinamento cronologico, la migliore disponibile."""
        q = self.meta.get("ended_datetime")
        if q:
            return q
        m = re.match(r"SESS_(\d{8})_(\d{4})", self.nome)
        if m:
            d, t = m.group(1), m.group(2)
            return f"{d[0:4]}-{d[4:6]}-{d[6:8]}T{t[0:2]}:{t[2:4]}:00"
        return "0000-" + self.nome        # i numerati finiscono in fondo

    def burst_del_tiro(self, shot: int) -> Burst | None:
        if self.tiri.empty:
            return None
        r = self.tiri[self.tiri["shot"] == shot]
        if r.empty:
            return None
        f = r.iloc[0].get("burst_file") or ""
        return self.bursts.get(f)

    def bursts_ordinati(self) -> list[Burst]:
        return [self.bursts[k] for k in sorted(self.bursts)]


# ============================================================================
#  Parsing dei singoli file
# ============================================================================
def leggi_session_txt(testo: str) -> dict:
    meta = {}
    for riga in testo.splitlines():
        if "=" in riga:
            k, v = riga.split("=", 1)
            meta[k.strip()] = v.strip()
    return meta


def leggi_shots_csv(testo: str) -> tuple[pd.DataFrame, str]:
    """shots.csv -> DataFrame. Ritorna anche la riga di commento (# ArchBB CSV v1 ...).

    IL PUNTO DELICATO: il campo VUOTO significa NON CALCOLATO, che non e' zero.
    Un hold non valido letto come 0 diventerebbe "tenuta perfetta" — l'esatto
    contrario del vero. pandas legge i vuoti come NaN, e NaN e' proprio la
    rappresentazione giusta: si propaga nei calcoli invece di falsarli in
    silenzio. Non si riempiono MAI con fillna(0).
    """
    righe = [r for r in testo.splitlines() if r.strip()]
    commento = ""
    i = 0
    while i < len(righe) and righe[i].lstrip().startswith("#"):
        commento = righe[i].lstrip("# ").strip()
        i += 1
    if i >= len(righe):
        return pd.DataFrame(), commento

    lettore = csvmod.DictReader(io.StringIO("\n".join(righe[i:])))
    dati = list(lettore)
    if not dati:
        return pd.DataFrame(), commento
    df = pd.DataFrame(dati)
    df.columns = [c.strip() for c in df.columns]

    for c in COL_INTERE:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c].replace("", np.nan), errors="coerce")
    for c in COL_CENTESIMI:
        if c in df.columns:
            v = pd.to_numeric(df[c].replace("", np.nan), errors="coerce")
            df[c.replace("_cdeg", "")] = v / 100.0      # cant, alzo, hold in gradi
    if "burst_file" in df.columns:
        df["burst_file"] = df["burst_file"].fillna("").astype(str).str.strip()
    if "colpito" in df.columns:
        df["colpito"] = df["colpito"] == 1
    return df, commento


# ============================================================================
#  Scansione
# ============================================================================
def _componi_sessione(nome: str, percorso: str, file_map: dict) -> Sessione:
    """file_map: nome file (minuscolo) -> bytes."""
    s = Sessione(nome=nome, percorso=percorso)

    if "session.txt" in file_map:
        s.meta = leggi_session_txt(file_map["session.txt"].decode("utf-8", "replace"))
    else:
        s.avvisi.append("session.txt assente: mancano fw e ODR dichiarato")

    if "shots.csv" in file_map:
        s.tiri, commento = leggi_shots_csv(file_map["shots.csv"].decode("utf-8", "replace"))
        if commento:
            s.meta.setdefault("csv_commento", commento)
    else:
        s.avvisi.append("shots.csv assente: nessuna metrica, solo forme d'onda")

    for nomefile, dati in file_map.items():
        if RE_BURST.match(nomefile):
            b = leggi_burst(dati, nomefile)
            if b is None:
                s.avvisi.append(f"{nomefile}: non e' un burst valido (magic errato)")
            else:
                s.bursts[nomefile] = b
                if not b.seq_continua:
                    s.avvisi.append(f"{nomefile}: sequenza con buchi, fs stimata dalla media")

    # Coerenza fra le due meta' del dato.
    if not s.tiri.empty and "burst_file" in s.tiri.columns:
        attesi = {f for f in s.tiri["burst_file"] if f}
        presenti = set(s.bursts)
        mancanti = attesi - presenti
        orfani = presenti - attesi
        if mancanti:
            s.avvisi.append(f"{len(mancanti)} tiri senza forma d'onda sulla card")
        if orfani:
            s.avvisi.append(
                f"{len(orfani)} forme d'onda senza riga nel CSV — tiri interrotti "
                f"fra la scrittura del burst e quella del CSV"
            )
    return s


def scansiona_cartella(radice: str | Path) -> list[Sessione]:
    """Scansiona una cartella. Accetta tre forme, riconosciute da sole:

      1. la RADICE della card      (contiene ARCHBB/)
      2. la cartella ARCHBB        (contiene SESS_*/)
      3. una singola cartella SESS_*

    Perche' tutte e tre: chi infila la card si trova davanti E:\\ ; chi ha
    copiato la roba sul disco ha una cartella ARCHBB; chi ha ricevuto uno zip
    ha una singola sessione. Costringere l'utente a indovinare quale livello
    scegliere e' un modo gratuito di farlo sbagliare.
    """
    radice = Path(radice).expanduser()
    if not radice.exists():
        raise FileNotFoundError(f"percorso inesistente: {radice}")

    if RE_SESSIONE.match(radice.name):
        cartelle = [radice]
    else:
        base = radice / "ARCHBB" if (radice / "ARCHBB").is_dir() else radice
        cartelle = sorted(d for d in base.iterdir() if d.is_dir() and RE_SESSIONE.match(d.name))

    sessioni = []
    for d in cartelle:
        fm = {}
        for f in d.iterdir():
            if f.is_file():
                try:
                    fm[f.name.lower()] = f.read_bytes()
                except OSError as e:
                    pass
        if fm:
            sessioni.append(_componi_sessione(d.name, str(d), fm))
    return ordina(sessioni)


def scansiona_zip(dati: bytes, etichetta: str = "zip") -> list[Sessione]:
    """Stessa cosa da un archivio zip caricato nell'interfaccia."""
    gruppi: dict[str, dict] = {}
    with zipfile.ZipFile(io.BytesIO(dati)) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            parti = Path(info.filename).parts
            sess = next((p for p in parti if RE_SESSIONE.match(p)), None)
            if sess is None:
                continue
            gruppi.setdefault(sess, {})[Path(info.filename).name.lower()] = z.read(info)
    return ordina([_componi_sessione(n, f"{etichetta}:{n}", fm) for n, fm in gruppi.items()])


def ordina(sessioni: list[Sessione]) -> list[Sessione]:
    """Dalla piu' recente. Vedi la nota sui due schemi di nome in testa al file."""
    return sorted(sessioni, key=lambda s: s.quando, reverse=True)


# ============================================================================
#  Correzione di distanza ed elevazione — l'UNICA scrittura dello strumento
# ============================================================================
#  Serve perche' il selettore di distanza sul dispositivo resta sull'ultimo
#  valore usato: nella seduta del 27/07 diciotto tiri su venti risultano a 18 m
#  mentre erano a 6. Senza correzione ogni analisi che usa la distanza mente.
#
#  TRE PRECAUZIONI, perche' qui si tocca il dato:
#
#  1. COPIA DI SICUREZZA. Alla prima modifica shots.csv viene copiato in
#     shots.csv.orig, che non viene MAI sovrascritto: la prima versione resta
#     recuperabile anche dopo dieci correzioni. Costa un file di un kilobyte.
#
#  2. MODIFICA CHIRURGICA, NON RIGENERAZIONE. Si rileggono le righe come TESTO
#     e si sostituiscono solo i campi interessati, lasciando tutto il resto
#     byte per byte: terminatori di riga, spazi, colonne che non conosciamo.
#     Rigenerare il file dal DataFrame sarebbe piu' comodo e comporterebbe il
#     rischio di riscrivere in modo diverso qualcosa che non c'entra.
#
#  3. arcs VIENE RICALCOLATO. Il punteggio codifica la distanza:
#         arcs = ±(dist_m * 10 + zona + 1)      negativo = mancato
#     Cambiare dist_m senza toccare arcs lascerebbe il file in contraddizione
#     con se stesso, ed e' il tipo di incoerenza che si scopre sei mesi dopo.
def correggi_distanza_elevazione(sessione, correzioni: dict) -> tuple[int, str]:
    """correzioni: {shot -> {"dist_m": float|None, "elev_deg": float|None}}

    Ritorna (righe modificate, messaggio). Solleva se la sorgente non e' una
    cartella su disco (con uno zip caricato non c'e' niente da riscrivere).
    """
    import shutil

    percorso = Path(sessione.percorso)
    if not percorso.is_dir():
        raise ValueError("la sorgente non e' una cartella: con uno zip la "
                         "correzione non si puo' salvare")
    csvp = percorso / "shots.csv"
    if not csvp.exists():
        raise ValueError("shots.csv assente")

    # 1) copia di sicurezza, una sola volta
    bak = percorso / "shots.csv.orig"
    creato = False
    if not bak.exists():
        shutil.copy2(csvp, bak)
        creato = True

    # 2) modifica chirurgica sul testo
    # newline="" DISATTIVA la traduzione universale dei fine riga: senza,
    # Python converte \r\n in \n prima ancora che il codice li veda, e la
    # riscrittura perde i terminatori originali del firmware. Un file che
    # cambia terminatori non e' piu' identico all'originale tranne dove volevo.
    with open(csvp, "r", encoding="utf-8", errors="replace", newline="") as fh:
        testo = fh.read()
    righe = testo.split("\n")
    idx_hdr = next((i for i, r in enumerate(righe)
                    if r and not r.lstrip().startswith("#")), None)
    if idx_hdr is None:
        raise ValueError("intestazione non trovata")
    cols = [c.strip() for c in righe[idx_hdr].rstrip("\r").split(",")]

    def pos(nome):
        return cols.index(nome) if nome in cols else -1

    p_shot, p_dist, p_elev = pos("shot"), pos("dist_m"), pos("elev_deg")
    p_zona, p_arcs, p_colp = pos("zona"), pos("arcs"), pos("colpito")
    if p_shot < 0 or p_dist < 0:
        raise ValueError("colonne shot/dist_m assenti")

    n = 0
    for i in range(idx_hdr + 1, len(righe)):
        riga = righe[i]
        if not riga.strip() or riga.lstrip().startswith("#"):
            continue
        fine = "\r" if riga.endswith("\r") else ""
        campi = riga.rstrip("\r").split(",")
        if len(campi) <= max(p_shot, p_dist):
            continue
        try:
            sh = int(float(campi[p_shot]))
        except ValueError:
            continue
        c = correzioni.get(sh)
        if not c:
            continue

        if c.get("dist_m") is not None:
            campi[p_dist] = f"{int(round(c['dist_m']))}"
        if c.get("elev_deg") is not None and p_elev >= 0:
            campi[p_elev] = f"{c['elev_deg']:.0f}"

        # 3) arcs coerente con la nuova distanza
        if p_arcs >= 0 and p_zona >= 0 and campi[p_dist].strip():
            try:
                d = int(float(campi[p_dist]))
                z = int(float(campi[p_zona])) if campi[p_zona].strip() else None
                if z is not None:
                    val = d * 10 + z + 1
                    colpito = (campi[p_colp].strip() == "1") if p_colp >= 0 else True
                    campi[p_arcs] = str(val if colpito else -val)
            except ValueError:
                pass

        righe[i] = ",".join(campi) + fine
        n += 1

    csvp.write_text("\n".join(righe), encoding="utf-8", newline="")
    msg = f"{n} righe corrette"
    if creato:
        msg += f" · originale salvato in {bak.name}"
    return n, msg


# ============================================================================
#  Assetto: quale colonna contiene cosa, e se le onde vanno raddrizzate
# ============================================================================
#  Le colonne del CSV si chiamano cant_cdeg / alzo_cdeg, ma cosa contengono
#  dipende dal montaggio con cui la seduta e' stata registrata:
#
#     sedute F11+ (mount dichiarato) -> colonne gia' giuste, burst gia' giusti
#     sedute precedenti              -> registrate con la scheda a DESTRA e la
#                                       configurazione a "frontale": le colonne
#                                       sono invertite e i burst sono nel frame
#                                       di mount 0
#
#  Non e' un'ipotesi: e' il verdetto del DIAG ASSI del 26/07 (montaggio destro,
#  margine 36 su soglia di allarme 5), confermato dai numeri stessi — nella
#  seduta del 25/07 la colonna "cant" segna 17,0 gradi con sd 0,72, cioe' una
#  mira TENUTA, non un rollio del braccio d'arco.
#
#  Lo strumento quindi APPLICA la corrispondenza e usa i nomi veri, dichiarando
#  che e' dedotta. Mostrare la formula al posto del nome sarebbe prudenza fuori
#  posto: rende illeggibile un dato di cui si conosce la provenienza.
@dataclass
class Assetto:
    dedotto: bool          # True se la corrispondenza e' dedotta, non dichiarata
    col_alzo: str          # nome della colonna del DataFrame che contiene l'alzo
    col_cant: str          # ... e quella che contiene il cant


def assetto(s: "Sessione") -> Assetto:
    if s.meta.get("mount", ""):
        return Assetto(dedotto=False, col_alzo="alzo", col_cant="cant")
    return Assetto(dedotto=True, col_alzo="cant", col_cant="alzo")


def offset_taratura(s: "Sessione") -> tuple[float, float]:
    """(off_cant_deg, off_alzo_deg) dichiarati in session.txt, 0 se assenti.

    Il firmware li sottrae agli angoli PRIMA di scriverli nel CSV. Qualunque
    ricalcolo fatto qui deve fare lo stesso, altrimenti i due numeri divergono
    di una costante — ed e' successo: la traccia dava -16,66 dove il CSV dava
    -18,40, su tutti e venti i tiri, cioe' esattamente off_alzo_deg.
    """
    def f(k):
        try:
            return float(s.meta.get(k, 0) or 0)
        except (TypeError, ValueError):
            return 0.0
    return f("off_cant_deg"), f("off_alzo_deg")


def burst_usabile(s: "Sessione", b):
    """Il burst nel frame GIUSTO, raddrizzato se serve. Con cache."""
    if b is None:
        return None
    if not assetto(s).dedotto:
        return b
    if not hasattr(b, "_radd"):
        object.__setattr__(b, "_radd", raddrizza(b))
    return b._radd


def bursts_usabili(s: "Sessione") -> list:
    return [burst_usabile(s, b) for b in s.bursts_ordinati()]


# ============================================================================
#  Vista d'insieme su piu' sessioni
# ============================================================================
def tabella_sessioni(sessioni: list[Sessione]) -> pd.DataFrame:
    return pd.DataFrame([{
        "sessione": s.nome,
        "quando": s.meta.get("ended_datetime", "—"),
        "tiri": s.n_tiri,
        "onde": s.n_onde,
        "firmware": s.meta.get("fw", "—"),
        # Dal firmware 1.83-F11 la sessione dichiara montaggio e taratura.
        # Prima non lo faceva, e su quelle sedute cant e alzo sono SCAMBIATI.
        "montaggio": s.meta.get("mount_lato", "destro (dedotto)"),
        "tarato": ("sì" if abs(float(s.meta.get("off_cant_deg", 0) or 0)) > 0.005
                   or abs(float(s.meta.get("off_alzo_deg", 0) or 0)) > 0.005
                   else ("no" if "off_cant_deg" in s.meta else "—")),
        "avvisi": len(s.avvisi),
    } for s in sessioni])


def assetto_dichiarato(s: "Sessione") -> bool:
    """La sessione dice con che montaggio e' stata registrata?

    Se no, cant e alzo potrebbero essere sulle colonne scambiate: e' il caso
    delle sedute anteriori al firmware 1.83-F11, registrate con la scheda
    montata di lato e la configurazione a "frontale". Nella seduta del 25/07 il
    "cant" segnava 17 gradi che erano l'alzo.
    Lo strumento NON corregge da solo: aggiustare in silenzio un dato di cui non
    si conosce la provenienza e' peggio che mostrarlo con un avviso.
    """
    return bool(s.meta.get("mount", ""))


def tiri_di_tutte(sessioni: list[Sessione]) -> pd.DataFrame:
    """Tutti i tiri di tutte le sessioni in una tabella sola.

    E' la base del confronto fra sedute: una colonna `sessione` in piu' e ogni
    analisi longitudinale diventa un raggruppamento. Le sessioni senza CSV
    vengono saltate: non hanno metriche da confrontare.
    """
    pezzi = []
    for s in sessioni:
        if s.tiri.empty:
            continue
        d = s.tiri.copy()
        # MAPPA APPLICATA ALLA FONTE: da qui in poi le colonne "alzo" e "cant"
        # contengono davvero l'alzo e il cant, qualunque sia il montaggio con cui
        # la seduta e' stata registrata. Farlo una volta sola qui evita che ogni
        # analisi a valle debba ricordarsene — ed e' esattamente il tipo di
        # dimenticanza che ha gia' prodotto grafici con l'asse sbagliato.
        A = assetto(s)
        if A.dedotto:
            d["alzo"], d["cant"] = s.tiri["cant"], s.tiri["alzo"]
        d.insert(0, "sessione", s.nome)
        d.insert(1, "quando", s.meta.get("ended_datetime", ""))
        d["assetto_dedotto"] = A.dedotto
        pezzi.append(d)
    if not pezzi:
        return pd.DataFrame()
    return pd.concat(pezzi, ignore_index=True)
