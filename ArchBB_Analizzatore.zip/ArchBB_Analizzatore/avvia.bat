@echo off
REM ArchBB - Analizzatore. Doppio clic da Windows.
REM PowerShell: ricorda che i comandi si concatenano con ; non con &&
cd /d "%~dp0"
py -m pip install -r requirements.txt
py -m streamlit run app.py
pause
