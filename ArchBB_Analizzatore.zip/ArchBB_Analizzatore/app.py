#!/usr/bin/env python3
# ============================================================================
#  ArchBB — Analizzatore  ·  app.py (Streamlit)
#  Cesare Pagura · Padova/Noale IT · luglio 2026
# ----------------------------------------------------------------------------
#  IL RUOLO DI QUESTO STRUMENTO
#    L'app HTML sta sul telefono, al campo, e vive di BLE: scarica le metriche
#    e mostra il quadro della seduta. Questo Streamlit sta alla scrivania, gira
#    su qualunque sistema operativo con Python, e legge la microSD: e' dove si
#    guarda DENTRO i tiri.
#
#    Divisione netta, per non fare due volte la stessa cosa a meta':
#      HTML  -> mobilita', BLE, colpo d'occhio
#      qui   -> tutta la card, confronto fra sedute, verifica, statistica
#
#    Le convenzioni di calcolo NON sono duplicate: stanno in archbb_dsp.py, che
#    e' l'implementazione di riferimento. Il JavaScript dell'app le cita nei
#    commenti come "stessa specifica implementata due volte".
# ============================================================================
from __future__ import annotations

import io
import sys
from pathlib import Path

# I moduli di calcolo stanno accanto a questo file. `streamlit run` di solito
# aggiunge da se' la cartella dello script a sys.path, ma non in ogni contesto
# (test automatici, avvio da un'altra directory, alcune installazioni). Una
# riga qui evita un ModuleNotFoundError che dall'esterno sembra un bug dell'app.
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots
from scipy import stats as sps_stats

import archbb_dsp as D
import archbb_io as IO
import archbb_metrics as MET

# ── Coerenza dei moduli ──────────────────────────────────────────────────
#  I quattro file vanno aggiornati INSIEME. Il controllo costa tre righe e
#  trasforma un AttributeError incomprensibile in un messaggio che dice quale
#  file e' rimasto indietro.
VERSIONE_ATTESA = "2026.07.27-11"
_disallineati = [nome for nome, mod in
                 (("archbb_dsp.py", D), ("archbb_io.py", IO), ("archbb_metrics.py", MET))
                 if getattr(mod, "VERSIONE", "assente") != VERSIONE_ATTESA]

st.set_page_config(page_title="ArchBB — Analizzatore", page_icon="🎯",
                   layout="wide", initial_sidebar_state="expanded")

# ── Palette, la stessa dell'app HTML e del dispositivo ──────────────────────
C = dict(bg="#0d1017", bg2="#131820", grid="#2a3548",
         txt="#e6eef8", txt2="#9fb4cd", txt3="#6b829e",
         acc="#00c8ff", grn="#00e87a", amb="#ffb020", red="#ff4455",
         pur="#a67cff", teal="#20d4c0")

# DIMENSIONI — questo strumento gira su un MONITOR, non su un telefono.
#  I default di Streamlit sono tarati per il mobile: il valore di st.metric e'
#  2.25rem (36 px), i titoli sono enormi, e su uno schermo da scrivania si
#  vedono quattro numeri per schermata. Qui si rimpicciolisce tutto di un
#  fattore ~2,5, che e' lo scarto misurato a occhio fra le due situazioni.
#  Vale la pena farlo in CSS e non tema per tema: cosi' resta un punto solo.
if _disallineati:
    st.error(
        "**Moduli disallineati.** Questi file sono di una versione diversa da "
        "`app.py` (attesa `" + VERSIONE_ATTESA + "`):\n\n"
        + "\n".join(f"- `{n}` → `{getattr(m, 'VERSIONE', 'nessuna versione')}`"
                     for n, m in (("archbb_dsp.py", D), ("archbb_io.py", IO),
                                  ("archbb_metrics.py", MET))
                     if n in _disallineati)
        + "\n\nSuccede estraendo lo zip **sopra** una cartella esistente senza "
          "sostituire tutti i file. Cancella la cartella e riestrai l'archivio "
          "per intero."
    )
    st.stop()

st.markdown(f"""
<style>
  .stApp {{ background:{C['bg']}; }}
  html, body, [class*="css"] {{ font-size:13px; }}
  h1 {{ font-size:1.45rem !important; letter-spacing:.4px; margin-bottom:.2rem; }}
  h2 {{ font-size:1.12rem !important; }}
  h3 {{ font-size:.98rem !important; }}
  h4 {{ font-size:.88rem !important; margin:.9rem 0 .3rem; }}
  .block-container {{ padding-top:2.2rem; padding-bottom:2rem; max-width:1500px; }}
  [data-testid="stMetric"] {{ background:{C['bg2']}; border:1px solid {C['grid']};
      border-radius:8px; padding:7px 10px; }}
  [data-testid="stMetricValue"] {{ font-size:1.15rem !important; font-weight:600; }}
  [data-testid="stMetricLabel"] {{ font-size:.72rem !important; }}
  [data-testid="stMetricLabel"] p {{ font-size:.72rem !important; }}
  [data-testid="stMetricDelta"] {{ font-size:.68rem !important; }}
  [data-testid="stMetricDelta"] svg {{ display:none; }}
  .stTabs [data-baseweb="tab"] {{ font-size:.8rem; padding:6px 12px; }}
  .stDataFrame {{ font-size:.78rem; }}
  .stSelectbox label, .stRadio label, .stMultiSelect label,
  .stTextInput label, .stCheckbox label {{ font-size:.78rem !important; }}
  code, .mono {{ font-family:'JetBrains Mono','Fira Code',monospace; font-size:.78rem; }}
  .nota {{ color:{C['txt3']}; font-size:11.5px; line-height:1.65; }}
  .nota b {{ color:{C['txt2']}; }}
  .fase-tit {{ font-family:monospace; letter-spacing:1.2px; font-weight:700;
               font-size:.76rem; margin:12px 0 3px; }}

  /* INTESTAZIONE FERMA, CONTENUTO SCORREVOLE.
     Appiccicare i singoli pezzi alla pagina che scorre e' fragile: bisogna
     indovinare l'altezza di ciascuno per impilare i "top", e basta un titolo
     che va a capo per sfasare tutto. Si rovescia: si toglie lo scorrimento al
     contenitore principale e lo si da' al pannello della scheda. Titolo e barra
     delle schede stanno sopra quel pannello, quindi restano fermi perche' non
     c'e' piu' nulla che li faccia scorrere.

     I SELETTORI SONO QUELLI VERI, letti dal bundle del frontend installato.
     Al primo tentativo avevo usato `html, body` e `[data-baseweb="tab-panel"]`:
     nessuno dei due esiste in Streamlit, e il CSS non agganciava niente.
       - il contenitore che scorre e' [data-testid="stMain"]
       - il pannello della scheda ha role="tabpanel", non un data-baseweb
     `section.main` e' la forma vecchia, tenuta per compatibilita'. */
  [data-testid="stMain"], section.main {{ overflow:hidden !important; }}
  .block-container {{ padding-bottom:0 !important; }}

  /* Regola generale: e' il PANNELLO della scheda a scorrere. */
  [data-testid="stTabs"] div[role="tabpanel"] {{
      max-height:calc(100vh - 185px); min-height:240px;
      overflow-y:auto; overflow-x:hidden;
      padding:2px 14px 40px 2px;
      scrollbar-width:thin; scrollbar-color:{C['grid']} transparent;
  }}

  /* ECCEZIONE: le due schede con la navigazione dei tiri.
     Li' la barra deve restare FUORI dalla zona che scorre, non appiccicata
     dentro. `position:sticky` non regge: dentro i blocchi annidati di Streamlit
     l'antenato che scorre non e' quello che serve, e la barra scorre via
     insieme al resto — che e' quello che si vedeva.
     Soluzione deterministica: il pannello NON scorre, e lo scorrimento va a un
     contenitore che contiene solo il corpo. La barra sta sopra quel
     contenitore, quindi non puo' scorrere: non e' dentro niente che scorra.
     Il selettore :has() individua i pannelli che hanno una barra dentro. */
  [data-testid="stTabs"] div[role="tabpanel"]:has(.st-key-nav_tiro),
  [data-testid="stTabs"] div[role="tabpanel"]:has(.st-key-nav_spettro) {{
      max-height:none; overflow:visible; padding-right:2px;
  }}
  .st-key-scroll_tiro, .st-key-scroll_spettro {{
      max-height:calc(100vh - 268px); min-height:220px;
      overflow-y:auto; overflow-x:hidden;
      padding:2px 14px 40px 2px;
      scrollbar-width:thin; scrollbar-color:{C['grid']} transparent;
  }}

  [data-testid="stTabs"] div[role="tabpanel"]::-webkit-scrollbar,
  .st-key-scroll_tiro::-webkit-scrollbar,
  .st-key-scroll_spettro::-webkit-scrollbar {{ width:9px; }}
  [data-testid="stTabs"] div[role="tabpanel"]::-webkit-scrollbar-thumb,
  .st-key-scroll_tiro::-webkit-scrollbar-thumb,
  .st-key-scroll_spettro::-webkit-scrollbar-thumb {{
      background:{C['grid']}; border-radius:5px; }}

  /* La barra di navigazione, ora fuori dalla zona scorrevole. */
  .st-key-nav_tiro, .st-key-nav_spettro {{
      background:{C['bg']}; padding:6px 4px 6px;
      border-bottom:1px solid {C['grid']}; margin-bottom:6px;
  }}
  .st-key-nav_tiro [data-testid="stHorizontalBlock"],
  .st-key-nav_spettro [data-testid="stHorizontalBlock"] {{ gap:.4rem; }}
</style>
""", unsafe_allow_html=True)


def fig_base(h=260, titolo_y="", titolo_x=""):
    # Altezza e caratteri ridotti: vedi la nota sulle dimensioni nel CSS.
    f = go.Figure()
    f.update_layout(
        height=h, template="plotly_dark",
        paper_bgcolor=C["bg"], plot_bgcolor=C["bg2"],
        font=dict(family="JetBrains Mono, monospace", size=9, color=C["txt2"]),
        margin=dict(l=48, r=14, t=22, b=34),
        xaxis=dict(gridcolor=C["grid"], zerolinecolor=C["grid"], title=titolo_x),
        yaxis=dict(gridcolor=C["grid"], zerolinecolor=C["grid"], title=titolo_y),
        legend=dict(orientation="h", y=1.14, x=0, bgcolor="rgba(0,0,0,0)",
                    font=dict(size=9)),
        hovermode="x unified",
    )
    return f


# ============================================================================
#  Caricamento (con cache: la card e' lenta, e si rilegge solo se cambia)
# ============================================================================
@st.cache_data(show_spinner="Lettura della card…")
def carica_cartella(percorso: str, _firma: float):
    return IO.scansiona_cartella(percorso)


@st.cache_data(show_spinner="Lettura dell'archivio…")
def carica_zip(dati: bytes, nome: str):
    return IO.scansiona_zip(dati, nome)


def firma_cartella(p: str) -> float:
    """Somma dei tempi di modifica: se cambia, la cache si invalida da sola.

    Piu' onesto di un pulsante "ricarica": l'utente non deve ricordarsi di
    premerlo dopo aver tirato altre frecce.
    """
    try:
        r = Path(p).expanduser()
        return sum(f.stat().st_mtime for f in r.rglob("*") if f.is_file())
    except OSError:
        return 0.0


# ============================================================================
#  Barra laterale — sorgente dei dati
# ============================================================================
st.sidebar.markdown("### 🎯 ArchBB · Analizzatore")
# La versione a schermo, sempre. Serve a rispondere in un secondo alla domanda
# "sto guardando la versione nuova o quella vecchia?", che finora si e' potuta
# risolvere solo aprendo i sorgenti.
st.sidebar.caption(f"analisi approfondita · legge la microSD  ·  **{VERSIONE_ATTESA}**")

modo = st.sidebar.radio("Sorgente", ["Cartella sulla card", "Archivio .zip"],
                        label_visibility="collapsed")

sessioni: list[IO.Sessione] = []
if modo == "Cartella sulla card":
    percorso = st.sidebar.text_input(
        "Percorso",
        value=st.session_state.get("ultimo_percorso", ""),
        placeholder=r"E:\  oppure  /Volumes/ARCHBB  oppure  …/ARCHBB",
        help="Va bene la radice della card, la cartella ARCHBB o una singola SESS_*",
    )
    if percorso:
        st.session_state["ultimo_percorso"] = percorso
        try:
            sessioni = carica_cartella(percorso, firma_cartella(percorso))
        except FileNotFoundError as e:
            st.sidebar.error(str(e))
else:
    up = st.sidebar.file_uploader("Archivio della sessione", type=["zip"])
    if up is not None:
        sessioni = carica_zip(up.getvalue(), up.name)

if not sessioni:
    st.title("Analizzatore ArchBB")
    st.markdown("""
Indica dove sono i dati, nella barra a sinistra.

**Dalla card:** il percorso può essere la radice (`E:\\`), la cartella
`ARCHBB`, o una singola cartella `SESS_…`. Vengono riconosciute da sole.

**Da archivio:** uno `.zip` che contenga una o più cartelle `SESS_…`.
""", unsafe_allow_html=False)
    st.markdown(f"""<div class="nota">
Questo strumento legge <b>tutta la card</b> e confronta le sedute fra loro.
Non usa il Bluetooth: per quello c'è l'app HTML, che sta sul telefono e serve
al campo. Qui si lavora sui campioni grezzi, dove servono numpy e scipy.
</div>""", unsafe_allow_html=True)
    st.stop()

# ── Selezione delle sessioni su cui lavorare ───────────────────────────────
nomi = [s.nome for s in sessioni]
st.sidebar.markdown("---")
st.sidebar.markdown(f"**{len(sessioni)} session{'e' if len(sessioni)==1 else 'i'} sulla card**")
scelte = st.sidebar.multiselect("Sedute in analisi", nomi, default=nomi[: min(4, len(nomi))])
attive = [s for s in sessioni if s.nome in scelte]
if not attive:
    st.warning("Nessuna seduta selezionata: scegline almeno una nella barra a sinistra.")
    st.stop()

# ATTENZIONE: il widget si crea UNA VOLTA, fuori dalla ricerca.
#  Prima era scritto come next((s for s in attive if s.nome == st.sidebar.selectbox(...)))
#  e il selectbox finiva DENTRO la condizione del generatore: veniva quindi
#  creato una volta per ogni seduta scorsa, finche' non trovava quella giusta.
#  Con una seduta sola corrisponde subito e non si vede nulla; con tre, se si
#  sceglie la seconda, il widget nasce due volte e Streamlit rifiuta l'ID
#  duplicato. Mai mettere la creazione di un widget dentro una comprehension:
#  ha un effetto collaterale, e le comprehension nascondono quante volte
#  vengono valutate.
nome_seduta = st.sidebar.selectbox("Seduta in dettaglio", [s.nome for s in attive],
                                   key="sel_seduta_dettaglio")
sess_corrente = next((s for s in attive if s.nome == nome_seduta), attive[0])

avvisi = [(s.nome, a) for s in attive for a in s.avvisi]
if avvisi:
    with st.sidebar.expander(f"⚠ {len(avvisi)} avvisi"):
        for n, a in avvisi:
            st.caption(f"**{n}** — {a}")

# ── Filtro: solo i tiri effettivamente tirati ──────────────────────────────
#  Serve sulle sedute di sviluppo, dove il buffer registra anche l'arco
#  maneggiato, appoggiato o falsi scocchi. Nel file importato del 14/07 sono
#  33 catture su 44 senza punteggio, e due hanno cant -76° e -92°: assetti
#  che un arco in mira non può avere. Lasciarli dentro non falsa "un po'" le
#  statistiche, le distrugge — σ(cant) passa da 3,7° a 19,4°.
#  Il criterio è quello del dispositivo stesso: se non è stato assegnato un
#  punteggio, per l'arciere quel gesto non era un tiro.
st.sidebar.markdown("---")
solo_punteggio = st.sidebar.checkbox(
    "Solo tiri con punteggio", value=True,
    help="Esclude le catture senza esito: arco maneggiato, falsi scocchi, prove")


def filtra(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or not solo_punteggio or "arcs" not in df.columns:
        return df
    return df[df["arcs"].abs() > 0]


# ============================================================================
#  Tabella delle metriche — calcolata UNA VOLTA, usata da tutte le schede
# ============================================================================
#  Panoramica, Tiro per tiro, Progressione e Statistica guardano gli stessi
#  numeri. Calcolarli in ogni scheda significherebbe quattro implementazioni
#  che possono divergere, e quattro volte il costo: su una card intera sono
#  migliaia di finestre calme.
COLONNE_FASE = ["fermezza", "scostamento in mira", "ξ consistenza", "cant",
                "pulizia rilascio", "nettezza scocco", "torsione",
                "hold", "follow-through"]


@st.cache_data(show_spinner="Calcolo delle metriche…")
def tabella_metriche(nomi: tuple, firma: float, _sessioni):
    righe = []
    for sx in _sessioni:
        if sx.nome not in nomi or sx.tiri.empty:
            continue
        A = IO.assetto(sx)
        precedenti = []          # xi confronta col PASSATO, non con la seduta intera
        for _, t in sx.tiri.iterrows():
            f = str(t.get("burst_file") or "")
            b = IO.burst_usabile(sx, sx.bursts.get(f))
            m = MET.ricalcola(b) if b is not None else None
            _, _offa = IO.offset_taratura(sx)
            tr = D.traccia(b, off_alzo_deg=_offa) if b is not None else None
            xi = MET.consistenza_xi(b, precedenti) if b is not None else None
            if b is not None:
                precedenti.append(b)
            righe.append({
                "sessione": sx.nome,
                "quando": sx.meta.get("ended_datetime", ""),
                "shot": t.get("shot"),
                "arcs": t.get("arcs"),
                "zona": t.get("zona"),
                "dist_m": t.get("dist_m"),
                "burst_file": f,
                "onda": b is not None,
                "fermezza": m.stability if m else None,
                "scostamento in mira": MET.scostamento_mira(b, tr) if tr is not None else None,
                "ξ consistenza": xi,
                "alzo": t.get(A.col_alzo),      # resta per la scheda del tiro
                "cant": t.get(A.col_cant),
                "pulizia rilascio": t.get("release_jerk"),
                "release_class": t.get("release_class"),
                "nettezza scocco": MET.nettezza_scocco(b) if b is not None else None,
                "torsione": m.torsione if m else None,
                "follow-through": MET.follow_through(b) if b is not None else None,
                # hold: dal CSV se l'assetto e' dichiarato, ricalcolato se
                # dedotto (a bordo era stato integrato l'asse sbagliato)
                "hold": (m.hold if (m and A.dedotto) else t.get("hold")),
                "hold_class": t.get("hold_class"),
                "assetto_dedotto": A.dedotto,
            })
    return pd.DataFrame(righe)


def metriche_attive(attive):
    return tabella_metriche(tuple(sorted(s.nome for s in attive)),
                            sum(len(s.tiri) + s.n_onde for s in attive),
                            attive)


st.title("Analizzatore ArchBB")

TAB = st.tabs(["Panoramica", "Tiro per tiro", "Progressione", "Sovrapposizione",
               "Spettro e smorzamento", "Verifica del dispositivo", "Statistica"])

# ============================================================================
#  1 · PANORAMICA — tutta la card in una tabella
# ============================================================================
with TAB[0]:
    tab = IO.tabella_sessioni(attive)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Sedute", len(attive))
    c2.metric("Tiri totali", int(tab["tiri"].sum()))  # dalla card, non filtrati
    c3.metric("Forme d'onda", int(tab["onde"].sum()))
    fw = sorted({s.meta.get("fw", "—") for s in attive})
    c4.metric("Firmware", fw[0] if len(fw) == 1 else f"{len(fw)} versioni")

    st.dataframe(tab, width='stretch', hide_index=True)

    ambigue = [s.nome for s in attive if IO.assetto(s).dedotto]
    if ambigue:
        st.info(f"""**{len(ambigue)} sedute con corrispondenza dedotta.**
Registrate prima del firmware `1.83-F11`, quindi senza `mount` in
`session.txt`. Lo strumento **applica la corrispondenza corretta**: colonne
rimesse a posto e forme d'onda raddrizzate col verdetto del DIAG ASSI del 26/07
(montaggio destro, margine 36 su soglia 5). L'`hold` viene **ricalcolato** dai
campioni, perché quello nel CSV il dispositivo l'ha integrato sull'asse
sbagliato e non è recuperabile.
\n\nResta indeterminato solo il valore **assoluto** dell'alzo: senza taratura
del montaggio contiene anche l'inclinazione della staffa. Le variazioni sono
affidabili.
\n\nSedute: {', '.join(ambigue)}""")

    grezzi = IO.tiri_di_tutte(attive)
    tutti = filtra(grezzi)
    esclusi = len(grezzi) - len(tutti)
    if esclusi:
        st.info(f"**{esclusi} catture senza punteggio escluse** su {len(grezzi)}. "
                "Sono gesti che il dispositivo ha registrato ma a cui non è stato "
                "assegnato un esito: arco maneggiato, falsi scocchi, prove. "
                "Togli la spunta nella barra a sinistra per includerle.")
    if not tutti.empty:
        st.markdown("#### Le tre fasi, seduta per seduta")
        st.markdown(f"""<div class="nota">
Struttura distillata dai 42 tiri del 14/07: PCA con PC1 al 32 % — <b>non esiste
un indice unico di bravura</b> — e tre gruppi statisticamente indipendenti
(ρ fra loro −0,24 / +0,25 / −0,04, tutte con p &gt; 0,1). Qui non si guarda il
singolo tiro ma come ciascuna fase si muove <b>fra le sedute</b>: è la domanda
a cui il singolo tiro non può rispondere.
</div>""", unsafe_allow_html=True)

        # Le metriche dal burst si calcolano una volta e si mettono in cache:
        # su una card intera sono migliaia di finestre calme.
        MF = filtra(metriche_attive(attive))

        FASI = [
            ("1 · MIRA", C["acc"], ["fermezza", "scostamento in mira", "ξ consistenza"]),
            ("2 · RILASCIO", C["amb"], ["pulizia rilascio", "nettezza scocco", "torsione"]),
            ("3 · TENUTA", C["grn"], ["hold", "follow-through"]),
        ]
        for titolo, colore, metriche in FASI:
            st.markdown(f"<div style='color:{colore};font-family:monospace;"
                        f"letter-spacing:1.4px;font-weight:700;margin:18px 0 6px'>"
                        f"{titolo}</div>", unsafe_allow_html=True)
            cols = st.columns(len(metriche))
            for col, nome in zip(cols, metriche):
                v = MF[nome].dropna() if nome in MF.columns else pd.Series(dtype=float)
                with col:
                    if len(v) >= 2:
                        st.metric(nome, f"{v.mean():.2f}", delta=f"σ {v.std(ddof=1):.2f}",
                                  delta_color="off")
                    else:
                        st.metric(nome, "—")

            if MF["sessione"].nunique() >= 2:
                g = MF.groupby("sessione")[metriche].agg(["mean", "std"])
                f = fig_base(200, "", "seduta")
                for k, nome in enumerate(metriche):
                    if nome not in MF.columns:
                        continue
                    m = g[(nome, "mean")]
                    f.add_trace(go.Scatter(x=m.index, y=m.values, mode="lines+markers",
                                           name=nome, line=dict(width=2)))
                st.plotly_chart(f, width='stretch')


# ============================================================================
#  2 · TIRO PER TIRO — tutte le metriche e i grafici di UN tiro
# ============================================================================
with TAB[1]:
    M = metriche_attive(attive)
    Ms = M[M["sessione"] == sess_corrente.nome].reset_index(drop=True)
    if Ms.empty:
        st.info("Questa seduta non ha metriche.")
    else:
        # NAVIGAZIONE a frecce. Con 60 tiri una tendina costringe a scorrere un
        # elenco per confrontare due tiri adiacenti; due frecce fanno un passo
        # per clic. La tendina resta per i salti lunghi.
        if "k_tiro" not in st.session_state:
            st.session_state.k_tiro = 0
        st.session_state.k_tiro = min(st.session_state.k_tiro, len(Ms) - 1)

        with st.container(key="nav_tiro"):
            cprev, cmid, cnext = st.columns([1, 6, 1])
            if cprev.button("‹", width='stretch',
                            disabled=st.session_state.k_tiro <= 0, key="btn_prev"):
                st.session_state.k_tiro -= 1
            if cnext.button("›", width='stretch',
                            disabled=st.session_state.k_tiro >= len(Ms) - 1,
                            key="btn_next"):
                st.session_state.k_tiro += 1
            etich = [f"tiro {int(r.shot)}" + ("" if r.onda else "  (senza onda)")
                     for r in Ms.itertuples()]
            k = cmid.selectbox("Tiro", range(len(etich)),
                               format_func=lambda i: etich[i],
                               key="k_tiro", label_visibility="collapsed")
        with st.container(key="scroll_tiro"):
            r = Ms.iloc[k]
            A = IO.assetto(sess_corrente)

            zn = "fuori" if pd.isna(r.zona) else ("centro" if r["zona"] == 4 else f"zona {int(r['zona'])}")
            st.caption(f"{sess_corrente.nome} · {zn}"
                       + (f" · {int(r['dist_m'])} m" if pd.notna(r["dist_m"]) else "")
                       + (" · forma d'onda presente" if r["onda"] else " · nessuna forma d'onda"))

            # --- le tre fasi, con il riferimento di seduta accanto ---------------
            FASI = [("1 · MIRA", C["acc"],
                     ["fermezza", "scostamento in mira", "ξ consistenza"],
                     ["/100", "°", ""]),
                    ("2 · RILASCIO", C["amb"],
                     ["pulizia rilascio", "nettezza scocco", "torsione"],
                     [" m/s³", " m/s³", "°"]),
                    ("3 · TENUTA", C["grn"], ["hold", "follow-through"], ["°", "/100"])]
            for titolo, colore, nomi_m, unita in FASI:
                st.markdown(f"<div style='color:{colore};font-family:monospace;"
                            f"letter-spacing:1.4px;font-weight:700;margin:16px 0 4px'>"
                            f"{titolo}</div>", unsafe_allow_html=True)
                cols = st.columns(len(nomi_m))
                for col, nome, u in zip(cols, nomi_m, unita):
                    v = r[nome]
                    rifv = Ms[nome].dropna()
                    with col:
                        if pd.isna(v):
                            st.metric(nome, "—")
                        else:
                            d = (f"seduta {rifv.mean():.2f} ± {rifv.std(ddof=1):.2f}"
                                 if len(rifv) >= 2 else None)
                            st.metric(nome, f"{v:.2f}{u}", delta=d, delta_color="off")

            cA_, cB_, cC_ = st.columns(3)
            cA_.metric("angolo di mira", f"{r['alzo']:+.2f}°" if pd.notna(r["alzo"]) else "—")
            cB_.metric("cant", f"{r['cant']:+.2f}°" if pd.notna(r["cant"]) else "—")
            zn2 = "—" if pd.isna(r["dist_m"]) else f"{int(r['dist_m'])} m"
            cC_.metric("distanza", zn2)
            st.markdown(f"""<div class="nota">
    <b>Angolo di mira e cant</b> stanno qui sotto e non fra le metriche di fase:
    dipendono dalla distanza e dal bersaglio, non dall'esecuzione. Nella fase MIRA
    c'è invece lo <b>scostamento</b>, cioè quanto la mano d'arco si muove mentre
    mira — che è la cosa che l'arciere controlla.
    </div>""", unsafe_allow_html=True)

            b = IO.burst_usabile(sess_corrente, sess_corrente.bursts.get(r["burst_file"]))
            if b is None:
                st.info("Senza forma d'onda non ci sono grafici per questo tiro.")
            else:
                # --- TRACCIA 2D ------------------------------------------------
                st.markdown("#### Traccia 2D — dove si è spostata la mano d'arco")
                cA, cB = st.columns([1, 1])
                segno = cA.radio("Verso dello yaw", [-1.0, +1.0], horizontal=True,
                                 format_func=lambda v: "+gx a destra" if v < 0
                                                       else "+gx a sinistra",
                                 help="Non validato sulla 1.83: fidati della forma, "
                                      "non del verso", key="segno_yaw")
                _, _offa = IO.offset_taratura(sess_corrente)
                tr = D.traccia(b, segno_yaw=segno, off_alzo_deg=_offa)
                g = D.geometria_traccia(b, tr)
                R = g.scala_deg
                # Serie gia' orientate: chi disegna non deve sapere se c'e' uno
                # scambio d'assi, e' deciso in un punto solo (archbb_dsp).
                ORIZ, VERT = D.serie_traccia(tr)

                # RIQUADRO QUADRATO con lo STESSO range sui due assi. La 1.29 disegna
                # su una tela quadrata e usa lo stesso fattore per x e y; qui bisogna
                # imporlo, perche' un riquadro largo con scaleanchor fa allargare
                # l'asse x a Plotly e la traccia esce deformata — sembra "ruotata".
                LATO = 560
                ft = go.Figure()
                ft.update_layout(
                    width=LATO, height=LATO, template="plotly_dark",
                    paper_bgcolor=C["bg"], plot_bgcolor=C["bg2"],
                    font=dict(family="JetBrains Mono, monospace", size=9, color=C["txt2"]),
                    margin=dict(l=44, r=16, t=16, b=40),
                    legend=dict(orientation="h", y=1.10, x=0, bgcolor="rgba(0,0,0,0)",
                                font=dict(size=9)),
                    xaxis=dict(range=[-R, R], gridcolor=C["grid"], zerolinecolor=C["txt3"],
                               title="laterale   sinistra ← → destra  [°]", constrain="domain"),
                    yaxis=dict(range=[-R, R], gridcolor=C["grid"], zerolinecolor=C["txt3"],
                               title="alzo   giù ← → su  [°]"),
                    hovermode="closest", showlegend=True,
                )

                # Quattro fasi, con i confini in CAMPIONI e i colori della 1.29.
                confini = [(0, g.i_mira), (g.i_mira, b.trig),
                           (b.trig, g.i_sep), (g.i_sep, b.n - 1)]
                for (a_, z_), (nome, col, w, op) in zip(confini, D.FASI_TRACCIA):
                    if z_ - a_ < 2:
                        continue
                    ft.add_trace(go.Scatter(
                        x=ORIZ[a_:z_ + 1], y=VERT[a_:z_ + 1], mode="lines",
                        name=nome, opacity=op,
                        line=dict(color=col, width=w, shape="linear")))

                # Scocco: cerchietto ambra al centro, con alone.
                ft.add_trace(go.Scatter(x=[0], y=[0], mode="markers", name="scocco",
                                        marker=dict(size=20, color="rgba(255,176,32,0.18)")))
                ft.add_trace(go.Scatter(x=[0], y=[0], mode="markers", showlegend=False,
                                        marker=dict(size=9, color=C["amb"])))
                # Separazione freccia-corda: anello bianco.
                ft.add_trace(go.Scatter(
                    x=[ORIZ[g.i_sep]], y=[VERT[g.i_sep]], mode="markers",
                    name="+15 ms · freccia libera",
                    marker=dict(size=11, color="rgba(0,0,0,0)",
                                line=dict(color="#e8eef8", width=1.8))))
                # Fine del follow-through: puntino rosso attenuato.
                ft.add_trace(go.Scatter(x=[ORIZ[b.n - 1]], y=[VERT[b.n - 1]],
                                        mode="markers", showlegend=False,
                                        marker=dict(size=7, color="rgba(255,68,85,0.55)")))
                cB.metric("scala riquadro", f"±{R:.0f}°")
                cB.metric("laterale @ separazione", f"{g.yaw_sep_deg:+.2f}°")
                cB.metric("angolo di mira", f"{r['alzo']:+.2f}°"
                          if pd.notna(r["alzo"]) else "—")
                st.plotly_chart(ft, width='content')

                st.markdown(f"""<div class="nota">
    Tutto è <b>centrato sullo scocco</b>: il cerchietto ambra al centro è l'istante
    del rilascio, e la traccia mostra gli scostamenti da lì.
    <b style="color:#4488ff">Blu</b> pre-mira · <b style="color:{C['grn']}">verde</b>
    mira (ultimi {D.CAMPIONI_MIRA} campioni, ~{D.CAMPIONI_MIRA/b.fs*1000:.0f} ms) ·
    <b style="color:{C['red']}">rosso acceso</b> i primi {D.SEPARAZIONE_MS:.0f} ms,
    con la freccia ancora nell'arco · <b style="color:{C['red']};opacity:.6">rosso
    spento</b> il follow-through.
    <br><br><b>La scala si calcola solo dalla mira in poi</b>, e il blu può uscire
    dal riquadro: il movimento di portata dell'arco in posizione vale 8–10°, contro
    i decimi di grado della mira. Includerlo schiaccerebbe tutto il resto in un
    punto — ed è esattamente l'effetto che faceva sembrare la traccia ruotata.
    <br><br>Riquadro <b>quadrato con range identico sui due assi</b>: su un riquadro
    largo la stessa traccia apparirebbe deformata.
    <br><br>Bias del giroscopio da ZUPT su <b>{tr.n_bias}</b> campioni fermi.
    <br><br><b>Orientamento degli assi.</b> Le due serie sono disposte così
    perché il movimento ampio è quello di mira, alto-basso — l'osservazione
    dell'arciere. Non è una misura: la prova statica valida l'accelerometro ma
    non il giroscopio, e dai dati di tiro non si risolve. Sta in una costante
    dichiarata (<code>TRACCIA_SCAMBIA_ASSI</code>) invece che nascosta nel
    disegno. Riguarda <b>solo</b> la traccia: hold e torsione restano sugli assi
    che usa il firmware.
    </div>""", unsafe_allow_html=True)

                # --- ONDE DEL SINGOLO TIRO -------------------------------------
                st.markdown("#### Forme d'onda")
                tms = b.t_ms
                sel = (tms >= -400) & (tms <= 800)
                fa = fig_base(220, "m/s²", "ms dallo scocco")
                for nome, arr, col in [("ax verticale", b.ax, C["red"]),
                                       ("ay laterale", b.ay, C["grn"]),
                                       ("az asse freccia", b.az, C["acc"])]:
                    fa.add_trace(go.Scatter(x=tms[sel], y=arr[sel], mode="lines",
                                            name=nome, line=dict(color=col, width=1.3)))
                fa.add_vline(x=0, line=dict(color=C["amb"], width=1.4, dash="dash"))
                fa.add_vrect(x0=0, x1=15, fillcolor=C["amb"], opacity=0.12, line_width=0)
                st.plotly_chart(fa, width='stretch')

                fg = fig_base(220, "°/s", "ms dallo scocco")
                for nome, arr, col in [("gx", b.gx, C["red"]), ("gy pitch", b.gy, C["grn"]),
                                       ("gz torsione", b.gz, C["acc"])]:
                    fg.add_trace(go.Scatter(x=tms[sel], y=arr[sel], mode="lines",
                                            name=nome, line=dict(color=col, width=1.3)))
                fg.add_vline(x=0, line=dict(color=C["amb"], width=1.4, dash="dash"))
                fg.add_vrect(x0=0, x1=15, fillcolor=C["amb"], opacity=0.12, line_width=0)
                st.plotly_chart(fg, width='stretch')

            # --- correzione di distanza ed elevazione ---------------------------
            with st.expander("Correggi distanza ed elevazione della seduta"):
                st.markdown(f"""<div class="nota">
    Il selettore di distanza sul dispositivo resta sull'ultimo valore usato: nella
    seduta del 27/07 diciotto tiri su venti risultano a 18 m mentre erano a 6.
    Qui si correggono <b>nel file</b>.
    <br><br>Alla prima modifica <code>shots.csv</code> viene copiato in
    <code>shots.csv.orig</code>, che non viene mai sovrascritto. La modifica è
    chirurgica: si toccano solo i campi indicati, lasciando tutto il resto byte per
    byte. E <b><code>arcs</code> viene ricalcolato</b>, perché il punteggio codifica
    la distanza — cambiarne una senza l'altro lascerebbe il file in contraddizione
    con sé stesso.
    </div>""", unsafe_allow_html=True)

                if not Path(sess_corrente.percorso).is_dir():
                    st.info("Sorgente da archivio zip: non c'è un file su disco da correggere.")
                else:
                    cc1, cc2, cc3 = st.columns([1, 1, 1])
                    nuova_d = cc1.number_input("Distanza [m]", min_value=1, max_value=200,
                                               value=6, step=1, key="corr_dist")
                    nuova_e = cc2.number_input("Elevazione [°]", min_value=-90, max_value=90,
                                               value=-14, step=1, key="corr_elev")
                    quali = cc3.radio("Applica a", ["tutti i tiri", "solo questo tiro"],
                                      key="corr_quali")
                    agg_d = st.checkbox("aggiorna la distanza", value=True, key="corr_cd")
                    agg_e = st.checkbox("aggiorna l'elevazione", value=True, key="corr_ce")

                    if st.button("Scrivi nel file", type="primary", key="corr_go"):
                        bersagli = (Ms["shot"].dropna().astype(int).tolist()
                                    if quali.startswith("tutti") else [int(r["shot"])])
                        corr = {sh: {"dist_m": nuova_d if agg_d else None,
                                     "elev_deg": nuova_e if agg_e else None}
                                for sh in bersagli}
                        try:
                            n_, msg = IO.correggi_distanza_elevazione(sess_corrente, corr)
                            st.success(msg)
                            # La cache si invalida da sola: firma_cartella somma gli
                            # mtime, e il file appena scritto ne ha uno nuovo.
                            st.rerun()
                        except Exception as e:
                            st.error(f"Non scritto: {e}")

            # --- tabella completa della seduta ---------------------------------
            st.markdown("#### Tutti i tiri della seduta")
            vis = Ms[["shot", "zona", "dist_m"] + COLONNE_FASE + ["onda"]].copy()
            st.dataframe(vis.round(2), width='stretch', hide_index=True)


# ============================================================================
#  3 · PROGRESSIONE — come le metriche si muovono nel tempo
# ============================================================================
with TAB[2]:
    M = filtra(metriche_attive(attive))
    if M.empty:
        st.info("Nessuna metrica da mostrare.")
    else:
        c1, c2 = st.columns([2, 1])
        scelte_m = c1.multiselect("Metriche", COLONNE_FASE,
                                  default=["fermezza", "cant", "hold"])
        asse = c2.radio("Asse orizzontale",
                        ["tiro nella seduta", "progressivo su tutta la card"],
                        help="Il primo confronta l'andamento DENTRO ogni seduta, "
                             "il secondo la storia complessiva")

        if not scelte_m:
            st.info("Scegli almeno una metrica.")
        else:
            M = M.sort_values(["quando", "sessione", "shot"]).reset_index(drop=True)
            M["progressivo"] = range(1, len(M) + 1)
            for nome in scelte_m:
                v = M[nome].dropna()
                if v.empty:
                    st.caption(f"{nome}: nessun dato"); continue
                f = fig_base(210, nome, asse)
                m_, sd_ = v.mean(), v.std(ddof=1)
                # Banda +-1sd come riferimento visivo: si vede al volo quale
                # tiro esce dal branco, senza doverlo cercare nella tabella.
                f.add_hrect(y0=m_ - sd_, y1=m_ + sd_, fillcolor=C["acc"],
                            opacity=0.08, line_width=0)
                f.add_hline(y=m_, line=dict(color=C["txt3"], width=1, dash="dot"))
                for nome_s, g in M.groupby("sessione"):
                    x = g["shot"] if asse.startswith("tiro") else g["progressivo"]
                    f.add_trace(go.Scatter(x=x, y=g[nome], mode="lines+markers",
                                           name=nome_s, marker=dict(size=7)))
                f.update_layout(hovermode="closest")
                st.plotly_chart(f, width='stretch')

            st.markdown(f"""<div class="nota">
La banda è <b>media ± 1σ</b> calcolata su tutte le sedute selezionate: serve a
vedere al volo quale tiro esce dal branco, senza cercarlo nella tabella.
<br><br>Con l'asse «tiro nella seduta» le curve si sovrappongono e si confronta
l'<b>andamento interno</b> — per esempio se la fermezza cala verso la fine di
ogni seduta, che è stanchezza e non caso. Con «progressivo» si legge la storia
in ordine cronologico.
</div>""", unsafe_allow_html=True)


# ============================================================================
#  2 · SOVRAPPOSIZIONE — priorità 1
# ============================================================================
with TAB[3]:
    st.markdown(f"### {sess_corrente.nome}")
    # burst gia' nel frame giusto: raddrizzati se la seduta e' anteriore alla F11
    bursts = IO.bursts_usabili(sess_corrente)
    if not bursts:
        st.info("Questa seduta non ha forme d'onda sulla card.")
    else:
        c1, c2, c3 = st.columns([1, 1, 2])
        campo = c1.selectbox("Asse", ["az", "ay", "ax", "gy", "gx", "gz"], index=0,
                             help="az = asse freccia · ay = laterale · ax = verticale")
        da, a = c2.select_slider("Finestra [ms]",
                                 options=[-600, -400, -300, -200, -100, 0, 100, 200,
                                          300, 400, 600, 800, 1000],
                                 value=(-300, 600))
        mostra_singoli = c3.checkbox("Mostra i singoli tiri", value=True)

        griglia, ov = D.sovrapponi(bursts, campo, da_ms=da, a_ms=a)
        if ov is None:
            st.info("Nessun dato nella finestra scelta.")
        else:
            scarti = D.scarto_dalla_mediana(ov["matrice"], ov["mediana"])
            peggiore = int(np.argmax(scarti))

            f = fig_base(210, f"{campo} [{'m/s²' if campo[0]=='a' else '°/s'}]",
                         "ms dallo scocco")
            f.add_trace(go.Scatter(x=griglia, y=ov["q3"], mode="lines",
                                   line=dict(width=0), showlegend=False, hoverinfo="skip"))
            f.add_trace(go.Scatter(x=griglia, y=ov["q1"], mode="lines",
                                   line=dict(width=0), fill="tonexty",
                                   fillcolor="rgba(0,200,255,0.18)",
                                   name="metà centrale dei tiri (Q1–Q3)"))
            if mostra_singoli:
                for i, b in enumerate(bursts):
                    ev = i == peggiore
                    f.add_trace(go.Scatter(
                        x=griglia, y=ov["matrice"][i],
                        mode="lines", name=f"tiro {b.shot}" + (" · più lontano" if ev else ""),
                        line=dict(color=C["pur"] if ev else C["txt3"],
                                  width=2.2 if ev else 0.9),
                        opacity=1.0 if ev else 0.55))
            f.add_trace(go.Scatter(x=griglia, y=ov["mediana"], mode="lines",
                                   line=dict(color=C["acc"], width=2.6), name="mediana"))
            f.add_vline(x=0, line=dict(color=C["amb"], width=1.5, dash="dash"))
            f.add_vrect(x0=0, x1=15, fillcolor=C["amb"], opacity=0.10, line_width=0)
            st.plotly_chart(f, width='stretch')

            st.markdown(f"""<div class="nota">
La banda è <b>Q1–Q3</b>, non media ± deviazione standard: con nove tiri un solo
gesto anomalo sposta la media e gonfia la σ, e la banda finisce per non
descrivere nessun tiro. La mediana lo ignora, e i quartili dicono dove sta la
metà centrale — che è esattamente la domanda «come tiro di solito».
<br><br>La striscia ambra sono i primi <b>15 ms</b>: finché la freccia è sulla
corda, il gesto la influenza ancora. Dopo, il movimento racconta le tue
tendenze ma non cambia più <i>questa</i> freccia.
</div>""", unsafe_allow_html=True)

            st.markdown("#### Quanto ogni tiro si allontana dalla mediana")
            d = pd.DataFrame({"tiro": [b.shot for b in bursts],
                              "scarto medio": scarti.round(3)}).sort_values(
                "scarto medio", ascending=False)
            f2 = fig_base(190, f"scarto |{campo}| medio", "tiro")
            f2.add_trace(go.Bar(x=[f"t{v}" for v in d["tiro"]], y=d["scarto medio"],
                                marker_color=[C["pur"] if i == 0 else C["acc"]
                                              for i in range(len(d))]))
            f2.update_layout(hovermode="closest")
            st.plotly_chart(f2, width='stretch')
            st.markdown(f"""<div class="nota">
La distanza di Mahalanobis (scheda Statistica) dice <b>che</b> un tiro è
diverso, guardando le metriche. Questo grafico dice <b>quanto</b> lo è nel
segnale, e la sovrapposizione qui sopra dice <b>dove nel tempo</b> lo diventa.
Sono tre domande diverse: conviene guardarle insieme.
</div>""", unsafe_allow_html=True)

# ============================================================================
#  3 · SPETTRO E SMORZAMENTO — priorità 2
# ============================================================================
with TAB[4]:
    bursts = IO.bursts_usabili(sess_corrente)
    if not bursts:
        st.info("Questa seduta non ha forme d'onda sulla card.")
    else:
        # Stessa navigazione della scheda "Tiro per tiro": frecce per il passo,
        # tendina per i salti. Con 60 tiri una tendina sola non basta.
        if "k_spettro" not in st.session_state:
            st.session_state.k_spettro = 0
        st.session_state.k_spettro = min(st.session_state.k_spettro, len(bursts) - 1)
        with st.container(key="nav_spettro"):
            cp, cm, cn = st.columns([1, 6, 1])
            if cp.button("‹", width='stretch', key="sp_prev",
                         disabled=st.session_state.k_spettro <= 0):
                st.session_state.k_spettro -= 1
            if cn.button("›", width='stretch', key="sp_next",
                         disabled=st.session_state.k_spettro >= len(bursts) - 1):
                st.session_state.k_spettro += 1
            etichette = [f"tiro {b.shot}" for b in bursts]
            ksp = cm.selectbox("Tiro", range(len(etichette)),
                               format_func=lambda i: etichette[i],
                               key="k_spettro", label_visibility="collapsed")
        with st.container(key="scroll_spettro"):
            b = bursts[ksp]
            c1, c2 = st.columns([1, 1])
            win = c2.select_slider("Finestra spettrale [ms]",
                                   options=list(D.FINESTRE_DISPONIBILI_MS),
                                   value=D.FINESTRA_SPETTRO_MS)

            sp = D.spettro(b.post("az", win), b.fs)
            fc = b.f_taglio_lpf

            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Picco", f"{sp.picco_hz:.1f} Hz")
            m2.metric("Ampiezza", f"{sp.picco_amp:.2f} m/s²")
            m3.metric("Risoluzione vera", f"{sp.ris_hz:.2f} Hz")
            m4.metric("fs misurata", f"{b.fs:.2f} Hz",
                      delta=f"{b.fs - b.fs_nominale:+.1f} vs nominale")

            if sp.picco_al_bordo:
                st.error(f"""**Il picco è appoggiato al limite inferiore.** Con una
    finestra di {sp.durata_ms:.0f} ms la risoluzione è {sp.ris_hz:.1f} Hz e sotto
    {sp.f_min:.1f} Hz non entrano due cicli completi: il valore mostrato è il bordo
    della banda, non un modo di oscillazione. Allunga la finestra.""")

            f = fig_base(400, "ampiezza az [m/s²]", "Hz")
            vis = sp.freq <= 60
            f.add_trace(go.Bar(x=sp.freq[vis], y=sp.ampiezza[vis],
                               marker_color=C["acc"], name="spettro", width=0.09))
            f.add_vrect(x0=0, x1=sp.f_min, fillcolor=C["txt3"], opacity=0.18,
                        line_width=0, annotation_text="meno di 2 cicli",
                        annotation_font_size=9)
            f.add_vrect(x0=fc, x1=60, fillcolor=C["red"], opacity=0.10, line_width=0,
                        annotation_text="oltre il filtro dell'IMU", annotation_font_size=9)
            f.add_vline(x=fc, line=dict(color=C["red"], width=1.4, dash="dash"))
            f.update_layout(hovermode="closest")
            st.plotly_chart(f, width='stretch')

            st.markdown(f"""<div class="nota">
    <b>La zona rossa non è misurabile.</b> Il QMI8658 è configurato con
    <code>LPF_MODE_2</code>, cioè un passa-basso al <b>5,39 % dell'ODR</b>: ai
    {b.fs:.0f} Hz effettivi il taglio cade a ~{fc:.0f} Hz. Ciò che sta sopra arriva
    attenuato dal sensore, non dall'arco. La banda 15–80 Hz che la 1.69 chiamava
    «vibrazione dei flettenti», con questa configurazione, <b>non esiste</b>.
    <br><br>Quello che resta — 5–15 Hz — è l'oscillazione del sistema arciere-arco
    dopo il rilascio. È dentro la banda passante, quindi si misura bene: è la base
    dello smorzamento qui sotto.
    </div>""", unsafe_allow_html=True)

            # ── Spettrogramma ──────────────────────────────────────────────────
            st.markdown("#### Come l'energia decade nel tempo")
            fr, tt, Sxx = D.spettrogramma(b.post("az", 1400), b.fs, finestra_ms=win)
            vis = fr <= 40
            fsp = fig_base(240, "Hz", "ms dallo scocco")
            fsp.add_trace(go.Heatmap(x=tt * 1000, y=fr[vis], z=Sxx[vis, :],
                                     colorscale="Viridis", showscale=False))
            fsp.add_hline(y=fc, line=dict(color=C["red"], width=1.2, dash="dash"))
            fsp.update_layout(hovermode="closest")
            st.plotly_chart(fsp, width='stretch')

            # ── Smorzamento ────────────────────────────────────────────────────
            st.markdown("#### Quanto ci metti a tornare fermo")
            sm = D.smorzamento(b)
            if not sm.valido:
                st.warning(f"Smorzamento non calcolabile: {sm.motivo}")
            else:
                k1, k2, k3, k4 = st.columns(4)
                k1.metric("Modo dominante", f"{sm.f0_hz:.1f} Hz")
                k2.metric("T90", f"{sm.t90_ms:.0f} ms",
                          help="tempo per scendere al 10 % dell'ampiezza iniziale")
                k3.metric("ζ smorzamento", f"{sm.zeta:.3f}")
                k4.metric("R² adattamento", f"{sm.r2:.2f}",
                          delta="affidabile" if sm.r2 >= 0.80 else "da non usare",
                          delta_color="normal" if sm.r2 >= 0.80 else "inverse")

                if sm.r2 < 0.80:
                    st.warning("""L'inviluppo **non è esponenziale**: il numero di ζ
    qui sopra non descrive questo tiro. Di solito succede quando l'oscillazione è
    debole e domina il rumore. Guarda il grafico prima di credere al numero.""")

                fd = fig_base(230, "inviluppo az [m/s²]", "ms dallo scocco")
                fd.add_trace(go.Scatter(x=sm.t_ms, y=sm.inviluppo, mode="lines",
                                        line=dict(color=C["acc"], width=1.6),
                                        name="inviluppo misurato"))
                fd.add_trace(go.Scatter(x=sm.t_ms, y=sm.adattamento, mode="lines",
                                        line=dict(color=C["amb"], width=2, dash="dash"),
                                        name=f"decadimento esponenziale (τ={sm.tau_ms:.0f} ms)"))
                st.plotly_chart(fd, width='stretch')

                st.markdown(f"""<div class="nota">
    <b>Perché questa metrica, e perché ha senso proprio su questo hardware.</b>
    Il filtro interno dell'IMU chiude la banda dei flettenti, quindi la vibrazione
    dell'attrezzo non è misurabile. Ma il modo dominante — 8–11 Hz sui dati veri —
    sta comodamente dentro la banda passante, e il suo <b>decadimento</b> si misura
    bene. Non dice quanto vibra l'arco: dice quanto in fretta l'insieme
    arciere+arco torna fermo. Un follow-through che si assesta in 150 ms e uno che
    oscilla per mezzo secondo sono due gesti diversi.
    <br><br>È una metrica <b>nuova e non ancora validata</b>: prima di metterla in
    dashboard va passata al vaglio della scheda Statistica (si ripete? distingue i
    tiri buoni?). Finché non lo fa, è un'osservazione, non un indicatore.
    </div>""", unsafe_allow_html=True)

                st.markdown("##### Confronto su tutta la seduta")
                righe = []
                for bb in bursts:
                    s2 = D.smorzamento(bb)
                    righe.append({"tiro": bb.shot,
                                  "f0 [Hz]": round(s2.f0_hz, 1) if s2.valido else None,
                                  "T90 [ms]": round(s2.t90_ms) if s2.valido else None,
                                  "ζ": round(s2.zeta, 3) if s2.valido else None,
                                  "R²": round(s2.r2, 2),
                                  "attendibile": "sì" if (s2.valido and s2.r2 >= 0.80) else "no"})
                st.dataframe(pd.DataFrame(righe), width='stretch', hide_index=True)

# ============================================================================
#  4 · VERIFICA — priorità 3
# ============================================================================
with TAB[5]:
    st.markdown(f"### {sess_corrente.nome}")
    st.markdown(f"""<div class="nota">
Il dispositivo calcola cant, alzo, hold e release <b>a bordo</b> e ne scrive il
risultato nel CSV. Il burst grezzo resta accanto, quindi il CSV è
<b>falsificabile</b>: si rifanno i conti dai campioni e si controlla che
tornino. Qui sotto, per ogni tiro, il valore del dispositivo, quello
ricalcolato e lo scarto.
<br><br>Tolleranze: <b>{MET.TOLL_GRADI}°</b> sugli angoli e <b>{MET.TOLL_JERK}
m/s³</b> sul jerk. Non sono arbitrarie: il CSV porta gli angoli in centesimi di
grado interi e il jerk come intero, quindi la sola quantizzazione vale già
0,005° e 0,5 m/s³. Sopra queste soglie non c'è arrotondamento che tenga: è un
algoritmo diverso, e va guardato.
</div>""", unsafe_allow_html=True)

    cmp = MET.confronta(sess_corrente)
    if cmp.empty:
        st.info("Nessun tiro con forma d'onda da verificare.")
    else:
        st.markdown(f"""<div class="nota">
<b>Cosa vuol dire «divergente».</b> Per ogni tiro si confrontano tre numeri: il
valore che il <b>dispositivo</b> ha scritto nel CSV, quello <b>ricalcolato</b>
qui dai campioni grezzi, e la loro <b>differenza</b>. Un tiro è marcato
<i>divergente</i> quando almeno una differenza supera la tolleranza —
{MET.TOLL_GRADI}° sugli angoli, {MET.TOLL_JERK} m/s³ sul jerk.
<br><br>Le tolleranze sono la sola <b>quantizzazione</b>: il CSV porta gli
angoli in centesimi di grado interi e il jerk come intero, quindi 0,005° e
0,5 m/s³ di scarto sono inevitabili. Sopra quelle soglie non c'è arrotondamento
che tenga: il dispositivo e questo strumento stanno calcolando <b>due cose
diverse</b>, e va guardato quale.
<br><br>«Coincide» quindi non significa «più o meno uguale»: significa che la
replica riproduce il firmware entro la precisione con cui il firmware scrive.
</div>""", unsafe_allow_html=True)

        esito = MET.riepilogo_confronto(cmp)
        if "divergenti" in esito:
            st.error(f"**{esito}** — guarda le colonne di scarto qui sotto.")
        else:
            st.success(f"**{esito}.** Il CSV è coerente con i campioni grezzi.")

        colonne = [c for c in ["shot", "cant_csv", "cant_ric", "cant_d",
                               "alzo_csv", "alzo_ric", "alzo_d",
                               "hold_csv", "hold_ric", "hold_d",
                               "jerk_csv", "jerk_ric", "jerk_d", "esito"]
                   if c in cmp.columns]
        st.dataframe(cmp[colonne].round(4), width='stretch', hide_index=True)

        with st.expander("Ritarare le soglie senza ri-tirare"):
            st.markdown(f"""<div class="nota">
Le costanti degli algoritmi di bordo stanno tutte in <code>archbb_metrics.py</code>,
in cima al file: <code>GUARD_S</code>, <code>WIN_S</code>, <code>TAU_DPS</code>,
<code>HOLD_SOGLIE</code>, <code>RELEASE_SOGLIE</code>. Cambiale lì, ricarica, e
vedi l'effetto sui tiri veri di tutte le sedute della card — senza rimettere
mano all'arco. Quando una taratura convince, la si porta in
<code>shot_angles.h</code>.
<br><br><b>Devono restare allineate al firmware.</b> Se divergono, questo
confronto smette di essere una verifica e diventa il paragone fra due cose
diverse — che è il modo più elegante di non accorgersi di niente.
</div>""", unsafe_allow_html=True)
            st.code(f"""GUARD_S        = {MET.GUARD_S}     # gap dal trigger [s]
WIN_S          = {MET.WIN_S}     # ampiezza finestra calma [s]
TAU_DPS        = {MET.TAU_DPS}
HOLD_SOGLIE    = {MET.HOLD_SOGLIE}     # gradi
RELEASE_SOGLIE = {MET.RELEASE_SOGLIE}   # m/s³""", language="python")

# ============================================================================
#  5 · STATISTICA — priorità 4
# ============================================================================
with TAB[6]:
    tutti = filtra(IO.tiri_di_tutte(attive))
    if tutti.empty:
        st.info("Nessuna delle sedute selezionate ha un CSV con le metriche.")
    else:
        # Nomi FISICI: tiri_di_tutte() ha gia' applicato la mappa alla fonte,
        # quindi "alzo" contiene l'alzo e "cant" il cant, su ogni seduta.
        metriche = [c for c in ["alzo", "cant", "hold", "release_jerk"] if c in tutti.columns]
        n = len(tutti)
        st.markdown(f"**{n} tiri** su {tutti['sessione'].nunique()} sedute.")

        SOGLIA_N = 15
        if n < SOGLIA_N:
            st.warning(f"""Con {n} tiri le correlazioni non sono interpretabili:
sotto una ventina di osservazioni il coefficiente oscilla più del segnale che
dovrebbe misurare. I numeri qui sotto vengono mostrati **con il loro p e il
loro n**, ma vanno letti come indicazioni da verificare, non come risultati.
Seleziona più sedute nella barra a sinistra.""")

        st.markdown("#### Correlazioni fra metriche")
        st.markdown(f"""<div class="nota">
ρ di Spearman (per ranghi, quindi robusta agli outlier), con <b>n e p sempre
accanto al coefficiente</b>. Sulla 1.69 il costo di non mostrarli era già stato
pagato: alcune metriche correlavano con l'alzo, cioè misuravano l'inclinazione
del bersaglio invece del gesto. Un ρ senza il suo p è un'opinione con i decimali.
</div>""", unsafe_allow_html=True)

        righe = []
        for i, a in enumerate(metriche):
            for bmet in metriche[i + 1:]:
                d = tutti[[a, bmet]].dropna()
                if len(d) < 5:
                    continue
                rho, p = sps_stats.spearmanr(d[a], d[bmet])
                righe.append({"metrica A": a, "metrica B": bmet,
                              "ρ": round(float(rho), 3), "p": round(float(p), 4),
                              "n": len(d),
                              "leggibile": "sì" if (len(d) >= SOGLIA_N and p < 0.05) else "no"})
        if righe:
            st.dataframe(pd.DataFrame(righe), width='stretch', hide_index=True)

        # ── Affidabilità split-half ────────────────────────────────────────
        st.markdown("#### Affidabilità: la metrica misura l'arciere o il rumore?")
        st.markdown(f"""<div class="nota">
Split-half: i tiri di ogni seduta si dividono in pari e dispari, si calcola la
media di ciascuna metà e si correlano fra loro sulle sedute. Se una metrica
misura qualcosa di stabile, le due metà devono concordare. Se non concordano,
quella metrica sta misurando il singolo tiro — cioè rumore — e non ha senso
metterla in una dashboard che parla di tendenze.
<br><br>È il vaglio da cui deve passare ogni metrica nuova, compreso lo
smorzamento della scheda precedente, prima di diventare un indicatore.
</div>""", unsafe_allow_html=True)

        rr = []
        for mname in metriche:
            A, B = [], []
            for _, g in tutti.groupby("sessione"):
                v = g[mname].dropna().to_numpy()
                if len(v) < 6:
                    continue
                A.append(float(np.mean(v[0::2])))
                B.append(float(np.mean(v[1::2])))
            if len(A) >= 3:
                rho, p = sps_stats.pearsonr(A, B)
                # Spearman-Brown: corregge il fatto che ogni meta' ha meta' dei tiri
                sb = 2 * rho / (1 + rho) if rho > -1 else float("nan")
                rr.append({"metrica": mname, "sedute": len(A),
                           "r fra le metà": round(float(rho), 3),
                           "r corretto (Spearman-Brown)": round(float(sb), 3),
                           "p": round(float(p), 4)})
            else:
                rr.append({"metrica": mname, "sedute": len(A),
                           "r fra le metà": None,
                           "r corretto (Spearman-Brown)": None, "p": None})
        st.dataframe(pd.DataFrame(rr), width='stretch', hide_index=True)
        if all(x["sedute"] < 3 for x in rr):
            st.info("""Servono almeno **3 sedute con 6+ tiri ciascuna** perché
lo split-half dica qualcosa. Con una sola seduta non è calcolabile: non è un
limite dello strumento, è che l'affidabilità *fra* sedute richiede più sedute.""")

        # ── Distanza di Mahalanobis ────────────────────────────────────────
        st.markdown("#### Tiri che si comportano diversamente dagli altri")
        base = tutti[metriche].astype(float)
        mu, sd = base.mean(), base.std(ddof=1)
        z = (base - mu) / sd.replace(0, np.nan)
        usati = z.notna().sum(axis=1)
        dist = np.sqrt((z ** 2).sum(axis=1) * len(metriche) / usati.replace(0, np.nan))
        out = tutti[["sessione", "shot"]].copy()
        out["D"] = dist.round(2)
        for mname in metriche:
            out[mname] = tutti[mname].round(2)
        st.dataframe(out.sort_values("D", ascending=False).head(20),
                     width='stretch', hide_index=True)
        st.markdown(f"""<div class="nota">
Versione <b>diagonale</b>, non a covarianza piena: con poche decine di tiri e
quattro variabili la matrice piena sarebbe singolare o quasi, e stimare dieci
covarianze da nove punti produce numeri che sembrano precisi e non lo sono.
Sopra <code>2,5</code> vale la pena guardare la forma d'onda.
</div>""", unsafe_allow_html=True)

st.markdown("---")
st.caption("ArchBB · Archery Black Box · Cesare Pagura — "
           "convenzioni di calcolo in archbb_dsp.py, algoritmi di bordo in archbb_metrics.py")
